/*
 * A dummy extension for scratch
 * Create a folder names scratch3_ExtensionName
 */

const ArgumentType = require('../../extension-support/argument-type');
const BlockType = require('../../extension-support/block-type');
const Cast = require('../../util/cast');
const log = require('../../util/log');
// require more fields here

class ExtensionClassName {
    constructor (runtime) {
        // Constructor here
        this.runtime = runtime;

        // Add other variables here
    }

    getInfo () {
        return {
            id: "ExtensionID",                      // optional
            name: "ExtensionName",                  // optional
            blocks: [
                // Extensions Blocks
                {
                    opcode: 'opcodeName',           // Optional
                    blockType: BlockType.COMMAND,   // Block type, optional
                    text: 'log [TEXT]',             
                    arguments: {
                        TEXT: {
                            type: ArgumentType.STRING,
                            defaultValue: "hello"   // This block will appear as: <log "hello">
                        }
                    }

                    // this block will be implemented at opcodeName(args)
                }

                // Add more blocks heres
            ],
            menus: {
            }
        };
    }

    // Implementation for opcodeName
    opcodeName (args) {
    }
}

module.exports = Scratch3NewBlocks;