#include <gtest/gtest.h>
#include "ephlib_job.h"
#include <gmock/gmock.h>
#include "com_middle_mock.h"
using ::testing::Return;

/*************** readImage() ***************/
TEST(GetRecognizeResultTest, TC11001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* folderPath = "./sample.jpg";
    const char* responseTopic = "Result_Send_Topic::Data";
    RecognitionCallback callback;
    EPHLIB_GetImageRecognizeResultJob getRecognizeResultJobObj(domainId, requestTopic, responseTopic, folderPath, NULL);

    //mock
    //CREATE_COM_MOCK_OBJ(comMockObj);
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    //getRecognizeResultJobObj.folderPath = folderPath;
    bool retVal = getRecognizeResultJobObj.readImage(buffer);


    // Expected output
    EXPECT_EQ(true, retVal);
}

/*************** receiveResult() ***************/
TEST(GetRecognizeResultTest, TC12001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* folderPath = "./sample.jpg";
    const char* responseTopic = "Result_Send_Topic::Data";
    
    EPHLIB_GetImageRecognizeResultJob getRecognizeResultJobObj(domainId, requestTopic, responseTopic, folderPath, NULL);

    DDS_SampleInfoSeq sequenceInfo;
    sequenceInfo._buffer[0].valid_data = true;
    
    DDS_sequence_Result_Send_Topic_Data sequenceData;
    sequenceData._length = 1;
    sequenceData._buffer[0].Pricereduction_srtRecognition = "Test";
    
    
    getRecognizeResultJobObj.sequenceResultData = &sequenceData;
    getRecognizeResultJobObj.resultDataSequenceInfo = &sequenceInfo;

    //mock
    EXPECT_CALL(comMockObj, ReadSubscriberData(1, 1, getRecognizeResultJobObj.sequenceResultData, getRecognizeResultJobObj.resultDataSequenceInfo, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function

    
    std::string retVal = getRecognizeResultJobObj.receiveResult();


    // Expected output
    EXPECT_STREQ("Test", retVal.c_str());
}

/*************** publishRecognizeImage() ***************/
TEST(GetRecognizeResultTest, TC13001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* folderPath = "./";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_GetImageRecognizeResultJob getRecognizeResultJobObj(domainId, requestTopic, responseTopic, folderPath, NULL);

    //mock
    EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    char buffer[1];
    memset(buffer, '0', sizeof(buffer));
    int length = 1;
    //bool retVal = getRecognizeResultJobObj.publishRecognizeImage((const char*)&buffer[0], length);
    
    getRecognizeResultJobObj.publishRecognizeImage(buffer, length);
    //No display error message
}

TEST(GetRecognizeResultTest, TC13002) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* folderPath = "./";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_GetImageRecognizeResultJob getRecognizeResultJobObj(domainId, requestTopic, responseTopic, folderPath, NULL);

    //mock
    EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    char buffer[1];
    memset(buffer, '0', sizeof(buffer));
    int length = 0xFFFFFFFF;
    getRecognizeResultJobObj.publishRecognizeImage(buffer, length);
    
    //No display error message
}

/*************** allocPublishData() ***************/
TEST(GetRecognizeResultTest, TC14001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* folderPath = "./";
    const char* responseTopic = "Result_Send_Topic::Data";

    bool retVal = true;
    EPHLIB_GetImageRecognizeResultJob getRecognizeResultJobObj(domainId, requestTopic, responseTopic, folderPath, NULL);

    //mock
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 1;
    Image_Send_Topic_Data* pubData = getRecognizeResultJobObj.allocPublishData(length);
    if (!pubData) {
        retVal = false;
    }

    // Expected output
    EXPECT_EQ(true, retVal);
}

TEST(GetRecognizeResultTest, TC14002) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* folderPath = "./";
    const char* responseTopic = "Result_Send_Topic::Data";

    bool retVal = true;
    EPHLIB_GetImageRecognizeResultJob getRecognizeResultJobObj(domainId, requestTopic, responseTopic, folderPath, NULL);

    //mock
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 0xFFFFFFFF;
    Image_Send_Topic_Data* pubData = getRecognizeResultJobObj.allocPublishData(length);
    if (!pubData) {
        retVal = false;
    }

    // Expected output
    EXPECT_EQ(true, retVal);
}
