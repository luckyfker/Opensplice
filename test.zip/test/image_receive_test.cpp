#include <gtest/gtest.h>
#include "ephlib_job.h"
#include <gmock/gmock.h>
#include "com_middle_mock.h"

/*************** buildFilePathName() ***************/
TEST(saveImageTest, TC01001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    const char* folderPath = "./";
    EPHLIB_SaveImageJob saveImageJobObj(domainId, topicName, folderPath);
    
    char buffer[128];
    
    const char* path             = "./";
    const char* request_DeviceId = "D01";
    const char* request_CameraId = "C01";
    const char* request_Date     = "20210101";
    unsigned int request_SeqNo   = 0;
    const char* Pricereduction_DeviceId = "P001";

    memset(buffer, '0', sizeof(buffer));

    saveImageJobObj.buildFilePathName(buffer,
            path, request_DeviceId, request_CameraId,
            request_Date, request_SeqNo, Pricereduction_DeviceId
            );
  // Expected output
  char expected_buffer[128];
  sprintf(expected_buffer, "%s/%s_%s_%d_%s.jpeg",
      path, request_DeviceId, request_CameraId,
      request_SeqNo, Pricereduction_DeviceId);

  EXPECT_STREQ(buffer, expected_buffer);
}

TEST(saveImageTest, TC01002) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    const char* folderPath = "./";
    EPHLIB_SaveImageJob saveImageJobObj(domainId, topicName, folderPath);
    
    char buffer[128];

    const char* path             = "./";
    const char* request_DeviceId = "D02";
    const char* request_CameraId = "C02";
    const char* request_Date     = "99991231";
    unsigned int request_SeqNo   = 0xFFFFFFFF;
    const char* Pricereduction_DeviceId = "P002";

    memset(buffer, '0', sizeof(buffer));

    saveImageJobObj.buildFilePathName(buffer,
            path, request_DeviceId, request_CameraId,
            request_Date, request_SeqNo, Pricereduction_DeviceId
            );
  // Expected output
  char expected_buffer[128];
  sprintf(expected_buffer, "%s/%s_%s_%d_%s.jpeg",
      path, request_DeviceId, request_CameraId,
      request_SeqNo, Pricereduction_DeviceId);

  EXPECT_STREQ(buffer, expected_buffer);
}

/*************** buildFilePathName() ***************/

TEST(saveImageTest, TC02001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    const char* folderPath = "./";
    EPHLIB_SaveImageJob saveImageJobObj(domainId, topicName, folderPath);
    
    Image_Take_Topic_Data *data = Image_Take_Topic_Data__alloc();;
    
    std::string deviceId = "D01";
    std::string cameraId = "C01";
    std::string requestDate = "20210202";
    std::string PricereductionCut_cutImage = "abcd";
    std::string Pricereduction_DeviceId = "P01";

    //Alloc memory

    data->request_DeviceId = DDS_string_alloc(deviceId.length());
    data->request_CameraId = DDS_string_alloc(cameraId.length());
    data->request_Date._buffer = DDS_sequence_char_allocbuf(requestDate.length());
    data->request_Date._length = requestDate.length();
    data->request_Date._maximum = requestDate.length();

    data->PricereductionCut_cutImage._buffer = DDS_sequence_char_allocbuf(PricereductionCut_cutImage.length());
    data->PricereductionCut_cutImage._length = PricereductionCut_cutImage.length();
    data->PricereductionCut_cutImage._maximum = PricereductionCut_cutImage.length();
    data->Pricereduction_DeviceId = DDS_string_alloc(Pricereduction_DeviceId.length());
    
    saveImageJobObj.saveImage(data);
}