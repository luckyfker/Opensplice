#include <gtest/gtest.h>
#include "ephlib_job.h"
#include <gmock/gmock.h>
#include "com_middle_mock.h"

using ::testing::Return;

/*************** captureImage() ***************/
TEST(ImageCaptureTest, TC03001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_CaptureImageJob captureImageJobObj(domainId, topicName, intervalSec);
    
    std::vector<uchar> buffer;
    
    bool retVal = captureImageJobObj.captureImage(buffer);


    // Expected output
    EXPECT_EQ(false, retVal);
}

/*************** convertToJPEG() ***************/
TEST(ImageCaptureTest, TC04001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_CaptureImageJob captureImageJobObj(domainId, topicName, intervalSec);

    std::vector<uchar> buffer;
    cv::Mat frame = cv::Mat::zeros(100,100,CV_8UC1);
    
    bool retVal = captureImageJobObj.convertToJPEG(frame, buffer);


    // Expected output
    EXPECT_EQ(true, retVal);
}

/*************** publishImage() ***************/
TEST(ImageCaptureTest, TC05001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_CaptureImageJob captureImageJobObj(domainId, topicName, intervalSec);

    //mock
    EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 1;
    captureImageJobObj.publishImage(buffer, 1);

    // Expected output
    //No display error message
}

TEST(ImageCaptureTest, TC05002) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_CaptureImageJob captureImageJobObj(domainId, topicName, intervalSec);

    //mock
    EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 0xFFFFFFFF;
    captureImageJobObj.publishImage((const char*)&buffer[0], length);

    // Expected output
    //No display error message
}

/*************** allocPublishData() ***************/
TEST(ImageCaptureTest, TC06001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_CaptureImageJob captureImageJobObj(domainId, topicName, intervalSec);

    //mock
    //CREATE_COM_MOCK_OBJ(comMockObj);
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 1;
    bool retVal = true;
    Image_Take_Topic_Data* pubData = captureImageJobObj.allocPublishData(length);
    if (!pubData) {
        retVal = false;
    }

    // Expected output
    EXPECT_EQ(true, retVal);
}

TEST(ImageCaptureTest, TC06002) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_CaptureImageJob captureImageJobObj(domainId, topicName, intervalSec);

    //mock
    //CREATE_COM_MOCK_OBJ(comMockObj);
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 0xFFFFFFFF;
    bool retVal = true;
    Image_Take_Topic_Data* pubData = captureImageJobObj.allocPublishData(length);
    if (!pubData) {
        retVal = false;
    }

    // Expected output
    EXPECT_EQ(true, retVal);
}
