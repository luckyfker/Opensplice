#ifndef WORKER_THREAD_TEST_H
#define WORKER_THREAD_TEST_H

// List all test suite here
#define workerThread_Tests() \
    EPHLIB_FRIEND_TEST_SUITE(WorkerThreadTest, TC15001); \
    EPHLIB_FRIEND_TEST_SUITE(WorkerThreadTest, TC16001); \
    EPHLIB_FRIEND_TEST_SUITE(WorkerThreadTest, TC17001); \
    EPHLIB_FRIEND_TEST_SUITE(WorkerThreadTest, TC18001); \

#endif
