#include <gtest/gtest.h>
#include "ephlib_job.h"
#include <gmock/gmock.h>
#include "com_middle_mock.h"
using ::testing::Return;

/*************** recognizeImage() ***************/
TEST(ImageRecognizeTest, TC07001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* responseTopic = "Result_Send_Topic::Data";
    std::string expectResult = "recognition";
    EPHLIB_RecognizeImageJob recognizeImageJobObj(domainId, requestTopic, responseTopic, NULL);
    
    //Call function
    cv::Mat image = cv::Mat::zeros(100,100,CV_8UC1);
    std::string retVal = recognizeImageJobObj.recognizeImage(image);


    // Expected output
    EXPECT_STREQ(expectResult.c_str(), retVal.c_str());
}

/*************** sendResult() ***************/

TEST(ImageRecognizeTest, TC08001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_RecognizeImageJob recognizeImageJobObj(domainId, requestTopic, responseTopic, NULL);
    
    //Call function
    Image_Send_Topic_Data *receivedBuffer = Image_Send_Topic_Data__alloc();

    std::string regStr = "recognition";
    std::string deviceId = "D01";
    std::string cameraId = "C01";
    std::string requestDate = "20210202";
    unsigned int seq_No = 7;

    //Alloc memory
    receivedBuffer->request_DeviceId = DDS_string_alloc(deviceId.length());
    receivedBuffer->request_CameraId = DDS_string_alloc(cameraId.length());
    receivedBuffer->request_Date._buffer = DDS_sequence_char_allocbuf(requestDate.length());
    receivedBuffer->request_Date._length = requestDate.length();
    receivedBuffer->request_Date._maximum = requestDate.length();

    // Fill in allocated memory with data
    memcpy(receivedBuffer->request_DeviceId, deviceId.c_str(), deviceId.length());
    memcpy(receivedBuffer->request_CameraId, cameraId.c_str(), cameraId.length());
    memcpy(receivedBuffer->request_Date._buffer, requestDate.c_str(), requestDate.length());
    receivedBuffer->request_SeqNo = seq_No;

    //mock
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).WillOnce(Return(CMSuccess));
    //Image_Send_Topic_Data receivedBuffer;
    CMStatus status = recognizeImageJobObj.sendResult(regStr, receivedBuffer);


    // Expected output
    EXPECT_EQ(status, CMSuccess);
}

/*************** convertToMat() ***************/
TEST(ImageRecognizeTest, TC09001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_RecognizeImageJob recognizeImageJobObj(domainId, requestTopic, responseTopic, NULL);
    bool retVal = true;
    //mock
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    Image_Send_Topic_Data *data = Image_Send_Topic_Data__alloc();

    std::string PricereductionCut_cutImage = "abcd";

    //Alloc memory
    //receivedBuffer.PricereductionCut_DeviceId = DDS_string_alloc(senderID.length());
    //data->request_DeviceId = DDS_string_alloc(deviceId.length());
    //data->request_CameraId = DDS_string_alloc(cameraId.length());
    data->PricereductionCut_cutImage._buffer = DDS_sequence_char_allocbuf(PricereductionCut_cutImage.length());
    data->PricereductionCut_cutImage._length = PricereductionCut_cutImage.length();
    data->PricereductionCut_cutImage._maximum = PricereductionCut_cutImage.length();

    // Fill in allocated memory with data
    //memcpy(data->request_DeviceId, deviceId.c_str(), deviceId.length());
    //memcpy(data->request_CameraId, cameraId.c_str(), cameraId.length());
    memcpy(data->PricereductionCut_cutImage._buffer, PricereductionCut_cutImage.c_str(), PricereductionCut_cutImage.length());
    
    //Image_Send_Topic_Data data;
    cv::Mat mat = recognizeImageJobObj.convertToMat(data);
    if (mat.empty()) {
        std::cerr << "MAT empty" << std::endl;
        retVal = false;
    }

    // Expected output
    EXPECT_EQ(true, retVal);
}

/*************** createResultData() ***************/
TEST(ImageRecognizeTest, TC10001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_RecognizeImageJob recognizeImageJobObj(domainId, requestTopic, responseTopic, NULL);

    //mock
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    

    //Call function
    Image_Send_Topic_Data *receivedBuffer = Image_Send_Topic_Data__alloc();

    std::string regStr = "recognition";
    std::string deviceId = "D01";
    std::string cameraId = "C01";
    std::string requestDate = "20210202";
    unsigned int seq_No = 7;

    //Alloc memory
    //receivedBuffer->PricereductionCut_DeviceId = DDS_string_alloc(senderID.length());
    receivedBuffer->request_DeviceId = DDS_string_alloc(deviceId.length());
    receivedBuffer->request_CameraId = DDS_string_alloc(cameraId.length());
    receivedBuffer->request_Date._buffer = DDS_sequence_char_allocbuf(requestDate.length());
    receivedBuffer->request_Date._length = requestDate.length();
    receivedBuffer->request_Date._maximum = requestDate.length();
    
    // Fill in allocated memory with data
    memcpy(receivedBuffer->request_DeviceId, deviceId.c_str(), deviceId.length());
    memcpy(receivedBuffer->request_CameraId, cameraId.c_str(), cameraId.length());
    memcpy(receivedBuffer->request_Date._buffer, requestDate.c_str(), requestDate.length());
    receivedBuffer->request_SeqNo = seq_No;

    Result_Send_Topic_Data *pubData = recognizeImageJobObj.createResultData(regStr, receivedBuffer);

    // Expected output
    EXPECT_STREQ(pubData->request_DeviceId, deviceId.c_str());
    EXPECT_STREQ(pubData->request_CameraId, cameraId.c_str());
    EXPECT_STREQ(pubData->request_Date._buffer, requestDate.c_str());
    EXPECT_EQ(pubData->request_SeqNo, seq_No);
    EXPECT_STREQ(pubData->Pricereduction_srtRecognition, regStr.c_str());
    EXPECT_STREQ(pubData->Pricereduction_DeviceId, "xxx");
}
