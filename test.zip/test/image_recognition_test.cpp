#include <gtest/gtest.h>
#include "ephlib_job.h"
#include <gmock/gmock.h>
#include "com_middle_mock.h"
using ::testing::Return;

/*************** recognizeImage() ***************/
TEST(ImageRecognizeTest, TC07001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* responseTopic = "Result_Send_Topic::Data";
    std::string expectResult = "recognition";
    EPHLIB_RecognizeImageJob recognizeImageJobObj(domainId, requestTopic, responseTopic, NULL);
    
    //Call function
    cv::Mat image = cv::Mat::zeros(100,100,CV_8UC1);
    std::string retVal = recognizeImageJobObj.recognizeImage(image);


    // Expected output
    EXPECT_STREQ(expectResult.c_str(), retVal.c_str());
}

/*************** sendResult() ***************/
TEST(ImageRecognizeTest, TC08001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_RecognizeImageJob recognizeImageJobObj(domainId, requestTopic, responseTopic, NULL);

    
    
    //Call function
    std::string regStr = "recognition";
    /*
    Image_Send_Topic_Data receivedBuffer = {
        .request_DeviceId = "D01",
        .request_CameraId = "C01",
        //.request_Date._buffer = "20210202",
        .request_SeqNo = 2,
        //.Pricereduction_DeviceId = "P002",
        //.PricereductionCut_cutImage._buffer = "abcd",
        .requestType = 1
    };
    */
    //mock
    EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).WillOnce(Return(CMSuccess));
    Image_Send_Topic_Data receivedBuffer;
    CMStatus status = recognizeImageJobObj.sendResult(regStr, &receivedBuffer);


    // Expected output
    EXPECT_EQ(status, CMSuccess);
}

/*************** convertToMat() ***************/
TEST(ImageRecognizeTest, TC09001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_RecognizeImageJob recognizeImageJobObj(domainId, requestTopic, responseTopic, NULL);
    bool retVal = true;
    //mock
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    /*
    Image_Send_Topic_Data data = {
        .request_DeviceId = "D01",
        .request_CameraId = "C01",
        //.request_Date._buffer = "20210202",
        .request_SeqNo = 2,
        //.Pricereduction_DeviceId = "P002",
        //.PricereductionCut_cutImage._buffer = "abcd",
        .PricereductionCut_cutImage.length = 4,
        .requestType = 1
    };
    */
    Image_Send_Topic_Data data;
    cv::Mat mat = recognizeImageJobObj.convertToMat(&data);
    if (mat.empty()) {
        retVal = false;
    }

    // Expected output
    EXPECT_EQ(true, retVal);
}

/*************** createResultData() ***************/
TEST(ImageRecognizeTest, TC10001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_RecognizeImageJob recognizeImageJobObj(domainId, requestTopic, responseTopic, NULL);

    //mock
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::string regStr = "Test";
    Image_Send_Topic_Data receivedBuffer = {
        .request_DeviceId = "D01",
        .request_CameraId = "C01",
        //.request_Date._buffer = "20210101",
        .request_SeqNo = 1,
    };
    Result_Send_Topic_Data* pubData = recognizeImageJobObj.createResultData(regStr, &receivedBuffer);


    // Expected output
    EXPECT_STREQ(pubData->request_DeviceId, receivedBuffer.request_DeviceId);
    EXPECT_STREQ(pubData->request_CameraId, receivedBuffer.request_CameraId);
    //EXPECT_STREQ(pubData->request_Date._buffer, receivedBuffer.request_DeviceId._buffer);
    EXPECT_EQ(pubData->request_SeqNo, receivedBuffer.request_SeqNo);
    EXPECT_STREQ(pubData->Pricereduction_srtRecognition, regStr.c_str());
    EXPECT_STREQ(pubData->Pricereduction_DeviceId, "xxx");
}
