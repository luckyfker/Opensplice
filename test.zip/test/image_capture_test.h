#ifndef IMAGE_CAPTURE_TEST_H
#define IMAGE_CAPTURE_TEST_H

// List all test suite here
#define CaptureImageJob_Tests() \
    EPHLIB_FRIEND_TEST_SUITE(ImageCaptureTest, TC03001); \
    EPHLIB_FRIEND_TEST_SUITE(ImageCaptureTest, TC04001); \
    EPHLIB_FRIEND_TEST_SUITE(ImageCaptureTest, TC05001); \
    EPHLIB_FRIEND_TEST_SUITE(ImageCaptureTest, TC05002); \
    EPHLIB_FRIEND_TEST_SUITE(ImageCaptureTest, TC06001); \
    EPHLIB_FRIEND_TEST_SUITE(ImageCaptureTest, TC06002); \

#endif
