#ifndef IMAGE_RECONITION_RECEIVE_TEST_H
#define IMAGE_RECONITION_RECEIVE_TEST_H

// List all test suite here
#define getRecognizeResultJob_Tests() \
    EPHLIB_FRIEND_TEST_SUITE(GetRecognizeResultTest, TC11001); \
    EPHLIB_FRIEND_TEST_SUITE(GetRecognizeResultTest, TC12001); \
    EPHLIB_FRIEND_TEST_SUITE(GetRecognizeResultTest, TC13001); \
    EPHLIB_FRIEND_TEST_SUITE(GetRecognizeResultTest, TC13002); \
    EPHLIB_FRIEND_TEST_SUITE(GetRecognizeResultTest, TC14001); \
    EPHLIB_FRIEND_TEST_SUITE(GetRecognizeResultTest, TC14002); \

#endif
