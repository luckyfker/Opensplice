#include <gtest/gtest.h>
#include "worker_thread.h"
#include "ephlib_job.h"
#include <gmock/gmock.h>
#include "com_middle_mock.h"

using ::testing::Return;

/*************** submitJob() ***************/
TEST(WorkerThreadTest, TC15001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    WorkerThread workerThreadObj();

    auto job = std::make_shared<EPHLIB_SaveImageJob>(1, "saveImg", "./sample.jpg");
    workerThreadObj.submitJob(job);

    int size = workerThreadObj.m_queue.size();

    // Expected output
    EXPECT_EQ(1, size);
}

/*************** submitPeriodicJob() ***************/
TEST(WorkerThreadTest, TC16001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    WorkerThread workerThreadObj();

    auto job = std::make_shared<EPHLIB_SaveImageJob>(1, "saveImg", "./sample.jpg");
    workerThreadObj.submitPeriodicJob(job);

    int size = workerThreadObj.m_jobList.size();

    // Expected output
    EXPECT_EQ(1, size);
}

/*************** removePeriodicJob() ***************/
TEST(WorkerThreadTest, TC17001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    WorkerThread workerThreadObj();

    auto job = std::make_shared<EPHLIB_SaveImageJob>(1, "saveImg", "./sample.jpg");
    workerThreadObj.submitPeriodicJob(job);
    workerThreadObj.removePeriodicJob(job);

    int size = workerThreadObj.m_jobList.size();

    // Expected output
    EXPECT_EQ(0, size);
}

/*************** removePeriodicJob() ***************/
TEST(WorkerThreadTest, TC18001) {
    CREATE_COM_MOCK_OBJ(comMockObj);
    WorkerThread workerThreadObj();

    auto job = std::make_shared<EPHLIB_SaveImageJob>(1, "saveImg", "./sample.jpg");
    workerThreadObj.submitJob(job);
    workerThreadObj.removePeriodicJob(&job);

    int size = workerThreadObj.m_jobList.size();

    // Expected output
    EXPECT_EQ(0, size);
}