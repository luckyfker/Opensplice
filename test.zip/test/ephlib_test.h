#ifndef _EPHLIB_TEST_H
#define _EPHLIB_TEST_H

#include "com_middle_mock.h"

#define EPHLIB_FRIEND_TEST_SUITE(test_suite_name, test_name) \
  friend class test_suite_name##_##test_name##_Test

#define EPHLIB_FRIEND_TEST(x) \
    x##_Tests()

#include "image_receive_test.h"
#include "image_capture_test.h"
#include "image_recognition_receive_test.h"
#include "image_recognition_test.h"
#include "worker_thread_test.h"

#endif
