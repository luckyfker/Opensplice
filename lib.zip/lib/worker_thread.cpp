#include "worker_thread.h"

#include <iostream>
#include <chrono>

#define TIMER_INTERVAL  30

typedef enum {
    MSG_TIMER,
    MSG_POST_USER_DATA,
    MSG_EXIT_THREAD
} MsgType;

struct ThreadMsg {
    MsgType id;
    std::shared_ptr<void> body;

    ThreadMsg(MsgType id, std::shared_ptr<void> body) {
        this->id = id;
        this->body = body;
    }
};

WorkerThread::WorkerThread() :
    m_thread(nullptr), m_busy(false),
    m_lastProcessingTime(0), m_timerExit(false) {
}

void WorkerThread::start() {
    if (!m_thread) {
        m_thread = std::unique_ptr<std::thread>(new std::thread(&WorkerThread::process, this));
    }
}

void WorkerThread::join() {
    if (!m_thread) {
        return;
    }

    m_thread->join();
    m_thread = nullptr;
}

void WorkerThread::stop() {
    if (!m_thread) {
        return;
    }

    // Create a new ThreadMsg
    std::shared_ptr<ThreadMsg> threadMsg(new ThreadMsg(MSG_EXIT_THREAD, 0));

    // Put exit thread message into the queue
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_queue.push(threadMsg);
        m_cv.notify_one();
    }
}

void WorkerThread::stopAndWait() {
    // Stop
    stop();

    // Wait for stop
    join();
}

void WorkerThread::submitJob(std::shared_ptr<Job> job) {
    // Create a new ThreadMsg
    std::shared_ptr<ThreadMsg> threadMsg(new ThreadMsg(MSG_POST_USER_DATA, job));

    // Add user data msg to queue and notify worker thread
    std::unique_lock<std::mutex> lk(m_mutex);
    m_queue.push(threadMsg);
    m_cv.notify_one();
}

void WorkerThread::submitPeriodicJob(std::shared_ptr<Job> job) {
    std::unique_lock<std::mutex> lk(m_mutex);
    m_jobList.push_back(job);
}

void WorkerThread::removePeriodicJob(std::shared_ptr<Job> job) {
    std::unique_lock<std::mutex> lk(m_mutex);
    m_jobList.remove_if([&job](std::shared_ptr<Job> ljob) {
        return ljob.get() == job.get();
    });
}

void WorkerThread::removePeriodicJob(const Job * job) {
    std::unique_lock<std::mutex> lk(m_mutex);
    m_jobList.remove_if([&job](std::shared_ptr<Job> ljob) {
        return ljob.get() == job;
    });
}

std::shared_ptr<ThreadMsg> WorkerThread::getMessage() {
    while (true) {
        std::shared_ptr<ThreadMsg> msg;
        {
            // Wait for a message to be added to the queue
            std::unique_lock<std::mutex> lk(m_mutex);
            while (m_queue.empty())
                m_cv.wait(lk);

            if (m_queue.empty())
                continue;

            msg = m_queue.front();
            m_queue.pop();
        }

        // Found message
        return msg;
    }
}

void WorkerThread::timerThreadProc() {
    while (!m_timerExit) {
        // Sleep for 30mS then put a MSG_TIMER into the message queue
        std::this_thread::sleep_for(std::chrono::milliseconds(TIMER_INTERVAL));

        // Add timer msg to queue and notify worker thread
        std::unique_lock<std::mutex> lk(m_mutex);
        if (m_queue.empty()) {
            std::shared_ptr<ThreadMsg> threadMsg(new ThreadMsg(MSG_TIMER, 0));
            m_queue.push(threadMsg);
            m_cv.notify_one();
        }
    }
}

void WorkerThread::runJob(std::shared_ptr<Job> job) {
    m_busy = true;
    auto start = std::chrono::high_resolution_clock::now();
    job->run();
    auto stop = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(stop - start);
    m_lastProcessingTime = duration.count();
    m_busy = false;
}

bool WorkerThread::isBusy() {
    return m_busy;
}

long long WorkerThread::getLastProcessingTime() {
    return m_lastProcessingTime;
}

void WorkerThread::process() {
    m_timerExit = false;
    std::thread timerThread(&WorkerThread::timerThreadProc, this);

    while (1) {
        std::shared_ptr<ThreadMsg> msg = getMessage();

        switch (msg->id) {
        case MSG_POST_USER_DATA: {
            auto job = std::static_pointer_cast<Job>(msg->body);

            // Execute this job
            runJob(job);
            break;
        }

        case MSG_TIMER:
            for (auto job : m_jobList) {
                runJob(job);
            }
            break;

        case MSG_EXIT_THREAD:
        default: {
            // Exit this thread
            m_timerExit = true;
            timerThread.join();
            return;
        }
        }
    }
}
