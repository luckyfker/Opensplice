#define _CRT_SECURE_NO_WARNINGS
#include "ephlib_job.h"

#include <exception>

EPHLIB_SaveImageJob::EPHLIB_SaveImageJob(int domainId, const char* topicName, const char* folderPath) :
    domainId(domainId), topicName(topicName), folderPath(folderPath) {
    // Create data reader
    CMStatus status = SetDataReaderLibUseQoSFile(domainId,
        (char *)topicName, (char *)"Image_Take_Topic::Data",
        TYPELIB_PATH,
        QOS_POLICY_URI,
        &this->dataReader,
        NULL);

    if (status != CMSuccess) {
        std::cerr << "Create Data Reader failed" << std::endl;
    }

    // Initialize for reading data
    this->subData = DDS_sequence_Image_Take_Topic_Data__alloc();
    this->seqInfo = DDS_SampleInfoSeq__alloc();
}

void EPHLIB_SaveImageJob::run() {
    // Read subscriber data and save image
    readAndSaveImage();
}

EPHLIB_SaveImageJob::~EPHLIB_SaveImageJob() {
    DDS_free(this->subData);
    DDS_free(this->seqInfo);

    this->subData = NULL;
    this->seqInfo = NULL;

    // Shutdown Data Reader, don't handle when error when shutdown
    if (this->dataReader) {
        ShutdownDataReader(domainId, this->dataReader, NULL);
        this->dataReader = NULL;
    }
}

// Read from subscriber and save image
void EPHLIB_SaveImageJob::readAndSaveImage() {
    if (ReadSubscriberData(domainId, dataReader, subData, seqInfo, NULL) != CMSuccess) {
        // Error
        std::cerr << "Read Data failed" << std::endl;
        return;
    }

    // if there are received DDS topic data
    for (int i = 0; i < subData->_length; i++) {
        if (seqInfo->_buffer[i].valid_data) {
            saveImage(&subData->_buffer[i]);
        }
    }
    DDS_DataReader_return_loan((DDS_DataReader)dataReader, (DDS_sequence)subData, seqInfo);
}

// Standadize file path and file name
int EPHLIB_SaveImageJob::buildFilePathName(char* buffer,
    const char* path,
    const char* request_DeviceId,
    const char* request_CameraId,
    const char* request_Date,
    unsigned int request_SeqNo,
    const char* Pricereduction_DeviceId) {
    return sprintf(buffer, "%s/%s_%s_%d_%s.jpeg",
        path, request_DeviceId, request_CameraId,
        request_SeqNo, Pricereduction_DeviceId);
}

// Actual save image file
void EPHLIB_SaveImageJob::saveImage(Image_Take_Topic_Data* data) {
    if (folderPath.empty() || !data) {
        return;
    }

    char fileNameBuf[FILENAME_MAX] = { 0 };
    buildFilePathName(fileNameBuf,
        folderPath.c_str(),
        data->request_DeviceId,
        data->request_CameraId,
        data->request_Date._buffer,
        data->request_SeqNo,
        data->Pricereduction_DeviceId
    );
    FILE* fb = fopen(fileNameBuf, "wb");
    if (!fb) {
        std::cerr << "Save image failed" << std::endl;

        return;
    }
    if (fwrite(data->PricereductionCut_cutImage._buffer, sizeof(char), data->PricereductionCut_cutImage._length, fb) != data->PricereductionCut_cutImage._length) {
        std::cerr << "Save image failed" << std::endl;
    }
    else {
        std::cout << "Receive image and save successfully." << std::endl;
    }
    fclose(fb);
}