#ifndef _EPHLIB_JOB_H_
#define _EPHLIB_JOB_H_

#include "com_middle.h"
#include "evaluation_topic.h"
#include "ephlib.h"
#include "worker_thread.h"
#include "opencv2/opencv.hpp"

#ifdef EPHLIB_TEST
#include "ephlib_test.h"
#endif

#ifdef WIN32
#define TYPELIB_PATH    "./evaluation_topic.dll"
#define QOS_POLICY_URI  "file://../../app/dummy_app/c/QosXmlFiles/test_Qos_Reliable.xml"
#else
#define TYPELIB_PATH    "../evaluation_topic/libevaluation_topic.so"
#define QOS_POLICY_URI  "file://../../dummy_app/c/QosXmlFiles/test_Qos_Reliable.xml"
#endif

class EPHLIB_SaveImageJob : public Job {
public:
    EPHLIB_SaveImageJob(int domainId, const char* topicName, const char* folderPath);
    ~EPHLIB_SaveImageJob();

    virtual void run();

private:
    // Read from subscriber and save image
    void readAndSaveImage();

    // Standadize file path and file name
    int buildFilePathName(char* buffer,
        const char* path,
        const char* request_DeviceId,
        const char* request_CameraId,
        const char* request_Date,
        unsigned int request_SeqNo,
        const char* Pricereduction_DeviceId);

    // Actual save image file
    void saveImage(Image_Take_Topic_Data* data);

#ifdef EPHLIB_TEST
EPHLIB_FRIEND_TEST(SaveImageJob)
#endif

private:
    int domainId;
    std::string topicName;
    std::string folderPath;

    CMULONG dataReader;
    DDS_sequence_Image_Take_Topic_Data* subData;
    DDS_SampleInfoSeq* seqInfo;
};


class EPHLIB_CaptureImageJob : public Job {
public:
    EPHLIB_CaptureImageJob(int domainId, const char* topicName, unsigned int intervalSec);
    ~EPHLIB_CaptureImageJob();

    virtual void run();
    
#ifdef EPHLIB_TEST
EPHLIB_FRIEND_TEST(CaptureImageJob)
#endif    

private:
    // Read from subscriber and save image
    bool captureImage(std::vector<uchar>& buffer);

    // convert to JPEG image buffer
    bool convertToJPEG(cv::Mat& frame, std::vector<uchar>& buffer);

    // Actual save image file
    void publishImage(const char* data, int length);

    // Get current time
    long long getCurrentTime();

    // Allocate memory for publish data
    Image_Take_Topic_Data* allocPublishData(int length);

private:
    int domainId;
    std::string topicName;
    unsigned int intervalMilis;

    // Camera capture object
    std::unique_ptr<cv::VideoCapture> camera;
    long long lastCaptureTime;
    DDS_unsigned_long seqNumber;

    CMULONG dataWriter;
};

class EPHLIB_RecognizeImageJob : public Job {

public:
    virtual void run();

public:
    EPHLIB_RecognizeImageJob(int domainID, const char *requestTopic, const char *responseTopic, const ImageOption* options);
    ~EPHLIB_RecognizeImageJob();

#ifdef EPHLIB_TEST
EPHLIB_FRIEND_TEST(ImageRecognizeJob)
#endif

private:
    int domainID;
    ImageOption options;

    CMULONG imageDataReaderID;
    DDS_sequence_Image_Send_Topic_Data *seqImageSendData;

    DDS_SampleInfoSeq *imageDataSequenceInfo;

    CMULONG resultDataWriterId;

private:
    void saveOptions(const ImageOption* imgOptions);

    //convert received data to cv::Mat
    cv::Mat convertToMat(Image_Send_Topic_Data *data);

    // Recognize received image
    std::string recognizeImage(cv::Mat image);

    // Send result back
    CMStatus sendResult(std::string recognitionResult, Image_Send_Topic_Data *receivedBuffe);

    // Create recoginize data for sending back
    Result_Send_Topic_Data *createResultData(std::string, Image_Send_Topic_Data *receivedBuffer);
};

class EPHLIB_GetImageRecognizeResultJob : public Job {
public:
    EPHLIB_GetImageRecognizeResultJob(int domainID, const char* requestTopic, const char* responseTopic, const char* imageFilePath, RecognitionCallback callback);
    ~EPHLIB_GetImageRecognizeResultJob();
    virtual void run();

#ifdef EPHLIB_TEST
EPHLIB_FRIEND_TEST(getRecognizeResultJob)
#endif

private:
    int domainId;
    std::string requestTopicName;
    std::string responeTopicName;
    std::string folderPath;

    CMULONG imageDataWriterId;
    CMULONG resultDataReaderId;

    static bool allowRequest;

    DDS_sequence_Image_Send_Topic_Data* sequenceImageData;
    DDS_sequence_Result_Send_Topic_Data* sequenceResultData;
    DDS_SampleInfoSeq* resultDataSequenceInfo;

    RecognitionCallback callbackHandler;

private:
    //Request recognize Image from Pi
    bool readImage(std::vector<uchar>& buffer);

    //Receive result from EPH via DDS
    std::string receiveResult();

    void publishRecognizeImage(const char* data, int length);

    // Allocate memory for publish data
    Image_Send_Topic_Data* allocPublishData(int length);
};
#endif
