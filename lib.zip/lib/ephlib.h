#ifndef _EPHLIB__H_
#define _EPHLIB__H_

#include "com_middle.h"

#ifdef WIN32
#ifdef ephlib_EXPORTS
#define EPHLIB_API __declspec(dllexport)
#else
#define EPHLIB_API __declspec(dllimport)
#endif
#else
#define EPHLIB_API
#endif

typedef struct ImageOption_t {
    int width;
    int height;
    unsigned char flip;
    float quality;
} ImageOption;

typedef void(*RecognitionCallback)(const char*);

#ifdef __cplusplus
extern "C"
{
#endif
    EPHLIB_API CMULONG SaveCapturedImage(const char* topicName, const char* folderPath);
    EPHLIB_API CMULONG GetImageRecognizeResult(const char* requestTopicName, const char* responseTopicName, const char * filePath, RecognitionCallback callback);
    EPHLIB_API CMULONG RecognizeImage(const char* requestTopic, const char* answerTopic, const ImageOption* options);
    EPHLIB_API CMULONG CaptureImage(const char* topicName);

    EPHLIB_API void WaitAllJob();
    EPHLIB_API void StopJob(CMULONG jobId);
    EPHLIB_API void ShutdownAllJob();

#ifdef __cplusplus
}
#endif

#endif