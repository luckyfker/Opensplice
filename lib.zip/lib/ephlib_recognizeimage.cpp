#include "ephlib_job.h"

#include <exception>

// priceDeductionId
static const std::string senderDeviceId = "xxx";

EPHLIB_RecognizeImageJob::EPHLIB_RecognizeImageJob(int domainID, const char *requestTopic, const char *responseTopic, const ImageOption* imgOptions) {
    this->domainID = domainID;

    // Save image options
    saveOptions(imgOptions);

    // Create data reader for receiving image
    CMStatus status = SetDataReaderLibUseQoSFile(domainID,
        (char*)requestTopic,
        (char*) "Image_Send_Topic::Data",
        TYPELIB_PATH,
        QOS_POLICY_URI,
        &this->imageDataReaderID,
        NULL);
    if (status != CMSuccess) {
        std::cerr << "Create Data Reader failed" << std::endl;
    }

    // Creater writer for sending result
    status = SetDataWriterLibUseQoSFile(domainID,
        (char*)responseTopic,
        (char*) "Result_Send_Topic::Data",
        TYPELIB_PATH,
        QOS_POLICY_URI,
        &this->resultDataWriterId,
        NULL);
    if (status != CMSuccess) {
        std::cerr << "Create Data Writer failed" << std::endl;
    }

    this->seqImageSendData = DDS_sequence_Image_Send_Topic_Data__alloc();
    this->imageDataSequenceInfo = DDS_SampleInfoSeq__alloc();
}

EPHLIB_RecognizeImageJob::~EPHLIB_RecognizeImageJob() {
    // Shutdown Data Reader and Data Writer (if running)
    if (this->imageDataReaderID) {
        ShutdownDataReader(domainID, this->imageDataReaderID, NULL);
        this->imageDataReaderID = NULL;
    }

    if (this->resultDataWriterId) {
        ShutdownDataWriter(domainID, this->resultDataWriterId, NULL);
        this->resultDataWriterId = NULL;
    }

    // Free all resources
    DDS_free(this->seqImageSendData);
    DDS_free(this->imageDataSequenceInfo);

    this->seqImageSendData = NULL;
    this->imageDataSequenceInfo = NULL;
}

void EPHLIB_RecognizeImageJob::saveOptions(const ImageOption* imgOptions) {
    if (!imgOptions) {
        this->options.flip = 'f';
        this->options.height = 1028;
        this->options.width = 640;
        this->options.quality = 100;
    }
    else {
        this->options.flip = imgOptions->flip;
        this->options.height = imgOptions->height;
        this->options.width = imgOptions->width;
        this->options.quality = imgOptions->quality;
    }

}

void EPHLIB_RecognizeImageJob::run() {
    // Read from reader
    if (ReadSubscriberData(domainID, imageDataReaderID, seqImageSendData, imageDataSequenceInfo, NULL) == CMSuccess) {
        for (int i = 0; i < seqImageSendData->_length; i++) {
            if (imageDataSequenceInfo->_buffer[i].valid_data) {
                cv::Mat mat = convertToMat(&seqImageSendData->_buffer[i]);
                if (mat.empty()) {
                    std::cerr << "Read image failed." << std::endl;
                }
                else {
                    std::string regStr = recognizeImage(mat);
                    if (regStr.length() > 0) {
                        if (sendResult(regStr, &seqImageSendData->_buffer[i]) != CMSuccess) {
                            std::cerr << "Recognize image failed."  << std::endl;
                        }
                        else {
                            std::cout <<"Recognition successfully: "<< regStr.c_str() << std::endl;
                        }
                    }
                    else {
                        std::cerr << "Recognize image failed." <<std::endl;
                    }
                }
            }
        }

        DDS_DataReader_return_loan((DDS_DataReader)imageDataReaderID, (DDS_sequence)seqImageSendData, imageDataSequenceInfo);
    }
    else {
        std::cerr << "Read data failed" << std::endl;
    }

}

// Convert sequence data to cv::Mat
cv::Mat EPHLIB_RecognizeImageJob::convertToMat(Image_Send_Topic_Data *data) {
    char *buffer = data->PricereductionCut_cutImage._buffer;
    std::vector<uchar> imgBuffer;
    imgBuffer.insert(imgBuffer.end(), buffer, buffer + data->PricereductionCut_cutImage._length);
#if (CV_MAJOR_VERSION < 3)
	cv::Mat mat = cv::imdecode(imgBuffer, CV_LOAD_IMAGE_UNCHANGED);
#else
	cv::Mat mat = cv::imdecode(imgBuffer, cv::IMREAD_UNCHANGED);
#endif

    return mat;
}


// Recognize image
std::string EPHLIB_RecognizeImageJob::recognizeImage(cv::Mat image) {
    //TODO: recognize image
    return std::string("recognition");
}


// Create result
Result_Send_Topic_Data* EPHLIB_RecognizeImageJob::createResultData(std::string regStr, Image_Send_Topic_Data *receivedBuffer) {
    std::cout << "GO" << std::endl;
    Result_Send_Topic_Data *result = Result_Send_Topic_Data__alloc();
    if (!result) {
        return result;
        std::cout << "ERROR" << std::endl;
    }
    std::cout << "END1" << std::endl;
    // Alloc memory for result
    result->Pricereduction_DeviceId = DDS_string_alloc(senderDeviceId.length());
    result->request_CameraId = DDS_string_alloc(strlen(receivedBuffer->request_CameraId));
    result->request_Date._buffer = DDS_sequence_char_allocbuf(receivedBuffer->request_Date._length);
    result->request_Date._length = receivedBuffer->request_Date._length;
    result->request_Date._maximum = receivedBuffer->request_Date._maximum;
    result->Pricereduction_srtRecognition = DDS_string_alloc(regStr.length());
    std::cout << "END2" << std::endl;
    
    // Fill in allocated memory with data
    memcpy(result->request_DeviceId, receivedBuffer->request_DeviceId, strlen(receivedBuffer->request_DeviceId));
    memcpy(result->request_CameraId, receivedBuffer->request_CameraId, strlen(receivedBuffer->request_CameraId));
    memcpy(result->request_Date._buffer, receivedBuffer->request_Date._buffer, receivedBuffer->request_Date._length);
    result->request_SeqNo = receivedBuffer->request_SeqNo;
    memcpy(result->Pricereduction_srtRecognition, regStr.c_str(), strlen(regStr.c_str()));
    memcpy(result->Pricereduction_DeviceId, senderDeviceId.c_str(), senderDeviceId.length());
    
    
    return result;
}

// Send result back
CMStatus EPHLIB_RecognizeImageJob::sendResult(std::string recognitionResult, Image_Send_Topic_Data *receivedBuffer) {
    Result_Send_Topic_Data *pubData = createResultData(recognitionResult, receivedBuffer);
    if (!pubData) {
        return CMFail;
        std::cout << "ERROR1" << std::endl;
    }
    std::cout << "DONE1" << std::endl;
    CMStatus status = WritePublishData(domainID, resultDataWriterId, pubData, NULL);
    std::cout << "DONE2" << std::endl;
    DDS_free(pubData);
    std::cout << "DONE3" << std::endl;
    return status;
}
