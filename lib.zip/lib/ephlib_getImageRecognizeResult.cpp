#include "ephlib_job.h"
#include <fstream>

#include <exception>

// Dummy data
static const std::string deviceId = "DS010";
static const std::string cameraId = "001AX";
static const std::string requestDate = "20210827";
static const std::string priceReductionId = "001";
static unsigned int requestType = 1;

bool EPHLIB_GetImageRecognizeResultJob::allowRequest = true;

EPHLIB_GetImageRecognizeResultJob::EPHLIB_GetImageRecognizeResultJob(int domainID, const char* requestTopic, const char* responseTopic, const char* imageFilePath, RecognitionCallback callback) :
    domainId(domainId), requestTopicName(requestTopicName), responeTopicName(responseTopic), folderPath(imageFilePath), callbackHandler(callback) {
    // Create data reader
    CMStatus statusReader = SetDataReaderLibUseQoSFile(domainId,
        (char *)responseTopic, (char *)"Result_Send_Topic::Data",
        TYPELIB_PATH,
        QOS_POLICY_URI,
        &this->resultDataReaderId,
        NULL);

    if (statusReader != CMSuccess) {
        std::cerr << "Create Data Reader failed." << std::endl;
    }

    // Create data Writer
    CMStatus statusWriter = SetDataWriterLibUseQoSFile(domainId,
        (char *)requestTopic, (char *)"Image_Send_Topic::Data",
        TYPELIB_PATH,
        QOS_POLICY_URI,
        &this->imageDataWriterId,
        NULL);

    if (statusWriter != CMSuccess) {
        std::cerr << "Create Data Writer failed." << std::endl;
    }

    // Initialize for reading data
    this->sequenceResultData = DDS_sequence_Result_Send_Topic_Data__alloc();
    this->resultDataSequenceInfo = DDS_SampleInfoSeq__alloc();
}

EPHLIB_GetImageRecognizeResultJob::~EPHLIB_GetImageRecognizeResultJob() {
    DDS_free(this->sequenceResultData);
    DDS_free(this->resultDataSequenceInfo);

    this->sequenceResultData = NULL;
    this->resultDataSequenceInfo = NULL;

    // Shutdown Data Reader, don't handle when error when shutdown
    if (this->resultDataReaderId) {
        ShutdownDataReader(domainId, this->resultDataReaderId, NULL);
        this->resultDataReaderId = NULL;
    }

    // Shutdown Data Writer, don't handle when error when shutdown
    if (this->imageDataWriterId) {
        ShutdownDataWriter(domainId, this->imageDataWriterId, NULL);
        this->imageDataWriterId = NULL;
    }
}

void EPHLIB_GetImageRecognizeResultJob::run() {
    std::vector<uchar> buffer;

    //Request recognize image
    //Only request recognition if result has been received before
    if (allowRequest == true) {
        if (readImage(buffer)) {

            publishRecognizeImage((const char*)&buffer[0], buffer.size());
            allowRequest = false;
        }
    }

    //Receive result
    std::string result = receiveResult();
    if (!result.empty() && callbackHandler) {
        callbackHandler(result.c_str());
    }
}

bool EPHLIB_GetImageRecognizeResultJob::readImage(std::vector<uchar>& buffer) {
    std::ifstream img(folderPath, std::ios::in);
    if (img.fail()) {
        std::cerr << "Read image failed." << std::endl;
        return false;
    }

    //Seek to the end
    img.seekg(0, std::ios::end);

    //Get the file image
    unsigned int imgSize = (unsigned int)img.tellg();
    img.seekg(0, std::ios::beg);
    imgSize -= (unsigned int)img.tellg();

    //Read image
    buffer.resize(imgSize);
    img.read((char *)&(buffer[0]), imgSize);

    //Close image
    img.close();

    return true;
}

std::string EPHLIB_GetImageRecognizeResultJob::receiveResult() {
    std::string resultReg;
    std::string otherResult;
    if (ReadSubscriberData(domainId, resultDataReaderId, sequenceResultData, resultDataSequenceInfo, NULL) == CMSuccess) {
        if (sequenceResultData->_length > 0) {
            for (int i = 0; i < sequenceResultData->_length; i++) {
                if (resultDataSequenceInfo->_buffer[i].valid_data) {
                    //Result match with request
                    if (sequenceResultData->_buffer[i].request_DeviceId == deviceId) {
                        resultReg = sequenceResultData->_buffer[i].Pricereduction_srtRecognition;
                        std::cout << "Result of recognition: " << resultReg << std::endl;
                    }
                    else {
                        otherResult = sequenceResultData->_buffer[i].Pricereduction_srtRecognition;
                        //TODO: other results
                        std::cout << "Warning: Other result of recognition: " << otherResult << std::endl;
                    }
                }
                //Allow request if received all result
                if (i == (sequenceResultData->_length - 1)) {
                    allowRequest = true;
                }
            }
            DDS_DataReader_return_loan((DDS_DataReader)resultDataReaderId, (DDS_sequence)sequenceResultData, resultDataSequenceInfo);
        }
    }
    else {
        std::cerr << "Read data failed." << std::endl;
    }

    return resultReg;
}

void EPHLIB_GetImageRecognizeResultJob::publishRecognizeImage(const char* data, int length) {
    // Allocate memory
    Image_Send_Topic_Data* pubData = allocPublishData(length);

    // Fill value
    memcpy(pubData->request_DeviceId, deviceId.c_str(), deviceId.length());
    memcpy(pubData->request_CameraId, cameraId.c_str(), cameraId.length());
    memcpy(pubData->request_Date._buffer, requestDate.c_str(), requestDate.length());
    memcpy(pubData->PricereductionCut_cutImage._buffer, data, length);
    memcpy(pubData->PricereductionCut_DeviceId, priceReductionId.c_str(), priceReductionId.length());
    pubData->requestType = requestType;
    // Send data
    CMStatus status = WritePublishData(domainId, imageDataWriterId, pubData, NULL);
    DDS_free(pubData);
    if (status != CMSuccess) {
        std::cerr << "Write data failed." << std::endl;
    }
}

Image_Send_Topic_Data* EPHLIB_GetImageRecognizeResultJob::allocPublishData(int length) {
    Image_Send_Topic_Data *pubData = Image_Send_Topic_Data__alloc();

    // Allocate with the dummy data
    pubData->request_DeviceId = DDS_string_alloc(deviceId.length());
    pubData->request_CameraId = DDS_string_alloc(cameraId.length());
    pubData->request_Date._buffer = DDS_sequence_char_allocbuf(requestDate.length());
    pubData->request_Date._length = requestDate.length();
    pubData->request_Date._maximum = requestDate.length();
    pubData->PricereductionCut_cutImage._buffer = DDS_sequence_char_allocbuf(length);
    pubData->PricereductionCut_cutImage._length = length;
    pubData->PricereductionCut_cutImage._maximum = length;
    pubData->PricereductionCut_DeviceId = DDS_string_alloc(priceReductionId.length());

    return pubData;
}
