/**
* --------------------------------------------------------------------------
*       TEC CORPORATION, ALL Rights Reserved
* --------------------------------------------------------------------------
* MODULE NAME   :   WebsocketSupporter.cpp
* (FILE NNAME)
* PARAMETERS    :   NONE
* DESCRIPTION   :   次の機能を有する。
*                     そのソースの機能概要記述
*                     ********************
* CREATE ON     :   Ver1.00 22/02/20    ThaiNH(TSDV)
*
* REMARKS       :   NONE
*/

#include "WebsocketSupporter.h"

static inline void ltrim(std::string& s) {
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](unsigned char ch) {
        return !std::isspace(ch);
        }));
}


WebsocketSupporter::WebsocketSupporter() {
	domainID = 0;
    typeLibPath = "";
    QoSFileName = "";
    pollingIntervalMs = 1000000;
    Topic = NULL;
    message_seq_RecognitionResult_Total_Data = NULL;
    message_infoSeq_RecognitionResult_Total_Data = NULL;
}
WebsocketSupporter::~WebsocketSupporter() {
    
}

std::string WebsocketSupporter::convertToString(char* arr)
{
	std::string s(arr);
	return s;
}

void WebsocketSupporter::setDomainID(int domainID)
{
    this->domainID = domainID;
}

void WebsocketSupporter::setTypeLibPath(std::string typeLibPath)
{
    this->typeLibPath = typeLibPath;
}

void WebsocketSupporter::setQoSFileName(std::string QoSFileName)
{
    this->QoSFileName = QoSFileName;
}

void WebsocketSupporter::setPollingIntervalMs(int pollingIntervalMs)
{
    this->pollingIntervalMs = pollingIntervalMs;
}

APPStatus WebsocketSupporter::parsingConfig(const char *configFilePath)
{
    struct stat Filestat;
    APPStatus status = APP_Success;
    int index = 0;
	long result = 0;
    char TopicSectionName[MAX_BUFF_SIZE];

    if (!configFilePath) {
        return APP_InvalidParameters;
    }

    if (stat(configFilePath, &Filestat) < DEFAULT_ZERO) {
        return APP_InvalidParameters;
    }

    App_Params.totaltopics = GetPrivateProfileInt(TOPIC_INFO_SECTION, NO_OF_TOPICS, DEFAULT_INT, configFilePath);
    if(App_Params.totaltopics <= DEFAULT_ZERO)
    {
        std::clog << "Parameter name - [TotalTopicNum] has invalid value, provide correct value" << std::endl;
        return  APP_INI_InvalidTotalTopicNumber;
    }

    App_Params.domain_id = GetPrivateProfileInt(TOPIC_INFO_SECTION, DOMAIN_ID, DEFAULT_INT, configFilePath);
    if(App_Params.domain_id < DEFAULT_ZERO)
    {
        std::clog << "Parameter name - [DomainId] has invalid value, provide correct value" << std::endl;
        return  APP_INI_InvalidDomainId;
    }

    App_Params.debugmode = GetPrivateProfileInt(DEBUG, DEBUG_MODE, DEFAULT_INT, configFilePath);
    if(App_Params.debugmode < DEFAULT_ZERO || App_Params.debugmode > DEFAULT_DEBUG_MODE)
    {
        std::clog << "Parameter name - [DebugMode] has invalid value, provide correct value" << std::endl;
        return  APP_INI_InvalidDebugMode;
    }

    Topic = (AppTopic *)calloc((unsigned long)App_Params.totaltopics, sizeof(AppTopic));
    
    for(index = 0; index < App_Params.totaltopics; index++)
    {
        sprintf(TopicSectionName, "Topic%d", index + 1);
        //Topic name
        result = GetPrivateProfileString(TopicSectionName, TOPIC_NAME, DEFAULT_STRING, Topic[index].TopicName, MAX_BUFF_SIZE, configFilePath);
        if(strcmp(Topic[index].TopicName, DEFAULT_STRING) == DEFAULT_ZERO)
        {
            std::clog << "Parameter name - [TopicName] of this Section name is missing" << std::endl;
            return APP_INI_Section_ParameterNameMissing;
        }
        else if((strcmp(Topic[index].TopicName, "NULL") == DEFAULT_ZERO) || (result == DEFAULT_ZERO))
        {
            std::clog << "Parameter name - [TopicName] has invalid value, provide correct value" << std::endl;
            return APP_INI_InvalidTopicName;
        }

        //Topic type
        result = GetPrivateProfileString(TopicSectionName, TOPIC_TYPE, DEFAULT_STRING, Topic[index].TopicType, MAX_BUFF_SIZE, configFilePath);
        if(strcmp(Topic[index].TopicType, DEFAULT_STRING) == DEFAULT_ZERO)
        {
            std::clog << "Parameter name - [TopicType] of this Section name is missing" << std::endl;
            return APP_INI_Section_ParameterNameMissing;
        }
        else if((strcmp(Topic[index].TopicType, "NULL") == DEFAULT_ZERO) || (result == DEFAULT_ZERO))
        {
            std::clog << "Parameter name - [TopicType] has invalid value, provide correct value" << std::endl;
            return APP_INI_InvalidTopicType;
        }

        //Qos File name
        result = GetPrivateProfileString(TopicSectionName, QOS_FILE_NAME, DEFAULT_STRING, Topic[index].QoSFileName, MAX_BUFF_SIZE, configFilePath);
        if(strcmp(Topic[index].QoSFileName, DEFAULT_STRING) == DEFAULT_ZERO)
        {
            std::clog << "Parameter name - [QosFilePath] of this Section name is missing" << std::endl;
            return APP_INI_Section_ParameterNameMissing;
        }
#ifndef WIN32
		else if ((stat(Topic[index].QoSFileName, &Filestat) < DEFAULT_ZERO) && (strcmp(Topic[index].QoSFileName, "NULL") != DEFAULT_ZERO))
#else
		else if ((PathFileExists(Topic[index].QoSFileName) == FALSE) && (strcmp(Topic[index].QoSFileName, "NULL") != DEFAULT_ZERO))
#endif
		{
            std::clog << "Parameter name - [QosFilePath] has invalid value, provide correct value" << std::endl;
			return APP_INI_InvalidQosFilePath;
		}

        //TopicLib Path
        result = GetPrivateProfileString(TopicSectionName, TOPICLIB_FILE_PATH, DEFAULT_STRING, Topic[index].TopicLibFilePath, MAX_BUFF_SIZE, configFilePath);
		if (strcmp(Topic[index].TopicLibFilePath, DEFAULT_STRING) == DEFAULT_ZERO)
		{
            std::clog << "Parameter name - [TopicLibFilePath] of this Section name is missing" << std::endl;
			return APP_INI_Section_ParameterNameMissing;
		}
#ifndef WIN32
		else if ((stat(Topic[index].TopicLibFilePath, &Filestat) < DEFAULT_ZERO) && (strcmp(Topic[index].TopicLibFilePath, "NULL") != DEFAULT_ZERO))
#else
		else if ((PathFileExists(Topic[index].TopicLibFilePath) == FALSE) && (strcmp(Topic[index].TopicLibFilePath, "NULL") != DEFAULT_ZERO))
#endif
		{
            std::clog << "Parameter name - [TopicLibFilePath] has invalid value, provide correct value" << std::endl;
			return APP_INI_InvalidTopicLibFilePath;
		}

        //Polling interval Ms
        Topic[index].ReceivePollingInterval = GetPrivateProfileInt(TopicSectionName, POLLING_INTERVAL, DEFAULT_INT, configFilePath);
        if((Topic[index].ReceivePollingInterval <= DEFAULT_ZERO))
        {
            std::clog << "Parameter name - [ReceivePollingInterval] has invalid value, provide correct value" << std::endl;
            return  APP_INI_InvalidReceivePollingInterval;
        }

        //Receive buffer size
        Topic[index].ReceiveBufferSize = GetPrivateProfileInt(TopicSectionName, RECEIVE_BUFFER_SIZE, DEFAULT_INT, configFilePath);
        if((Topic[index].ReceiveBufferSize <= DEFAULT_ZERO) || (Topic[index].ReceiveBufferSize > MAX_RECEIVE_BUFFER_SIZE))
        {
            std::clog << "Parameter name - [ReceiveBufferSize] has invalid value, provide correct value" << std::endl;
            return  APP_INI_InvalidReceiveBufferSize;
        }
#if 0
        printf("\n******************************Topic Info********************************\r\n");
        printf("Section name :%s\r\n", TopicSectionName);
		printf("Topicid %d.ReceivePollingInterval %d\r\n", index, Topic[index].ReceivePollingInterval);
        printf("Topicid %d.ReceiveBufferSize %d\r\n", index, Topic[index].ReceiveBufferSize);
        printf("Topicid %d.TopicName is :%s\r\n", index, Topic[index].TopicName);
        printf("Topicid %d.TopicLibFilePath is :%s\r\n", index, Topic[index].TopicLibFilePath);
        printf("Topicid %d.QoSFileName is :%s\r\n", index, Topic[index].QoSFileName);
		printf("index = %d\r\n", index);
		printf("***************************************************************************\r\n");
#endif
    }
    return status;
}

CMStatus WebsocketSupporter::initDDS(int index)
{
    CMStatus CMstatus = CMSuccess;
    char QoSFilePath[MAX_BUFF_SIZE] = "file://";

    if (index < 0) {
        return CMFail;
    }
    strcat(QoSFilePath, Topic[index].QoSFileName);
    setDomainID(App_Params.domain_id);
    setQoSFileName(QoSFilePath);
    setTypeLibPath(Topic[index].TopicLibFilePath);

    CMstatus = SetParticipant(domainID);
    if(CMstatus != CMSuccess)
    {
        std::clog << "Set Particpant failed " << std::endl;
        return CMstatus;
    }

    CMstatus = SetDataReaderLibUseQoSFile(domainID, Topic[index].TopicName, Topic[index].TopicType, 
                                            typeLibPath.c_str(), QoSFileName.c_str(), &readerId_RecognitionResult_Total_Data, NULL);
    if(CMstatus != CMSuccess)
    {
        std::clog << "Create data reader failed " << std::endl;
        return CMstatus;
    }

    CMstatus = SetDataWriterLibUseQoSFile(domainID, Topic[index].TopicName, Topic[index].TopicType, 
                                            typeLibPath.c_str(), QoSFileName.c_str(), &writerId_RecognitionResult_Total_Data, NULL);
    if(CMstatus != CMSuccess)
    {
        std::clog << "Create data writer failed " << std::endl;
        return CMstatus;
    }
    return CMstatus;
}

RecognitionResult_Total_Data* WebsocketSupporter::allocPublishData()
{
    RecognitionResult_Total_Data *data = RecognitionResult_Total_Data__alloc();
    data->request_DeviceId = DDS_string_alloc(BUFF_SIZE);
	data->request_CameraId = DDS_string_alloc(BUFF_SIZE);
	data->response_Barcode_strRecognition = DDS_string_alloc(BUFF_SIZE);
	data->response_Barcode_DeviceId = DDS_string_alloc(BUFF_SIZE);
	data->response_PricereductionCut_DeviceId = DDS_string_alloc(BUFF_SIZE);
	data->response_Pricereduction_srtRecognition = DDS_string_alloc(BUFF_SIZE);
	data->response_Pricereduction_DeviceId = DDS_string_alloc(BUFF_SIZE);

    return data;
}

int WebsocketSupporter::getTopicIndex(char *topicName)
{
    int result = -1;
    int i = 0;

	if(topicName != NULL)
	{
		for(i = 0; i < App_Params.totaltopics; i++)
		{
			if(strcmp(topicName, Topic[i].TopicName) == 0)
			{
				result = i;
				break;
			}
		}
	}
	else
	{
		return APP_InvalidParameters;
	}

    return result;
}

CMStatus WebsocketSupporter::endAppProcessing()
{
    CMStatus CMstatus = CMSuccess;
    short domainID = -1;
    char *resultcode = NULL;
    domainID = App_Params.domain_id;
	
	//Topic_End_Process_RecognitionResult_Total_Data();
    //Free Publisher
    DDS_free(message_Sample_RecognitionResult_Total_Data);

    CMstatus = ShutdownDataWriter(domainID, writerId_RecognitionResult_Total_Data, resultcode);
    if(CMstatus != CMSuccess)
    {
        //WriteLog(g_logfileid, DEFAULT, "[RecognitionResult_Total_Data] Error : Shutdown writer failed..!!!");
        if (App_Params.debugmode) {
            std::clog << "Shutdown writer failed..!!!" << std::endl;
        }
        return CMstatus;
    }

    //Free Subscriber
    DDS_free(message_seq_RecognitionResult_Total_Data);
    DDS_free(message_infoSeq_RecognitionResult_Total_Data);
    CMstatus = ShutdownDataReader(domainID, readerId_RecognitionResult_Total_Data, resultcode);
    if(CMstatus != CMSuccess)
    {
        //WriteLog(g_logfileid, DEFAULT, "[RecognitionResult_Total_Data] Error : Shutdown reader failed..!!!");
        if (App_Params.debugmode) {
            std::clog << "Shutdown reader failed..!!!" << std::endl;
        }
        return CMstatus;
    }
	
    CMstatus = ShutdownParticipant(domainID, resultcode);
	if(CMstatus != CMSuccess)
	{
		//WriteLog(g_logfileid, 1, "[RecognitionResult_Total_Data] Error : Shutdown partcipant failed..!!!");
        if (App_Params.debugmode) {
            std::clog << "Shutdown partcipant failed..!!!" << std::endl;
        }
		return CMstatus;
	}
	
	return CMstatus;
}

APPStatus WebsocketSupporter::serializeJson(Json::Value& root, RecognitionResult_Total_Data *scanData)
{
    if (root.empty()) {
        return APP_InvalidParameters;
    }

    if (!scanData) {
        return APP_InvalidParameters;
    }
    scanData->request_DeviceId = strdup(root.get("デバイスID","").asString().c_str());
    scanData->request_CameraId = strdup(root.get("カメラID","").asString().c_str());
    scanData->request_SeqNo = stoi(root.get("シーケンス番号","").asString());
    scanData->response_Barcode_ResultCode = stoi(root.get("バーコード認識結果コード","").asString());
    scanData->response_Barcode_strRecognition = strdup(root.get("バーコード認識結果文字列","").asString().c_str());
    scanData->response_Barcode_DeviceId = strdup(root.get("バーコード認識結果実行デバイスID","").asString().c_str());
    scanData->response_PricereductionCut_ResultCode = stoi(root.get("値引きシール結果コード","").asString());
    scanData->response_PricereductionCut_DeviceId = strdup(root.get("値引きシール切出し実行デバイスID","").asString().c_str());
    scanData->response_Pricereduction_ResultCode = stoi(root.get("値引きシール認識結果コード","").asString());
    scanData->response_Pricereduction_srtRecognition = strdup(root.get("値引きシール認識結果文字列","").asString().c_str());
    scanData->response_Pricereduction_DeviceId = strdup(root.get("値引きシール認識実行デバイスID","").asString().c_str());

    return APP_Success;
}

Request_command WebsocketSupporter::analyzeMessage(const Json::Value& args, Json::Value& value, int *requestId)
{
    if (args.empty()) {
        return CMD_Wrong;
    }

    if (!value.empty()) {
        return CMD_Wrong;
    }

    if (!requestId) {
        return CMD_Wrong;
    }

    if (args.isMember(C_REQUEST_CMD)) {
        Json::Value defaultValue;
        *requestId = stoi(args.get(C_REQUEST_ID, defaultValue).asString());
        value = args.get(C_REQUEST_CMD, defaultValue);
        if (value.asString() == C_PUBLISH_DATA) { //Publish command
            if (args.isMember(C_REQUEST_DATA)) {
                value = args.get(C_REQUEST_DATA, defaultValue);
                if (value.isMember(C_TOPIC_DATA)) {
                    value = value.get(C_TOPIC_DATA, defaultValue);
                    return CMD_Publish;
                }
            }
        } else {
            //Others command: TBD
        }
    }

    return CMD_Wrong;
}