/**
 * MODULE_NAME      :   queue.h
 * (FILE NAME)
 * DESCRIPTION      :   次の機能を有する。
 *                      そのソースの機能概要記述
 *                      ********************
 * CREATE ON        :   Ver1.00 25/02/2022      QuanPDA(TSDV)
 * 
 * REMARKS          :   NONE
 */

#ifndef QUEUE_H
#define QUEUE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <errno.h>
#include <unistd.h>

struct queue_t {
    void                *data;
    unsigned int        data_size;
    unsigned int        size;
    unsigned int        front;
    unsigned int        tail;
};

int get_next_index(int index, const struct queue_t *queue)
{
    return (index + 1) % queue->size;
}
/*
NO.1
TITLE:      Queue emtpy
MODULE:     queue_emtpy(const struct queue_t *queue)
INCLUDE:    N/A
PARAMETERS: queue:
                valid: not NULL
                invalid: NULL

RETURNS:    return values:
                1: queue is empty
                0: queue is not emtpy

OUTLINE:    
            Check if a queue is empty or not

NOTES:
HISTORY:
            1.0 (TSDV)      QuanPDA 25/02/2022 original
 */
int queue_empty(const struct queue_t *queue) {
    if (!queue) {
        return -1;
    }

    if(queue->front == queue->tail) {
        return 1;
    }

    return 0;
}

/*
NO.2
TITLE:      Queue full
MODULE:     queue_full(const struct queue_t *queue)
INCLUDE:    N/A
PARAMETERS: queue:
                valid: not NULL
                invalid: NULL

RETURNS:    return values:
                1: queue is empty
                0: queue is not emtpy

OUTLINE:    
            Check if a queue is full or not

NOTES:
HISTORY:
            1.0 (TSDV)      QuanPDA 25/02/2022 original
 */
int queue_full(const struct queue_t *queue) {
    if (!queue) {
        return -1;
    }
    unsigned int tail = queue->tail;
    unsigned int front = queue->front;
    unsigned int size = queue->size;

    if((tail + 1) % (size) == front) {
        return 1;
    }

    return 0;
}

/*
NO.3
TITLE:      Enqueue data
MODULE:     enqueue(struct queue_t *queue, void *data)
INCLUDE:    N/A
PARAMETERS: queue:
                valid: not NULL
                invalid: NULL
            
            data:
                valid: not NULL
                invalid: NULL

RETURNS:    return values:
                RET_NG: queue is full
                RET_OK: successfully enqueued data to queue

OUTLINE:    
            Enqueue data to queue

NOTES:
HISTORY:
            1.0 (TSDV)      QuanPDA 25/02/2022 original
 */
int enqueue(struct queue_t *queue, void *data) {
    if (!queue || !data) {
        return -1;
    }
    
    if(queue_full(queue)) {
        return -1;
    }
    // int tail = queue->tail;
    // if (get_next_index(tail, queue) == queue->front){
    //     return -1;
    // }
    void *queue_data = queue->data;
    memcpy(queue_data + (queue->data_size)*queue->tail, data, queue->data_size);
    queue->tail = (queue->tail + 1) % queue->size;
    //queue->tail = get_next_index(tail, queue);
    return 0;
}

/*
NO.4
TITLE:      Dequeue data
MODULE:     dequeue(struct queue_t *queue)
INCLUDE:    N/A
PARAMETERS: queue:
                valid: not NULL
                invalid: NULL

RETURNS:    return values:
                NULL: queue is emtpy
                not NULL: pointer to data dequeued from queue
OUTLINE:    
            Dequee data from queue

NOTES:
HISTORY:
            1.0 (TSDV)      QuanPDA 25/02/2022 original
 */
void *dequeue(struct queue_t *queue) {
    if(queue_empty(queue)) {
        return NULL;
    }

    unsigned int front = queue->front;
    void *queue_data = queue->data;
    queue->front = (queue->front + 1) % queue->size;
    //queue->front = get_next_index(front, queue);
    return queue_data + front*queue->data_size;
}

/*
NO.5
TITLE:      Delete queue
MODULE:     delete_queue(struct queue_t *queue)
INCLUDE:    N/A
PARAMETERS: queue:
                valid: not NULL
                invalid: NULL

RETURNS:    NA
OUTLINE:    
            Delete a queue

NOTES:
HISTORY:
            1.0 (TSDV)      QuanPDA 25/02/2022 original
 */
void delete_queue(struct queue_t *queue) {
    if (!queue) {
        return;
    }
    
    if(queue->data) {
        free(queue->data);
        queue->data = NULL;
    }
}



#endif