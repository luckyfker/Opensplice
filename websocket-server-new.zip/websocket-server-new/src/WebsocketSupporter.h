/**
* --------------------------------------------------------------------------
*       TEC CORPORATION, ALL Rights Reserved
* --------------------------------------------------------------------------
* MODULE NAME   :   WebsocketSupporter.h
* (FILE NNAME)
* PARAMETERS    :   NONE
* DESCRIPTION   :   次の機能を有する。
*                     そのソースの機能概要記述
*                     ********************
* CREATE ON     :   Ver1.00 22/01/17    ThaiNH(TSDV)
*
* REMARKS       :   NONE
*/

#ifndef _WEBSOCKET_SUPPORTER
#define _WEBSOCKET_SUPPORTER
#include <algorithm>
#include <functional>
#include <iostream>
#include <string>
#include <vector>
#include <cstring>
#include <stdio.h>
#include <fstream>
#include "json/json.h"
#include <stdexcept>
#include "com_middle.h"
#include "RecognitionResult_Total.h"
#include "common.h"
#include "inictrldll.h"
//#include <sys/stat.h>


class WebsocketSupporter {
public:
	AppTopic *Topic;
	AppParams_t App_Params;
	int domainID;
	std::string typeLibPath;
	std::string QoSFileName;
	int pollingIntervalMs;
	CMULONG readerId_RecognitionResult_Total_Data;
	CMULONG writerId_RecognitionResult_Total_Data;
	DDS_sequence_RecognitionResult_Total_Data *message_seq_RecognitionResult_Total_Data;
	DDS_SampleInfoSeq *message_infoSeq_RecognitionResult_Total_Data;
	RecognitionResult_Total_Data *message_Sample_RecognitionResult_Total_Data;

public:
	WebsocketSupporter();
	~WebsocketSupporter();

	void setDomainID(int domainID);
	void setTypeLibPath(std::string typeLibPath);
	void setQoSFileName(std::string QoSFileName);
	void setPollingIntervalMs(int pollingIntervalMs);

	std::string convertToString(char* arr);

	APPStatus parsingConfig(const char *configFilePath);
	int getTopicIndex(char *topicName);
	CMStatus initDDS(int index);
	RecognitionResult_Total_Data* allocPublishData();

	Request_command analyzeMessage(const Json::Value& args, Json::Value& value, int *requestId);

	APPStatus serializeJson(Json::Value& root, RecognitionResult_Total_Data *scanData);
	CMStatus endAppProcessing();
	
};

#endif