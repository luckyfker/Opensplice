/**
* --------------------------------------------------------------------------
*       TEC CORPORATION, ALL Rights Reserved
* --------------------------------------------------------------------------
* MODULE NAME   :   main.cpp
* (FILE NNAME)
* PARAMETERS    :   NONE
* DESCRIPTION   :   次の機能を有する。
*                     そのソースの機能概要記述
*                     ********************
* CREATE ON     :   Ver1.00 22/02/20    ThaiNH(TSDV)
*
* REMARKS       :   NONE
*/

#include "WebsocketServer.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <asio/io_service.hpp>
#include "WebsocketSupporter.h"
#include <stdarg.h>
#include <vector>
#include <csignal>
#include <fstream>
#include "queue.h"

//Global variable
std::shared_ptr< WebsocketServer>   server = std::make_shared<WebsocketServer>();
bool                                g_connected = false;
struct queue_t                      g_queue;
int                                 g_thread_stop = 0;
int                                 g_bufferSize = 0;
std::string                         g_topicName;
int                                 g_pollingIntervalMs;
int                                 g_debugMode;
pthread_mutex_t                     g_mutex;

//std::mutex                          g_mutex;
std::condition_variable             g_cv;
bool                                g_ready = false;
bool                                g_processed = false;
char                                g_resultcode[100];

static void sigIntHandler(int signum)
{
    g_thread_stop = 1;
}

static int init_queue(int size) {
    g_queue.data = malloc(sizeof(struct RecognitionResult_Total_Data) * size);
    if(!g_queue.data) {
        return RET_NG;
    }
    g_queue.size = size;
    g_queue.data_size = sizeof(struct RecognitionResult_Total_Data);
    g_queue.front = 0;
    g_queue.tail = 0;

    return RET_OK;
}

static void PollingSubscriberThread_RecognitionResult_Total_Data(int domainID, CMULONG readerId_RecognitionResult_Total_Data, DDS_sequence_RecognitionResult_Total_Data *message_seq_RecognitionResult_Total_Data, DDS_SampleInfoSeq *message_infoSeq_RecognitionResult_Total_Data)
{
    int lastSeqNo = 0;
    message_seq_RecognitionResult_Total_Data = DDS_sequence_RecognitionResult_Total_Data__alloc();
	message_infoSeq_RecognitionResult_Total_Data = DDS_SampleInfoSeq__alloc();
    os_time os_delay = { 0, g_pollingIntervalMs }; //1ms
    while(!g_thread_stop) {
        ReadSubscriberData(domainID, readerId_RecognitionResult_Total_Data, message_seq_RecognitionResult_Total_Data, message_infoSeq_RecognitionResult_Total_Data, NULL);
        for(DDS_unsigned_long i = 0; i < message_seq_RecognitionResult_Total_Data->_length; i++) {
            pthread_mutex_lock(&g_mutex);
            {
                //std::lock_guard<std::mutex> lk(g_mutex);
                if(message_infoSeq_RecognitionResult_Total_Data->_buffer[i].valid_data) {
                    int seqNo = message_seq_RecognitionResult_Total_Data->_buffer[i].request_SeqNo;
                    
                    if (seqNo != lastSeqNo && seqNo != 0) {
                        lastSeqNo = seqNo;
                        
                        //Push to ring buffer
                        if(enqueue(&g_queue, (struct RecognitionResult_Total_Data*)message_seq_RecognitionResult_Total_Data->_buffer) != RET_OK) {
                            if (g_debugMode) {
                                std::clog << "Cannot enqueue data. SeqNo = " << message_seq_RecognitionResult_Total_Data->_buffer[i].request_SeqNo << std::endl;
                            }
                        }
                    }
                }
                else {
                    //printf( "Error\n");
                }
            }
            pthread_mutex_unlock(&g_mutex);
        }

        RecognitionResult_Total_DataDataReader_return_loan((DDS_DataReader) readerId_RecognitionResult_Total_Data, message_seq_RecognitionResult_Total_Data, 
                                                    message_infoSeq_RecognitionResult_Total_Data);
        //Sleep 1ms
        os_nanoSleep(os_delay);
    }
}

static void SendThread_RecognitionResult_Total_Data()
{
    struct RecognitionResult_Total_Data *data;
    Json::Value valueData;
    Json::Value valueSub;
    Json::Value valueSubScan;
    valueSub[TOPIC_NAME] = g_topicName;
    bool flag = false;
    os_time os_delay = { 0, g_pollingIntervalMs }; //1ms
    while(!g_thread_stop) {
        pthread_mutex_lock(&g_mutex);
        {
            //std::lock_guard<std::mutex> lk(g_mutex);
            while(!queue_empty(&g_queue)) {
                data = (struct RecognitionResult_Total_Data*) dequeue(&g_queue);
                if (data) {
                    valueSubScan[DEVICEID] = data->request_DeviceId;
                    valueSubScan[CAMERA_ID] = data->request_CameraId;
                    valueSubScan[SEQ_NO] = data->request_SeqNo;
                    valueSubScan[BARCODE_RESULTCODE] = data->response_Barcode_ResultCode;
                    valueSubScan[BARCODE_STR_RECOGNITION] = data->response_Barcode_strRecognition;
                    valueSubScan[BARCODE_STR_DEVICEID] = data->response_Barcode_DeviceId;
                    valueSubScan[PRICEREDUCTIONCUT_RESULTCODE] = data->response_PricereductionCut_ResultCode;
                    valueSubScan[PRICEREDUCTIONCUT_DEVICEID] = data->response_PricereductionCut_DeviceId;
                    valueSubScan[PRICEREDUCTION_RESULTCODE] = data->response_Pricereduction_ResultCode;
                    valueSubScan[PRICEREDUCTION_SRT_RECOGNITION] = data->response_Pricereduction_srtRecognition;
                    valueSubScan[PRICEREDUCTION_DEVICEID] = data->response_Pricereduction_DeviceId;
                    
                    valueSub[VALUE].append(valueSubScan);
                    flag = true;
                }
            }
            
            if (flag) {
                flag = false;
                valueData[DATA] = valueSub;
                if (g_debugMode) {
                    std::clog << "Topic data: " << valueData.toStyledString() << "\n";
                }
                server->broadcastMessage(NOTIFY, valueData);
                valueSub.removeMember(VALUE);
            }
        }
        
        pthread_mutex_unlock(&g_mutex);
        //Sleep 1ms
        os_nanoSleep(os_delay);
    }
}


int main(int argc, char* argv[])
{
    //Create the event loop for the main thread, and the WebSocket server
    asio::io_service mainEventLoop;
    
    WebsocketSupporter support;
    std::string arrParams[] = {"デバイスID", "カメラID", "シーケンス番号", "バーコード認識結果コード", "バーコード認識結果文字列",
                                "バーコード認識結果実行デバイスID", "値引きシール結果コード", "値引きシール切出し実行デバイスID",
                                "値引きシール認識結果コード", "値引きシール認識結果文字列", "値引きシール認識実行デバイスID"};
    int indexTopic;

    //Handle sigint
    signal(SIGINT, sigIntHandler);

    //Read config
    APPStatus status = APP_Success;
    status = support.parsingConfig(APP_CONFG_INI_FILEPATH);
    if (status != APP_Success && status != APP_INI_InvalidReceiveBufferSize) {
        return EXIT_FAILURE;
    }

    //Get index topic
    char TopicName[] = "RecognitionResult_Total_Data";
    indexTopic = support.getTopicIndex(TopicName);
    if (indexTopic < 0) {
        return EXIT_FAILURE;
    }
    if (status == APP_INI_InvalidReceiveBufferSize) {
        g_bufferSize = DEFAULT_RECEIVE_BUFFER_SIZE;
    } else {
        g_bufferSize = support.Topic[indexTopic].ReceiveBufferSize;
    }

    g_pollingIntervalMs = support.Topic[indexTopic].ReceivePollingInterval * 1000000;
    g_topicName = support.convertToString(support.Topic[indexTopic].TopicName);
    g_debugMode = support.App_Params.debugmode;

    //Init ring buffer
    if(init_queue(g_bufferSize) != RET_OK) {
        if(g_debugMode) {
            std::clog << "Cannot initialize ring buffer" << std::endl;
        }
        return EXIT_FAILURE;
    }

    //Init DDS
    CMStatus CMstatus = CMSuccess;
    CMstatus = support.initDDS(indexTopic);
    if (CMstatus != CMSuccess) {
        if(g_debugMode) {
            std::clog << "Cannot initialize DDS" << std::endl;
        }
        return EXIT_FAILURE;
    }

    //Allocate publish data
    support.message_Sample_RecognitionResult_Total_Data = support.allocPublishData();

    //Params list field
    Json::Value value;
    Json::Value subValue;
    
    subValue[TOPIC_NAME] = support.Topic[indexTopic].TopicName;
    subValue[QUEUE_SIZE] = g_bufferSize;
    
    for (size_t i = 0; i < sizeof(arrParams)/sizeof(arrParams[0]); i++) {
        subValue[TOPIC_FIELD].append(arrParams[i]);
    }
    value[TOPIC_DEF].append(subValue);

    std::thread recvDataFromDds(PollingSubscriberThread_RecognitionResult_Total_Data, support.domainID, support.readerId_RecognitionResult_Total_Data, support.message_seq_RecognitionResult_Total_Data, support.message_infoSeq_RecognitionResult_Total_Data);
    std::thread sendDataToScratch(SendThread_RecognitionResult_Total_Data);
    
    //Register our network callbacks, ensuring the logic is run on the main thread's event loop
    server->connect([&mainEventLoop, &value](ClientConnection conn)
        {
            mainEventLoop.post([conn, &value]()
                {
                    if (g_debugMode) {
                        std::clog << "Connection opened." << std::endl;
                        std::clog << "There are now " << server->numConnections() << " open connections." << std::endl;
                    }
                    
                    server->sendMessage(conn, "Handshake", value);
                    g_connected = true;
                });
        });
    server->disconnect([&mainEventLoop](ClientConnection conn)
        {
            mainEventLoop.post([conn]()
                {
                    if (g_debugMode) {
                        std::clog << "Connection closed." << std::endl;
                        std::clog << "There are now " << server->numConnections() << " open connections." << std::endl;
                    }
                    g_connected = false;
                });
        });
    server->message(SCATCH_COMMAND, [&mainEventLoop, &support](ClientConnection conn, const Json::Value& args)
        {
            mainEventLoop.post([conn, args, &support]()
                {
                    Json::Value value;
                    int requestId;
                    CMStatus CMstatus = CMSuccess;
                    Request_command command = support.analyzeMessage(args, value, &requestId);
                    
                    if (command == CMD_Wrong) {
                        if(g_debugMode) {
                            std::clog << "Command is wrong" << std::endl;
                        }
                    } else if (command == CMD_Publish) {
                        support.serializeJson(value, support.message_Sample_RecognitionResult_Total_Data);
                        CMstatus = WritePublishData(support.domainID, support.writerId_RecognitionResult_Total_Data, support.message_Sample_RecognitionResult_Total_Data, g_resultcode);
                        if (CMstatus != CMSuccess) {
                            if(g_debugMode) {
                                std::clog << "Write data failed" << std::endl;
                            }
                        }
                        Json::Value response;
                        Json::Value res_payload;
                        response[C_REQUEST_ID] = requestId;
                        res_payload[RESULT_CODE] = support.convertToString(g_resultcode);
                        res_payload[CMSTATUS] = CMstatus;
                        response[PAYLOAD] = res_payload;
                        server->sendMessage(conn, RESPONSE, response);
                    } else {
                        //Others command: TBD
                    }
                });
        });

    //Start the networking thread
    std::thread serverThread([]() {
        server->run(PORT_NUMBER);
        });

    //Start a keyboard input thread that reads from stdin
    std::thread inputThread([ &mainEventLoop]()
        {
            string input;
            while (1)
            {
                //Read user input from stdin
                std::getline(std::cin, input);

                //Broadcast the input to all connected clients (is sent on the network thread)
                Json::Value payload;
                payload["input"] = input;
                server->broadcastMessage("userInput", payload);

                //Debug output on the main thread
                mainEventLoop.post([]() {
                    if (g_debugMode) {
                        std::clog << "User input debug output on the main thread" << std::endl;
                    }
                    });
            }
        });

    
    std::thread runMainEventLoop([&mainEventLoop]()
        {
            asio::io_service::work work(mainEventLoop);
            mainEventLoop.run();
            while (!g_thread_stop) {
                //Do nothing
            }
            mainEventLoop.stop();
        });
    
    // asio::io_service::work work(mainEventLoop);
    // mainEventLoop.run();

    recvDataFromDds.join();
    sendDataToScratch.join();

    //Delele queue
    delete_queue(&g_queue);

    //End Process
    CMstatus = support.endAppProcessing();
    if (CMstatus != CMSuccess) {
        std::clog << "End app processing failed" << std::endl;
    } else {
        std::clog << "End app processing success" << std::endl;
    }

    return 0;
}
