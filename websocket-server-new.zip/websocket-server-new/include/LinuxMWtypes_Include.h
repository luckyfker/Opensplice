#ifndef __DDSCOMULINUXMWTYPES_INCLUDE__
#define __DDSCOMULINUXMWTYPES_INCLUDE__

#ifdef WIN32
#ifdef ddscomu_EXPORTS
#define DDSCOMU_API __declspec(dllexport) 
#else
#define DDSCOMU_API __declspec(dllimport) 
#endif
#else
#define DDSCOMU_API 
#endif

#endif