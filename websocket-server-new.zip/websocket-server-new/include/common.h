#ifndef _COMMON_H
#define _COMMON_H

#define BUFF_SIZE 16
#define MAX_BUFF_SIZE 255

//App config
typedef struct {
	int  queueMaxSize;
} appConf_t;


typedef struct AppParams
{
    int domain_id;
    int totaltopics;
    int debugmode;
} AppParams_t;

typedef enum Apps_errorcode_t
{
    APP_Fail  = -1,
    APP_Success = 0,
    APP_InvalidParameters,
    APP_InvalidINIFilePath,
    APP_INI_Section_ParameterNameMissing,
    APP_INI_InvalidTotalTopicNumber,
	APP_INI_InvalidDomainId,
    APP_INI_InvalidAppType,
	APP_INI_InvalidSubType,
    APP_INI_InvalidModuleName,
    APP_INI_InvalidTopicName,
    APP_INI_InvalidTopicType,
	APP_INI_InvalidQoSFileName,
    APP_INI_InvalidTopicLibTypeH,
    APP_INI_InvalidQosFilePath,
    APP_INI_InvalidTopicLibFilePath,
	APP_INI_InvalidSubLogFilePath,
	APP_INI_InvalidPubLogFilePath,
	APP_INI_InvalidQueryString,
	APP_INI_InvalidQueryCondToSubscribe,
	APP_INI_InvalidContentFiltered,
	APP_INI_InvalidFilterExpression,
    APP_INI_InvalidReceivePollingInterval,
    APP_INI_InvalidReceiveBufferSize,
    APP_INI_InvalidDebugMode,

}APPStatus;

typedef enum Request_command_t
{
    CMD_Wrong = -1,
    CMD_Publish = 0,
} Request_command;

typedef struct Topic{
    int ReceivePollingInterval;
    int ReceiveBufferSize;
    char TopicName[MAX_BUFF_SIZE];
    char TopicType[MAX_BUFF_SIZE];				
    char QoSFileName[MAX_BUFF_SIZE];		
    char TopicLibFilePath[MAX_BUFF_SIZE];		
    // char SubLogFilePath[MAX_BUFF_SIZE];		
    // char PubLogFilePath[MAX_BUFF_SIZE];
	// char ContentFilteredTopicName[MAX_BUFF_SIZE];
	// char FilterExpression[MAX_BUFF_SIZE];
	// char QueryString[MAX_BUFF_SIZE];
	// char QueryCondToSubscribe[MAX_BUFF_SIZE];
}AppTopic;

#define TOPIC_INFO_SECTION "DDS_setting"
#define DEBUG "Debug"
#define MAX_APP_TYPE 8
#define MAX_SUB_TYPE 3
#define MAX_RECEIVE_BUFFER_SIZE 1000
#define DEFAULT_RECEIVE_BUFFER_SIZE 10
#define DEFAULT_ZERO 0
#define DEFAULT_INT -1
#define DEFAULT_DEBUG_MODE 1
#define DEFAULT_STRING "String Not Found"
#define DOMAIN_ID "DomainId"
#define SUB_TYPE "SubType"
#define APP_TYPE "AppType"
#define POLLING_INTERVAL "ReceivePollingInterval"
#define RECEIVE_BUFFER_SIZE "ReceiveBufferSize"
#define NO_OF_TOPICS "TotalTopicNum"
#define TOPIC_NAME "TopicName"
#define TOPIC_TYPE "TopicType"
#define MODULE_NAME "ModuleName"
#define QOS_FILE_NAME "QoSFilePath"
#define TOPICLIB_FILE_PATH "TopicLibFilePath"
#define SUB_LOG_FILE_PATH "SubLogFilePath"
#define PUB_LOG_FILE_PATH "PubLogFilePath"
#define CONTENT_FILTERED_TOPICNAME "ContentFilteredTopicName"
#define FILTER_EXPRESSION "FilterExpression"
#define QUERY_STRING "QueryString"
#define QUERYCOND_TO_SUBSCRIBE "QueryCondToSubscribe"
#define DEBUG_MODE "DebugMode"



//Qos Path DDS
#define APL_DDS_MERGE_QOS_FILE          "file://../qos/apl_dds_recognition_marge.xml"

//Topic lib path
#define TOPIC_LIB_PATH                  "../lib/libtopicScan.so"

//File path config
#define APP_CONFG_INI_FILEPATH          "../config/Application_Config.ini"

//Idl path
#define IDL_FILE_PATH                   "../idl/RecognitionResult_Total.idl"

//Return value
#define RET_NG						    -1
#define RET_OK						    0

//Config file
#define CNF_DELIMITER               	"="
#define CNF_QUEUE_MAX_SIZE				"RingBufferSize"

//Message field WebSocket server
#define TOPIC_FIELD                     "TopicField"
#define TOPIC_DEF                       "topicdef"
#define QUEUE_SIZE                      "ReceiveBufferSize"
#define VALUE                           "Value"
#define DATA                            "Data"
#define NOTIFY                          "Notify"

//Params list scan data
#define DEVICEID                        "デバイスID"
#define CAMERA_ID                       "カメラID"
#define SEQ_NO                          "シーケンス番号"
#define BARCODE_RESULTCODE              "バーコード認識結果コード"
#define BARCODE_STR_RECOGNITION         "バーコード認識結果文字列"
#define BARCODE_STR_DEVICEID            "バーコード認識結果実行デバイスID"
#define PRICEREDUCTIONCUT_RESULTCODE    "値引きシール結果コード"
#define PRICEREDUCTIONCUT_DEVICEID      "値引きシール切出し実行デバイスID"
#define PRICEREDUCTION_RESULTCODE       "値引きシール認識結果コード"
#define PRICEREDUCTION_SRT_RECOGNITION  "値引きシール認識結果文字列"
#define PRICEREDUCTION_DEVICEID         "値引きシール認識実行デバイスID"

//Json Tittle Client
#define C_REQUEST_CMD                   "Request_command"
#define C_REQUEST_DATA                  "Request_data"
#define C_TOPIC_DATA                    "Topic_data"
#define C_PUBLISH_DATA                  "Publish"
#define C_REQUEST_ID                    "Request_id"

//Json Tittle Server
#define SCATCH_COMMAND                  "Command"
#define RESULT_CODE                     "Result_Code"
#define CMSTATUS                        "CMstatus"
#define RESPONSE                        "Response"
#define PAYLOAD                         "Payload"


#endif // _COMMON_H