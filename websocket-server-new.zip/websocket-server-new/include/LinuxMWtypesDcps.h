#ifndef LinuxMWtypesDCPS_H
#define LinuxMWtypesDCPS_H

#include <dds_primitive_types.h>

#include "LinuxMWtypes_Include.h"
#ifndef _Duration_defined
#define _Duration_defined
#ifdef __cplusplus
struct Duration;
#else /* __cplusplus */
typedef struct Duration Duration;
#endif /* __cplusplus */
#endif /* _Duration_defined */
DDSCOMU_API Duration *Duration__alloc (void);

struct Duration {
    DDS_long sec;
    DDS_unsigned_long nanosec;
};

#define TopicDataQosPolicy_sequence_octet__alloc DDS_sequence_octet__alloc
#define TopicDataQosPolicy_sequence_octet_allocbuf DDS_sequence_octet_allocbuf

#ifndef _TopicDataQosPolicy_defined
#define _TopicDataQosPolicy_defined
#ifdef __cplusplus
struct TopicDataQosPolicy;
#else /* __cplusplus */
typedef struct TopicDataQosPolicy TopicDataQosPolicy;
#endif /* __cplusplus */
#endif /* _TopicDataQosPolicy_defined */
DDSCOMU_API TopicDataQosPolicy *TopicDataQosPolicy__alloc (void);

struct TopicDataQosPolicy {
    DDS_sequence_octet value;
};

#ifndef _TransportPriorityQosPolicy_defined
#define _TransportPriorityQosPolicy_defined
#ifdef __cplusplus
struct TransportPriorityQosPolicy;
#else /* __cplusplus */
typedef struct TransportPriorityQosPolicy TransportPriorityQosPolicy;
#endif /* __cplusplus */
#endif /* _TransportPriorityQosPolicy_defined */
DDSCOMU_API TransportPriorityQosPolicy *TransportPriorityQosPolicy__alloc (void);

struct TransportPriorityQosPolicy {
    DDS_long value;
};

#ifndef _LifespanQosPolicy_defined
#define _LifespanQosPolicy_defined
#ifdef __cplusplus
struct LifespanQosPolicy;
#else /* __cplusplus */
typedef struct LifespanQosPolicy LifespanQosPolicy;
#endif /* __cplusplus */
#endif /* _LifespanQosPolicy_defined */
DDSCOMU_API LifespanQosPolicy *LifespanQosPolicy__alloc (void);

struct LifespanQosPolicy {
    Duration duration;
};

#ifndef _DeadlineQosPolicy_defined
#define _DeadlineQosPolicy_defined
#ifdef __cplusplus
struct DeadlineQosPolicy;
#else /* __cplusplus */
typedef struct DeadlineQosPolicy DeadlineQosPolicy;
#endif /* __cplusplus */
#endif /* _DeadlineQosPolicy_defined */
DDSCOMU_API DeadlineQosPolicy *DeadlineQosPolicy__alloc (void);

struct DeadlineQosPolicy {
    Duration period;
};

#ifndef _LatencyBudgetQosPolicy_defined
#define _LatencyBudgetQosPolicy_defined
#ifdef __cplusplus
struct LatencyBudgetQosPolicy;
#else /* __cplusplus */
typedef struct LatencyBudgetQosPolicy LatencyBudgetQosPolicy;
#endif /* __cplusplus */
#endif /* _LatencyBudgetQosPolicy_defined */
DDSCOMU_API LatencyBudgetQosPolicy *LatencyBudgetQosPolicy__alloc (void);

struct LatencyBudgetQosPolicy {
    Duration duration;
};

#ifndef _ExtQoSPolicy_defined
#define _ExtQoSPolicy_defined
#ifdef __cplusplus
struct ExtQoSPolicy;
#else /* __cplusplus */
typedef struct ExtQoSPolicy ExtQoSPolicy;
#endif /* __cplusplus */
#endif /* _ExtQoSPolicy_defined */
DDSCOMU_API ExtQoSPolicy *ExtQoSPolicy__alloc (void);

struct ExtQoSPolicy {
    DDS_unsigned_long SubscriberId;
    DDS_char SubscriberStrength;
    DDS_char SubscriberStrengthRotationType;
    DDS_unsigned_long TimeStamp;
    DDS_string SubscriberTopicName;
};

#ifndef _HelloWorldData_Msg_defined
#define _HelloWorldData_Msg_defined
#ifdef __cplusplus
struct HelloWorldData_Msg;
#else /* __cplusplus */
typedef struct HelloWorldData_Msg HelloWorldData_Msg;
#endif /* __cplusplus */
#endif /* _HelloWorldData_Msg_defined */
DDSCOMU_API HelloWorldData_Msg *HelloWorldData_Msg__alloc (void);

struct HelloWorldData_Msg {
    DDS_long userID;
    DDS_char message[128];
    DDS_string test;
};

#ifndef _Input_Data_defined
#define _Input_Data_defined
#ifdef __cplusplus
struct Input_Data;
#else /* __cplusplus */
typedef struct Input_Data Input_Data;
#endif /* __cplusplus */
#endif /* _Input_Data_defined */
DDSCOMU_API Input_Data *Input_Data__alloc (void);

struct Input_Data {
    DDS_long a;
    DDS_long b;
};

#ifndef _Result_Mul_defined
#define _Result_Mul_defined
#ifdef __cplusplus
struct Result_Mul;
#else /* __cplusplus */
typedef struct Result_Mul Result_Mul;
#endif /* __cplusplus */
#endif /* _Result_Mul_defined */
DDSCOMU_API Result_Mul *Result_Mul__alloc (void);

struct Result_Mul {
    DDS_long c;
};

#define ThroughputModule_DataType_sequence_octet__alloc DDS_sequence_octet__alloc
#define ThroughputModule_DataType_sequence_octet_allocbuf DDS_sequence_octet_allocbuf

#ifndef _ThroughputModule_DataType_defined
#define _ThroughputModule_DataType_defined
#ifdef __cplusplus
struct ThroughputModule_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule_DataType ThroughputModule_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule_DataType_defined */
DDSCOMU_API ThroughputModule_DataType *ThroughputModule_DataType__alloc (void);

struct ThroughputModule_DataType {
    DDS_unsigned_long_long count;
    DDS_sequence_octet payload;
};

#ifndef _ThroughputModule128_DataType_defined
#define _ThroughputModule128_DataType_defined
#ifdef __cplusplus
struct ThroughputModule128_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule128_DataType ThroughputModule128_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule128_DataType_defined */
DDSCOMU_API ThroughputModule128_DataType *ThroughputModule128_DataType__alloc (void);

struct ThroughputModule128_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[128];
};

#ifndef _ThroughputModule256_DataType_defined
#define _ThroughputModule256_DataType_defined
#ifdef __cplusplus
struct ThroughputModule256_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule256_DataType ThroughputModule256_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule256_DataType_defined */
DDSCOMU_API ThroughputModule256_DataType *ThroughputModule256_DataType__alloc (void);

struct ThroughputModule256_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[256];
};

#ifndef _ThroughputModule512_DataType_defined
#define _ThroughputModule512_DataType_defined
#ifdef __cplusplus
struct ThroughputModule512_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule512_DataType ThroughputModule512_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule512_DataType_defined */
DDSCOMU_API ThroughputModule512_DataType *ThroughputModule512_DataType__alloc (void);

struct ThroughputModule512_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[512];
};

#ifndef _ThroughputModule1024_DataType_defined
#define _ThroughputModule1024_DataType_defined
#ifdef __cplusplus
struct ThroughputModule1024_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule1024_DataType ThroughputModule1024_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule1024_DataType_defined */
DDSCOMU_API ThroughputModule1024_DataType *ThroughputModule1024_DataType__alloc (void);

struct ThroughputModule1024_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[1024];
};

#ifndef _ThroughputModule2048_DataType_defined
#define _ThroughputModule2048_DataType_defined
#ifdef __cplusplus
struct ThroughputModule2048_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule2048_DataType ThroughputModule2048_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule2048_DataType_defined */
DDSCOMU_API ThroughputModule2048_DataType *ThroughputModule2048_DataType__alloc (void);

struct ThroughputModule2048_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[2048];
};

#ifndef _ThroughputModule4096_DataType_defined
#define _ThroughputModule4096_DataType_defined
#ifdef __cplusplus
struct ThroughputModule4096_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule4096_DataType ThroughputModule4096_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule4096_DataType_defined */
DDSCOMU_API ThroughputModule4096_DataType *ThroughputModule4096_DataType__alloc (void);

struct ThroughputModule4096_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[4096];
};

#ifndef _ThroughputModule8192_DataType_defined
#define _ThroughputModule8192_DataType_defined
#ifdef __cplusplus
struct ThroughputModule8192_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule8192_DataType ThroughputModule8192_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule8192_DataType_defined */
DDSCOMU_API ThroughputModule8192_DataType *ThroughputModule8192_DataType__alloc (void);

struct ThroughputModule8192_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[8192];
};

#ifndef _ThroughputModule16384_DataType_defined
#define _ThroughputModule16384_DataType_defined
#ifdef __cplusplus
struct ThroughputModule16384_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule16384_DataType ThroughputModule16384_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule16384_DataType_defined */
DDSCOMU_API ThroughputModule16384_DataType *ThroughputModule16384_DataType__alloc (void);

struct ThroughputModule16384_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[16384];
};

#ifndef _ThroughputModule32768_DataType_defined
#define _ThroughputModule32768_DataType_defined
#ifdef __cplusplus
struct ThroughputModule32768_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule32768_DataType ThroughputModule32768_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule32768_DataType_defined */
DDSCOMU_API ThroughputModule32768_DataType *ThroughputModule32768_DataType__alloc (void);

struct ThroughputModule32768_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[32768];
};

#ifndef _ThroughputModule65536_DataType_defined
#define _ThroughputModule65536_DataType_defined
#ifdef __cplusplus
struct ThroughputModule65536_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule65536_DataType ThroughputModule65536_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule65536_DataType_defined */
DDSCOMU_API ThroughputModule65536_DataType *ThroughputModule65536_DataType__alloc (void);

struct ThroughputModule65536_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[65536];
};

#ifndef _ThroughputModule128K_DataType_defined
#define _ThroughputModule128K_DataType_defined
#ifdef __cplusplus
struct ThroughputModule128K_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule128K_DataType ThroughputModule128K_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule128K_DataType_defined */
DDSCOMU_API ThroughputModule128K_DataType *ThroughputModule128K_DataType__alloc (void);

struct ThroughputModule128K_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[131072];
};

#ifndef _ThroughputModule256K_DataType_defined
#define _ThroughputModule256K_DataType_defined
#ifdef __cplusplus
struct ThroughputModule256K_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule256K_DataType ThroughputModule256K_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule256K_DataType_defined */
DDSCOMU_API ThroughputModule256K_DataType *ThroughputModule256K_DataType__alloc (void);

struct ThroughputModule256K_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[262144];
};

#ifndef _ThroughputModule512K_DataType_defined
#define _ThroughputModule512K_DataType_defined
#ifdef __cplusplus
struct ThroughputModule512K_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule512K_DataType ThroughputModule512K_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule512K_DataType_defined */
DDSCOMU_API ThroughputModule512K_DataType *ThroughputModule512K_DataType__alloc (void);

struct ThroughputModule512K_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[524288];
};

#ifndef _ThroughputModule1M_DataType_defined
#define _ThroughputModule1M_DataType_defined
#ifdef __cplusplus
struct ThroughputModule1M_DataType;
#else /* __cplusplus */
typedef struct ThroughputModule1M_DataType ThroughputModule1M_DataType;
#endif /* __cplusplus */
#endif /* _ThroughputModule1M_DataType_defined */
DDSCOMU_API ThroughputModule1M_DataType *ThroughputModule1M_DataType__alloc (void);
struct ThroughputModule1M_DataType {
    DDS_unsigned_long_long count;
    DDS_octet payload[1363149];
};
#ifndef _LMWtopics_Req_PublishLog_defined
#define _LMWtopics_Req_PublishLog_defined
#ifdef __cplusplus
struct LMWtopics_Req_PublishLog;
#else /* __cplusplus */
typedef struct LMWtopics_Req_PublishLog LMWtopics_Req_PublishLog;
#endif /* __cplusplus */
#endif /* _LMWtopics_Req_PublishLog_defined */
DDSCOMU_API LMWtopics_Req_PublishLog *LMWtopics_Req_PublishLog__alloc (void);

struct LMWtopics_Req_PublishLog {
    DDS_unsigned_long status;
    DDS_char Date[12];
    DDS_char Time[12];
    DDS_char Loglevel[2];
    DDS_char LineNumStart[8];
    DDS_char LineNumEnd[8];
    DDS_char DateStart[12];
    DDS_char DateEnd[12];
    DDS_char FileName[256];
};

#ifndef _LMWtopics_Log_defined
#define _LMWtopics_Log_defined
#ifdef __cplusplus
struct LMWtopics_Log;
#else /* __cplusplus */
typedef struct LMWtopics_Log LMWtopics_Log;
#endif /* __cplusplus */
#endif /* _LMWtopics_Log_defined */
DDSCOMU_API LMWtopics_Log *LMWtopics_Log__alloc (void);

struct LMWtopics_Log {
    DDS_unsigned_long seqNum;
    DDS_char LineNum[8];
    DDS_char Date[12];
    DDS_char Time[12];
    DDS_char Loglevel[2];
    DDS_char Logcode[8];
    DDS_char Message[256];
};

#ifndef _LMWtopics_DeviceInfo_defined
#define _LMWtopics_DeviceInfo_defined
#ifdef __cplusplus
struct LMWtopics_DeviceInfo;
#else /* __cplusplus */
typedef struct LMWtopics_DeviceInfo LMWtopics_DeviceInfo;
#endif /* __cplusplus */
#endif /* _LMWtopics_DeviceInfo_defined */
DDSCOMU_API LMWtopics_DeviceInfo *LMWtopics_DeviceInfo__alloc (void);

struct LMWtopics_DeviceInfo {
    DDS_char Product_name[8];
    DDS_unsigned_long Serial_num;
    DDS_char Product_code[8];
    DDS_char Manufacture_date[8];
    DDS_float Version;
    DDS_char Position_info[8];
    DDS_unsigned_long DeviceId;
};

#ifndef _LMWtopics_QoSPolicy_defined
#define _LMWtopics_QoSPolicy_defined
#ifdef __cplusplus
struct LMWtopics_QoSPolicy;
#else /* __cplusplus */
typedef struct LMWtopics_QoSPolicy LMWtopics_QoSPolicy;
#endif /* __cplusplus */
#endif /* _LMWtopics_QoSPolicy_defined */
DDSCOMU_API LMWtopics_QoSPolicy *LMWtopics_QoSPolicy__alloc (void);

struct LMWtopics_QoSPolicy {
    TopicDataQosPolicy topic_data;
    DeadlineQosPolicy deadline;
    LatencyBudgetQosPolicy latency_budget;
    TransportPriorityQosPolicy transport_priority;
    LifespanQosPolicy lifespan;
};

#ifndef _LMWtopics_RequestSysCtrl_defined
#define _LMWtopics_RequestSysCtrl_defined
#ifdef __cplusplus
struct LMWtopics_RequestSysCtrl;
#else /* __cplusplus */
typedef struct LMWtopics_RequestSysCtrl LMWtopics_RequestSysCtrl;
#endif /* __cplusplus */
#endif /* _LMWtopics_RequestSysCtrl_defined */
DDSCOMU_API LMWtopics_RequestSysCtrl *LMWtopics_RequestSysCtrl__alloc (void);

struct LMWtopics_RequestSysCtrl {
    DDS_unsigned_long DeviceId;
    DDS_char Date[12];
    DDS_char Time[12];
    DDS_short Request_code;
    DDS_long value;
    DDS_char TopicName[256];
    LMWtopics_QoSPolicy TopicQoS;
};

#ifndef _LMWtopics_ResponseSysCtrl_defined
#define _LMWtopics_ResponseSysCtrl_defined
#ifdef __cplusplus
struct LMWtopics_ResponseSysCtrl;
#else /* __cplusplus */
typedef struct LMWtopics_ResponseSysCtrl LMWtopics_ResponseSysCtrl;
#endif /* __cplusplus */
#endif /* _LMWtopics_ResponseSysCtrl_defined */
DDSCOMU_API LMWtopics_ResponseSysCtrl *LMWtopics_ResponseSysCtrl__alloc (void);

struct LMWtopics_ResponseSysCtrl {
    DDS_unsigned_long DeviceId;
    DDS_char Date[12];
    DDS_char Time[12];
    DDS_short Request_code;
    DDS_short Execution_result_code;
    DDS_char TopicName[256];
    LMWtopics_QoSPolicy TopicQoS;
};

#ifndef _LMWtopics_ExtendQoSPolicy_defined
#define _LMWtopics_ExtendQoSPolicy_defined
#ifdef __cplusplus
struct LMWtopics_ExtendQoSPolicy;
#else /* __cplusplus */
typedef struct LMWtopics_ExtendQoSPolicy LMWtopics_ExtendQoSPolicy;
#endif /* __cplusplus */
#endif /* _LMWtopics_ExtendQoSPolicy_defined */
DDSCOMU_API LMWtopics_ExtendQoSPolicy *LMWtopics_ExtendQoSPolicy__alloc (void);

struct LMWtopics_ExtendQoSPolicy {
    ExtQoSPolicy ext_qos_policy;
};

#endif
