#ifndef LinuxMWtypesSPLTYPES_H
#define LinuxMWtypesSPLTYPES_H

#include <c_base.h>
#include <c_misc.h>
#include <c_sync.h>
#include <c_collection.h>
#include <c_field.h>
#include <v_copyIn.h>

#include "LinuxMWtypesDcps.h"
#include "LinuxMWtypes_Include.h"

extern const char *Duration_metaDescriptor[];
extern const int Duration_metaDescriptorArrLength;
extern const int Duration_metaDescriptorLength;
extern c_metaObject __Duration__load (c_base base);
struct _Duration ;
extern DDSCOMU_API v_copyin_result __Duration__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __Duration__copyOut(const void *_from, void *_to);
struct _Duration {
    c_long sec;
    c_ulong nanosec;
};

extern const char *TopicDataQosPolicy_metaDescriptor[];
extern const int TopicDataQosPolicy_metaDescriptorArrLength;
extern const int TopicDataQosPolicy_metaDescriptorLength;
extern c_metaObject __TopicDataQosPolicy__load (c_base base);
struct _TopicDataQosPolicy ;
extern DDSCOMU_API v_copyin_result __TopicDataQosPolicy__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __TopicDataQosPolicy__copyOut(const void *_from, void *_to);
struct _TopicDataQosPolicy {
    c_sequence value;
};

extern const char *TransportPriorityQosPolicy_metaDescriptor[];
extern const int TransportPriorityQosPolicy_metaDescriptorArrLength;
extern const int TransportPriorityQosPolicy_metaDescriptorLength;
extern c_metaObject __TransportPriorityQosPolicy__load (c_base base);
struct _TransportPriorityQosPolicy ;
extern DDSCOMU_API v_copyin_result __TransportPriorityQosPolicy__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __TransportPriorityQosPolicy__copyOut(const void *_from, void *_to);
struct _TransportPriorityQosPolicy {
    c_long value;
};

extern const char *LifespanQosPolicy_metaDescriptor[];
extern const int LifespanQosPolicy_metaDescriptorArrLength;
extern const int LifespanQosPolicy_metaDescriptorLength;
extern c_metaObject __LifespanQosPolicy__load (c_base base);
struct _LifespanQosPolicy ;
extern DDSCOMU_API v_copyin_result __LifespanQosPolicy__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __LifespanQosPolicy__copyOut(const void *_from, void *_to);
struct _LifespanQosPolicy {
    struct _Duration duration;
};

extern const char *DeadlineQosPolicy_metaDescriptor[];
extern const int DeadlineQosPolicy_metaDescriptorArrLength;
extern const int DeadlineQosPolicy_metaDescriptorLength;
extern c_metaObject __DeadlineQosPolicy__load (c_base base);
struct _DeadlineQosPolicy ;
extern DDSCOMU_API v_copyin_result __DeadlineQosPolicy__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __DeadlineQosPolicy__copyOut(const void *_from, void *_to);
struct _DeadlineQosPolicy {
    struct _Duration period;
};

extern const char *LatencyBudgetQosPolicy_metaDescriptor[];
extern const int LatencyBudgetQosPolicy_metaDescriptorArrLength;
extern const int LatencyBudgetQosPolicy_metaDescriptorLength;
extern c_metaObject __LatencyBudgetQosPolicy__load (c_base base);
struct _LatencyBudgetQosPolicy ;
extern DDSCOMU_API v_copyin_result __LatencyBudgetQosPolicy__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __LatencyBudgetQosPolicy__copyOut(const void *_from, void *_to);
struct _LatencyBudgetQosPolicy {
    struct _Duration duration;
};

extern const char *ExtQoSPolicy_metaDescriptor[];
extern const int ExtQoSPolicy_metaDescriptorArrLength;
extern const int ExtQoSPolicy_metaDescriptorLength;
extern c_metaObject __ExtQoSPolicy__load (c_base base);
struct _ExtQoSPolicy ;
extern DDSCOMU_API v_copyin_result __ExtQoSPolicy__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ExtQoSPolicy__copyOut(const void *_from, void *_to);
struct _ExtQoSPolicy {
    c_ulong SubscriberId;
    c_char SubscriberStrength;
    c_char SubscriberStrengthRotationType;
    c_ulong TimeStamp;
    c_string SubscriberTopicName;
};

extern c_metaObject __LinuxMWtypes_HelloWorldData__load (c_base base);

extern const char *HelloWorldData_Msg_metaDescriptor[];
extern const int HelloWorldData_Msg_metaDescriptorArrLength;
extern const int HelloWorldData_Msg_metaDescriptorLength;
extern c_metaObject __HelloWorldData_Msg__load (c_base base);
struct _HelloWorldData_Msg ;
extern DDSCOMU_API v_copyin_result __HelloWorldData_Msg__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __HelloWorldData_Msg__copyOut(const void *_from, void *_to);
struct _HelloWorldData_Msg {
    c_long userID;
    c_char message[128];
    c_string test;
};

extern c_metaObject __LinuxMWtypes_Input__load (c_base base);

extern const char *Input_Data_metaDescriptor[];
extern const int Input_Data_metaDescriptorArrLength;
extern const int Input_Data_metaDescriptorLength;
extern c_metaObject __Input_Data__load (c_base base);
struct _Input_Data ;
extern DDSCOMU_API v_copyin_result __Input_Data__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __Input_Data__copyOut(const void *_from, void *_to);
struct _Input_Data {
    c_long a;
    c_long b;
};

extern c_metaObject __LinuxMWtypes_Result__load (c_base base);

extern const char *Result_Mul_metaDescriptor[];
extern const int Result_Mul_metaDescriptorArrLength;
extern const int Result_Mul_metaDescriptorLength;
extern c_metaObject __Result_Mul__load (c_base base);
struct _Result_Mul ;
extern DDSCOMU_API v_copyin_result __Result_Mul__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __Result_Mul__copyOut(const void *_from, void *_to);
struct _Result_Mul {
    c_long c;
};

extern c_metaObject __LinuxMWtypes_ThroughputModule__load (c_base base);

extern const char *ThroughputModule_DataType_metaDescriptor[];
extern const int ThroughputModule_DataType_metaDescriptorArrLength;
extern const int ThroughputModule_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule_DataType__load (c_base base);
struct _ThroughputModule_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule_DataType {
    c_ulonglong count;
    c_sequence payload;
};

extern c_metaObject __LinuxMWtypes_ThroughputModule128__load (c_base base);

extern const char *ThroughputModule128_DataType_metaDescriptor[];
extern const int ThroughputModule128_DataType_metaDescriptorArrLength;
extern const int ThroughputModule128_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule128_DataType__load (c_base base);
struct _ThroughputModule128_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule128_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule128_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule128_DataType {
    c_ulonglong count;
    c_octet payload[128];
};

extern c_metaObject __LinuxMWtypes_ThroughputModule256__load (c_base base);

extern const char *ThroughputModule256_DataType_metaDescriptor[];
extern const int ThroughputModule256_DataType_metaDescriptorArrLength;
extern const int ThroughputModule256_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule256_DataType__load (c_base base);
struct _ThroughputModule256_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule256_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule256_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule256_DataType {
    c_ulonglong count;
    c_octet payload[256];
};

extern c_metaObject __LinuxMWtypes_ThroughputModule512__load (c_base base);

extern const char *ThroughputModule512_DataType_metaDescriptor[];
extern const int ThroughputModule512_DataType_metaDescriptorArrLength;
extern const int ThroughputModule512_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule512_DataType__load (c_base base);
struct _ThroughputModule512_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule512_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule512_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule512_DataType {
    c_ulonglong count;
    c_octet payload[512];
};

extern c_metaObject __LinuxMWtypes_ThroughputModule1024__load (c_base base);

extern const char *ThroughputModule1024_DataType_metaDescriptor[];
extern const int ThroughputModule1024_DataType_metaDescriptorArrLength;
extern const int ThroughputModule1024_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule1024_DataType__load (c_base base);
struct _ThroughputModule1024_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule1024_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule1024_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule1024_DataType {
    c_ulonglong count;
    c_octet payload[1024];
};

extern c_metaObject __LinuxMWtypes_ThroughputModule2048__load (c_base base);

extern const char *ThroughputModule2048_DataType_metaDescriptor[];
extern const int ThroughputModule2048_DataType_metaDescriptorArrLength;
extern const int ThroughputModule2048_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule2048_DataType__load (c_base base);
struct _ThroughputModule2048_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule2048_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule2048_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule2048_DataType {
    c_ulonglong count;
    c_octet payload[2048];
};

extern c_metaObject __LinuxMWtypes_ThroughputModule4096__load (c_base base);

extern const char *ThroughputModule4096_DataType_metaDescriptor[];
extern const int ThroughputModule4096_DataType_metaDescriptorArrLength;
extern const int ThroughputModule4096_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule4096_DataType__load (c_base base);
struct _ThroughputModule4096_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule4096_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule4096_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule4096_DataType {
    c_ulonglong count;
    c_octet payload[4096];
};

extern c_metaObject __LinuxMWtypes_ThroughputModule8192__load (c_base base);

extern const char *ThroughputModule8192_DataType_metaDescriptor[];
extern const int ThroughputModule8192_DataType_metaDescriptorArrLength;
extern const int ThroughputModule8192_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule8192_DataType__load (c_base base);
struct _ThroughputModule8192_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule8192_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule8192_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule8192_DataType {
    c_ulonglong count;
    c_octet payload[8192];
};

extern c_metaObject __LinuxMWtypes_ThroughputModule16384__load (c_base base);

extern const char *ThroughputModule16384_DataType_metaDescriptor[];
extern const int ThroughputModule16384_DataType_metaDescriptorArrLength;
extern const int ThroughputModule16384_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule16384_DataType__load (c_base base);
struct _ThroughputModule16384_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule16384_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule16384_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule16384_DataType {
    c_ulonglong count;
    c_octet payload[16384];
};

extern c_metaObject __LinuxMWtypes_ThroughputModule32768__load (c_base base);

extern const char *ThroughputModule32768_DataType_metaDescriptor[];
extern const int ThroughputModule32768_DataType_metaDescriptorArrLength;
extern const int ThroughputModule32768_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule32768_DataType__load (c_base base);
struct _ThroughputModule32768_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule32768_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule32768_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule32768_DataType {
    c_ulonglong count;
    c_octet payload[32768];
};

extern c_metaObject __LinuxMWtypes_ThroughputModule65536__load (c_base base);

extern const char *ThroughputModule65536_DataType_metaDescriptor[];
extern const int ThroughputModule65536_DataType_metaDescriptorArrLength;
extern const int ThroughputModule65536_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule65536_DataType__load (c_base base);
struct _ThroughputModule65536_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule65536_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule65536_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule65536_DataType {
    c_ulonglong count;
    c_octet payload[65536];
};

extern c_metaObject __LinuxMWtypes_ThroughputModule128K__load (c_base base);

extern const char *ThroughputModule128K_DataType_metaDescriptor[];
extern const int ThroughputModule128K_DataType_metaDescriptorArrLength;
extern const int ThroughputModule128K_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule128K_DataType__load (c_base base);
struct _ThroughputModule128K_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule128K_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule128K_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule128K_DataType {
    c_ulonglong count;
    c_octet payload[131072];
};

extern c_metaObject __LinuxMWtypes_ThroughputModule256K__load (c_base base);

extern const char *ThroughputModule256K_DataType_metaDescriptor[];
extern const int ThroughputModule256K_DataType_metaDescriptorArrLength;
extern const int ThroughputModule256K_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule256K_DataType__load (c_base base);
struct _ThroughputModule256K_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule256K_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule256K_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule256K_DataType {
    c_ulonglong count;
    c_octet payload[262144];
};

extern c_metaObject __LinuxMWtypes_ThroughputModule512K__load (c_base base);

extern const char *ThroughputModule512K_DataType_metaDescriptor[];
extern const int ThroughputModule512K_DataType_metaDescriptorArrLength;
extern const int ThroughputModule512K_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule512K_DataType__load (c_base base);
struct _ThroughputModule512K_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule512K_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule512K_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule512K_DataType {
    c_ulonglong count;
    c_octet payload[524288];
};

extern c_metaObject __LinuxMWtypes_ThroughputModule1M__load (c_base base);
extern const char *ThroughputModule1M_DataType_metaDescriptor[];
extern const int ThroughputModule1M_DataType_metaDescriptorArrLength;
extern const int ThroughputModule1M_DataType_metaDescriptorLength;
extern c_metaObject __ThroughputModule1M_DataType__load (c_base base);
struct _ThroughputModule1M_DataType ;
extern DDSCOMU_API v_copyin_result __ThroughputModule1M_DataType__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __ThroughputModule1M_DataType__copyOut(const void *_from, void *_to);
struct _ThroughputModule1M_DataType {
    c_ulonglong count;
    c_octet payload[1363149];
};
extern c_metaObject __LinuxMWtypes_LMWtopics__load (c_base base);

extern const char *LMWtopics_Req_PublishLog_metaDescriptor[];
extern const int LMWtopics_Req_PublishLog_metaDescriptorArrLength;
extern const int LMWtopics_Req_PublishLog_metaDescriptorLength;
extern c_metaObject __LMWtopics_Req_PublishLog__load (c_base base);
struct _LMWtopics_Req_PublishLog ;
extern DDSCOMU_API v_copyin_result __LMWtopics_Req_PublishLog__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __LMWtopics_Req_PublishLog__copyOut(const void *_from, void *_to);
struct _LMWtopics_Req_PublishLog {
    c_ulong status;
    c_char Date[12];
    c_char Time[12];
    c_char Loglevel[2];
    c_char LineNumStart[8];
    c_char LineNumEnd[8];
    c_char DateStart[12];
    c_char DateEnd[12];
    c_char FileName[256];
};

extern const char *LMWtopics_Log_metaDescriptor[];
extern const int LMWtopics_Log_metaDescriptorArrLength;
extern const int LMWtopics_Log_metaDescriptorLength;
extern c_metaObject __LMWtopics_Log__load (c_base base);
struct _LMWtopics_Log ;
extern DDSCOMU_API v_copyin_result __LMWtopics_Log__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __LMWtopics_Log__copyOut(const void *_from, void *_to);
struct _LMWtopics_Log {
    c_ulong seqNum;
    c_char LineNum[8];
    c_char Date[12];
    c_char Time[12];
    c_char Loglevel[2];
    c_char Logcode[8];
    c_char Message[256];
};

extern const char *LMWtopics_DeviceInfo_metaDescriptor[];
extern const int LMWtopics_DeviceInfo_metaDescriptorArrLength;
extern const int LMWtopics_DeviceInfo_metaDescriptorLength;
extern c_metaObject __LMWtopics_DeviceInfo__load (c_base base);
struct _LMWtopics_DeviceInfo ;
extern DDSCOMU_API v_copyin_result __LMWtopics_DeviceInfo__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __LMWtopics_DeviceInfo__copyOut(const void *_from, void *_to);
struct _LMWtopics_DeviceInfo {
    c_char Product_name[8];
    c_ulong Serial_num;
    c_char Product_code[8];
    c_char Manufacture_date[8];
    c_float Version;
    c_char Position_info[8];
    c_ulong DeviceId;
};

extern const char *LMWtopics_QoSPolicy_metaDescriptor[];
extern const int LMWtopics_QoSPolicy_metaDescriptorArrLength;
extern const int LMWtopics_QoSPolicy_metaDescriptorLength;
extern c_metaObject __LMWtopics_QoSPolicy__load (c_base base);
struct _LMWtopics_QoSPolicy ;
extern DDSCOMU_API v_copyin_result __LMWtopics_QoSPolicy__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __LMWtopics_QoSPolicy__copyOut(const void *_from, void *_to);
struct _LMWtopics_QoSPolicy {
    struct _TopicDataQosPolicy topic_data;
    struct _DeadlineQosPolicy deadline;
    struct _LatencyBudgetQosPolicy latency_budget;
    struct _TransportPriorityQosPolicy transport_priority;
    struct _LifespanQosPolicy lifespan;
};

extern const char *LMWtopics_RequestSysCtrl_metaDescriptor[];
extern const int LMWtopics_RequestSysCtrl_metaDescriptorArrLength;
extern const int LMWtopics_RequestSysCtrl_metaDescriptorLength;
extern c_metaObject __LMWtopics_RequestSysCtrl__load (c_base base);
struct _LMWtopics_RequestSysCtrl ;
extern DDSCOMU_API v_copyin_result __LMWtopics_RequestSysCtrl__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __LMWtopics_RequestSysCtrl__copyOut(const void *_from, void *_to);
struct _LMWtopics_RequestSysCtrl {
    c_ulong DeviceId;
    c_char Date[12];
    c_char Time[12];
    c_short Request_code;
    c_long value;
    c_char TopicName[256];
    struct _LMWtopics_QoSPolicy TopicQoS;
};

extern const char *LMWtopics_ResponseSysCtrl_metaDescriptor[];
extern const int LMWtopics_ResponseSysCtrl_metaDescriptorArrLength;
extern const int LMWtopics_ResponseSysCtrl_metaDescriptorLength;
extern c_metaObject __LMWtopics_ResponseSysCtrl__load (c_base base);
struct _LMWtopics_ResponseSysCtrl ;
extern DDSCOMU_API v_copyin_result __LMWtopics_ResponseSysCtrl__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __LMWtopics_ResponseSysCtrl__copyOut(const void *_from, void *_to);
struct _LMWtopics_ResponseSysCtrl {
    c_ulong DeviceId;
    c_char Date[12];
    c_char Time[12];
    c_short Request_code;
    c_short Execution_result_code;
    c_char TopicName[256];
    struct _LMWtopics_QoSPolicy TopicQoS;
};

extern const char *LMWtopics_ExtendQoSPolicy_metaDescriptor[];
extern const int LMWtopics_ExtendQoSPolicy_metaDescriptorArrLength;
extern const int LMWtopics_ExtendQoSPolicy_metaDescriptorLength;
extern c_metaObject __LMWtopics_ExtendQoSPolicy__load (c_base base);
struct _LMWtopics_ExtendQoSPolicy ;
extern DDSCOMU_API v_copyin_result __LMWtopics_ExtendQoSPolicy__copyIn(c_base base, const void *from, void *to);
extern DDSCOMU_API void __LMWtopics_ExtendQoSPolicy__copyOut(const void *_from, void *_to);
struct _LMWtopics_ExtendQoSPolicy {
    struct _ExtQoSPolicy ext_qos_policy;
};

#undef OS_API
#endif
