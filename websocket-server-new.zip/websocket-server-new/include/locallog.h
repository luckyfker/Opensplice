//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		:	locallog.h
//
//		DESCRIPTION :	Local log out library
//
//		CREATE ON	: 	V001.000 			Surendra.s 		11-27-2019		#0
//
//		MODIFIED ON	:
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef LOCALLOG_H
#define LOCALLOG_H
#include <stdbool.h>

#ifdef WIN32
#ifdef locallog_EXPORTS
#define LOCALLOG_API __declspec(dllexport)
#else
#define LOCALLOG_API __declspec(dllimport)
#endif
#else
#define LOCALLOG_API 
#endif

typedef enum log
{
    LogSuccess = 0,

    LogInvalidParameter,
    LogMaxRecordLimit,
    LogLevelLimit,
	LogSetLogFileNameFailed,

} LogStatus;

#ifdef __cplusplus

extern "C"
{
#endif

typedef void      *DDS_Sample;
typedef int (*SerializeSample)(char *, char *, DDS_Sample, char *, long *);
typedef int (*SerializeSequence)(char *, char *, DDS_Sample *, int, char *, long *);

/**************************************************************************************************************/
/*!
    @brief This function is used to initialize local log
    @param		: None
    @retval		: None
    @attention	: None
*/
/**************************************************************************************************************/
LOCALLOG_API void locallog_init();

/**************************************************************************************************************/
/*!
    @brief This function creates a file for logging the data. It should generate the file ID and it returns to the application layer
using FileID parameter.
    @param		: pFName : File name appended with path of the file
    @param		: FileID : File ID to identify the file
    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LOCALLOG_API LogStatus SetLogFileName(const char *pFName, short *FileID);

/**************************************************************************************************************/
/*!
    @brief The number of the maximum records of a log file is set up.
    @param		: FileID : File ID to identify the file
    @param		: MaxFileRcCount : This variable will decide the max records count to be allowed for the file
    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LOCALLOG_API LogStatus SetLogMaxRecCount(short FileID, long lRecMax);

/**************************************************************************************************************/
/*!
    @brief The log level allowed for a file is set using this function.
    @param		: FileID : File ID to identify the file
    @param		: LogLevel : Log level.
    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LOCALLOG_API LogStatus SetLogLevel(short FileID, short sLevel);

/**************************************************************************************************************/
/*!
    @brief A multithread exclusion function is initialized.
    @param		: FileID : File ID to identify the file
    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LOCALLOG_API LogStatus InitialLogSync(short FileID);

/**************************************************************************************************************/
/*!
    @brief A multithread exclusion function is initialized.
    @param		: FileID : File ID to identify the file
    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LOCALLOG_API LogStatus ReleaseLogSync(short FileID);

/**************************************************************************************************************/
/*!
    @brief A log is written into a log file. The files is identified by FileID.
    @param		: FileID : File ID to identify the file
    @param		: lineNum : This parameter indicates to the library to include a line number at the beginning of the log record.
    @param		: LogLevel : Log level.
    @param		: lpszFormat : String buffer to handle the log strings.
    @param		: ... : variable arguments.
    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LOCALLOG_API LogStatus WriteLogEx(short FileID, short bLineNo, short Level, const char *lpszFormat, ...);

/**************************************************************************************************************/
/*!
    @brief A log is written into a log file. The files is identified by FileID.
    @param		: FileID : File ID to identify the file
    @param		: lineNum : This parameter indicates to the library to include a line number at the beginning of the log record.
    @param		: LogLevel : Log level.
    @param		: lpszFormat : String buffer to handle the log strings.
    @param		: ... : variable arguments.
    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LOCALLOG_API LogStatus WriteDDSPubLog(short FileID, char *topicName, char *typeName, SerializeSample serializer, DDS_Sample *sample);
LOCALLOG_API LogStatus WriteDDSSubLog(short FileID, char *topicName, char *typeName, SerializeSequence serializer, DDS_Sample *sample, int index);
/**************************************************************************************************************/
/*!
    @brief A log is written into a log file. The files is identified by FileID.
    @param		: FileID : File ID to identify the file
    @param		: LogLevel : Log level.
    @param		: lpszFormat : String buffer to handle the log strings.
    @param		: ... : variable arguments.
    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LOCALLOG_API LogStatus WriteLog(short FileID, short Level, const char *lpszFormat, ...);

/**************************************************************************************************************/
/*!
    @brief This function is used to set the maximum file size of a log file.
    @param		: FileID : File ID to identify the file
    @param		: FileSize : This variable indicates the Max size of the file
    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LOCALLOG_API LogStatus SetLogFileMaxSize(short FileID, long FileSize);

#ifndef WIN32
/**************************************************************************************************************/
/*!
    @brief This function is used to set the Logfile output mode to cyclic or rotation
    @param		: FileID : File ID to identify the file
    @param		: Mode :  0 - Cyclic, 1- Rotation
    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LogStatus SetLogOutputMode(short FileID, short Mode);

/**************************************************************************************************************/
/*!
    @brief This function sets the Rotation setting parameters for a log file. It is applicable only if the Log file is enabled with Rotation mode.
    @param		: FileID : File ID to identify the file
    @param		: Weekly : A log rotation interval is specified(0-daily, 1-Weekly, 2-Month, 3-Hourly)
    @param		: Rotate : Log rotation count (ex: 5. i.e. retains up to 5 compressed logs)
    @param		: missingok : Condition - If true, missing a log file is acceptable. If false, error will be thrown when a log file is missing.
    @param		: Create : Condition - After performing log rotation, a new log file is created, if this parameter is true.	Nocompress (INPUT) (TBD) : Condition which says if compression for this file is required or not
    @param		: Postrotate : The path to script which should be executed after rotation
    @param		: size : Size if exceeded, rotation should be performed. Parameter is in KB (ex: 100 means 100KB)

    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LogStatus SetLogRoatateSetting(short FileID, short interval, short rotate_count, bool missingok, bool create, bool nocompress, char *postrotate, long size);
#endif

/**************************************************************************************************************/
/*!
    @brief A Ring buffer is created and a corresponding ID is generated.
    @param		: lpszFileName : A ring buffer corresponding log file.
    @param		: FileID : Ring buffer ID to be returned through this variable
    @param		: RingbuffAddr : Address of the ring buffer.
    @param		: Size : Size of the ring buffer is passed by caller.
    @param		: ringBuffID : Generated ring buffer address is stored here.
    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LOCALLOG_API LogStatus SetLogRingBuffer(short *FileID, const char *lpszFileName, char *RingbuffAddr, long size);

/**************************************************************************************************************/
/*!
    @brief This function sets the interval at which the content of a Ring buffer is outputted to its corresponding log file.
    @param		: FileID : File ID to identify the file
    @param		: Interval : Time interval to be followed to write it to the file periodically. In seconds
    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LOCALLOG_API LogStatus SetLogRingBufferInterval(short FileID, short interval);

/**************************************************************************************************************/
/*!
    @brief The data stored in the ring buffer is outputted to its corresponding log file.
    @param		: FileID : File ID to identify the file
    @retval		: Returns LogSuccess on success.
    @retval		: Returns LogFailed on failure.
    @attention	: None
*/
/**************************************************************************************************************/
LOCALLOG_API LogStatus OutputLogRingBuff(short FileID);

#ifdef __cplusplus

}
#endif

#endif // LOCALLOG_H
