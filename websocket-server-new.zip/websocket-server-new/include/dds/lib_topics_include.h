#ifndef __LIB_TOPICS_INCLUDE__
#define __LIB_TOPICS_INCLUDE__

#ifdef WIN32
#ifdef LIB_TOPICS_EXPORTS
#define LIB_TOPICS_API __declspec(dllexport) 
#else
#define LIB_TOPICS_API __declspec(dllimport) 
#endif
#else
#define LIB_TOPICS_API 
#endif

#endif