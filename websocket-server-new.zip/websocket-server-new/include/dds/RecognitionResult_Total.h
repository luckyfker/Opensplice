#if defined (__cplusplus)
extern "C" {
#endif

#include "RecognitionResult_TotalSacDcps.h"

#if defined (__cplusplus)
}
#endif
