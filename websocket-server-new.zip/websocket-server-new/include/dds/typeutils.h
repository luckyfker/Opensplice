//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    Copyright (C) 2019
//      TOSHIBA TEC CORPORATION,  ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    FILE    : type.h
//
//    DESCRIPTION : Implementation of functions that gets type related parameters to communication middle library
//
//    CREATEd ON :  10-12-2019, By: mythila/bhanu/raghava Version:V0.007         #0
//
//    MODIFIED ON : 14-12-2019
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __TYPEUTILS_H__
#define __TYPEUTILS_H__

#include <stdio.h>
#include "dds_dcps.h"

#ifdef WIN32
#define TYPEUTIL_API __declspec(dllexport)
#else
#define TYPEUTIL_API 
#endif

TYPEUTIL_API int finalTypeUtils();

TYPEUTIL_API int get_type_support(char* messageTypeName, DDS_TypeSupport *messageTypeSupport);

#endif