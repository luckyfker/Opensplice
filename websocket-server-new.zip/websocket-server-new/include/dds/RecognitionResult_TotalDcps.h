#ifndef RecognitionResult_TotalDCPS_H
#define RecognitionResult_TotalDCPS_H

#include <dds_primitive_types.h>

#include "lib_topics_include.h"
/* Definition for sequence of DDS_char */
#ifndef _DDS_sequence_char_defined
#define _DDS_sequence_char_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    DDS_char *_buffer;
    DDS_boolean _release;
} DDS_sequence_char;
LIB_TOPICS_API DDS_sequence_char *DDS_sequence_char__alloc (void);
LIB_TOPICS_API DDS_char *DDS_sequence_char_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_char_defined */
#define RecognitionResult_Total_sequence_char__alloc DDS_sequence_char__alloc
#define RecognitionResult_Total_sequence_char_allocbuf DDS_sequence_char_allocbuf

typedef DDS_sequence_char RecognitionResult_Total_seq_char;
LIB_TOPICS_API RecognitionResult_Total_seq_char *RecognitionResult_Total_seq_char__alloc (void);
LIB_TOPICS_API DDS_char *RecognitionResult_Total_seq_char_allocbuf (DDS_unsigned_long len);

#ifndef _RecognitionResult_Total_Data_defined
#define _RecognitionResult_Total_Data_defined
#ifdef __cplusplus
struct RecognitionResult_Total_Data;
#else /* __cplusplus */
typedef struct RecognitionResult_Total_Data RecognitionResult_Total_Data;
#endif /* __cplusplus */
#endif /* _RecognitionResult_Total_Data_defined */
LIB_TOPICS_API RecognitionResult_Total_Data *RecognitionResult_Total_Data__alloc (void);

struct RecognitionResult_Total_Data {
    DDS_string request_DeviceId;
    DDS_string request_CameraId;
    DDS_unsigned_long request_SeqNo;
    DDS_long response_Barcode_ResultCode;
    DDS_string response_Barcode_strRecognition;
    DDS_string response_Barcode_DeviceId;
    DDS_long response_PricereductionCut_ResultCode;
    DDS_string response_PricereductionCut_DeviceId;
    DDS_long response_Pricereduction_ResultCode;
    DDS_string response_Pricereduction_srtRecognition;
    DDS_string response_Pricereduction_DeviceId;
};

#endif
