#ifndef RecognitionResult_TotalSACDCPS_H
#define RecognitionResult_TotalSACDCPS_H

#include "dds_dcps.h"
#include "RecognitionResult_TotalDcps.h"

#ifndef DDS_API
#define DDS_API
#endif


#define RecognitionResult_Total_DataTypeSupport DDS_TypeSupport

LIB_TOPICS_API RecognitionResult_Total_DataTypeSupport
RecognitionResult_Total_DataTypeSupport__alloc (
    void
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataTypeSupport_register_type (
    RecognitionResult_Total_DataTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

LIB_TOPICS_API DDS_string
RecognitionResult_Total_DataTypeSupport_get_type_name (
    RecognitionResult_Total_DataTypeSupport _this
    );

#ifndef _DDS_sequence_RecognitionResult_Total_Data_defined
#define _DDS_sequence_RecognitionResult_Total_Data_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    RecognitionResult_Total_Data *_buffer;
    DDS_boolean _release;
} DDS_sequence_RecognitionResult_Total_Data;

LIB_TOPICS_API DDS_sequence_RecognitionResult_Total_Data *DDS_sequence_RecognitionResult_Total_Data__alloc (void);
LIB_TOPICS_API RecognitionResult_Total_Data *DDS_sequence_RecognitionResult_Total_Data_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_RecognitionResult_Total_Data_defined */

#define RecognitionResult_Total_DataDataWriter DDS_DataWriter

#define RecognitionResult_Total_DataDataWriter_enable DDS_Entity_enable

#define RecognitionResult_Total_DataDataWriter_get_status_changes DDS_Entity_get_status_changes

#define RecognitionResult_Total_DataDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define RecognitionResult_Total_DataDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define RecognitionResult_Total_DataDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define RecognitionResult_Total_DataDataWriter_get_listener DDS_DataWriter_get_listener

#define RecognitionResult_Total_DataDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define RecognitionResult_Total_DataDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define RecognitionResult_Total_DataDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define RecognitionResult_Total_DataDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define RecognitionResult_Total_DataDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define RecognitionResult_Total_DataDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define RecognitionResult_Total_DataDataWriter_get_publisher DDS_DataWriter_get_publisher

#define RecognitionResult_Total_DataDataWriter_get_qos DDS_DataWriter_get_qos

#define RecognitionResult_Total_DataDataWriter_get_topic DDS_DataWriter_get_topic

#define RecognitionResult_Total_DataDataWriter_set_listener DDS_DataWriter_set_listener

#define RecognitionResult_Total_DataDataWriter_set_qos DDS_DataWriter_set_qos

LIB_TOPICS_API DDS_InstanceHandle_t
RecognitionResult_Total_DataDataWriter_register_instance (
    RecognitionResult_Total_DataDataWriter _this,
    const RecognitionResult_Total_Data *instance_data
    );

LIB_TOPICS_API DDS_InstanceHandle_t
RecognitionResult_Total_DataDataWriter_register_instance_w_timestamp (
    RecognitionResult_Total_DataDataWriter _this,
    const RecognitionResult_Total_Data *instance_data,
    const DDS_Time_t *source_timestamp
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataWriter_unregister_instance (
    RecognitionResult_Total_DataDataWriter _this,
    const RecognitionResult_Total_Data *instance_data,
    const DDS_InstanceHandle_t handle
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataWriter_unregister_instance_w_timestamp (
    RecognitionResult_Total_DataDataWriter _this,
    const RecognitionResult_Total_Data *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataWriter_write (
    RecognitionResult_Total_DataDataWriter _this,
    const RecognitionResult_Total_Data *instance_data,
    const DDS_InstanceHandle_t handle
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataWriter_write_w_timestamp (
    RecognitionResult_Total_DataDataWriter _this,
    const RecognitionResult_Total_Data *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataWriter_dispose (
    RecognitionResult_Total_DataDataWriter _this,
    const RecognitionResult_Total_Data *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataWriter_dispose_w_timestamp (
    RecognitionResult_Total_DataDataWriter _this,
    const RecognitionResult_Total_Data *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataWriter_writedispose (
    RecognitionResult_Total_DataDataWriter _this,
    const RecognitionResult_Total_Data *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataWriter_writedispose_w_timestamp (
    RecognitionResult_Total_DataDataWriter _this,
    const RecognitionResult_Total_Data *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataWriter_get_key_value (
    RecognitionResult_Total_DataDataWriter _this,
    RecognitionResult_Total_Data *key_holder,
    const DDS_InstanceHandle_t handle
    );

LIB_TOPICS_API DDS_InstanceHandle_t
RecognitionResult_Total_DataDataWriter_lookup_instance (
    RecognitionResult_Total_DataDataWriter _this,
    const RecognitionResult_Total_Data *key_holder
    );

#define RecognitionResult_Total_DataDataReader DDS_DataReader

#define RecognitionResult_Total_DataDataReader_enable DDS_Entity_enable

#define RecognitionResult_Total_DataDataReader_get_status_changes DDS_Entity_get_status_changes

#define RecognitionResult_Total_DataDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define RecognitionResult_Total_DataDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define RecognitionResult_Total_DataDataReader_create_querycondition DDS_DataReader_create_querycondition

#define RecognitionResult_Total_DataDataReader_create_readcondition DDS_DataReader_create_readcondition

#define RecognitionResult_Total_DataDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define RecognitionResult_Total_DataDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define RecognitionResult_Total_DataDataReader_get_listener DDS_DataReader_get_listener

#define RecognitionResult_Total_DataDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define RecognitionResult_Total_DataDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define RecognitionResult_Total_DataDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define RecognitionResult_Total_DataDataReader_get_qos DDS_DataReader_get_qos

#define RecognitionResult_Total_DataDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define RecognitionResult_Total_DataDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define RecognitionResult_Total_DataDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define RecognitionResult_Total_DataDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define RecognitionResult_Total_DataDataReader_get_subscriber DDS_DataReader_get_subscriber

#define RecognitionResult_Total_DataDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define RecognitionResult_Total_DataDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define RecognitionResult_Total_DataDataReader_set_listener DDS_DataReader_set_listener

#define RecognitionResult_Total_DataDataReader_set_qos DDS_DataReader_set_qos

#define RecognitionResult_Total_DataDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_read (
    RecognitionResult_Total_DataDataReader _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_take (
    RecognitionResult_Total_DataDataReader _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_read_w_condition (
    RecognitionResult_Total_DataDataReader _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_take_w_condition (
    RecognitionResult_Total_DataDataReader _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_read_next_sample (
    RecognitionResult_Total_DataDataReader _this,
    RecognitionResult_Total_Data *received_data,
    DDS_SampleInfo *sample_info
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_take_next_sample (
    RecognitionResult_Total_DataDataReader _this,
    RecognitionResult_Total_Data *received_data,
    DDS_SampleInfo *sample_info
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_read_instance (
    RecognitionResult_Total_DataDataReader _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_take_instance (
    RecognitionResult_Total_DataDataReader _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_read_next_instance (
    RecognitionResult_Total_DataDataReader _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_take_next_instance (
    RecognitionResult_Total_DataDataReader _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_read_next_instance_w_condition (
    RecognitionResult_Total_DataDataReader _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_take_next_instance_w_condition (
    RecognitionResult_Total_DataDataReader _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_return_loan (
    RecognitionResult_Total_DataDataReader _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReader_get_key_value (
    RecognitionResult_Total_DataDataReader _this,
    RecognitionResult_Total_Data *key_holder,
    const DDS_InstanceHandle_t handle
    );

LIB_TOPICS_API DDS_InstanceHandle_t
RecognitionResult_Total_DataDataReader_lookup_instance (
    RecognitionResult_Total_DataDataReader _this,
    const RecognitionResult_Total_Data *key_holder
    );

#define RecognitionResult_Total_DataDataReaderView DDS_DataReaderView

#define RecognitionResult_Total_DataDataReaderView_enable DDS_Entity_enable

#define RecognitionResult_Total_DataDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define RecognitionResult_Total_DataDataReaderView_get_qos DDS_DataReaderView_get_qos

#define RecognitionResult_Total_DataDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define RecognitionResult_Total_DataDataReaderView_set_qos DDS_DataReaderView_set_qos

#define RecognitionResult_Total_DataDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define RecognitionResult_Total_DataDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define RecognitionResult_Total_DataDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define RecognitionResult_Total_DataDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_read (
    RecognitionResult_Total_DataDataReaderView _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_take (
    RecognitionResult_Total_DataDataReaderView _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_read_next_sample (
    RecognitionResult_Total_DataDataReaderView _this,
    RecognitionResult_Total_Data *received_data,
    DDS_SampleInfo *sample_info
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_take_next_sample (
    RecognitionResult_Total_DataDataReaderView _this,
    RecognitionResult_Total_Data *received_data,
    DDS_SampleInfo *sample_info
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_read_instance (
    RecognitionResult_Total_DataDataReaderView _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_take_instance (
    RecognitionResult_Total_DataDataReaderView _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_read_next_instance (
    RecognitionResult_Total_DataDataReaderView _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_take_next_instance (
    RecognitionResult_Total_DataDataReaderView _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_return_loan (
    RecognitionResult_Total_DataDataReaderView _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_read_w_condition (
    RecognitionResult_Total_DataDataReaderView _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_take_w_condition (
    RecognitionResult_Total_DataDataReaderView _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_read_next_instance_w_condition (
    RecognitionResult_Total_DataDataReaderView _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_take_next_instance_w_condition (
    RecognitionResult_Total_DataDataReaderView _this,
    DDS_sequence_RecognitionResult_Total_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

LIB_TOPICS_API DDS_ReturnCode_t
RecognitionResult_Total_DataDataReaderView_get_key_value (
    RecognitionResult_Total_DataDataReaderView _this,
    RecognitionResult_Total_Data *key_holder,
    const DDS_InstanceHandle_t handle
    );

LIB_TOPICS_API DDS_InstanceHandle_t
RecognitionResult_Total_DataDataReaderView_lookup_instance (
    RecognitionResult_Total_DataDataReaderView _this,
    RecognitionResult_Total_Data *key_holder
    );

#endif
