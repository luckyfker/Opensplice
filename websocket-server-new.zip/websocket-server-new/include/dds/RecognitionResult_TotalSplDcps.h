#ifndef RecognitionResult_TotalSPLTYPES_H
#define RecognitionResult_TotalSPLTYPES_H

#include <c_base.h>
#include <c_misc.h>
#include <c_sync.h>
#include <c_collection.h>
#include <c_field.h>
#include <v_copyIn.h>

#include "RecognitionResult_TotalDcps.h"
#include "lib_topics_include.h"

extern c_metaObject __RecognitionResult_Total_RecognitionResult_Total__load (c_base base);

extern c_metaObject __RecognitionResult_Total_seq_char__load (c_base base);
typedef c_sequence _RecognitionResult_Total_seq_char;

extern const char *RecognitionResult_Total_Data_metaDescriptor[];
extern const int RecognitionResult_Total_Data_metaDescriptorArrLength;
extern const int RecognitionResult_Total_Data_metaDescriptorLength;
extern c_metaObject __RecognitionResult_Total_Data__load (c_base base);
struct _RecognitionResult_Total_Data ;
extern LIB_TOPICS_API v_copyin_result __RecognitionResult_Total_Data__copyIn(c_base base, const void *from, void *to);
extern LIB_TOPICS_API void __RecognitionResult_Total_Data__copyOut(const void *_from, void *_to);
struct _RecognitionResult_Total_Data {
    c_string request_DeviceId;
    c_string request_CameraId;
    c_ulong request_SeqNo;
    c_long response_Barcode_ResultCode;
    c_string response_Barcode_strRecognition;
    c_string response_Barcode_DeviceId;
    c_long response_PricereductionCut_ResultCode;
    c_string response_PricereductionCut_DeviceId;
    c_long response_Pricereduction_ResultCode;
    c_string response_Pricereduction_srtRecognition;
    c_string response_Pricereduction_DeviceId;
};

#undef OS_API
#endif
