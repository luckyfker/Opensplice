////////////////////////////////////////////////////////////////////////////
//	Copyright (C) 2020
//	TOSHIBA TEC CORPORATION All Right Reserved
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//	FILE		:	comm_middle_lib.h
//	DESCRIPTION	:	comm_middle shared memory library header, This file contain all
//					the	comm_middle shared memory macros and variable.
//
//	CREATE ON	:	V001.000	Yashas D G[TSIP]				2021.02.04
//
//	MODIFIED ON	:	V002.000	Subham Das[TSIP]				2021.03.16
//	MODIFIED ON	:	V003.000	Yashas D G[TSIP]				2021.03.25(Windows Compatible)
////////////////////////////////////////////////////////////////////////////

#ifndef INCLUDE_COMMON_SHM_H_
#define INCLUDE_COMMON_SHM_H_

#ifdef _WIN32
#include "pch.h"
#endif

/***************************************************************************
 *	Macro Definition
****************************************************************************/
#ifdef WIN32
#define CMULONG unsigned long long
#else
#define CMULONG unsigned long
#endif
#define PERM 0777							/* value for the permission */
#define FTOK_PROJ_ID 65						/* Ftok unique value */
/***************************************************************************
 *	Structure and Enum Definition
****************************************************************************/
/* Shared memory state */
typedef enum
{
	IDLE,									/* Shared memory not in any state */
	ATTACHED,								/* Shared memory in attached state */
	DETACHED								/* Shared memory in detached state */
}state_t;

/* Shared memory return status */
typedef enum
{
	SHM_DEFAULT = -1,						/* Shared memory default values */
	SHM_SUCCESS = 0, 						/* Shared memory functionality is success */
	SHM_NOT_SUCCESS, 						/* Shared memory functionality is not success */
	SHM_SEM_ERROR,							/* Semaphore error */
	SHM_KEY_FILE_PATH_ERROR,				/* Requested key file path is valid but not present in the location */
	SHM_KEY_FILE_PATH_NULL_ERROR,			/* Requested key file path is not valid */
	SHM_TBL_INDEX_NULL_ERROR,				/* Requested shm index is not valid */
	SHM_ALREADY_DETACHED_ERROR,				/* Requested to detach shared memory Already in detached state */
	SHM_INIT_ERROR, 						/* Shared memory is not initialized/created */
	SHM_INVALID_MEM_SIZE_ERROR, 			/* Invalid shared memory size error */
	SHM_TBL_INDEX_ERROR, 					/* Invalid Table index error */
	SHM_NOT_DETACHED_ERROR,					/* Shared Memory is not dttached but requested to remove/clear */
	SHM_FTOK_ERROR, 						/* shared memory ftok() error */
	SHM_SHMGET_ERROR, 						/* shared memory shmget() error */
	SHM_SHMAT_ERROR, 						/* shared memory shmat() error */
	SHM_SHMDT_ERROR, 						/* Shared memory shmdt() error */
	SHM_SHMCTL_ERROR,						/* Shared memory shmctl() error */
	SHM_DATA_BLOCK_INFO_NULL_ERROR,			/* If requestest dataBlockInfo_t reference address is not valid */
	SHM_DATA_NOT_AVAILABLE_ERROR,			/* No data is available in the shared memmory */
	SHM_DATA_SIZE_NULL_ERROR,				/* Input data size reference address is not valid */
	SHM_DATA_BUFFER_NULL_ERROR,				/* Input data buffer reference address is not valid */
	SHM_DATA_BLOCK_OVERFLOW_ERROR,			/* Requested data block location is more than the available data block */
	SHM_INVALID_DATA_SIZE_ERROR,			/* Data size is not valid or out of range */
	SHM_DATA_BLOCK_LOC_ERROR,				/* Data location is invalid*/
	SHM_WRITE_UPDATE_DATA_SIZE_ERROR,		/* Data size to write and update is more than the accomodate size*/
	SHM_DATA_READ_OFFSET_NOT_AVAILABLE_ERROR,/* If shmLatestRead() or getInfo() API is not called for setting last read offset value */
    SHM_REALLOC_ERROR						/* In some rare cases call to 'realloc()' might return NULL. */
}shmSts_t;

/* Data block address and sequence info structure */
typedef struct
{
     CMULONG dataBlockOffset;			/* Data block Offset value from the shared memory starting address */
     CMULONG seqNo;					/* Sequence number for any data block */
}dataBlockInfo_t;

/* Shared memory Header structure */
typedef struct
{
	CMULONG topDataBlockOffset;		/* Top data block Offset value from the shared memory starting address */
	CMULONG bottomDataBlockOffset;	/* Bottom data block Offset value from the shared memory starting address */
}shmHeader_t;

/* Data Block header */
typedef struct
{
	CMULONG previousDataBlockOffset; 	/* Stores the previous block Offset value from the shared memory starting address */
	CMULONG nextDataBlockOffset; 		/* Stores the next block Offset value from the shared memory starting address */
	CMULONG sequenceNumber; 			/* Stores the respective sequence number */
	CMULONG dataSize;  				/* Stores the dataSize */
}dataBlockHeader_t;

/*Shared memory table*/
typedef struct
{
#ifdef _WIN32
	HANDLE shmid; 								/* Handle to shared memory segment */
	HANDLE semid; 								/* Handle to semaphore used along with the shared memory */
	LPCTSTR shmAddress;						/* Pointer pointing to shared memory Address */
#else
	int shmid; 								/* stores shmId for the shared memory */
	int semid; 								/* stores semaphore Id  for the shared memory */
	void *shmAddress;						/* Pointer for attaching shared memory Address */
#endif
	CMULONG shmMemSize;				/* Shared memory size */
	state_t  state;							/* Indicates the state - (IDLE = 0 / ATTACHED = 1 / DETACHED = 2 )*/
	CMULONG lastReadOffset;			/* Last read data block Offset value from the shared memory starting address */
}shmTbl_t;

/***************************************************************************
 *	Function Declaration
****************************************************************************/
// The windows specific function declarations are declared in SharedLib.h header file, so these are hidden for windows here.
#ifndef _WIN32
shmSts_t shmInit(const char *keyFilePath, CMULONG shmMemSize, unsigned int *shmTblIndex);
shmSts_t shmDeinit(unsigned int shmTblIndex);
shmSts_t shmClear(unsigned int shmTblIndex);
shmSts_t shmGetInfo(unsigned int shmTblIndex, dataBlockInfo_t *dataBlockInfo);
shmSts_t shmDelete(unsigned int shmTblIndex, const dataBlockInfo_t *dataBlockInfo);
shmSts_t shmRead(unsigned int shmTblIndex, void *rData, CMULONG *dataSize, const dataBlockInfo_t *dataBlockInfo, int dataBlockLoc);
shmSts_t shmReadLatest(unsigned int shmTblIndex, void *rData, CMULONG *dataSize);
shmSts_t shmWrite(unsigned int shmTblIndex, const void *wData, CMULONG dataSize, int dataBlockLoc);
shmSts_t shmWriteLatest(unsigned int shmTblIndex, const void *wData, CMULONG dataSize);
shmSts_t shmTblFree(void);
#else
// The 'PROJECT_EXPORTS' macro is automatically added with the project template.
// So, in the DLL the macro exports the APIs. And when this header is used in client projects,
// the macro will import the APIs.
#ifdef SHAREDLIB_EXPORTS
#define SHAREDLIB_API __declspec(dllexport)
#else
#define SHAREDLIB_API __declspec(dllimport)
#endif

SHAREDLIB_API shmSts_t shmInit(const char* keyFilePath, CMULONG shmMemSize, unsigned int* shmTblIndex);
SHAREDLIB_API shmSts_t shmDeinit(unsigned int shmTblIndex);
SHAREDLIB_API shmSts_t shmClear(unsigned int shmTblIndex);
SHAREDLIB_API shmSts_t shmGetInfo(unsigned int shmTblIndex, dataBlockInfo_t *dataBlockInfo);
SHAREDLIB_API shmSts_t shmDelete(unsigned int shmTblIndex, const dataBlockInfo_t *dataBlockInfo);
SHAREDLIB_API shmSts_t shmRead(unsigned int shmTblIndex, void* rData, CMULONG *dataSize, const dataBlockInfo_t *dataBlockInfo, int dataBlockLoc);
SHAREDLIB_API shmSts_t shmReadLatest(unsigned int shmTblIndex, void* rData, CMULONG *dataSize);
SHAREDLIB_API shmSts_t shmWrite(unsigned int shmTblIndex, const void* wData, CMULONG dataSize, int dataBlockLoc);
SHAREDLIB_API shmSts_t shmWriteLatest(unsigned int shmTblIndex, const void* wData, CMULONG dataSize);

#endif // !__WIN32
#endif /* INCLUDE_COMMON_SHM_H_ */
