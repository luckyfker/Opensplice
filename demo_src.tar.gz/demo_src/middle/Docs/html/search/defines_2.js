var searchData=
[
  ['bool',['BOOL',['../common_8h.html#ae4cc35dcc70810fa972cc8a5185a28fa',1,'BOOL():&#160;common.h'],['../setmemory_8h.html#ae4cc35dcc70810fa972cc8a5185a28fa',1,'BOOL():&#160;setmemory.h']]],
  ['buf_5fsize',['BUF_SIZE',['../macros_8h.html#a6821bafc3c88dfb2e433a095df9940c6',1,'macros.h']]]
];
