var searchData=
[
  ['ownershipqoskind',['OwnershipQoSKind',['../com__middle_8h.html#a166e92d847d1296b8ebd23e50dd05b49',1,'com_middle.h']]]
];
