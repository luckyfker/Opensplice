var searchData=
[
  ['b',['b',['../structInput__Data.html#a6d85cdce863db9e038adb8c7faabc614',1,'Input_Data::b()'],['../struct__Input__Data.html#acef52849165eeb21ba7058f56cc1f24b',1,'_Input_Data::b()']]],
  ['besteffort_5freliability',['BESTEFFORT_RELIABILITY',['../com__middle_8h.html#a6fe9671c41493049311dc7f5f25a62a4a6e8213c077c02d4df42755a8a398570b',1,'com_middle.h']]],
  ['bool',['BOOL',['../common_8h.html#ae4cc35dcc70810fa972cc8a5185a28fa',1,'BOOL():&#160;common.h'],['../setmemory_8h.html#ae4cc35dcc70810fa972cc8a5185a28fa',1,'BOOL():&#160;setmemory.h']]],
  ['buf_5fsize',['BUF_SIZE',['../macros_8h.html#a6821bafc3c88dfb2e433a095df9940c6',1,'macros.h']]]
];
