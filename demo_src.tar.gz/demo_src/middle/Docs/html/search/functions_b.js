var searchData=
[
  ['notifyclearbuffer',['NotifyClearBuffer',['../com__middle_8h.html#a9dd85eee941d586d40797f2b09120543',1,'com_middle.h']]],
  ['notifyflushbuffer',['NotifyFlushBuffer',['../com__middle_8h.html#ac84da43cd34f2f21b93c7ff92f9cdc0f',1,'com_middle.h']]]
];
