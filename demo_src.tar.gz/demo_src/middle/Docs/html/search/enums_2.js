var searchData=
[
  ['historyqoskind_5ft',['HistoryQoSKind_t',['../com__middle_8h.html#adcea68241cf1c3d33938610ffeb074b5',1,'com_middle.h']]]
];
