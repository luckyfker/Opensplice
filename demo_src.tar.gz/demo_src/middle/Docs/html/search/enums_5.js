var searchData=
[
  ['parms',['parms',['../sensor__ext_8h.html#a2f89f57843ff897ab4ff5140716d0b8b',1,'sensor_ext.h']]]
];
