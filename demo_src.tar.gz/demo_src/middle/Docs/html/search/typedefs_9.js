var searchData=
[
  ['parsedlogdata_5ft',['parsedLogData_t',['../local__log__out__with__dds_8h.html#a31eff09e1177604aa1c8e4bdef4ce865',1,'local_log_out_with_dds.h']]]
];
