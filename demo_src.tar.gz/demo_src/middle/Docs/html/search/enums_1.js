var searchData=
[
  ['durabilityqoskind_5ft',['DurabilityQoSKind_t',['../com__middle_8h.html#a95289f5755c3e0c419e777af6eab2af7',1,'com_middle.h']]]
];
