var searchData=
[
  ['nwiname',['nwIName',['../nw__types_8h.html#a73da93a612cfd6afbe8e850f8c56fda6',1,'nw_types.h']]]
];
