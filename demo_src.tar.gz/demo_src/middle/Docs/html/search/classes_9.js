var searchData=
[
  ['parsedlogdata',['parsedLogData',['../structparsedLogData.html',1,'']]]
];
