var searchData=
[
  ['transient_5fdurability',['TRANSIENT_DURABILITY',['../com__middle_8h.html#a95289f5755c3e0c419e777af6eab2af7ad49f45701a4a74dd7c839755a84c94aa',1,'com_middle.h']]],
  ['transientlocal_5fdurability',['TRANSIENTLOCAL_DURABILITY',['../com__middle_8h.html#a95289f5755c3e0c419e777af6eab2af7ab08cc94da695e03584178fd849b7dbf7',1,'com_middle.h']]]
];
