var searchData=
[
  ['keepall_5fhistory',['KEEPALL_HISTORY',['../com__middle_8h.html#adcea68241cf1c3d33938610ffeb074b5a12e9f65c788e2b6102dcb08d6c9d4ec2',1,'com_middle.h']]],
  ['keeplast_5fhistory',['KEEPLAST_HISTORY',['../com__middle_8h.html#adcea68241cf1c3d33938610ffeb074b5a3f1e6cb9c340a9197c125c21c4cac650',1,'com_middle.h']]]
];
