var searchData=
[
  ['volatile_5fdurability',['VOLATILE_DURABILITY',['../com__middle_8h.html#a95289f5755c3e0c419e777af6eab2af7accc7391700e951b8e62a020fe3ef09ef',1,'com_middle.h']]]
];
