var searchData=
[
  ['shared',['SHARED',['../com__middle_8h.html#a5fc250716b9c24ce6c7e307e04adeb11a9c46e16a4ab019339596acadeefc8c53',1,'com_middle.h']]]
];
