var searchData=
[
  ['besteffort_5freliability',['BESTEFFORT_RELIABILITY',['../com__middle_8h.html#a6fe9671c41493049311dc7f5f25a62a4a6e8213c077c02d4df42755a8a398570b',1,'com_middle.h']]]
];
