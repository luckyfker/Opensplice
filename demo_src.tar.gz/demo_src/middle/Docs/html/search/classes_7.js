var searchData=
[
  ['name',['name',['../structname.html',1,'']]]
];
