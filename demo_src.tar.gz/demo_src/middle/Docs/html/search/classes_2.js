var searchData=
[
  ['filelist',['filelist',['../structfilelist.html',1,'']]],
  ['ftpinfo',['ftpInfo',['../structftpInfo.html',1,'']]]
];
