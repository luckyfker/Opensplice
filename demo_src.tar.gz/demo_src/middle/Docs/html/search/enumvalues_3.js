var searchData=
[
  ['ddsdatareaderdeletereadconditionfailed',['DDSDataReaderDeleteReadConditionFailed',['../com__middle_8h.html#a7b6eb85309713636de1e95aa11c43838a11705c2cfcc3b829d7742103b54a2287',1,'com_middle.h']]],
  ['decrement',['DECREMENT',['../com__middle_8h.html#aa1a0b563887f2607eeeb206329ab5fbaacd27a3a13d233019cec19a2423d65a84',1,'com_middle.h']]]
];
