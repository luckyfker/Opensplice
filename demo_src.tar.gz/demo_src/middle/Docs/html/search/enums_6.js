var searchData=
[
  ['rbeventtype',['rbEventType',['../com__middle_8h.html#a6c275a5b3e80a3a16f1a4998f4133bf3',1,'com_middle.h']]],
  ['reliabilityqoskind_5ft',['ReliabilityQoSKind_t',['../com__middle_8h.html#a6fe9671c41493049311dc7f5f25a62a4',1,'com_middle.h']]]
];
