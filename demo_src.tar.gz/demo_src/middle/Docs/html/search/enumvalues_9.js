var searchData=
[
  ['opt_5ferase',['OPT_ERASE',['../sf__types_8h.html#a3cfe71f40b244562d3665516c3934c06aa5a41f652b59fc4667167c9941e4fe97',1,'sf_types.h']]],
  ['opt_5finfo',['OPT_INFO',['../sf__types_8h.html#a3cfe71f40b244562d3665516c3934c06ad7b81f3fb036a94daaa9b07df168ca12',1,'sf_types.h']]],
  ['opt_5fread',['OPT_READ',['../sf__types_8h.html#a3cfe71f40b244562d3665516c3934c06a0967e205ef61623ae88f74a2ec19ef72',1,'sf_types.h']]],
  ['opt_5fwrite',['OPT_WRITE',['../sf__types_8h.html#a3cfe71f40b244562d3665516c3934c06ad72ac1454c5a4666793860db240eee95',1,'sf_types.h']]]
];
