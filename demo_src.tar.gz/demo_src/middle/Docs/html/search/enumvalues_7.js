var searchData=
[
  ['manual_5fby_5ftopic',['MANUAL_BY_TOPIC',['../com__middle_8h.html#a986742580fae585b149dfa8e5754886da704dc9e652bce3dc4b027e2670d4160e',1,'com_middle.h']]]
];
