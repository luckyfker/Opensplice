var searchData=
[
  ['qos_5fpolicy',['QoS_Policy',['../com__middle_8h.html#a12d336e30d38287558f94463267ccc15',1,'com_middle.h']]]
];
