var searchData=
[
  ['writerid',['writerID',['../structlogSettingsLWD.html#a5db809af4e8e22a102ab6294cba82d21',1,'logSettingsLWD']]],
  ['writesize',['writeSize',['../structmtdInfoStruct.html#aab06dbf88fcbfa73c73d764a8b3d2ccb',1,'mtdInfoStruct']]]
];
