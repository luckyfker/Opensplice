var searchData=
[
  ['option',['option',['../sf__types_8h.html#a3cfe71f40b244562d3665516c3934c06',1,'sf_types.h']]],
  ['ownershipqoskind_5ft',['OwnershipQoSKind_t',['../com__middle_8h.html#a5fc250716b9c24ce6c7e307e04adeb11',1,'com_middle.h']]]
];
