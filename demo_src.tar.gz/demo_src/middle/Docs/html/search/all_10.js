var searchData=
[
  ['qos_5fpolicy',['QoS_Policy',['../structQoS__Policy.html',1,'QoS_Policy'],['../com__middle_8h.html#a12d336e30d38287558f94463267ccc15',1,'QoS_Policy():&#160;com_middle.h']]],
  ['qosfilename',['QoSFileName',['../structlogSettingsLWD.html#a2b3298d379c0c34283c50becb786a3d2',1,'logSettingsLWD']]]
];
