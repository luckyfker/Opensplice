var searchData=
[
  ['allocsharedmemory',['allocSharedMemory',['../rfcommon_8h.html#af4dff62ae0bcb4b677877dd2e9896be3',1,'rfcommon.h']]]
];
