var searchData=
[
  ['name',['name',['../structRFS__THREAD__CTRL.html#a3f2cf814d73dbf96691969688e97538b',1,'RFS_THREAD_CTRL']]],
  ['nanosec',['nanosec',['../structDuration.html#aa77d744fef4a84caaf8b805dfa0d1a79',1,'Duration::nanosec()'],['../struct__Duration.html#a1a78eb71a83824005301e28803d35d23',1,'_Duration::nanosec()']]]
];
