var searchData=
[
  ['setmemory',['SetMemory',['../classSetMemory.html',1,'']]],
  ['setthreshold',['setthreshold',['../structsetthreshold.html',1,'']]],
  ['settings',['settings',['../structsettings.html',1,'']]],
  ['statusstruct',['statusStruct',['../structstatusStruct.html',1,'']]]
];
