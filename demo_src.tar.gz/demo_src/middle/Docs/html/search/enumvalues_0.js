var searchData=
[
  ['autodispose_5ffalse',['AUTODISPOSE_FALSE',['../com__middle_8h.html#a3b2dd25889b48ff4c92e613dd3fec155afa48673268ac85a945f37cb7677b91d5',1,'com_middle.h']]],
  ['autodispose_5ftrue',['AUTODISPOSE_TRUE',['../com__middle_8h.html#a3b2dd25889b48ff4c92e613dd3fec155ae3991a5e7a1c4442f63950cd4fee3232',1,'com_middle.h']]],
  ['automatic',['AUTOMATIC',['../com__middle_8h.html#a986742580fae585b149dfa8e5754886da0a831c2bc18e8354fe3e30ec0f3cdcda',1,'com_middle.h']]]
];
