var searchData=
[
  ['ftpinfostruct',['ftpInfoStruct',['../nw__types_8h.html#a76c64c3f30b1f77c68e3b2431ed8eda4',1,'nw_types.h']]],
  ['ftpsettinsstruct',['ftpSettinsStruct',['../nw__types_8h.html#ab7e1a3adc9207c1be559828489c9f229',1,'nw_types.h']]]
];
