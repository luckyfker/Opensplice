var searchData=
[
  ['b',['b',['../structInput__Data.html#a6d85cdce863db9e038adb8c7faabc614',1,'Input_Data::b()'],['../struct__Input__Data.html#acef52849165eeb21ba7058f56cc1f24b',1,'_Input_Data::b()']]]
];
