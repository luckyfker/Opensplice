#!/bin/sh
idlpp -l c CameraImage.idl
idlpp -l c RecognitionResult_Barcode.idl
idlpp -l c RecognitionResult_Pricereduction.idl
idlpp -l c RecognitionResult_PricereductionCut.idl
idlpp -l c RecognitionResult_Total.idl
idlpp -l c DeviceInfo.idl

# add 20B
idlpp -l c CameraRawImage.idl
idlpp -l c FpgaImage.idl
idlpp -l c DisplayImage.idl
idlpp -l c RecognitionResult_PricereductionCutCode.idl

# add 20B
mv CameraRawImage*.c ../src/dds_type/camera_raw_image
mv CameraRawImage*.h ../src/dds_type/camera_raw_image

mv FpgaImage*.c ../src/dds_type/fpga_image
mv FpgaImage*.h ../src/dds_type/fpga_image

mv DisplayImage*.c ../src/dds_type/display_image
mv DisplayImage*.h ../src/dds_type/display_image

mv RecognitionResult_PricereductionCutCode*.c ../src/dds_type/price_reduction_cut_code
mv RecognitionResult_PricereductionCutCode*.h ../src/dds_type/price_reduction_cut_code

#rm -f ../src/dds_type/*/*
mv CameraImage*.c ../src/dds_type/camera_image
mv CameraImage*.h ../src/dds_type/camera_image

mv RecognitionResult_Barcode*.c ../src/dds_type/barcode_recognition
mv RecognitionResult_Barcode*.h ../src/dds_type/barcode_recognition

mv RecognitionResult_PricereductionCut*.c ../src/dds_type/price_reduction_cut
mv RecognitionResult_PricereductionCut*.h ../src/dds_type/price_reduction_cut

mv RecognitionResult_Pricereduction*.c ../src/dds_type/price_reduction_recognition
mv RecognitionResult_Pricereduction*.h ../src/dds_type/price_reduction_recognition

mv RecognitionResult_Total*.c ../src/dds_type/recognition_result_total
mv RecognitionResult_Total*.h ../src/dds_type/recognition_result_total

mv DeviceInfo*.c ../src/dds_type/device_info
mv DeviceInfo*.h ../src/dds_type/device_info

