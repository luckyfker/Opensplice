/***************************************************************************
 *	Copyright (C) 2009
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		QR_Block.h
 *	\brief 		Decode QR(Model2) code binary matrix

				This file includes the QR(Model2) binary matrix decoding interface and
				the core process: decode format information, release the mask, extract the codeword
				and rearrange them into RS block, call RS error correction function and the data block
				decoding function.
 *	@date		2009.08.10	�V�K�쐬
 *	@author		TCH-���ؑ�w (chach-up Mihara_Hidemi)
****************************************************************************/
/*! \file QRBlock.h
\brief Decode QR(Model2) code binary matrix

This file includes the QR(Model2) binary matrix decoding interface and
the core process: decode format information, release the mask, extract the codeword
and rearrange them into RS block, call RS error correction function and the data block
decoding function.
*/
#ifndef QRBLOCK_H
#define QRBLOCK_H

#include "AbsoluteDefinition.h"

#ifdef USE_QR_DECODE						// QR�R�[�h�f�R�[�h����

#include "QR_Common.h"
#include "QR_BasicFunc.h"

/**
*The pointer to the data byte
*/
int * m_blocks;
/**
*The pointer to current data byte
*/
int m_blockPointer;
/**
*The pointer to current bit
*/
int m_bitPointer;
/**
*Maximum number of data byte
*/
int m_MaxBlock;
/**
*Is end reached abnormally
*/
int m_IsEnd;

/**
*Galois Field of ReedSolomon
*/
int alpha_to[512];

/**
*Index of Galois Field of ReedSolomon
*/
int index_of[512];

/**
*Galois Field of BCH5_15
*/
int galpha_to[32];
/**
*Index of Galois Field of BCH5_15
*/
int gindex_of[32];

/**
*Alignment pattern for modal 2
*/
//Point ** gAlignmentPattern;
Point  gAlignmentPattern[7][7];	/* 070919 */
/**
*Extension pattern for modal 1
*/
//Point * gExtensionPattern;
Point gExtensionPattern[128];	/* 070919 */
/**
*Binary data matrix
*/
//uchar ** gdatamatrix;
uchar gdatamatrix[MAXA][MAXA];	/* 070919 */
/**
*Confidence of each modular
*/
//uchar ** gconfidence;
uchar gconfidence[MAXA][MAXA];	/* 070919 */
/**
*Number of error collection code for modal 2
*/
short ** gnumErrorCollectionCode;
/**
*Number of RS block for modal 2
*/
uchar ** gnumRSBlocks;
/**
*Number of error collection code for modal 1
*/
short ** gnumErrorCollectionCodeM1;
/**
*Number of RS block for modal 1
*/
uchar ** gnumRSBlocksM1;
/**
*Code words restored from data matrix
*/
//int * gCodeWords;
int gCodeWords[MAXE];		/* 070919 */
/**
*gErasures restored from confidence
*/
//int * gErasures;
int gErasures[MAXA * MAXA];		/* 070919 */
/**
*Is a modular is in alignment pattern of modal 2
*/
//uchar ** gIsInAlign;
uchar gIsInAlign[MAXA][MAXA];	/* 070919 */
/**
*Is a modular is in extension pattern of modal 1
*/
//uchar ** gIsInExtension;
uchar gIsInExtension[MAXA][MAXA];	/* 070919 */
/**
*Data blocks used to rearrange the code word
*/
//int * gDataBlocks;
int gDataBlocks[MAXE];		/* 070919 */

//extern char * gTransData;
#ifndef Emulator
extern char gTransData[]; /* 070919 */
#else
extern char gTransData[];		/* 20070911 */
#endif
extern int gTransPointer;
extern CodeRegion gCurrentRegion;

/**
*Initialize the block decoding models 
*@return Whether initialization succeeded
-1: Failed
Others: Succeeded
*/
int InitializeBlock();

/**
*Release the block decoding module 
*@return Whether release succeeded
-1: Failed
Others: Succeeded
*/
int ReleaseBlock();
/**
*Get the decoded string of QR Model 2 Code 
*@return Whether decoding succeeded
-1: Failed
Others: Number of bytes decoded
*/
int DecodeQRBlock();

/**
*Get the decoded string of Micro QR Code
*@return Whether decoding succeeded
-1: Failed
Others: Number of bytes decoded
*/
int DecodeMicroQRBlock();


/**
*Get the decoded string of QR Model 1 Code 
*@return Whether decoding succeeded
-1: Failed
Others: Number of bytes decoded
*/
int DecodeQRBlockM1();



/**
*Initialize The Micro QR Block Algorithm
*@return Whether initialization succeeded
*/
int InitializeMicroQRBlock();


/**
*Unmask the code bit
*@param i horizontal coordinate
*@param j vertical coordinate
*/
int UnMaskMicroQR(int i, int j, int Val);
/**
*Whether the coordinate is in function pattern region
*@param i horizontal coordinate
*@param j vertical coordinate
*/
int IsInMicroFunctionPattern(int i, int j);
/**
*Get data blocks according to the arrange rules
*@return the bit stream
*/
int GetMicroDataBlocks();
/**
*Correct the data blocks using ReedSolomon algorithm
*@param blocks the raw bit stream
*@return the corrected bit stream
*/
int CorrectMicroDataBlocks(int * blocks);
/**
*Get the version and level information
*@return whether succeeded
*/
int GetMicroFormatInfo();
/**
*Get the data block number
*@return the data block number
*/
int GetMicroDataBlockNum();
/**
*Initialize The QR Model1 Block Algorithm
*@return Whether initialization succeeded
*/
int InitializeQRBlockM1();

/**
*Get the mask and correct level information
*@return whether succeeded
*/
int GetFormatInfoM1();
/**
*Get the number of error collection code
*@return The number of error collection code 
*/
int GetNumErrorCollectionCodeM1();
/**
*Get the number of RS blocks
*@return The number of RS blocks
*/
int GetNumRSBlocksM1();
/**
*Unmask the code bit
*@param i horizontal coordinate
*@param j vertical coordinate
*@param Val The masked value
*@return the unmasked value
*/
int UnMaskM1(int i, int j, int Val);
/**
*Whether the coordinate is in function pattern region
*@param targetX horizontal coordinate
*@param targetY vertical coordinate
*/
int IsInFunctionPatternM1(int targetX, int targetY);
/**
*Get data blocks according to the arrange rules
*@return Whether succeeded
*/
int GetDataBlocksM1();
/**
*Correct the data blocks using ReedSolomon algorithm
*@param blocks the raw bit stream
*@return Whether succeeded 
*/
int GetCorrectedDataBlocksM1(int * blocks);
/**
*Get the data capacity
*@return The data capacity
*/
int CalcDataCapacityM1();
/**
*Construct the class
*@param Input The data bit stream
*@param ver Version of the code
*/
int DecodeMicroBlock(int * Input, int version, int level);

int GetNextMicroMode(int version);
/**
*Get the length of the data block
*@param The mode of the data block
*@return The length of the data block
*/
int GetMicroDataLength(int mode, int version);
/**
*Judge whether the code is terminated
*@return whether the code is terminated
*/
int IsTerminator(int version);

int CheckDataLength(int level, int DN, int DA, int D8, int DK);


/**
*Initialize The QR Block Algorithm
*@return Whether initialization succeeded
*/
int InitializeQRBlock();
/**
*Get data blocks according to the arrange rules
*@return Whether succeeded
*/
int GetDataBlocks();
/**
*Correct the data blocks using ReedSolomon algorithm
*@param blocks the raw bit stream
*@return Whether succeeded 
*/
int GetCorrectedDataBlocks(int * blocks);
/**
*Get the decoded string 
*@return the decoded string
*/
int DecodeString();
/**
*Get the mask and correct level information
*@return whether succeeded
*/
int GetFormatInfo();
/**
*Get the number of error collection code
*@return The number of error collection code 
*/
int GetNumErrorCollectionCode();
/**
*Get the number of RS blocks
*@return The number of RS blocks
*/
int GetNumRSBlocks();
/**
*Unmask the code bit
*@param i horizontal coordinate
*@param j vertical coordinate
*@param Val The masked value
*@return the unmasked value
*/
int UnMask(int i, int j, int Val);
/**
*Whether the coordinate is in function pattern region
*@param targetX horizontal coordinate
*@param targetY vertical coordinate
*/
int IsInFunctionPattern(int targetX, int targetY);
int CalcDataCapacity();

/**
*Interface of the bit decoding process
*@return Whether decoding succeed
*/
int DecodeBlock(int * Input, int version);
/**
*Get some bits from the stream and move the pointer
*@param numBits The number of bits to be gotten
*@return The bits in integer format
*/
int GetNextBits(int numBits);
/**
*Get some bits from the stream
*@param numBits The number of bits to be gotten
*@return The bits in integer format
*/
int GetBits(int numBits);
/**
*Get the mode of next data block and move the pointer
*@return The mode
*/
int GetNextMode();
/**
*Get the length of the data block
*@param mode The mode of the data block
*@param version The version of the code
*@return The length of the data block
*/
int GetDataLength(int mode, int version);
/**
*Get decoded string in numeric mode
*@param dataLength Length of the data block
*@return The decoded string
*/
unsigned short int *  GetFigureString(int dataLength);
/**
*Get decoded string in Alphanumeric mode
*@param dataLength Length of the data block
*@return The decoded string
*/
unsigned short int *  GetRomanAndFigureString(int dataLength);
/**
*Get decoded string in 8-bit Byte mode
*@param dataLength Length of the data block
*@return The decoded string
*/
unsigned short int * Get8bitByteString(int dataLength);
/**
*Get decoded string in Kanji mode
*@param dataLength Length of the data block
*@return The decoded string
*/
unsigned short int * GetKanjiString(int dataLength);



/**
*Initialize The ReedSolomon Decoding Algorithm.
*Construct the Galois Field \f$GF(2^8)\f$ and the primitive polynomial
*@param pInput The codewords to be corrected
*@param pErasures The position of the erasures
*@param nRs The number of error correction codewords
*@param nt The number of error correction capacity
*/
int ReedSolomon(int * pInput, int * pErasures, int nRS, int nt);
/**
*Initialize The ReedSolomon Decoding Algorithm.
*Construct the Galois Field \f$GF(2^8)\f$ and the primitive polynomial  
*/
int InitializeRS();
/**
*Decode the RS using Berlekamp's algorithm.
*Compute the syndromes and use the Berlekamp algorithm to find the error location polynomial(elp).
*Then use Chien's search algorithm to get the roots, hence the inverse roots and the error location.
*@param nt The number of error correction capacity
*@param nRS The number of error correction codewords
*@param Data The codewords to be corrected
*@param Erasures The position of the erasures
*@return The number of error corrected, -1 means failed
*/
int DecodeRS(int nt, int nRS, int nLength, int * Data, int nEra, int * Erasures);

/**
*Initialize The BCH5_15 Decoding Algorithm.
*Construct the Galois Field \f$GF(2^4)\f$ and the primitive polynomial  
*/
void InitializeBCH5_15();
/**
*BCH5_15 Error Correction Interface
*@param Data Encoded data stream
*@return The number of error corrected, -1 means failed
*/
int BCH(int* Data);
/**
*Decode the BCH using Berlekamp's algorithm.
*Compute the syndromes and use the Berlekamp algorithm to find the error location polynomial(elp).
*Then use Chien's search algorithm to get the roots, hence the inverse roots and the error location.
*@param recd Encoded data Stream
*@return The number of error corrected, -1 means failed
*/
int DecodeBCH(int * recd);

#endif

#endif
