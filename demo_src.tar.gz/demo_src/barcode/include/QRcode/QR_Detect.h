/***************************************************************************
 *	Copyright (C) 2009
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		QR_Detect.h
 *	\brief 		QR code detection module.
 
				This file includes the QR and MicroQR Code detection interface and
				the core process: find Position Detection Pattern, judge the Finder Pattern.
				And for Micro QR Code, the direction of the code and the version of the code 
				is also calculated in this file.
 *	@date		2009.08.10	�V�K�쐬
 *	@author		TCH-���ؑ�w (chach-up Mihara_Hidemi)
****************************************************************************/
#ifndef DETECTQRCODE_H
#define DETECTQRCODE_H

#include "AbsoluteDefinition.h"

#ifdef USE_QR_DECODE						// QR�R�[�h�f�R�[�h����

#include "QR_Common.h"
#include "QR_BasicFunc.h"
extern MonoImage * gSrc;
extern MonoImage * gBin;
extern MonoImage * gBinEdge;
extern int * gThreshold;
extern int gLastThreshold;

/**
*Find all potential position detection patterns 
*@return Position detection patterns list
*/
PosDetPatternList * GetPosDetPatterns();
/**
*Find all potential Micro QR code region using topology constraint
*@param centerlist All potential position detection patterns list
*@return Micro QR code region list
*/
RegionList *  GetMicroRegion(PosDetPatternList *  centerlist);

/**
*Find all potential QR code region using topology constraint
*@param centerList All potential position detection patterns list
*@return QR code region list
*/
RegionList * GetQRRegion(PosDetPatternList * centerList);

/**
*Binarize the gray image using appointed threshold
*@param Th The appointed threshold
0: Using OTSU algorithm to determine the global threshold
-1: Using adaptive thresholding algorithm
Others: Using nTh as the global threshold 
*/
void Binarize(int nTh);

/**
*Rearrange the corners
*@param coderegion The code region to be rearranged
The rearranged index should be
0   3
1   2
*/
void RearrangeCorner(CodeRegion * coderegion);

/**
*Get the index of the left up corner
*@param center The mark symbol center
*@param Src The source image
*@return Whether P1 contains P0
*/
int GetLeftUpCorner(PosDetPattern center, float dis, float *dirc, int pm[4][2], Point *offset);

/**
*Use Hough Transformation to find two perpendicular direction in a binary image
*@param src The binary image
*@return the two perpendicular direction
*/
Point32f HoughTrans(PosDetPattern *region, ListNode * pList);

/**
*Find counters of the binary image.
*Here the edge tracing technique is used.
*@param img The binary image
*@param confine Confine of the binary images
*@param isContour A temporary array to indicate whether a point is on a contour
*@param contours The output contour list header
*/
void FindContours(MonoImage* img, uchar * confine, uchar * isContour, LinkNode * contours);
/**
*Find counters of the binary image.
*Here the connect region analysis is used.
*@param img The binary image
*@param contours The output contour list header
*/
void FindContours0(MonoImage* img, LinkNode * contours);
/**
*Flood fill the binary image from appointed point
*@param src The binary image. It will be changed when return
*@param Pt The appointed point
*@param bit The operating bit
*/
int MyFloodFill(MonoImage * src, Point Pt, int bit);
/**
*Analysis the topology of the contours
*@param contours The header of the original contours list
*@param contour The header of the valid contour list
*@param level The level of the valid containing topolpgy
*/
void Cluster(LinkNode* contours, LinkNode* contour, int level);
/**
*Detect four corners form a contour
*@param contour The contour to be operated on
*@param corner Array of the detected corner
*@return whether corner detected
*/
int CornerDetect(LinkNode* contour,Point* corner);

/**
*Find the confine on binary image
*@param img The binary image
*@param confine The output confine of  the image
*/
void FindConfine(MonoImage * img,uchar * confine);

void RefineRegion2(PosDetPattern *Region);

#endif

#endif
