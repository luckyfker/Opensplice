/***************************************************************************
 *	Copyright (C) 2009
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		QR_Decode.h
 *	\brief 		QR and MicroQR Code decoding module.

				This file includes the QR and Micro QR Code decoding interface and
				binary matrix sampling process.
 *	@date		2009.08.10	�V�K�쐬
 *	@author		TCH-���ؑ�w (chach-up Mihara_Hidemi)
****************************************************************************/
#ifndef DECODEQRCODE_H
#define DECODEQRCODE_H

#include "AbsoluteDefinition.h"

#ifdef USE_QR_DECODE						// QR�R�[�h�f�R�[�h����

#include "QR_Common.h"
#include "QR_BasicFunc.h"
#include "QR_Detect.h"
//#include "QRBlock.h"

/**
*Predefined version information
*/
int * gVersionInfoBit;

extern MonoImage * gSrc;
extern MonoImage * gBin;
extern int * gThreshold;

//extern Point **gAlignmentPattern;
extern   Point gAlignmentPattern[7][7];			/* 070919 */
//extern uchar ** gdatamatrix;
extern   uchar gdatamatrix[MAXA][MAXA];			/* 070919 */
//extern uchar ** gconfidence;
extern  uchar gconfidence[MAXA][MAXA];			/* 070919 */
extern CodeRegion gCurrentRegion;
//extern char * gTransData;
extern  char gTransData[];	/* 070919 */

/**
*Transform matrix
*/
float m_M[8];
float m_R[6];

int DecodeQRM2();
/**
*Decode QR code interface
*@return Whether succeeded: -1 Failed and 1 succeeded
*/
int DecodeQR();

/**
*Decode MicroQR code interface
*@return Whether succeeded: -1 Failed and 1 succeeded
*/
int DecodeMicroQR();	

/**
*Main Decode QR code function
*@return Whether decoding succeeded
*/
int DecodeQRProcess();

/**
*Main Decode QR Model1 code function
*/
int DecodeQRModel1Process();

/**
*Main Decode QR code function
*@return Whether decoding succeeded
*/
int DecodeQRProcessAffine();

/**
*Main Decode QR Model1 code function
*/
int DecodeQRModel1ProcessAffine();


/**
*Decode QR Model 1 code interface
*@return Whether succeeded: -1 Failed and 1 succeeded
*/
int DecodeQRModel1();

/**
*Get the rough version information
*@return The rough version
*/
int GetRoughVersion();

/**
*Refine the version information
*@return The refined version
*/
int RefineVersion();
/**
*Check the version information
*@return The refined version
*/
int CheckVersionInfo(int * target, int * nErr);
/**
*Get the alignment pattern position 
*@return The alignment pattern number 
*/
int GetAlignmentPattern(int m_Ver);
/**
*Refine the center
*@param center The center to be refined
*@param radius The radius of the interesting region
*@return The alignment pattern number 
*/
Point32f RefineCenter(Point32f center, float radius);

/**
*Get code value in logical coordinates
*@param i horizontal coordinate
*@param j vertical coordinate
*/
Conf GetRawSampleValConf(float i, float j);

/**
*Get code value in logical coordinates
*@param i horizontal coordinate
*@param j vertical coordinate
*/
Conf GetRawSampleValConfAffine(float i, float j);


/**
*Main Decode MicroQR code function
*/
int DecodeMicroQRProcess();
/**
*Get code value in logical coordinates
*@param i horizontal coordinate
*@param j vertical coordinate
*/
Conf GetSampleValConf(int i, int j, int judge);



/**
*Get the extension pattern position 
*@return The extension pattern position 
*/
int GetExtensionPattern();

/**
*Calibration the affine transform
*@param N Total point number 
*@param cc The image coordinates
*@param Wd The real coordinates
*/
void CalibrationAffine(int N, const float * cc, const float * Wd);


/**
*Calibration the perspective transform
*@param N Total point number 
*@param cc The image coordinates
*@param Wd The real coordinates
*/
void CalibrationPer(int N, const float * cc, const float * Wd);

/**
*Real coordinates to image coordinates
*@param G Real coordinates
*@return Image coordinates
*/
Point32f Logical2ImagePer(Point G);


/**
*Real coordinates to image coordinates
*@param G Real coordinates
*@return Image coordinates
*/
Point32f Logical2Image(Point G);
/**
*SVD decomposition of matrix
*@param A Matrix to be decomposed
*@param Nrows Number of rows of  matrix A
*@param Ncols Number of columns of matrix A
*@param U The left singular matrix
*@param S The diagonal singular value matrix
*@param V The right singular matrix
*/
void SVD(const float * A, int Nrows, int Ncols, float *U, float *S, float *V);
/**
*Multiplication of two matrix
*@param A First source matrix
*@param Nrows Number of rows of  matrix A
*@param Ncols Number of columns of matrix A
*@param B Second source matrix
*@param Nrows Number of rows of  matrix B
*@param Ncols Number of columns of matrix B
*@return A * B
*/
float * Mul(const float * A, int NrowsA, int NcolsA, const float * B, int NrowsB, int NcolsB);
/**
*Transpose a matrix
*@param transpose_matrix the matrix to be transposed 
*@param Nrows Number of rows of  transpose_matrix
*@param Ncols Number of columns of transpose_matrix
*/
void Transpose(float* transpose_matrix, int Nrows, int Ncols);
/**
*Solve the equation A * x = B using SVD algorithm
*@param A First source matrix
*@param Nrows Number of rows of  matrix A
*@param Ncols Number of columns of matrix A
*@param B Second source matrix
*@return x
*/
float * solveEqn(const float * A, int Nrows, int Ncols, const float * B);

#endif

#endif
