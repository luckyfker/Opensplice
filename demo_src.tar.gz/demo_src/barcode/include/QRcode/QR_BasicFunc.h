/***************************************************************************
 *	Copyright (C) 2009
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		QR_BasicFunc.h
 *	\brief 		QR Code Basic functions module

				This file includes the memory operation functions, 
				the image processing functions and data structure maniplute functions.
 *	@date		2009.08.10	�V�K�쐬
 *	@author		TCH-���ؑ�w (chach-up Mihara_Hidemi)
****************************************************************************/
#ifndef QR_BASICFUNC_H
#define QR_BASICFUNC_H

#include "AbsoluteDefinition.h"

#ifdef USE_QR_DECODE						// QR�R�[�h�f�R�[�h����

#include "QR_Common.h"
/**
*Check whether a point is in the image
*/
#define ISINIMAGE(y,x,width,height) (((y)>=0)&&((y+1)<=(height))&&((x)>=0)&&((x+1)<=(width)))
/**
*Automatic global threshold selection
*@param image The pointer to image structure
*@param x0 The column index of the left-up point of the region of interest
*@param y0 The row index of the left-up point of the region of interest
*@param dx The column span of the region of interest
*@param dy The row span of the region of interest
*/
int minError(MonoImage * image, int x0, int y0, int dx, int dy);
/**
*Automatic global threshold selection
*@param image The pointer to image structure
*@param x0 The column index of the left-up point of the region of interest
*@param y0 The row index of the left-up point of the region of interest
*@param dx The column span of the region of interest
*@param dy The row span of the region of interest
*/
int Otsu(MonoImage * image, int x0, int y0, int dx, int dy);
/**
*Adaptive thresholding
*@param src The source gray image
*@param dst The destination binary image
*@param x0 The column index of the left-up point of the region of interest
*@param y0 The row index of the left-up point of the region of interest
*@param dx The column span of the region of interest
*@param dy The row span of the region of interest
*@param block_size The length of the adaptive operation window
*/
void AdaptiveThres(MonoImage *src, MonoImage *dst, int x0, int y0, int dx, int dy, int block_size);
/**
*Binarize the gray image using appointed threshold
*@param Src The source gray image
*@param Dst The destination binary image
*@param Th The appointed threshold
*/

void ThreshHold(MonoImage * Src,MonoImage * Dst, int Th);
/** 
*Allocate 2 dimension integer array
*@param row Number of first dimension
*@param col Number of second dimension
*@return The pointer to the memory
*/
int **Array2I(int row, int col);
/** 
*Allocate 2 dimension short integer array
*@param row Number of first dimension
*@param col Number of second dimension
*@return The pointer to the memory
*/
short int **Array2Short(int row, int col);
/** 
*Allocate 2 dimension unsigned char array
*@param row Number of first dimension
*@param col Number of second dimension
*@return The pointer to the memory
*/
uchar **Array2U(int row, int col);

/** 
*Allocate 2 dimension char array
*@param row Number of first dimension
*@param col Number of second dimension
*@return The pointer to the memory
*/
char **Array2C(int row, int col);
/** 
*Allocate 2 dimension Point32F array
*@param row Number of first dimension
*@param col Number of second dimension
*@return The pointer to the memory
*/
Point32f **Array2Point32F(int row, int col);
/** 
*Allocate 2 dimension Point array
*@param row Number of first dimension
*@param col Number of second dimension
*@return The pointer to the memory
*/
Point **Array2Point(int row, int col); 
/** 
*Free the 2 dimension array
*@param buf  The pointer to the memory
*@param row Number of first dimension
*/
void Free2DArray(void **buf, int row);
/** 
*Allocate 1 dimension integer array
*@param size Number of elements
*@return The pointer to the memory
*/
int * ArrayI(int size);
/** 
*Allocate 1 dimension float array
*@param size Number of elements
*@return The pointer to the memory
*/
float * ArrayF(int size);
/** 
*Allocate 1 dimension short int array
*@param size Number of elements
*@return The pointer to the memory
*/
unsigned short int * ArrayWC(int size);
/** 
*Allocate 1 dimension char array
*@param size Number of elements
*@return The pointer to the memory
*/
char *  ArrayC(int size);
/** 
*Allocate 1 dimension unsigned char array
*@param size Number of elements
*@return The pointer to the memory
*/
uchar * ArrayU(int size);
/** 
*Allocate 1 dimension Point array
*@param size Number of elements
*@return The pointer to the memory
*/
Point * ArrayPoint(int size);
/** 
*Free the 1 dimension array
*@param buf  The pointer to the memory
*/
void FreeArray(void* buf);
/** 
*Append a PosDetPattern to the PosDetPatternList
*@param List  The header of the list
*@param point The point to be appended
*/
void AppendPosDetPattern(PosDetPatternList * List, PosDetPattern *point);
/** 
*Append a CodeRegion to the RegionList
*@param List  The header of the list
*@param point The region to be appended
*/
void AppendCodeRegion(RegionList * List, CodeRegion *reg);
/** 
*Get the length of the PosDetPatternList
*@param List  The header of the list
*@return the length of the PosDetPatternList
*/
int GetPosDetPatternListLength(PosDetPatternList * List);
/** 
*Get the length of the RegionList
*@param List  The header of the list
*@return the length of the RegionList
*/
int GetRegionListLength(RegionList * List);
/** 
*Delete the RegionList
*@param List  The header of the list
*/
void DeleteRegionList(RegionList * List);
/** 
*Delete the PosDetPatternList
*@param List  The header of the list
*/
void DeletePosDetPatternList(PosDetPatternList * List);
/** 
*Append a ListNode to the list
*@param head  The header of the list
*@param p The point on the contour
*/
void InsertList(ListNode *head,Point p);
/** 
*Append a LinkNode to the list
*@param head  The header of the list
*@param p Points list of the contour
*@param area Area of the contour region
*@param length Length of the contour
*/
void InsertLink(LinkNode *head,ListNode* p,float area,int length);
/** 
*Delete the contour point list
*@param List  The header of the list
*/
void DeleteList(ListNode * List);
/** 
*Delete the contour list
*@param List  The header of the list
*/
void DeleteLink(LinkNode * List);
void DeleteLink2(LinkNode * List);
/**
*Calculate the angle of the points
*@param pt1 The first point
*@param pt2 The last point
*@param pt0 The middle point
*@return The cosine of the angle
*/
float Angle( Point32f* pt1, Point32f* pt2, Point32f* pt0 );
/**
*Calculate the Euclidean distance of two points
*@param pt1 The first point
*@param pt2 The second point
*@return The Euclidean distance of the angle
*/
float Distance( Point32f *pt1, Point32f *pt2);
float Distance2( Point32f *pt1, Point32f *pt2);


/**
*Create a gray image
*@param Width The width of the image
*@param Width The height of the image
*@param WidthStep The number of bytes per row
*return The pointer to the image structure
*/
MonoImage * CreateMonoImage(int Width, int Height, int WidthStep);
/**
*Release a MonoImage structure 
*@param Image Pointer to the image structure
*/
void ReleaseMonoImage(MonoImage ** Image);
/**
*Load a MonoImage structure from a bmp file.
*Only 8-bit gray format is supported
*@param FileName The bmp file name
*@return Image Pointer to the image structure
*/
MonoImage * LoadMonoImage(const char * FileName);


float CrossProduct(Point32f* pt1, Point32f* pt2, Point32f* pt0);

float Distance4( short *x0, short *y0,  float *x1, float *y1);

void ThreshHoldRect(MonoImage * Src,MonoImage * Dst,int x0, int y0, int dx, int dy, int Th);

#endif

#endif
