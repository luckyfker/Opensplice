/***************************************************************************
 *	Copyright (C) 2009
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		QR_Util.h
 *	\brief 		The interface module
 *
 *	@date		2009.08.10	�V�K�쐬
 *	@author		Mihara_Hidemi
****************************************************************************/
#include "AbsoluteDefinition.h"

#ifdef USE_QR_DECODE						// QR�R�[�h�f�R�[�h����

extern int * gDecodedPointers;		/* QR No of Decoded characters */
extern CodeRegion gCurrentRegion;	/* QR Version */
extern char gTransData[];		/* 20070911 */
extern int gTransPointer;

int QrDecodeProc(unsigned char * inP1,unsigned char * inP2);
int QR_Initialize();
int QR_Release();
int QR_isFind();
#endif
