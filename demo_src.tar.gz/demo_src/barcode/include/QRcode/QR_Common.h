/***************************************************************************
 *	Copyright (C) 2009
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		QR_Common.h
 *	\brief 		The commonly used data structure and macros.

				This file includes the definition of commonly used data structures and 
				macros. It contains the required system header files also.
 *	@date		2009.08.10	�V�K�쐬
 *	@author		TCH-���ؑ�w (chach-up Mihara_Hidemi)
****************************************************************************/

#ifndef COMMON_H
#define COMMON_H

#include "AbsoluteDefinition.h"

#ifdef USE_QR_DECODE						// QR�R�[�h�f�R�[�h����

#include <stdlib.h>
//#include <memory.h>
#include <stdio.h>
//#include <locale.h>
#include <math.h>
typedef unsigned char uchar;
/*
*define the different algorithms for micro qr decoding
* if MICROQRAFFINE is defined, affine transformation is used
*/
#define MICROQRAFFINE
/**
*Memory allocation error
*/

#define ERROR_MEMORY 1
/**
*Maximum seed number
*/

#define MAXSEED 50000

/**
*Maximum Area of Position Detection Patterns
*/
#define MAXAREA (1024 * 768 / 16)

/**
*Minimum Area of Position Detection Patterns
*/
#define MINAREA 4

/**
*Maximum number of code in one image
*/

#define MAXCODENUM 2


/**
*Maximum angle tolerance
*/
#define ANGLEEPS 0.2f
/**
*Similarity between Position Detection Patterns
*/
#define POSITIONEPS 0.5f



/**
*Binarize thresholds number
*/
//#define BINARIZETHNUM 18
//#define BINARIZETHNUM 1

/**
*Maximum modular along the side
*/
#define MAXA 177

/**
*Maximum code words number 
*/ 
#define MAXE 3800

/**
*Maximum version
*/ 
#define MAXV 40

/**
*Mode indicator
*/ 
#define MODE_NUMBER 1
/**
*Mode indicator
*/ 
#define MODE_ROMAN_AND_NUMBER 2
/**
*Mode indicator
*/ 
#define MODE_STRUCTURE_LINK 3
/**
*Mode indicator
*/ 
#define MODE_8BIT_BYTE 4
/**
*Mode indicator
*/ 
#define MODE_FNC1_1 5
/**
*Mode indicator
*/ 
#define	MODE_ECI 7
/**
*Mode indicator
*/ 
#define MODE_KANJI 8
/**
*Mode indicator
*/ 
#define MODE_FNC1_2 9

/**
*Mode indicator
*/ 
#define  MICRO_MODE_NUMBER  0
/**
*Mode indicator
*/ 
#define  MICRO_MODE_ROMAN_AND_NUMBER  1
/**
*Mode indicator
*/ 
#define  MICRO_MODE_8BIT_BYTE  2
/**
*Mode indicator
*/ 
#define  MICRO_MODE_KANJI  3


/**
*\f$\pi\f$
*/
#define PI   3.1415926535897932384626433832795
/**
*Maximum of two input
*/
#ifndef max
#define max(a,b)  (((a) > (b)) ? (a) : (b))
#endif
/**
*Minimum of two input
*/
#ifndef min
#define min(a,b)  (((a) < (b)) ? (a) : (b))
#endif
/**
*Point
*/
struct tPoint
{
		/**
		*x coordinate
		*/
		short int x;
		/**
		*y coordinate
		*/
		short int y;
};

typedef struct tPoint Point;

/**
*Float Point
*/
struct tPoint32f
{
		/**
		*x coordinate
		*/
		float x;
		/**
		*y coordinate
		*/
		float y;
};

typedef struct tPoint32f Point32f;

/**
*Rectangle
*/
struct tRect
{
		/**
		*x coordinate of left up
		*/
		int x;
		/**
		*y coordinate of left up
		*/
		int y;
		/**
		*Width
		*/
		int width;
		/**
		*Height
		*/
		int height;
};
typedef  struct tRect Rect;

/**
*Positioning Pattern
*/ 
struct tPosDetPattern
{

		/**
		*Center of the pattern
		*/ 
		Point32f point;
		/**
		*Direction of the pattern (Only for MicroQR)
		*/ 
		Point32f dir;
		/**
		*Rough size of the pattern
		*/ 
		float rectsize;
		/**
		*The corners of the pattern
		*/ 
		Point32f Corner[4];

		float height;	// �t�@�C���_�[�p�^�[���̍���
		float width;	// �t�@�C���_�[�p�^�[���̕�
};

typedef struct tPosDetPattern PosDetPattern;


/**
*Finder Pattern
*/ 

struct tCodeRegion
{
		/**
		*The Position Detection Patterns of the region
		*/ 
		PosDetPattern MPoint[3];//0:leftup, 1:rightup, 2:leftbottom
		/**
		*The version
		*/ 
		int Ver;
		/**
		*The number of modulars along each side
		*/ 
		int L;
		/**
		*The number of alignment patterns along each side
		*/ 
		int AL;
		/**
		*The number of extension patterns
		*/ 
		int EL;
		/**
		*The error correction level
		*/ 
		int Level;
		/**
		*The mask type
		*/ 
		int Mask;
		/**
		*The average size of the Position Detection Patterns
		*/ 
		float centersize;
		/**
		*Directions of MicroQR
		*/
		float dirc[2];
};

typedef struct tCodeRegion CodeRegion;

/**
*List of the Finder Patterns
*/
struct tRegionList
{
		/**
		*Finder Pattern
		*/
		CodeRegion Region;
		/**
		*Pointer to next region
		*/
		struct tRegionList * next;
};
typedef struct tRegionList RegionList;

/**
*List of the Position Detection Patterns
*/
struct tPosDetPatternList
{
		/**
		*Position Detection Pattern
		*/
		PosDetPattern Region;
		/**
		*Pointer to next Position Detection Pattern
		*/
		struct tPosDetPatternList * next;
};
typedef struct tPosDetPatternList PosDetPatternList;


/**
*Confidence and value of a point
*/
struct tConf
{
		/**
		*Value of the point
		*/
		uchar val;
		/**
		*Confidence of the point
		*/
		uchar cof;

		int x;
		int y;
};

typedef struct tConf Conf;



/**
*Gray image structure
*/
struct tMonoImage
{
		/**
		*Pointer to the image data
		*/
		uchar* imageData;
		/**
		*Image width
		*/
		int width;
		/**
		*Image height
		*/
		int height;
		/**
		*Number of bytes for each line
		*/
		int widthStep;
};

typedef struct tMonoImage MonoImage;

/**
*Points list of a contour
*/
struct tListNode
{
		/**
		*Point value
		*/
		Point point;
		/**
		*Pointer to next node
		*/
		struct tListNode *next;
		/**
		*Pointer to the rear node of the list, only for head node
		*/
		struct tListNode *Rear;
};

typedef struct tListNode ListNode;

/**
*Contours list
*/
struct tLinkNode
{
		/**
		*Points list of the contour
		*/
		ListNode* list;
		/**
		*Center of the contour
		*/
		Point32f center;
		/**
		*Area of the contour
		*/
		float area;
		/**
		*Length of the contour
		*/
		short length;
		/**
		*Pointer to the next Contours list
		*/
		struct tLinkNode *next;
};

typedef struct tLinkNode LinkNode;



#ifndef bool	// bool ����`����Ă��Ȃ�������
#define bool unsigned char
#endif

#ifndef true	// TRUE ����`����Ă��Ȃ�������
#define true 1
#endif

#ifndef false	// FALSE ����`����Ă��Ȃ�������
#define false 0
#endif


#endif

#endif
