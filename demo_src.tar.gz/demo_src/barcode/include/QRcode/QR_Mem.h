/***************************************************************************
 *	Copyright (C) 2009
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		QR_Mem.h
 *	\brief 		QR�R�[�h�p�������Ǘ�
 *
 *	@date		2009.08.10	�V�K�쐬
 *	@author		Hidemi_Mihara
****************************************************************************/
#include "AbsoluteDefinition.h"

#ifdef USE_QR_DECODE						// QR�R�[�h�f�R�[�h����

#ifndef Emulator
//void *malloc_QR(size_t size);
//void *calloc_QR(size_t num, size_t size);
#define malloc_QR malloc
#define free_QR free
void *realloc_QR(void *packet, size_t size);
//void free_QR(void *packet);
void minit_QR(void);
#else
#define malloc_QR malloc
#define free_QR free
#endif

#define  memory_size_QR 0x500000

#endif
