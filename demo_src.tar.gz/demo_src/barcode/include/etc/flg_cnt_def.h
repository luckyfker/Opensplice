/***************************************************************************
 *	Copyright (C) 2017
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		flg_cnt_def.h
 *	\brief 		�t���O�E�J�E���^�[���̒�`
 *
 *	@date		2017.08.23	�V�K�쐬
 *	@author		Takuya1_Takasu@toshibatec.co.jp
****************************************************************************/

#ifndef INC_FLG_CNT_DEF_H_
#define INC_FLG_CNT_DEF_H_

#include "AbsoluteDefinition.h"
#include <stdbool.h>

/** �ǂݎ��֐� */

unsigned char flg_init_end_read();
unsigned int SoftwareFlag_read();
unsigned int SoftwareFlag2_read();

unsigned char flg_usb_5V_read();
int flg_req_usb_5V_read();
unsigned char flg_four_image_transfer_read();
unsigned char flg_60fps_image_transfer_read();
unsigned int flg_send_status_read();
unsigned char flg_exit_mobile_read();
unsigned char flg_same_label_scan_read();

unsigned char flg_prg_data_ng_read();

unsigned char flg_test_sound_read();
unsigned char flg_test_light_read();
unsigned char flg_test_led_read();

#ifdef USE_SEAL_RECOGNITION		// �l�����V�[��
unsigned int flg_NiDanNebiki_read();
unsigned int flg_nidoyomi_save_read();
#endif

#if defined(USE_OBJECT_RECOGNITION) || defined(DEBUG_SEAL_ONLY_RECOGNITION)	// �I�u�W�F�N�g�F��
bool flg_IsDecodedInObjectMode_read();
#endif

bool flg_IsScanModeChange_read();
bool flg_IsAssertedSwitch_ScanModeChange_read();

int flg_key_code_read();
int flg_system_error_read();
int flg_program_kakunin_read();

bool flg_decode_success_gpio_out_read();
unsigned char flg_decode_time_recode_read();
unsigned char flg_check_frame_out_read();
bool flg_check_frame_out_on_read();

bool flg_disable_image_output_read();

#ifdef MINI_SCANNER
bool flg_saturn_seal_timeout_read();
bool flg_saturn_interval_check_read();
#endif

bool flg_hybrid_scanmode_read();

int cnt_dec_sym_read();
int cnt_set_dec_sym_read();
int cnt_data_read();
unsigned int cnt_ng_flame_read();

int cnt_disable_light_read();
int cnt_prg_mode_timeout_read();
int cnt_mobile_mode_timeout_read();

unsigned int cnt_apo_timer_read();
unsigned int cnt_apo2_timer_read();

unsigned int decode_all_cnt_read();
unsigned int decode_mobile_cnt_read();

#ifdef USE_QR_DECODE			// QR�R�[�h
int cnt_timeout_for_Maesabaki_read();
#endif

#ifdef USE_SEAL_RECOGNITION		// �l�����V�[��
int cnt_flag_seal_timer_read();
int cnt_flag_seal_timer_A_read();
int cnt_flag_seal_timer_B_read();
int cnt_timeout_for_seal_read();
#endif

#ifdef MINI_SCANNER
unsigned char cnt_apo_sync_read();
unsigned int cnt_apo_bd_start_timer_read();
unsigned int cnt_apo_bright_timer_read();
unsigned int cnt_apo_dark_timer_read();
unsigned int cnt_saturn_light_read();
#endif


/** �������݊֐� */

unsigned char flg_init_end_write(unsigned char val);
unsigned int SoftwareFlag_write(unsigned int val);
unsigned int SoftwareFlag2_write(unsigned int val);

unsigned char flg_usb_5V_write(unsigned char val);
int flg_req_usb_5V_write(int val);

unsigned char flg_four_image_transfer_write(unsigned char val);
unsigned char flg_60fps_image_transfer_write(unsigned char val);
unsigned int flg_send_status_write(unsigned int val);
unsigned char flg_exit_mobile_write(unsigned char val);
unsigned char flg_same_label_scan_write(unsigned char val);

unsigned char flg_prg_data_ng_write(unsigned char val);

unsigned char flg_test_sound_write(unsigned char val);
unsigned char flg_test_light_write(unsigned char val);
unsigned char flg_test_led_write(unsigned char val);

#ifdef USE_SEAL_RECOGNITION		// �l�����V�[��
unsigned int flg_NiDanNebiki_write(unsigned int val);
unsigned int flg_nidoyomi_save_write(unsigned char val);
#endif

#if defined(USE_OBJECT_RECOGNITION) || defined(DEBUG_SEAL_ONLY_RECOGNITION)	// �I�u�W�F�N�g�F��
bool flg_IsDecodedInObjectMode_write(bool val);
#endif

bool flg_IsScanModeChange_write(bool val);
bool flg_IsAssertedSwitch_ScanModeChange_write(bool val);

int flg_key_code_write(int val);
int flg_system_error_write(int val);
int flg_program_kakunin_write(int val);

bool flg_decode_success_gpio_out_write(bool val);
unsigned char flg_decode_time_recode_write(unsigned char val);
unsigned char flg_check_frame_out_write(unsigned char val);
bool flg_check_frame_out_on_write(bool val);

bool flg_disable_image_output_write(bool val);

#ifdef MINI_SCANNER
bool flg_saturn_seal_timeout_write(bool val);
bool flg_saturn_interval_check_write(bool val);
#endif

bool flg_hybrid_scanmode_write(bool val);

int cnt_dec_sym_write(int val);
int cnt_set_dec_sym_write(int val);
int cnt_data_write(int val);
unsigned int cnt_ng_flame_write(unsigned int val);

int cnt_disable_light_write(int val);
int cnt_prg_mode_timeout_write(int val);
int cnt_mobile_mode_timeout_write(int val);

unsigned int cnt_apo_timer_write(unsigned int val);
unsigned int cnt_apo2_timer_write(unsigned int val);

unsigned int decode_all_cnt_write(unsigned int val);
unsigned int decode_mobile_cnt_write(unsigned int val);

#ifdef USE_QR_DECODE			// QR�R�[�h
int cnt_timeout_for_Maesabaki_write(int val);
#endif

#ifdef USE_SEAL_RECOGNITION		// �l�����V�[��
int cnt_flag_seal_timer_write(int val);
int cnt_flag_seal_timer_A_write(int val);
int cnt_flag_seal_timer_B_write(int val);
int cnt_timeout_for_seal_write(int val);
#endif

#ifdef MINI_SCANNER
unsigned char cnt_apo_sync_write(unsigned char val);
unsigned int cnt_apo_bd_start_timer_write(unsigned int val);
unsigned int cnt_apo_bright_timer_write(unsigned int val);
unsigned int cnt_apo_dark_timer_write(unsigned int val);
unsigned int cnt_saturn_light_write(unsigned int val);
#endif

#endif /* INC_FLG_CNT_DEF_H_ */
