/************************************************************************
*																		*
*      Copyright (C) 2012                                               *
*      TOSHIBA TEC CORPORATION All Rights Reserved                      *
*      570 Ohito, Izunokuni-shi, Shizuoka-ken, JAPAN                    *
*                                                                       *
*************************************************************************/

/************************************************************************
	�f�[�^�錾
************************************************************************/
#ifndef	_TYPE_DEF_H_
 #define	_TYPE_DEF_H_

//-----------------------------------------------------------------------
// ���V�[�g�v�����^�Œ�`���Ă����^�C�v
//-----------------------------------------------------------------------

 typedef	unsigned char	UBYTE;
 typedef	unsigned short	UWORD;
 typedef	unsigned long	ULONG;
 typedef	char			SBYTE;
 typedef	short			SWORD;
 typedef	long			SLONG;
 typedef	void			(*FUNCPTR)();			/* pfunction returning int 		*/
 #define	LONG			SLONG

//-----------------------------------------------------------------------
// �s�h(DSP)�Œ�`���Ă����^�C�v
//-----------------------------------------------------------------------
typedef unsigned int   		Uint32;
typedef unsigned short   	Uint16;
typedef unsigned char   	Uint8;
typedef int 		  		Int32;
typedef short 		  		Int16;
typedef signed char 		Int8;

#endif	/* _TYPE_DEF_H_	*/

