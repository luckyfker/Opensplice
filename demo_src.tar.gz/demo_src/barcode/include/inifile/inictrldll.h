/////////////////////////////////////////////////////////////////////////////
//
//	    Copyright (C) 2002
//				TEC CORPORATION,  ALL Rights Reserved
//				1-14-10 Uchikanda Chiyoda-ku Tokyo JAPAN
//
/////////////////////////////////////////////////////////////////////////////
//
//  MODULE NAME	:  inictrldll.h
//  (FILE NAME)
//  PARAMETERS	:  NONE
//
//  DESCRIPTION	:  libinifile.so ���󥿡��ե�����
//			/ Linux�� INI�ե����륢�������ؿ��ʥ��������ɥ饤�֥���
//
//  CREATE   ON :  	V001.001				2002.07.10
//			ITAGAKI YU-YA [TOSHIBA TEC]
//
//  MODIFIED ON :  	V002.001				2003.04.21			#1
//		 	ITAGAKI YU-YA [TOSHIBA TEC]
//			GetPrivateProfileSection,GetPrivateProfileSectionName �ɲ�
//
/////////////////////////////////////////////////////////////////////////////

#ifndef __INICTRLDLL_H__
#define __INICTRLDLL_H__

//#ifndef TRUE
//#define	TRUE	1
//#endif
//
//#ifndef FALSE
//#define	FALSE	0
//#endif
//
//#ifndef BOOL
//#define	BOOL	int
//#endif

//#define	TRUE	1
//#define	FALSE	0
//#define	BOOL	int

#ifdef __cplusplus
extern "C"
{
#endif

	void _init(void);

	long GetPrivateProfileString(const char *lpAppName,
								 const char *lpKeyName,
								 const char *lpDefault,
								 char *lpReturnedString,
								 long nSize,
								 const char *lpFileName);

	short WritePrivateProfileString(const char *lpAppName,
									const char *lpKeyName,
									const char *lpString,
									const char *lpFileName);

	int GetPrivateProfileInt(const char *lpAppName,
							 const char *lpKeyName,
							 int nDefault,
							 const char *lpFileName);

	short WritePrivateProfileInt(const char *lpAppName,
								 const char *lpKeyName,
								 int nValue,
								 const char *lpFileName);

	//Add start 2003.04.21 Y.Itagaki------#1

	unsigned long GetPrivateProfileSection(const char *lpAppName,
										   char *lpReturnedString,
										   unsigned long nSize,
										   const char *lpFileName);

	unsigned long GetPrivateProfileSectionNames(char *lpReturnedString,
												unsigned long nSize,
												const char *lpFileName);

	//Add end 2003.04.21 Y.Itagaki------#1

#ifdef __cplusplus
}
#endif

#endif // __INICTRLDLL_H__
