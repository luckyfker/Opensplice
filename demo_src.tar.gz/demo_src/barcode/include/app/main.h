/***************************************************************************
 *	Copyright (C) 2009
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		main.h
 *	\brief 		HWI,SWI���� main����
 *
 *	@date		2009.08.10	�V�K�쐬
 *	@author		Iizaka_Hitoshi@toshibatec.co.jp
****************************************************************************/
/*! \mainpage CCD SCANNER
 *
From the image by the CCD sensor as a successor of the scanner using the current laser
?Scanner that reads barcodes

?Features: Can read discount stickers and QR codes

?CPU used: Zynq-7000 made by XILINX (operates at 666MHz internally)

?Operating system used None

?<center>
?[RS Ha Shu 3 Scanning Equipment]
??<img src = "main.jpg" alt = "doxygen" align = "center" border = "0">
?</ center>
 */

#ifndef _MAIN
#define _MAIN

#define BAR_DEC_OK						0			/* Decoding result */
#define BAR_DEC_NG						1			/* Decoding result */
#define BAR_NON_DETECT					2			/* No symbol			*/
#define QR_DEC_OK						3			/* QR code decode ok	*/
#define QR_DEC_NG						4			/* too short interval	*/
#define SEAL_DEC_OK						5			/* There is discount seal recognition data */
#define SEAL_DEC_NG						6			/* There are discount seal recognition candidates /unt seal recognition candidates */
#define SEAL_NON_DETECT					7			/* No discount seal recognition candidate */
#define NO_DATA							8
#define INPUT_IMG						9
#define QR_DETECT						10			/* With finder pattern */
#define BAR_HARF_OK						11			/* Half recognition */
#define BAR_DEC_NEBIKI_TIMEOUT			12			/* Data transmission when discount timeout	*/
#define FLG_DETECT						13			/* Flag seal detection successful */

#define DM_DEC_OK						14			/* DataMatrix decode ok	�yIS-820 ver G�zDataMatrix�Ή�*/
#define DM_DEC_NG						15			/* DataMatrix decode of �yIS-820 ver G�zDataMatrix�Ή�*/

#define SCAN_OK							1			/* Reading interval judgment result */
#define SCAN_NG							-1			/* Reading interval judgment result */

/************************************************/
/*     Software control flag & setting value	*/
/************************************************/
#define FLAG_PASS_THROUGH_INPUT_IMAGE			0x00000001		/* Through display mode	*/
#define FLAG_SCANNING_INTERVAL					0x00000002		/* Double reading control	*/
#define FLAG_DECODE_QRCODE						0x00000004
#define FLAG_DECODE_RSS							0x00000008
#define FLAG_NO_INPUTIMAGE						0x00000010		/* Output only decoded image for rotation test	*/
#define FLAG_GAIN_CTRL_MOBILE					0x00000100		/* GAIN control for mobile phone reading */ /* 070823 */
#define FLAG_SET_OPOS_MODE						0x00000200		/* OPOS connection mode */ /* 070823 */
#define FLAG_DEC_IMAGE_OUTPUT_ENABLE			0x00001000		/* Output setting of decoded image */
#define FLAG_DECODE_SEAL						0x00002000
#define FLAG_DECODE_QR_MODEL1					0x00004000		/* 071016 */
#define FLAG_DECODE_QR_MODEL2					0x00008000		/* 071016 */
#define FLAG_DECODE_MICRO_QR					0x00010000		/* 071016 */
#define FLAG_DECODE_CODE39_FULL					0x00020000		/* 071115 */
#define FLAG_DECODE_CODE39_CD					0x00040000		/* 071115 */
#define FLAG_DECODE_CODE39						0x00080000		/* 071115 */

#define FLAG_ADD_ON_MIX_						0x00100000		/* ADD-ON code Mixed reading */
#define FLAG_ADD_ON_DISABLE						0x00200000		/* ADD-ON code Unreadable */
#define FLAG_ADD_ON_ENABLE						0x00400000		/* Read only ADD-ON code */
#define FLAG_ADD_ON_WAIT_ON						0x00800000		/* ADD-ON code without reading WAIT */
#define FLAG_ADD_ON_WAIT_OFF					0x01000000		/* ADD-ON code with read WAIT */
#define FLAG_ADD_ON_SCAN_BOTH					0x02000000		/* ADD-ON code 2/5 readable */
#define FLAG_ADD_ON_SCAN_ONLY_2					0x04000000		/* Only ADD-ON code 2 can be read */
#define FLAG_ADD_ON_SCAN_ONLY_5					0x08000000		/* Only ADD-ON code 5 can be read */

#define FLAG_DECODE_NW7							0x10000000		/* Industrial barcode */
#define FLAG_DECODE_NW7_CD						0x20000000		/* Industrial barcode */
#define FLAG_DECODE_CODE93						0x40000000		/* Industrial barcode */
//------------------------------------------------------------------------------constant for SoftwareFlag2
#define FLAG_DECODE_ITF							0x00000001		/* Industrial barcode */
#define FLAG_DECODE_ITF_CD						0x00000002		/* Industrial barcode */

#endif
