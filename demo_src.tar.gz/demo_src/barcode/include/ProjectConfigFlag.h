/******IS820 delay configuration*******/

#define IS_820_DELAY_US 50000
#define IDEAL_DELAY_TIME_S 1
#define TX_EVENT_DELAY_US 10000

/******IS820 delay configuration end*******/

/******IS820 test configuration*******/

#define TIMER_VALUE 1
#define ITERATION_COUNT 3
#define PERFORMANCE_TEST  0 //0 = no Performance test, 1 = performance test without Camera, 
							//2 = performance test with camera, 3 = performance test Timer without camera
#define DEBUG_TEST			//enable debug print

/******IS820 test configuration end*******/

/***************Non Updaitng Section*****************/
#if(PERFORMANCE_TEST == 1)
	#define PERFORMANCE_TEST_WITHOUT_CAM
#elif(PERFORMANCE_TEST == 2)
	#define PERFORMANCE_TEST_WITH_CAM
#elif(PERFORMANCE_TEST == 3)
	#define PERFORMANCE_TEST_WITHOUT_CAM
	#define PERFORMANCE_TEST_WITH_TIMER
#else
	#define NO_PERFORMANCE_TEST
#endif
