/*******************************************************************/
/*                                                                 */
/* Copyright(C) 2013 Grape Systems, Inc. All Rights Reserved.      */
/*                                                                 */
/*                                                                 */
/* This software is furnished under a license and may be used      */
/* and copied only in accordance with the terms of such license    */
/* and with the inclusion of the above copyright notice.           */
/* No title to and ownership of the software is transferred.       */
/*                                                                 */
/* Grape Systems Inc. makes no representation or warranties with   */
/* respect to the performance of this computer program, and        */
/* specifically disclaims any responsibility for any damages,      */
/* special or consequential, connected with the use of this        */
/* program.                                                        */
/*                                                                 */
/*******************************************************************/
/*                                                                 */
/*	< PRODUCT   >                                                  */
/*    GR-DataMatrix/DECODER                                        */
/*                                                                 */
/*  < FILENAME  >                                                  */
/*	  GrDmDecooder.h                                               */
/*                                                                 */
/*  < HISTORY   >                                                  */
/*    2013.07.01	Ver1.00 Create                                 */
/*    2015.10.23	Ver1.01 X12�̓���p�^�[���ւ̑Ή�              */
/*                          Macro�̃g���[���[�����C��              */
/*    2019.10.09	Ver1.02 �N���b�N�p�^�[�����������ɂă��W���[�� */
/*                          ��72�𒴂������ɗ�������ɑΉ�     */
/*                                                                 */
/*******************************************************************/ 

#ifndef	_GrDmDecoder_h_
#define	_GrDmDecoder_h_

/*******************************************************************/
/* �@�\����                                                        */
/*******************************************************************/

/*******************************************************************/

/* ���E�l�����Z�o���̃A���S���Y�� 0-�Z�p���� 1-�q�X�g�O���� */
#define GRDMD_THRESHOLD_ALGORITHM	1	
/* ECI�̗L�������@0-���� 1-�L��                                                     */
/* �L�����̓o�b�N�X���b�V��������\�}�[�N�̓G�X�P�[�v�V�[�P���X�ƂȂ��d�\�L�����B*/
#define GRDMD_ENABLE_ECI			0

#define GRDMD_MAX_MODULE_COUNT		144
#define GRDMD_MAX_CHARCTERS			3116

/* Image Data */
typedef struct tagGRDMD_IMAGE_INFO
{
	unsigned char*	pMatrix		; /* Image Data (Byte Mattrix Monotone 0-255)*/
//TODO:IMP	int*   	pDummy      ;
	int		nWidth		; /* Image Width(pixel) */
	int		nHeight		; /* Image Height(pixel) */
	int    nRangeX[2]	; /* Varid range. index 0 is top left. 1 is bottom right. */
	int    nRangeY[2]  ; /* Varid range. index 0 is top left. 1 is bottom right. */
} GRDMD_IMAGE_INFO , *lpGRDMD_IMAGE_INFO;


/* DataMatrix Data for One */
typedef struct tagGRDMD_CODE_DATA
{
	int				nRows           ;   /* Row modules                 */
	int				nCols           ;   /* Column modules              */
	int				nRectX[4]		;	/* Code Rect Position X	   */
	int				nRectY[4]		;	/* Code Rect Position Y	   */
	int				nCodeLen		;	/* Code length    */
	
	/* Structured Append Info */
	int                nNum			;	/*  */
	int                nDenomi			;	/*  */
	int				nFileId			;	/*  */

	int				nErrCorCnt		;	/* Error Correct Count */
} GRDMD_CODE_DATA , *lpGRDMD_CODE_DATA		;

typedef struct tagGRDMD_TraceData
{
	unsigned short	x			; 
	unsigned short	y			;
	signed char		direction   ;
	signed char		dummy[3]	;
	float	radian				;
	double	abex				; 
	double	abey				;
} GRDMD_TraceData , *lpGRDMD_TraceData ;

/* The decode Parameta of the Data Matrix cord */
typedef struct tagGRDMD_DECODE_PARAM
{
	GRDMD_IMAGE_INFO	ImageSrc		;	/* Image data Source                     */

	int	nThreshold					;	/* I/O Threshold of Bright & Dark 0-255 (0-Auto) */
	int bEnableFilter				;	/* I   Enable Filter Processing */
	int	nScanLineIntervals          ;   /* I   At intervals of how many lines does it scan (0 is transposed to default )*/
	int	nBufSize					;   /* I   size of BarcodeDataBuf                          */
	int	nMaxReadCnt					;   /* I   �ǂݍ��ލő�o�[�R�[�h�� 0�̏ꍇ�S�Ẵo�[�R�[�h��ǂݍ��� */
	int	nBarcodeCnt					;   /* O   The number of the decoded bar code                         */
	unsigned char*   pBarcodeDataBuf    ;   /* I �f�R�[�h�����o�[�R�[�h�̃f�[�^���i�[����̈� */
	unsigned char*   pWorkImage			;   /* I ��ƈ�̃|�C���^ �摜�T�C�Y���̍�ƈ��p�ӂ���B            */
	GRDMD_TraceData* pWorkTrace         ;   /* I ��ƈ�̃|�C���^ �̈�̃T�C�Y�͈ȉ��̒ʂ�                    */
											/*�@ sizeof(GRDMD_TraceData) * (�摜�̒����ӂ̃h�b�g��) * 6       */
	//TODO:IMP	int*	pDummy                      ;
} GRDMD_DECODE_PARAM , *lpGRDMD_DECODE_PARAM;

/* //////////////////////////////////////////////////////////// */

/* Function */
#ifdef __cplusplus
extern "C" {
#endif

int GRDMD_DecodeDataMatrix(GRDMD_DECODE_PARAM* pParam) ;

int GRDMD_GetTraceBufferSize( int nWidth , int nHeight) ;

#ifdef __cplusplus
}
#endif

#endif /* _GrDmDecoder_h_ */
