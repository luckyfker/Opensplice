/*******************************************************************/
/*                                                                 */
/* Copyright(C) 2011 Grape Systems, Inc.   All Rights Reserved.    */
/*                                                                 */
/*                                                                 */
/* This software is furnished under a license and may be used      */
/* and copied only in accordance with the terms of such license    */
/* and with the inclusion of the above copyright notice.           */
/* No title to and ownership of the software is transferred.       */
/*                                                                 */
/* Grape Systems Inc. makes no representation or warranties with   */
/* respect to the performance of this computer program, and        */
/* specifically disclaims any responsibility for any damages,      */
/* special or consequential, connected with the use of this        */
/* program.                                                        */
/*                                                                 */
/*                                                                 */
/*******************************************************************/
/*                                                                 */
/*	< PRODUCT   >                                                  */
/*    GR-Homography Decomposition                                  */
/*                                                                 */
/*  < FILENAME  >                                                  */
/*	  GrHomography.h                                               */
/*                                                                 */
/*  < HISTORY   >                                                  */
/*    2011.12.26	Ver1.00 Create                                 */
/*                                                                 */
/*******************************************************************/ 

#ifndef	_GrHomography_h_
#define	_GrHomography_h_

/* Function */
#ifdef __cplusplus
extern "C" {
#endif

/* �ˉe�ϊ��W���Z�o*/
void GR_CalcHomographyCoefficient(double *dxy , double *dXY, double dA[8] );
/* �ˉe�ϊ�*/
void GR_HomographyDecomposition( double dx, double dy, double dA[8] ,double *dX, double  *dY);

#ifdef __cplusplus
}
#endif

#endif /* 	_GrHomography_h_ */
