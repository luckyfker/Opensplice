/***************************************************************************
 *	Copyright (C) 2009
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		QR_BasicFunc.h
 *	\brief 		QR Code Basic functions module

				This file includes the memory operation functions, 
				the image processing functions and data structure maniplute functions.
 *	@date		2009.08.10	�V�K�쐬
 *	@author		TCH-���ؑ�w (chach-up Mihara_Hidemi)
****************************************************************************/
#ifndef BASICFUNC_H
#define BASICFUNC_H

#if defined(USE_SEAL_RECOGNITION) || defined(DEBUG_FLAG_ONLY_RECOGNITION) || defined(USE_QR_DECODE)		// �l�����V�[�� or QR�R�[�h

#define ERROR_MEMORY 1

int CheckFlagSealFeature(unsigned char *inP, int LavelNumber0, int LavelNumber1, int LavelNumber2, int LavelNumber3, int bar, int n );

int GT_Otsu(unsigned char *image, int x0, int y0, int dx, int dy);
int GT_OtsuBufL255(unsigned char * pixelBuf, int cnt);

#endif

#endif
