/***************************************************************************
 *	Copyright (C) 2009
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		EditDecodeData.h
 *	\brief 		���M�f�[�^�ҏW����
 *
 *	@date		2009.08.10	�V�K�쐬
 *	@author		Mihara_Hidemi@toshibatec.co.jp
****************************************************************************/


typedef enum _Code128Offseal {	// CODE128 �I�t�V�[�� ���
	CODE128_NOT_OFFSEAL,		// �I�t�V�[���łȂ�
	CODE128_OFFSEAL,			// �I�t�V�[��
	CODE128_OFFSEAL26,			// 26���L�����ԃ��x��

	Code128Offseal_Num
} Code128Offseal;

// ======== Prototypes ========================================================
void SetDecodeTextDataAddOn(unsigned char *pStringOut);
void SetDecodeTextDataPlural(
	unsigned char 	*pStringOut,
	int flag1,
	int flag);
void SetDecodeTextDataPlural3(unsigned char *pStringOut);

void SetCharData(unsigned char code);

int BackupScanData(char flag);
int BackupScanDataAddOn();
int BackupScanDataPlural();
int BackupScanDataPlural3();
int BackupScanDataPlural_check();														//�yVer J�z
int BackupScanDataPlural3_check();														//

int CheckMod10Wt3(char *pSrc, int n);

int CmpOffseal();

void WriteDecData(unsigned char *pStringOut, char flag);
void WriteDecDataForOPOS(unsigned char *pStringOut, char flag);
void WriteDecDataForOriginal(unsigned char *pStringOut, char flag);

#ifdef USE_SEAL_RECOGNITION		// �l�����V�[��
void SetFlagSealFind();
int OffsealCheck(int code, char *pSrc);
int Play_sound_Pre();
void SetNebikiSealTimeout();
#endif
