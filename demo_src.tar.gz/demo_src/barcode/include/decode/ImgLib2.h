/***************************************************************************
 *	Copyright (C) 2009
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		ImgLib2.h
 *	\brief 		Image processing library 2 (for QR code)
 *	@date		2009.08.10	�V�K�쐬
 *	@author		Mihara_Hidemi@toshibatec.co.jp
****************************************************************************/

#include "AbsoluteDefinition.h"
#ifdef USE_QR_DECODE			// QR�R�[�h
#include "QR_Common.h"
#endif

// ======== Prototypes (Gloval functions)===================================
int IPT_init_2(void);
#ifdef USE_QR_DECODE			// QR�R�[�h
void Create_EdgeImage_from_Label(unsigned char *in);
void IPT_Label_Selection(IPCombineTbl *tblB, IPCombineTblExt *tblE);
PosDetPatternList * IPT_Cluster(IPCombineTbl *tblB,IPCombineTblExt *tblE);
#endif
#if defined(USE_SEAL_RECOGNITION) || defined(DEBUG_FLAG_ONLY_RECOGNITION)		// �l�����V�[��
void IPT_Label_SelectionForSeal(IPCombineTbl *tblB, IPCombineTblExt *tblE);
int IPT_ClusterForSeal(unsigned char *inP, IPCombineTbl *tblB,IPCombineTblExt *tblE);
int CheckOvalness(int tableNo);		// (TrigSeal.c)
#endif
void IPT_CutCombine2
(
	unsigned char *in,		/* Input image data						*/	
	unsigned char *out0,	/* Copy input image						*/
	unsigned char *out1,	/* Output image data P02(Laplacian4)	*/
	unsigned char *out2,	/* Output image data P22(Sobel)			*/
	unsigned char *out3,	/* Output image data P23(Sobel Binarize)*/
	unsigned char *out4,	/* Output image data P03(�ے�_����)    */
	short cols, short rows,	/* Image dimensions						*/
	unsigned char th		/* Binarize Threshold					*/
);

