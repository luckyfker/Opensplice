#ifndef APL_COMMON_H_
#define APL_COMMON_H_
#include <time.h>
#include <sys/time.h>

/* APL RETURN CODE */
#define APL_RETCODE_OK               0
#define APL_RETCODE_NG               -1

/* Delivery mode */
#define APL_DELIVERY_DDS             1
#define APL_DELIVERY_SHM             2

/* Recv mode */
#define APL_DDS_RECV_FILTER_ON       1
#define APL_DDS_RECV_PROFIBIT        2 

/* DDS RequestType flag */
#define APL_DDS_REQ_NONE               0
#define APL_DDS_REQ_BARCODE_RECOG      1
#define APL_DDS_REQ_PRICE_CUT          2
#define APL_DDS_REQ_BARCODE_PRICE_CUT  3
#define APL_DDS_REQ_PRICE_RECOG        4

/* log file */
#define APL_STREAMING_LOG_FILE       "/demo/app/log/apl_streaming.log"
#define APL_DDS_BARCODE_LOG_FILE     "/demo/app/log/apl_dds_barcode_recognition.log"
#define APL_DDS_CUTTING_LOG_FILE     "/demo/app/log/apl_dds_pricereduction_cutting.log"
#define APL_DDS_PRICE_RECOG_LOG_FILE "/demo/app/log/apl_dds_pricereduction_recognition.log"
#define APL_DDS_MERGE_LOG_FILE       "/demo/app/log/apl_dds_recognition_marge.log"

/* log level */
#define LOG_SYSERR                    1
#define LOG_ERR                       2
#define LOG_INFO                      3
#define LOG_DEBUG                     4 

#define LOGOUT_INTERVAL               100

/* pid file */
#define APL_STREAMING_PID_FILE       "/demo/app/pid/.apl_streaming.pid"
#define APL_DDS_BARCODE_PID_FILE     "/demo/app/pid/.apl_dds_barcode_recognition.pid"
#define APL_DDS_CUTTING_PID_FILE     "/demo/app/pid/.apl_dds_pricereduction_cutting.pid"
#define APL_DDS_PRICE_RECOG_PID_FILE "/demo/app/pid/.apl_dds_pricereduction_recognition.pid"
#define APL_DDS_MERGE_PID_FILE       "/demo/app/pid/.apl_dds_recognition_marge.pid"

/* conf file */
#define APL_COMMON_CNF_FILE          "/demo/app/cnf/apl_common.cnf"
#define APL_STREAMING_CNF_FILE       "/demo/app/cnf/apl_streaming.cnf"
#define APL_DDS_BARCODE_CNF_FILE     "/demo/app/cnf/apl_dds_barcode_recognition.cnf"
#define APL_DDS_CUTTING_CNF_FILE     "/demo/app/cnf/apl_dds_pricereduction_cutting.cnf"
#define APL_DDS_PRICE_RECOG_CNF_FILE "/demo/app/cnf/apl_dds_pricereduction_recognition.cnf"
#define APL_DDS_MERGE_CNF_FILE       "/demo/app/cnf/apl_dds_recognition_marge.cnf"

/* qos file */
#define APL_STREAMING_QOS_FILE       "file:///demo/app/qos/apl_streaming.xml"
#define APL_DDS_BARCODE_QOS_FILE     "file:///demo/app/qos/apl_dds_barcode_recognition.xml"
#define APL_DDS_CUTTING_QOS_FILE     "file:///demo/app/qos/apl_dds_pricereduction_cutting.xml"
#define APL_DDS_PRICE_RECOG_QOS_FILE "file:///demo/app/qos/apl_dds_pricereduction_recognition.xml"
#define APL_DDS_MERGE_QOS_FILE       "file:///demo/app/qos/apl_dds_recognition_marge.xml"
#define APL_DDS_MERGE_DEVINFO_QOS_FILE "file:///demo/app/qos/apl_dds_recognition_marge_devinfo.xml"

/* dds lib */
#define APL_STREAMING_LIB_PATH       "/demo/app/lib/libtype_camera_image.so"
#define APL_BARCODE_LIB_PATH         "/demo/app/lib/libtype_barcode_recognition.so"
#define APL_PRICE_CUT_LIB_PATH       "/demo/app/lib/libtype_price_reduction_cut.so"
#define APL_PRICE_RECOG_LIB_PATH     "/demo/app/lib/libtype_price_reduction_recognition.so"
#define APL_RESULT_TOTAL_LIB_PATH    "/demo/app/lib/libtype_recognition_result_total.so"
#define APL_DEVICE_INFO_LIB_PATH     "/demo/app/lib/libtype_device_info.so"

#define IMAGE_MAX_SIZE               1*1280*1024
#define IMAGE_CUT_MAX_SIZE           3*64*64

#define APL_ID_MAX_LEN               16
#define APL_RESULT_MAX_LEN           16
#define APL_CUT_IMAGE_MAX_LEN        12288

#define APL_TIMEOUT_ERR_CODE         2

#define APL_CAMERADATA_GETALREADY      0x01        /* カメラデータ受信済み */
#define APL_BARCODEDATA_GETALREADY     0x02        /* バーコードデータ受信済み */
#define APL_PRICECUT_GETALREADY		0x04        /* 値引き切出しデータ受信済み */
#define APL_PRICERECOG_GETALREADY		0x08        /* 値引き認識データ受信済み */
#define APL_ALLDATA_GETALREADY			0x0f		/* 全データ受信済み *///(APL_CAMERADATA_GETALREADY|APL_BARCODEDATA_GETALREADY|APL_PRICECUT_GETALREADY|APL_PRICERECOG_GETALREADY)

/* camera image data for shared memory */
typedef struct {
	char                srcCameraId[APL_ID_MAX_LEN];
    char                aplId[APL_ID_MAX_LEN];
	struct timeval      date;
	unsigned long        srcSeqNo;
	unsigned int        imageSize;
	unsigned char       imageData[IMAGE_MAX_SIZE]; 
} aplCamera_t;

/* barcode recognition data for shared memory */
typedef struct{
	char                request_AplId[APL_ID_MAX_LEN];
    char                request_CameraId[APL_ID_MAX_LEN];
	struct timeval      request_Date;
    unsigned long        request_SeqNo;
    int                 response_Barcode_ResultCode;
    char                response_Barcode_strRecognition[APL_RESULT_MAX_LEN];
} aplBarcodeRecognition_t;

/* price reduction cut for shared memory */
typedef struct{
    char                request_AplId[APL_ID_MAX_LEN];
    char                request_CameraId[APL_ID_MAX_LEN];
    struct timeval      request_Date;
    unsigned long        request_SeqNo;
    int                 response_PricereductionCut_ResultCode;
    unsigned int        response_PricereductionCut_DataSize;
    unsigned char       response_PricereductionCut_cutImage[IMAGE_CUT_MAX_SIZE];
} aplPricereductionCut_t;

/* price reduction recognition for shared memory */
typedef struct{
    char                request_AplId[APL_ID_MAX_LEN];
    char                request_CameraId[APL_ID_MAX_LEN];
    struct timeval      request_Date;
    unsigned long        request_SeqNo;
    int                 response_Pricereduction_ResultCode;
    char                response_Pricereduction_srtRecognition[APL_RESULT_MAX_LEN];
} aplPricereductionRecognition_t;

/* cmera image data for mergeTotal data */
typedef struct {
    char                   srcCameraId[APL_ID_MAX_LEN];
    char                   aplId[APL_ID_MAX_LEN];
    unsigned int          imageSize;
    unsigned char			imageData[IMAGE_MAX_SIZE];
} aplMergeTotalCamera_t;

/* barcode recognition data for mergeTotal data */
typedef struct{
    int                    response_Barcode_ResultCode;
    char                   response_Barcode_strRecognition[APL_RESULT_MAX_LEN];
} aplMergeTotal_BarcodeRecognition_t;

/* price reduction cut for mergeTotal data */
typedef struct{
    int                    response_PricereductionCut_ResultCode;
    unsigned int          response_PricereductionCut_DataSize;
    unsigned char         response_PricereductionCut_cutImage[IMAGE_CUT_MAX_SIZE];
} aplMergeTotal_PricereductionCut_t;

/* price reduction recognition for mergeTotal data */
typedef struct{
    int                 response_Pricereduction_ResultCode;
    char                response_Pricereduction_srtRecognition[APL_RESULT_MAX_LEN];
} aplMergeTotal_PricereductionRecognition_t;

/* total for merge */
typedef struct aplMergeTotal{
	aplMergeTotalCamera_t                       aplMergeTotalCamera;
	aplMergeTotal_BarcodeRecognition_t          aplMergeTotalBarcodeRecognition;
	aplMergeTotal_PricereductionCut_t           aplMergeTotalPricereductionCut;
	aplMergeTotal_PricereductionRecognition_t   aplMergeTotalPricereductionRecognition;
    struct timeval                             createTime;
    unsigned long                             request_SeqNo;
    char                                       response_Barcode_DeviceId[APL_ID_MAX_LEN];
    char                                       response_PricereductionCut_DeviceId[APL_ID_MAX_LEN];
    char                                       response_Pricereduction_DeviceId[APL_ID_MAX_LEN];
    int                                        getAlready;		/* 受信済み情報格納（bit単位） */
    struct aplMergeTotal                       *next;
} aplMergeTotal_t;

/* DDS時間計測オプション */
#define DDS_TIME_LOGOUT            /* DDS時間計測用 非計測時はこの行をコメントアウトすること */
#define SHM_TIME_LOGOUT            /* 共有メモリ時間計測用 非計測時はこの行をコメントアウトすること */
#define DDS_MARGE_TIME_LOGOUT      /* apl_dds_recogniton_margeアプリのDDS OUTPUT時間計測用 非計測時はこの行をコメントアウトすること */


#ifdef DDS_TIME_LOGOUT
    #define APL_STREAMING_DDS_SEND                         "/demo/app/log/apl_streaming_ddssend.log"
    #define APL_BARCODE_RECOGNITION_DDS_SEND               "/demo/app/log/apl_dds_barcode_recognition_ddssend.log"
    #define APL_BARCODE_RECOGNITION_DDS_RECV               "/demo/app/log/apl_dds_barcode_recognition_ddsrecv.log"
    #define APL_PRICEREDUCTION_CUTTING_DDS_SEND            "/demo/app/log/apl_dds_pricereduction_cutting_ddssend.log"
    #define APL_PRICEREDUCTION_CUTTING_DDS_RECV            "/demo/app/log/apl_dds_pricereduction_cutting_ddsrecv.log"
    #define APL_PRICEREDUCTION_RECOGNITION_DDS_SEND        "/demo/app/log/apl_dds_pricereduction_recognition_ddssend.log"
    #define APL_PRICEREDUCTION_RECOGNITION_DDS_RECV        "/demo/app/log/apl_dds_pricereduction_recognition_ddsrecv.log"
    #define APL_RECOGNITION_MARGE_DDS_RECV_CAMERA          "/demo/app/log/apl_dds_recognition_marge_ddsrecv_camera.log"
    #define APL_RECOGNITION_MARGE_DDS_RECV_BARCODE         "/demo/app/log/apl_dds_recognition_marge_ddsrecv_barcode.log"
    #define APL_RECOGNITION_MARGE_DDS_RECV_PRICECUT        "/demo/app/log/apl_dds_recognition_marge_ddsrecv_pricecut.log"
    #define APL_RECOGNITION_MARGE_DDS_RECV_PRICERECOG      "/demo/app/log/apl_dds_recognition_marge_ddsrecv_pricerecog.log"
#endif

#ifdef SHM_TIME_LOGOUT
    #define APL_STREAMING_SHM_SEND                         "/demo/app/log/apl_streaming_shmsend.log"
    #define APL_BARCODE_RECOGNITION_SHM_SEND               "/demo/app/log/apl_dds_barcode_recognition_shmsend.log"
    #define APL_BARCODE_RECOGNITION_SHM_RECV               "/demo/app/log/apl_dds_barcode_recognition_shmrecv.log"
    #define APL_PRICEREDUCTION_CUTTING_SHM_SEND            "/demo/app/log/apl_dds_pricereduction_cutting_shmsend.log"
    #define APL_PRICEREDUCTION_CUTTING_SHM_RECV            "/demo/app/log/apl_dds_pricereduction_cutting_shmrecv.log"
    #define APL_PRICEREDUCTION_RECOGNITION_SHM_SEND        "/demo/app/log/apl_dds_pricereduction_recognition_shmsend.log"
    #define APL_PRICEREDUCTION_RECOGNITION_SHM_RECV        "/demo/app/log/apl_dds_pricereduction_recognition_shmrecv.log"
    #define APL_RECOGNITION_MARGE_SHM_RECV_CAMERA          "/demo/app/log/apl_dds_recognition_marge_shmrecv_camera.log"
    #define APL_RECOGNITION_MARGE_SHM_RECV_BARCODE         "/demo/app/log/apl_dds_recognition_marge_shmrecv_barcode.log"
    #define APL_RECOGNITION_MARGE_SHM_RECV_PRICECUT        "/demo/app/log/apl_dds_recognition_marge_shmrecv_pricecut.log"
    #define APL_RECOGNITION_MARGE_SHM_RECV_PRICERECOG      "/demo/app/log/apl_dds_recognition_marge_shmrecv_pricerecog.log"
#endif
#ifdef DDS_MARGE_TIME_LOGOUT
    #define APL_RECOGNITION_MARGE_DDS_SEND_RESULT          "/demo/app/log/apl_dds_recognition_marge_ddssend_result.log"
    #define APL_RECOGNITION_MARGE_DDS_SEND_DEVICE          "/demo/app/log/apl_dds_recognition_marge_ddssend_device.log"
#endif

#endif
