////////////////////////////////////////////////////////////////////////////
//	Copyright (C) 2020
//	TOSHIBA TEC CORPORATION All Right Reserved
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//  FILE		:	fpga_sh_lib.h
//	DESCRIPTION	:	FPGA library header file, This file contain all the
//					API related to FPGA driver interaction.
//
//	CREATE ON	:	V001.000	Subham Das[TSIP]				2020.12.21
//
//	MODIFIED ON	:
////////////////////////////////////////////////////////////////////////////

#ifndef INCLUDE_FPGA_SH_LIB_FPGA_SH_LIB_H_
#define INCLUDE_FPGA_SH_LIB_FPGA_SH_LIB_H_

/***************************************************************************
 *	Macro Definition
****************************************************************************/
#define X_SIZE 1280
#define Y_SIZE 1024

/***************************************************************************
 *	Structure and Enum Definition
****************************************************************************/


/***************************************************************************
 *	Function Declaration
****************************************************************************/

bool unmergeData(unsigned char *mrgImg, unsigned char *rawImg, unsigned char *srpImg, unsigned char *runImg, unsigned char *redImg);

#endif /* INCLUDE_FPGA_SH_LIB_FPGA_SH_LIB_H_ */
