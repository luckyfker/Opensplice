#ifndef _TYPELIB__H_
#define _TYPELIB__H_

#include "dds_dcps.h"

typedef struct _TypeLib {
  void* handle;
  const char* topicName;

  DDS_TypeSupport (*alloc)(void);
  DDS_string (*getTypeName)(DDS_TypeSupport);
  DDS_ReturnCode_t (*registerType)(
    DDS_TypeSupport,
    const DDS_DomainParticipant,
    const DDS_string);
  DDS_ReturnCode_t (*writerWrite) (
    DDS_DataWriter,
    const void* instance_data,
    const DDS_InstanceHandle_t handle
    );

  DDS_ReturnCode_t (*readerTake) (
    DDS_DataReader,
    void *received_data,
    DDS_SampleInfoSeq *,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

  DDS_ReturnCode_t (*readerReturnLoan) (
    DDS_DataReader,
    void *received_data,
    DDS_SampleInfoSeq *info_seq
    );
} TypeLib;

typedef struct _WrappedHandler {
  DDS_DomainParticipant participant;
  DDS_Topic topic;
  DDS_Object pubSub;
  DDS_Object object;
  TypeLib* handle;
  struct _WrappedHandler* next;
} WrappedHandler;

TypeLib* TypeLib_alloc(const char* typeLib, const char* topicName, const char* dataType);
void TypeLib_free(TypeLib* lib);

void unregisterAllWrapperHandler();
WrappedHandler* findWrappedHandler(DDS_Object handler);
WrappedHandler* registerWrapperHandler(DDS_DomainParticipant participant, DDS_Topic topic, DDS_Object pubSub, DDS_Object object, TypeLib* lib);
DDS_boolean unregisterWrapperHandler(WrappedHandler* handle);
void unregisterAllWrapperHandler();


#endif