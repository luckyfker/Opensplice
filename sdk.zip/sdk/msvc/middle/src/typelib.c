
#include "typelib.h"

#ifdef WIN32
#include <Windows.h>
#else
#include <dlfcn.h>
#endif
#include <string.h>

#define FUNCTION_NAME_LENGTH 256

void adjustTypeName(char* functionName, int nameLength, const char* dataType) {
  char* firstWord = dataType;
  char* next = strstr(firstWord, "::");
  while (next != NULL) {
#ifdef WIN32
    strncat_s(functionName, nameLength, firstWord, next - firstWord);
    strcat_s(functionName, nameLength, "_");
#else
    strncat(functionName, firstWord, next - firstWord);
    strcat(functionName, "_");
#endif
    firstWord = next + 2;
    next = strstr(firstWord, "::");
  }

  if (firstWord != NULL && *firstWord != 0) {
#ifdef WIN32
    strcat_s(functionName, nameLength, firstWord);
#else
    strcat(functionName, firstWord);
#endif
  }
}

TypeLib* TypeLib_alloc(const char* typeLib, const char* topicName, const char* dataType) {
#ifdef WIN32
  HINSTANCE handle = LoadLibraryA(typeLib);
#else
  void* handle = dlopen(typeLib, RTLD_LAZY);
#endif
  if (!handle) {
    // Cannot load typelib
    return NULL;
  }

  // Temporary function to dlsym
  char functionName[FUNCTION_NAME_LENGTH] = {0};
  char baseFunctionName[FUNCTION_NAME_LENGTH] = { 0 };
  adjustTypeName(baseFunctionName, FUNCTION_NAME_LENGTH, dataType);

  TypeLib* lib = (TypeLib*) malloc(sizeof(TypeLib));
  lib->handle = handle;
  lib->topicName = topicName;

  struct _TypeLibFunction {
    const char* suffix;
    void** handler;
  } functions[] = {
    {"TypeSupport__alloc", (void**)&lib->alloc},
    {"TypeSupport_get_type_name", (void**)&lib->getTypeName},
    {"TypeSupport_register_type", (void**)&lib->registerType},
    {"DataWriter_write", (void**)&lib->writerWrite},
    {"DataReader_take", (void**)&lib->readerTake},
    {"DataReader_return_loan", (void**)&lib->readerReturnLoan},
    {NULL, NULL}
  };

  for (int i = 0; ; i++) {
    struct _TypeLibFunction* t = &functions[i];
    if (t->suffix == NULL) {
      break;
    }

    memset(functionName, 0x0, FUNCTION_NAME_LENGTH);
    os_strcat(os_strcpy(functionName, baseFunctionName), t->suffix);
#ifdef WIN32
    *(t->handler) = GetProcAddress(handle, functionName);
#else
    *(t->handler) = dlsym(handle, functionName);
#endif // WIN32
  }

  return lib;
}

void TypeLib_free(TypeLib* lib) {
  if (!lib|| !lib->handle) {
    return;
  }

#ifdef WIN32
  FreeLibrary(lib->handle);
#else
  dlclose(lib->handle);
#endif // WIN32
  lib->handle = NULL;

  free(lib);
}

WrappedHandler* rwHandlerList = NULL;

WrappedHandler* findWrappedHandler(DDS_Object handler) {
  for (WrappedHandler* object = rwHandlerList; object != NULL; object = object->next) {
    if (object->object == handler) {
      return object;
    }
  }

  return NULL;
}


WrappedHandler* registerWrapperHandler(DDS_DomainParticipant participant, DDS_Topic topic, DDS_Object pubSub, DDS_Object object, TypeLib* lib) {
  if (findWrappedHandler(object) != NULL) {
    return NULL; // Already register
  }

  WrappedHandler* handle = (WrappedHandler*) malloc(sizeof(WrappedHandler));
  handle->participant = participant;
  handle->topic = topic;
  handle->pubSub = pubSub;
  handle->object = object;
  handle->handle = lib;
  handle->next = rwHandlerList;

  rwHandlerList = handle;
  return handle;
}


DDS_boolean unregisterWrapperHandler(WrappedHandler* handle) {
  if (handle == NULL) {
    return FALSE; // Not found
  }

  for (WrappedHandler* handleObject = rwHandlerList; handleObject != NULL; handleObject = handleObject->next) {
    if (handleObject->next == handle) {
      // remove this node
      handleObject->next = handle->next;
      break;
    }
  }

  if (rwHandlerList == handle) {
    rwHandlerList = handle->next;
  }

  // Free memory
  free(handle);
  return TRUE;
}

void unregisterAllWrapperHandler() {
  WrappedHandler* handle = rwHandlerList;
  while (handle != NULL) {
    WrappedHandler* nextHandle = handle->next;
    free(handle);
    handle = nextHandle;
  }

  rwHandlerList = NULL;
}

