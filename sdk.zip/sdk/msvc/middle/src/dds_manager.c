/*
 *                         Vortex OpenSplice
 *
 *   This software and documentation are Copyright 2006 to TO_YEAR ADLINK
 *   Technology Limited, its affiliated companies and licensors. All rights
 *   reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 *
 */

/************************************************************************
 * LOGICAL_NAME:    DDSEntitiesManager.c
 * FUNCTION:        Implementation of functions calling DDS OpenSplice API code using basic error handling.
 * MODULE:          OpenSplice HelloWorld example for the C programming language.
 * DATE             September 2010.
 ***********************************************************************/
#include "dds_manager.h"
#include "check.h"
#ifdef _WIN32
#include "os_stdlib.h"
#endif
#include "typelib.h"
#include <string.h>

typedef struct _Participant {
  const char* name;
  DDS_DomainParticipant participant;
  struct _Participant* next;
} Participant;

typedef struct _Domain {
  DDS_DomainId_t domainId;
  DDS_QosProvider provider;
  Participant* participant;
  struct _Domain* next;
} Domain;

Domain* domainList = NULL;

// DDS entities and other variables that can be made global
DDS_DomainParticipantFactory g_domainParticipantFactory = DDS_OBJECT_NIL;

// Error handling
DDS_ReturnCode_t g_status;

static Domain* Domain_alloc(DDS_DomainId_t domainId) {
  Domain* newDomain = (Domain*)malloc(sizeof(Domain));
  newDomain->domainId = domainId;
  newDomain->participant = NULL;
  newDomain->provider = DDS_OBJECT_NIL;
  newDomain->next = NULL;

  return newDomain;
}

static Participant* Participant_alloc(DDS_DomainParticipant participant, const char* name) {
  Participant* newParticipant = (Participant*)malloc(sizeof(Participant));
  newParticipant->name = name;
  newParticipant->participant = participant;
  newParticipant->next = NULL;

  return newParticipant;
}

Domain* findDomain(DDS_DomainId_t domainId) {
  for (Domain* domain = domainList; domain != NULL; domain = domain->next) {
    if (domain->domainId == domainId) {
      return domain;
    } else if (domain->domainId > domainId) {
      // Not found
      break;
    }
  }

  return NULL;
}

void freeDomain(DDS_DomainId_t domainId) {
  Domain* lastDomain = NULL;
  for (Domain* domain = domainList; domain != NULL; domain = domain->next) {
    if (domain->domainId == domainId) {
      if (lastDomain != NULL) {
        lastDomain->next = domain->next;
        free(domain);
      } else {
        // First one
        domainList = domain->next;
        free(domain);
      }
    }

    lastDomain = domain;
  }
}

DDS_ReturnCode_t setDomain(DDS_DomainId_t domainId) {
  Domain* lastDomain = NULL;
  for (Domain* domain = domainList; domain != NULL; domain = domain->next) {
    if (domain->domainId == domainId) {
      // Found it
      return DDS_RETCODE_OK;
    } else if (domain->domainId > domainId) {
      Domain* newDomain = Domain_alloc(domainId);
      newDomain->next = domain;

      if (lastDomain != NULL) {
        // Insert to between lastDomain and this domain
        lastDomain->next = newDomain;
      } else {
        // Become first node
        domainList = newDomain;
      }

      return DDS_RETCODE_OK;
    } else if (domain->next == NULL) {
      // This is the last, add to last
      Domain* newDomain = Domain_alloc(domainId);
      domain->next = newDomain;
      return DDS_RETCODE_OK;
    }

    lastDomain = domain;
  }

  // First in list
  if (domainList == NULL) {
    domainList = Domain_alloc(domainId);
    return DDS_RETCODE_OK;
  }

  return DDS_RETCODE_ERROR;
}

DDS_ReturnCode_t shutdownDomain(DDS_DomainId_t domainId) {
  Domain* domain = findDomain(domainId);
  if (domain == NULL) {
    return DDS_RETCODE_NO_DATA;
  }

  // clear provider
  if (domain->provider != DDS_OBJECT_NIL) {
    DDS_free(domain->provider);
    domain->provider = DDS_OBJECT_NIL;
  }

  while (domain->participant != NULL) {
    Participant* next = domain->participant->next;

    // Delete participant object
    deleteParticipant(domain->participant->participant);
    free(domain->participant);

    // Move to next
    domain->participant = next;
  }

  freeDomain(domainId);
  return DDS_RETCODE_OK;
}

DDS_ReturnCode_t setDomainQosProvider(int domainId, const char* uri) {
  Domain* domain = findDomain(domainId);
  CHECK_HANDLE_RETURN(domain, "findDomain", DDS_RETCODE_ERROR);

  // set provider
  if (domain->provider != DDS_OBJECT_NIL) {
    DDS_free(domain->provider);
  }
  domain->provider = DDS_QosProvider__alloc(uri, "DDS DefaultQosProfile");
  return (domain->provider != DDS_OBJECT_NIL) ? DDS_RETCODE_OK : DDS_RETCODE_ERROR;
}

DDS_DomainParticipant createParticipant(int domainId, const char* partitionName)
{
  Domain* domain = findDomain(domainId);
  CHECK_HANDLE_RETURN(domain, "findDomain", NULL);

  DDS_DomainParticipant domainParticipant = DDS_OBJECT_NIL;

  if (g_domainParticipantFactory == DDS_OBJECT_NIL) {
    g_domainParticipantFactory = DDS_DomainParticipantFactory_get_instance();
    CHECK_HANDLE_RETURN(g_domainParticipantFactory, "DDS_DomainParticipantFactory_get_instance", NULL);
  }

  // Get Participant QoS
  DDS_DomainParticipantQos* participantQos = DDS_DomainParticipantQos__alloc();
  g_status = DDS_QosProvider_get_participant_qos(domain->provider, participantQos, NULL);
  CHECK_STATUS_RETURN(g_status, "DDS_QosProvider_get_participant_qos", NULL);
  domainParticipant = DDS_DomainParticipantFactory_create_participant(g_domainParticipantFactory, domainId, participantQos, NULL, DDS_STATUS_MASK_NONE);

  CHECK_HANDLE_RETURN(domainParticipant, "DDS_DomainParticipantFactory_create_participant", NULL);

  // add participant to pool
  Participant* newParticipant = Participant_alloc(domainParticipant, partitionName);
  newParticipant->next = domain->participant;
  domain->participant = newParticipant;

  return domainParticipant;
}

void deleteParticipant(DDS_DomainParticipant domainParticipant)
{
   g_status = DDS_DomainParticipantFactory_delete_participant(g_domainParticipantFactory, domainParticipant);
   checkStatus(g_status, "DDS_DomainParticipantFactory_delete_participant");
}

void registerMessageType(DDS_DomainParticipant domainParticipant, DDS_TypeSupport messageTypeSupport, TypeLib* handle)
{
  DDS_string typeName = handle->getTypeName(messageTypeSupport);
  g_status = handle->registerType(messageTypeSupport, domainParticipant, typeName);
  checkStatus(g_status, "HelloWorldData_MsgTypeSupport_register_type");
  DDS_free(typeName);
}

DDS_Topic createTopic(DDS_DomainParticipant domainParticipant, const char *topicName, const char *typeName)
{
   DDS_Topic topic;
   const char* messageFirstPart;
   char* message;
   size_t messageFirstPartLength, topicNameLength;
   DDS_TopicQos* topicQos = DDS_TopicQos__alloc();
   CHECK_HANDLE_RETURN(topicQos, "DDS_TopicQos__alloc", NULL);
   DDS_DomainId_t domainId = DDS_DomainParticipant_get_domain_id(domainParticipant);

   Domain* domain = findDomain(domainId);
   CHECK_HANDLE_RETURN(domain, "findDomain not found", NULL);
   g_status = DDS_QosProvider_get_topic_qos(domain->provider, topicQos, NULL);
   CHECK_STATUS_RETURN(g_status, "DDS_QosProvider_get_topic_qos", NULL);

   topicQos->reliability.kind = DDS_RELIABLE_RELIABILITY_QOS;
   topicQos->durability.kind = DDS_TRANSIENT_DURABILITY_QOS;

   // Set the history Policy
   // topicQos.history.kind = KEEP_LAST_HISTORY_QOS;
   // topicQos.history.depth = 2;

   // Use the changed policy when defining the Ownership topic
   topic = DDS_DomainParticipant_create_topic(domainParticipant, topicName, typeName, topicQos, NULL, DDS_STATUS_MASK_NONE);
   CHECK_HANDLE_RETURN(topic, "DDS::DomainParticipant::create_topic ()", NULL);

   DDS_free(topicQos);
   return topic;
}

void deleteTopic(DDS_DomainParticipant domainParticipant, DDS_Topic topic)
{
   g_status = DDS_DomainParticipant_delete_topic(domainParticipant, topic);
   checkStatus(g_status, "DDS_DomainParticipant_delete_topic");
}

DDS_Publisher createPublisher(DDS_DomainParticipant domainParticipant, const char* partitionName)
{
   DDS_Publisher publisher;
   DDS_PublisherQos* publisherQos = DDS_PublisherQos__alloc();
   CHECK_HANDLE_RETURN(publisherQos, "DDS_PublisherQos__alloc", NULL);

   // Domain
   DDS_DomainId_t domainId = DDS_DomainParticipant_get_domain_id(domainParticipant);
   Domain* domain = findDomain(domainId);
   CHECK_HANDLE_RETURN(domain, "findDomain not found", NULL);

  // QoS
   g_status = DDS_QosProvider_get_publisher_qos(domain->provider, publisherQos, NULL);
   CHECK_STATUS_RETURN(g_status, "DDS_QosProvider_get_publisher_qos", NULL);
   publisherQos->partition.name._length = 1;
   publisherQos->partition.name._maximum = 1;
   publisherQos->partition.name._release = TRUE;
   publisherQos->partition.name._buffer = DDS_StringSeq_allocbuf(1);
   CHECK_HANDLE_RETURN(publisherQos->partition.name._buffer, "DDS_StringSeq_allocbuf", NULL);
   publisherQos->partition.name._buffer[0] = DDS_string_dup(partitionName);
   CHECK_HANDLE_RETURN(publisherQos->partition.name._buffer[0], "DDS_string_dup", NULL);

   /* Create a Publisher for the application. */
   publisher = DDS_DomainParticipant_create_publisher(domainParticipant, publisherQos, NULL, DDS_STATUS_MASK_NONE);
   CHECK_HANDLE_RETURN(publisher, "DDS_DomainParticipant_create_publisher", NULL);

   DDS_free(publisherQos);
   return publisher;
}

void deletePublisher(DDS_DomainParticipant domainParticipant, DDS_Publisher publisher)
{
   g_status = DDS_DomainParticipant_delete_publisher(domainParticipant, publisher);
   checkStatus(g_status, "DDS_DomainParticipant_delete_publisher");
}

DDS_DataWriter createDataWriter(DDS_Publisher publisher, DDS_Topic topic)
{
   DDS_DataWriter dataWriter;
   DDS_TopicQos *topicQos = DDS_TopicQos__alloc();
   DDS_DataWriterQos *dataWriterQos = DDS_DataWriterQos__alloc();
   CHECK_HANDLE_RETURN(dataWriterQos, "DDS_DataWriterQos__alloc", NULL);
   g_status = DDS_Publisher_get_default_datawriter_qos(publisher, dataWriterQos);
   CHECK_STATUS_RETURN(g_status, "DDS_Publisher_get_default_datawriter_qos", NULL);
   g_status = DDS_Topic_get_qos(topic, topicQos);
   CHECK_STATUS_RETURN(g_status, "DDS_Topic_get_qos", NULL);
   g_status = DDS_Publisher_copy_from_topic_qos(publisher, dataWriterQos, topicQos);
   CHECK_STATUS_RETURN(g_status, "DDS_Publisher_copy_from_topic_qos", NULL);
   dataWriterQos->writer_data_lifecycle.autodispose_unregistered_instances = FALSE;
   dataWriter = DDS_Publisher_create_datawriter(publisher, topic, dataWriterQos, NULL, DDS_STATUS_MASK_NONE);
   CHECK_HANDLE_RETURN(dataWriter, "DDS_Publisher_create_datawriter", NULL);

   DDS_free(dataWriterQos);
   DDS_free(topicQos);

   return dataWriter;
}

void deleteDataWriter(DDS_Publisher publisher, DDS_DataWriter dataWriter)
{
   g_status = DDS_Publisher_delete_datawriter(publisher, dataWriter);
   checkStatus(g_status, "DDS_Publisher_delete_datawriter");
}

DDS_Subscriber createSubscriber(DDS_DomainParticipant domainParticipant, const char* partitionName)
{
   DDS_Subscriber subscriber;
   // Adapt the default SubscriberQos to read from the Partition with the given name.
   DDS_SubscriberQos* subscriberQos = DDS_SubscriberQos__alloc();
   CHECK_HANDLE_RETURN(subscriberQos, "DDS_SubscriberQos__alloc", NULL);
   g_status = DDS_DomainParticipant_get_default_subscriber_qos(domainParticipant, subscriberQos);
   CHECK_STATUS_RETURN(g_status, "DDS_DomainParticipant_get_default_subscriber_qos", NULL);
   subscriberQos->partition.name._length = 1;
   subscriberQos->partition.name._maximum = 1;
   subscriberQos->partition.name._release = TRUE;
   subscriberQos->partition.name._buffer = DDS_StringSeq_allocbuf(1);
   CHECK_HANDLE_RETURN(subscriberQos->partition.name._buffer, "DDS_StringSeq_allocbuf", NULL);
   subscriberQos->partition.name._buffer[0] = DDS_string_dup(partitionName);
   CHECK_HANDLE_RETURN(subscriberQos->partition.name._buffer[0], "DDS_string_dup", NULL);

   // Create a Subscriber for the MessageBoard application.
   subscriber = DDS_DomainParticipant_create_subscriber(domainParticipant, subscriberQos, NULL, DDS_STATUS_MASK_NONE);
   CHECK_HANDLE_RETURN(subscriber, "DDS_DomainParticipant_create_subscriber", NULL);

   DDS_free(subscriberQos);

   return subscriber;
}

void deleteSubscriber(DDS_DomainParticipant domainParticipant, DDS_Subscriber subscriber)
{
   g_status = DDS_DomainParticipant_delete_subscriber(domainParticipant, subscriber);
   checkStatus(g_status, "DDS_DomainParticipant_delete_subscriber");
}

DDS_DataReader createDataReader(DDS_Subscriber subscriber, DDS_Topic topic)
{
   DDS_DataReader dataReader;
   DDS_TopicQos* topicQos;
   DDS_DataReaderQos* dataReaderQos;

   // Create a DataWriter for this Topic (using the appropriate QoS).
   dataReaderQos = DDS_DataReaderQos__alloc();
   CHECK_HANDLE_RETURN(dataReaderQos, "DDS_DataReaderQos__alloc", NULL);

   topicQos = DDS_TopicQos__alloc();
   CHECK_HANDLE_RETURN(topicQos, "DDS_TopicQos__alloc", NULL);

   g_status = DDS_Topic_get_qos(topic, topicQos);
   CHECK_STATUS_RETURN(g_status, "DDS_Topic_get_qos", NULL);

   g_status = DDS_Subscriber_get_default_datareader_qos(subscriber, dataReaderQos);
   CHECK_STATUS_RETURN(g_status, "DDS_Subscriber_get_default_datareader_qos", NULL);

   g_status = DDS_Subscriber_copy_from_topic_qos(subscriber, dataReaderQos, topicQos);
   CHECK_STATUS_RETURN(g_status, "DDS_Publisher_copy_from_topic_qos", NULL);

   dataReader = DDS_Subscriber_create_datareader(subscriber, topic, dataReaderQos, NULL, DDS_STATUS_MASK_NONE);
   CHECK_HANDLE_RETURN(dataReader, "DDS_Subscriber_create_datareader", NULL);

   DDS_free(dataReaderQos);
   DDS_free(topicQos);

   return dataReader;
}

void deleteDataReader(DDS_Subscriber subscriber, DDS_DataReader dataReader)
{
   g_status = DDS_Subscriber_delete_datareader(subscriber, dataReader);
   checkStatus(g_status, "DDS_Subscriber_delete_datareader");
}
