#include "com_middle.h"
#include "dds_manager.h"
#include "typelib.h"
#include "check.h"

#include <stdio.h>

#define NAME_SIZE 64

/**************************************************************************************************************/
/*!
    @brief : This function is use to create domain participant
    @param    : DomainID - Domain ID for which participant is created
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
CMStatus SetParticipant(int DomainID) {
  return (setDomain(DomainID) == DDS_RETCODE_OK) ?
                    CMSuccess :
                    CMFail;
}

/**************************************************************************************************************/
/*!
    @brief : This function is use to create the data writer
    @param    : DomainID - Domain ID for which participant is created
    @param    : topicName - Name of the topic
    @param    : QoS_Policy QoS - QoS file consists of all QoS parameters
    @param    : DataWriterID - Data writer id is passed
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
    @example:
    SetDataWriterLibUseQoSFile(g_domainID,
                               (char *)"Result_Send_Topic_Data",(char *)"Result_Send_Topic::Data",
                               "../../evaluation_topic/prog/bin/libevaluation_topic.so",
                               "file://../c/QosXmlFiles/test_Qos_Reliable.xml",
                               &g_message_DataWriter,
                               g_result);
*/
/**************************************************************************************************************/
CMStatus SetDataWriterLibUseQoSFile(int DomainID, const char *topicName, const char *typeName, const char *typeLib, const char *QoSFileName, CMULONG *DataWriterID, char *resultCode) {
  DDS_ReturnCode_t status = setDomainQosProvider(DomainID, QoSFileName);
  CHECK_STATUS_RETURN(status, "setDomainQosProvider", CMFail);

  // Create Participant
  DDS_DomainParticipant participant = createParticipant(DomainID, "ExampleWriter");
  CHECK_HANDLE_RETURN(participant, "createParticipant", CMFail);

  // Register message type
  TypeLib* lib = TypeLib_alloc(typeLib, topicName, typeName);
  CHECK_HANDLE_RETURN(lib, "TypeLib_alloc", CMFail);
  // Get message type support
  DDS_TypeSupport messageTypeSupport = lib->alloc();
  registerMessageType(participant, messageTypeSupport, lib);
  DDS_string messageTypeName = lib->getTypeName(messageTypeSupport);

  // Create topic
  DDS_Topic topic = createTopic(participant, topicName, messageTypeName);
  CHECK_HANDLE_RETURN(topic, "createTopic", CMFail);
  DDS_free(messageTypeName);
  DDS_free(messageTypeSupport);

  // Create publisher
  DDS_Publisher publisher = createPublisher(participant, "ExampleWriter");
  CHECK_HANDLE_RETURN(topic, "createPublisher", CMFail);

  // Create data writer
  DDS_DataWriter writer = createDataWriter(publisher, topic);

  registerWrapperHandler(participant, topic, publisher, writer, lib);
  if (resultCode != NULL) {
    *resultCode = 0;
  }

  *DataWriterID = (CMULONG)writer;
  return CMSuccess;
}

/**************************************************************************************************************/
/*!
    @brief : This function is use to create the data writer
    @param    : DomainID - Domain ID for which participant is created
    @param    : topicName - Name of the topic
    @param    : QoS_Policy QoS - QoS file consists of all QoS parameters
    @param    : DataWriterID - Data writer id is passed
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
CMStatus SetDataReaderLibUseQoSFile(int DomainID, const char *topicName, const char *typeName, const char *typeLib, const char *QoSFileName, CMULONG *DataReaderID, char *resultCode) {
  DDS_ReturnCode_t status = setDomainQosProvider(DomainID, QoSFileName);
  CHECK_STATUS_RETURN(status, "setDomainQosProvider", CMFail);

  // Create Participant
  DDS_DomainParticipant participant = createParticipant(DomainID, "ExampleReader");
  CHECK_HANDLE_RETURN(participant, "createParticipant", CMFail);

  // Register message type
  TypeLib* lib = TypeLib_alloc(typeLib, topicName, typeName);
  CHECK_HANDLE_RETURN(lib, "TypeLib_alloc", CMFail);
  // Get message type support
  DDS_TypeSupport messageTypeSupport = lib->alloc();
  registerMessageType(participant, messageTypeSupport, lib);
  DDS_string messageTypeName = lib->getTypeName(messageTypeSupport);

  // Create topic
  DDS_Topic topic = createTopic(participant, topicName, messageTypeName);
  CHECK_HANDLE_RETURN(topic, "createTopic", CMFail);
  DDS_free(messageTypeName);
  DDS_free(messageTypeSupport);

  // Create subcriber
  DDS_Subscriber subcriber = createSubscriber(participant, "ExampleReader");
  CHECK_HANDLE_RETURN(subcriber, "createSubscriber", CMFail);

  // Create data writer
  DDS_DataReader reader = createDataReader(subcriber, topic);
  CHECK_HANDLE_RETURN(reader, "createDataReader", CMFail);

  registerWrapperHandler(participant, topic, subcriber, reader, lib);
  if (resultCode != NULL) {
    *resultCode = 0;
  }

  *DataReaderID = (CMULONG)reader;
  return CMSuccess;
}

/**************************************************************************************************************/
/*!
    @brief : This function is use to publish data to specified domain
    @param    : DomainID - Domain ID for which participant is created
    @param    : datawriterId - Data writer id is provided
    @param    : publishData- Data to be published is passed here
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
CMStatus WritePublishData(int DomainID, CMULONG datawriterId, void *publishData, char *resultCode) {
  DDS_DataWriter dataWriter = (DDS_DataWriter)(void*)datawriterId;
  DDS_ReturnCode_t status = DDS_DataWriter_write(dataWriter, publishData, DDS_HANDLE_NIL);
  return checkStatus(status, "WritePublishData") ? CMSuccess : CMFail;
}

/**************************************************************************************************************/
/*!
    @brief : This function is use to read the data published by subscriber
    @param    : DomainID - Domain ID for which participant is created
    @param    : DataReaderID - Data reader id is provided
    @param    : SubData - the structure with received data is returned to application
    @param    : SubInfoSeq - the structure with sequence info is returned to application
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
CMStatus ReadSubscriberData(int DomainID, CMULONG datareaderId, void *SubData, void *SubInfoSeq, char *resultCode) {
	DDS_DataReader dataReader = (DDS_DataReader)(void*)datareaderId;
  DDS_ReturnCode_t status = DDS_DataReader_take(
          dataReader,
          SubData,
          SubInfoSeq,
          1,
          DDS_ANY_SAMPLE_STATE,
          DDS_ANY_VIEW_STATE,
          DDS_ANY_INSTANCE_STATE);
  return checkStatus(status, "ReadSubscriberData") ? CMSuccess : CMFail;
}

/**************************************************************************************************************/
/*!
    @brief : This function is used to delete the participant
    @param    : DomainID - Domain ID for which participant is created
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
CMStatus ShutdownParticipant(int DomainID, char *resultCode) {
  DDS_ReturnCode_t status = shutdownDomain(DomainID);
  return checkStatus(status, "ShutdownParticipant") ? CMSuccess : CMFail;
}

/**************************************************************************************************************/
/*!
    @brief : This function is used to delete data writer of specified Domain Id. Internally, the publisher and topic would also be deleted
    @param    : DomainID - Domain ID for which participant is created
    @param    : datawriterId - Data writer id is provided
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
CMStatus ShutdownDataWriter(int DomainID, CMULONG datawriterId, char *resultCode) {
  DDS_DataWriter dataWriter = (DDS_DataWriter)(void*)datawriterId;
  WrappedHandler* handle = findWrappedHandler(dataWriter);

  if (handle == NULL) {
    return CMFail;
  }

  deleteDataWriter(handle->pubSub, handle->object);
  deletePublisher(handle->participant, handle->pubSub);
  deleteTopic(handle->participant, handle->topic);

  // Delete lib
  TypeLib_free(handle->handle);
  unregisterWrapperHandler(handle);

  return CMSuccess;
}

/*!
    @brief : This function is used to delete the reader. Internally, the publisher and topic would also be deleted
    @param    : DomainID - Domain ID for which participant is created
    @param    : DataReaderID - Data reader id is provided
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : Nonev
*/
/**************************************************************************************************************/
CMStatus ShutdownDataReader(int DomainID, CMULONG datareaderId, char *resultCode) {
  DDS_DataReader dataReader = (DDS_DataReader)(void*)datareaderId;
  WrappedHandler* handle = findWrappedHandler(dataReader);

  if (handle == NULL) {
    return CMFail;
  }

  deleteDataReader(handle->pubSub, handle->object);
  deleteSubscriber(handle->participant, handle->pubSub);
  deleteTopic(handle->participant, handle->topic);

  // Delete lib
  TypeLib_free(handle->handle);
  unregisterWrapperHandler(handle);
  return CMSuccess;
}