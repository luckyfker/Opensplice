SDK development
=========

SDK contains a set of function, which support end user to interact with EPH and other services.

OpenSplice Installation
==

  - Access OpenSplice web site, download the corresponding version
    * Community version:
      - Download from [Here](https://github.com/ADLINK-IST/opensplice/releases)
      - Extract files to a folder, example: `D:\Downloads\HDE`
      - Set the `OSPL_HOME` variable to `HDE` folder
    * Evaluation/Commercial versions:
      - Register an account
      - Receive an email verification, and get the license file from email
      - Download from [Here](https://www.adlinktech.com/en/dds-community-software-evaluation)
      - Run the `exe` file and use the license file for installation
  - Example codes in [examples](https://github.com/ADLINK-IST/opensplice/tree/master/examples), check the `c`, `SAC` accordingly

Compilation
==

1. On windows

  - **Visual Studio**:
    + Already build and test with Visual Studio 2015. If you want to build with another version, you may need to do migration process of Visal Studio
    + Open `sdk.sln` solution
    + Build, debug
  - **cmake**:
    + Ensure `OSPL_HOME` and `OpenCV_DIR` variables are set correctly
    + ```bash
      cd app/build
      # For windows 64 bits, default is x86
      cmake .. -A x64 -DCMAKE_INSTALL_PREFIX=<installation folder>
      # build
      cmake --build .
      # install the package
      cmake -P cmake_install.cmake [-DBUILD_TYPE=<Debug|Release>]
      ```
2. On Linux/Raspberry

  - **Only cmake**:
    + Ensure `OSPL_HOME` and `OpenCV_DIR` variables are set correctly
    + For `arm` platforms (raspberry, EPH), change `PLATFORM_ARM` to `TRUE` in `app/CMakeList.txt` file
    + ```bash
      cd app/build
      cmake .. -DCMAKE_INSTALL_PREFIX=<installation folder>
      cmake --build .
      cmake -P cmake_install.cmake [-DBUILD_TYPE=<Debug|Release>]
      ```

Development
==

1. Define new topic

    - Open `app/evaluation_topic/idl/` folder
    - Modify/define new topic data structure in `evaluatiopn_topic.idl`
    - Re-Compile the project

2. SDK/CLI development

    - Develop in `dummy_app` folder
