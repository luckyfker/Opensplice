#ifndef IMAGE_RECOGNIZE_TEST_H
#define IMAGE_RECOGNIZE_TEST_H

// List all test suite here
#define SaveImageJob_Tests() \
    EPHLIB_FRIEND_TEST_SUITE(ImageRecognizeTest, TC07001); \
    EPHLIB_FRIEND_TEST_SUITE(ImageRecognizeTest, TC08001); \
    EPHLIB_FRIEND_TEST_SUITE(ImageRecognizeTest, TC09001); \
    EPHLIB_FRIEND_TEST_SUITE(ImageRecognizeTest, TC10001); \

#endif
