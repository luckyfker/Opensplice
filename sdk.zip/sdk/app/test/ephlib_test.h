#ifndef _EPHLIB_TEST_H
#define _EPHLIB_TEST_H

#include "com_middle_mock.h"

#define EPHLIB_FRIEND_TEST_SUITE(test_suite_name, test_name) \
  friend class test_suite_name##_##test_name##_Test

#define EPHLIB_FRIEND_TEST(x) \
    x##_Tests()

#include "image_receive_test.h"

#endif
