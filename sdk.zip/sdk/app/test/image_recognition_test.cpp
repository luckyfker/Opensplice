#include <gtest/gtest.h>
#include "ephlib_job.h"
#include <gmock/gmock.h>
#include "com_middle_mock.h"


/*************** recognizeImage() ***************/
TEST(ImageRecognizeTest, TC07001) {
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* responseTopic = "Result_Send_Topic::Data";
    unsigned int intervalSec = 10;
    std::string expectResult = "recognition";
    EPHLIB_RecognizeImageJob recognizeImageJobObj(domainId, requestTopic, responseTopic, NULL);

    //mock
    //CREATE_COM_MOCK_OBJ(comMockObj);
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    cv::Mat image = cv::Mat::zeros(100,100,CV_8UC1);
    std::string retVal = recognizeImageJobObj.recognizeImage(image);


    // Expect captureImage() return true
    EXPECT_STREQ(expectResult, retVal);
}

/*************** sendResult() ***************/
TEST(ImageRecognizeTest, TC08001) {
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* responseTopic = "Result_Send_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_RecognizeImageJob recognizeImageJobObj(domainId, requestTopic, responseTopic, NULL);

    //mock
    CREATE_COM_MOCK_OBJ(comMockObj);
    EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::string regStr = "recognition";
    Image_Send_Topic_Data receivedBuffer = NULL;
    Image_Send_Topic_Data receivedBuffer = {
        .request_DeviceId = "D01",
        .request_CameraId = "C01",
        .request_Date._buffer = "20210202",
        .request_SeqNo = 2,
        .Pricereduction_DeviceId = "P002",
        .PricereductionCut_cutImage._buffer = "abcd",
        .requestType = 1
    };
    CMStatus status = recognizeImageJobObj.sendResult(regStr, &receivedBuffer);


    // Expect captureImage() return true
    EXPECT_EQ(status, CMSuccess);
}

/*************** convertToMat() ***************/
TEST(ImageRecognizeTest, TC09001) {
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* responseTopic = "Result_Send_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_RecognizeImageJob recognizeImageJobObj(domainId, requestTopic, responseTopic, NULL);

    //mock
    //CREATE_COM_MOCK_OBJ(comMockObj);
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    Image_Send_Topic_Data data = = {
        .request_DeviceId = "D01",
        .request_CameraId = "C01",
        .request_Date._buffer = "20210202",
        .request_SeqNo = 2,
        .Pricereduction_DeviceId = "P002",
        .PricereductionCut_cutImage._buffer = "abcd",
        .PricereductionCut_cutImage.length = 4,
        .requestType = 1
    };
    cv::Mat mat = recognizeImageJobObj.convertToMat(&data);


    // Expect captureImage() return true
    EXPECT_NE(NULL, mat);
}

/*************** createResultData() ***************/
TEST(ImageRecognizeTest, TC10001) {
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* responseTopic = "Result_Send_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_RecognizeImageJob recognizeImageJobObj(domainId, requestTopic, responseTopic, NULL);

    //mock
    //CREATE_COM_MOCK_OBJ(comMockObj);
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::string regStr = "Test";
    Image_Send_Topic_Data receivedBuffer = NULL;
    Image_Send_Topic_Data receivedBuffer = {
        .request_DeviceId = "D01",
        .request_CameraId = "C01",
        .request_Date._buffer = "20210101",
        .request_SeqNo = 1,
    };
    Result_Send_Topic_Data* pubData = recognizeImageJobObj.createResultData(regStr, &receivedBuffer);


    // Expect captureImage() return true
    EXPECT_STREQ(pubData->request_DeviceId, receivedBuffer.request_DeviceId);
    EXPECT_STREQ(pubData->request_CameraId, receivedBuffer.request_CameraId);
    EXPECT_STREQ(pubData->request_Date._buffer, receivedBuffer.request_DeviceId._buffer);
    EXPECT_EQ(pubData->request_SeqNo, receivedBuffer.request_SeqNo);
    EXPECT_STREQ(pubData->Pricereduction_srtRecognition, regStr);
    EXPECT_STREQ(pubData->Pricereduction_DeviceId, "xxx");
}
