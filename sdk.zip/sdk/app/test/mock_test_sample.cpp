#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "com_middle_mock.h"

using ::testing::Return;

TEST(ComMiddleMock, SetParticipant) {
    CREATE_COM_MOCK_OBJ(comMockObj);

    // Mock behavior for SetParticipant
    EXPECT_CALL(comMockObj, SetParticipant(1))
        .WillOnce(Return(CMFail));

    // Call SetPariticipant to test
    CMStatus ret = CMFail;
    ret = SetParticipant(1);

    EXPECT_EQ(ret, CMSuccess);
}
