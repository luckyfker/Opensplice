#if defined (__cplusplus)
extern "C" {
#endif

#include "LinuxMWtypesSacDcps.h"

#if defined (__cplusplus)
}
#endif
