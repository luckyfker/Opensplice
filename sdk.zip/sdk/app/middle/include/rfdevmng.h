/* @file */
/*****************************************************************************
**
**		Copyright (C) 2003
**				TOSHIBA TEC CORPORATION,  ALL Rights Reserved
**				1-14-10 Uchikanda Chiyoda-ku Tokyo JAPAN
**
**----------------------------------------------------------------------------
**
**	MODULE NAME	:	rfdevmng.h
**	(FILE NAME)
**	PARAMETERS	:	NONE
**
**	DESCRIPTION	:	
**
**	CREATE ON	:	V001.000				2003.05.07		Y.Tanaka[SG]
**
**	MODIFIED ON :
**
*****************************************************************************/
#ifndef ___RF_DEVMNG_H___
#define ___RF_DEVMNG_H___

/*****************************************************************************
**	HEADER FILES
*****************************************************************************/
#include "rfdefs.h"

/*****************************************************************************
**	MACROS
*****************************************************************************/
/*-----< ����� >-----------------------------------------------------------*/
#define RFD_ERR_LIFE_RCVSIZE		(-400)			/* �������������顼				*/
#define RFD_ERR_ID_OVER				(-401)			/* �ǥХ���ID�³�Ķ��			*/
#define RFD_ERR_FIELD_READ			(-402)			/* �ե�����ɿ��ɤ߹��ߥ��顼	*/

/*****************************************************************************
**	EXTERN FUNCTIONS
*****************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/* �ǥХ����ơ��֥�ե�����ɿ�����	*/
int GetDeviceFieldCount(int devId, int *num);
/* ��̿�ǡ������� */
int GetDeviceAll(int devId, int num, unsigned int *devInfo);
/* ��̿�ǡ������� */
int SetDeviceAll(int devId, int num, unsigned int *devInfo);
/* ��̿����Хå����å� */
int RequestBackUp(void);


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* ___RF_DEVMNG_H___ */
