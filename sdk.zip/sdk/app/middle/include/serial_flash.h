//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		: serialFlash.h
//
//		DESCRIPTION 	: serial flash library
//
//		CREATE ON	: V001.000 			Suresh B 		11-11-2019		#0
//
//		MODIFIED ON	: 21-11-2019
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __SERIALFLASH_H__
#define __SERIALFLASH_H__

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "sf_local.h"
#ifndef RUN_ON_HOST
#include <fcntl.h>
#include <sys/ioctl.h>
#include <mtd/mtd-user.h>
#endif
#include "sf_types.h"

#ifdef RUN_ON_HOST
#include "sf_stub.h"
#endif

/*!
 * getDeviceInfo - colect information of from given by device id.
 * @devId: Device ID
 * @devInfo: Pointer to the infoStruct  structure 
 *
 * This function gets the device information from the Serial Flash connected to the flash.
 */
int getSFDeviceInfo (const char *devId, mtdInfo *devInfo);

/*!
 * flashWrite - This function writes  data to Serial Flash connected to the flash interface.
 * 
 * @devId: Device ID 
 * @offset: Address contains the address to write data to in the Flash
 * @byteCount: Number of bytes to write
 * @dataBuffer: Pointer to the write buffer. 
 *
 * This function writes file to Serial Flash connected to the flash interface.
 */

int flashWrite (const char *devId, uint32_t offset, uint32_t byteCount, const uint8_t *dataBuffer);

/*!
 * flashWrite - This function writes data to Serial Flash connected to the flash.
 * 
 * @devId: Device ID 
 * @address: Address contains the address to write data to in the Flash
 * @byteCount: Number of bytes to write
 * @dataBuffer: Source file name with or without path 
 *
 * This function writes data to Serial Flash connected to the flash.
 * In addition to write, it reads the written data and compares.
 */
int flashWrite2 (const char *devId, uint32_t offset, uint32_t byteCount, const uint8_t *dataBuffer);

/*!
 * flashRead - This function reads data from the Serial Flash connected to the flash.
 * 
 * @devId: Device ID  
 * @address: Address contains the address to write data to in the Flash
 * @byteCount: Number of bytes to read (in bytes)
 * @dataBuffer: destination file name with or without path 
 *
 * This function Reads data from Serial Flash based on the source address and the size.
 */
ssize_t flashRead (const char *devId, uint32_t offset, uint32_t byteCount, uint8_t *dataBuffer);

/*!
 * flashErase - This function erase data from the Serial Flash connected to the flash.
 *
 * @devId: Device ID
 * @offset: Starting address of flash memory
 * @blockCount: Number of blocks to erase
 *
 * This function erase data from Serial Flash based on the source address and the size.
 */
int flashErase (const char *devId,  uint32_t offset, uint32_t blockCount);

/*!
 * flashBulkErase - This function erase the partition.
 *
 * @devId: Device ID
 *
 * This function erase partition from Serial Flash.
 */
int flashBulkErase (const char *devId);

#endif /* __SERIALFLASH_H__ */
