//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		: sfLocal.h
//
//		DESCRIPTION 	: Serial Flash library
//
//		CREATE ON	: V001.000 			Suresh B 		11-11-2019		#0
//
//		MODIFIED ON	: 21-11-2019
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __SFLOCAL_H__
#define __SFLOCAL_H__

//#define RUN_ON_HOST	//Define to run on host machine, Undefine to run on target machine
//#define DEBUG		// For debug
//#define INFO		// For verbose

#ifdef  DEBUG 
#define DEBUG_PRINT    printf
#else
#define DEBUG_PRINT(x,...)  ((void)0)
#endif	

#ifdef  INFO 
#define INFO_PRINT    printf
#else
#define INFO_PRINT(x,...)  ((void)0)
#endif

#define SF_DEVICE_ID_0 "/dev/mtd0"
#define SF_DEVICE_ID_1 "/dev/mtd1"
#define SF_DEVICE_ID_2 "/dev/mtd2"

#define SF_WRITE_BUF_SIZE	(256 * 1024)    // If occurs SPI interface timout issue then reduce buffer size
#define SF_READ_BUF_SIZE 	(256 * 1024)    // If occurs SPI interface timout issue then reduce buffer size

#define SF_SUCCESS 0
#define SF_ERROR -1
#define SF_EINVAL -2

#endif /* __SFLOCAL_H__ */
