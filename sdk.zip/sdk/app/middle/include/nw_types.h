//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		: nw_types.h
//
//		DESCRIPTION     : nw utility settings library
//
//		CREATE ON	: V001.000 			Suresh B 		04-12-2019		#0
//
//		MODIFIED ON	: 13-02-2020
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __NW_TYPES_H__
#define __NW_TYPES_H__

////////////////////////////////////////////////////////////////////////////////
//	Variable Declaration
////////////////////////////////////////////////////////////////////////////////

typedef struct settings
{
	int CA_SELFSIGNED;          // CA or SELFSIGNED
	uint32_t portNumber;        // FTP Port number
}ftpSettinsStruct;

typedef struct ftpInfo
{
	uint8_t *hostName;
	uint8_t hostNameBuffSize;
	uint8_t *userName;
	uint8_t userNameBuffSize;
	uint8_t *pwd;
	uint8_t pwdBuffSize;
}ftpInfoStruct;

typedef struct opensslConfig
{
        char *countryName;
        char *organizationName;
        char *commonName;
}certConfig;

typedef struct name {
	char ifrn_name[IFNAMSIZ];
}nwIName;

#endif /* __NW_UTILITY_SETTINGS_H__ */

