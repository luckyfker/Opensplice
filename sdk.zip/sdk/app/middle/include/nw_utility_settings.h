//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		: nw_utility_settings.h
//
//		DESCRIPTION     : nw utility settings library
//
//		CREATE ON	: V001.000 			Suresh B 		26-11-2019		#0
//
//		MODIFIED ON	: 06-12-2019
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __NW_UTILITY_SETTINGS_H__
#define __NW_UTILITY_SETTINGS_H__

#include "nw_local.h"

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <linux/route.h>

#include "nw_types.h"
#include "nw_error.h"

#ifdef OPENSSL
#include "nw_gen_cert.h"
#endif

////////////////////////////////////////////////////////////////////////////////
//	Prototype Declaration
////////////////////////////////////////////////////////////////////////////////

/** ping
 * @ipAddress: Host-name / IP
 * @count: The number of times to send ping request
 * @byteSize: The packet size for each request
 * @timeout: the time(seconds) to wait for response
 *
 * Ping is used to check connectivity between source and destination with number of pings specified
 * and size of packet specified with timeout.
 */
int ping (const char * ipAddress, int count, int byteSize, uint32_t timeout);

/** Get HostName
 * @name: buffer which will hold host name
 * @len: length of the buffer
 *
 * This function returns the standard host name for the current machine.
 * The len argument specify the size of the array pointed to by the name argument.
 */
int getHostName (char *name, size_t len);

/** Set HostName
 * @name: buffer which holds to the hostname to be set
 * @len: length of host name to be set
 *
 * This function sets the host-name to the value given in character array name.
 * The length argument specifies the number of bytes in name .
 */
int setHostName (const char *name, size_t len);

/** Get net address
 * @name: interface name
 * @ipAddr: ip address
 * @netMask: net mask address
 *
 * This function gets the ip address and the net mask address of the specified device.
 */
int getNetAddress (const char *name, char *ipAddr, char *netMask);

/** Set net address
 * @name: interface name
 * @ipAddr: ip address
 * @netMask: net mask address
 *
 * This function sets the new ip address and net mask of the specified device.
 */
int setNetAddress (const char *name, const char *ipAddr, const char *netMask);

/** Get default gateway
 * @name: interface name
 * @gateway: Default gateway
 *
 * This function helps in getting the default gateway address of the device.
 */
int getDefaultGateway (const char *name,  char **gateway);

/** Set default gateway
 * @name: interface name
 * @gateway: Default gateway
 *
 * This function sets the default gateway address to the interface/device specified.
 */
int setDefaultGateway(const char *name, const char * gatewayAddr);

/** Get Mac Address
 * @name: interface name
 * @mac: Mac / hardware address
 * @len: Mac buffer size
 *
 * This function gets  mac address of the interface specified.
 */
int getMacAddress (const char * name, char *mac, size_t len);

/** Get device status
 * @name: Interface name
 *
 * This function helps in getting the network interface status whether it’s up/down
 * and returns negative value in case of error.
 */
int  getDeviceStatus (const char *name);

/** Set device status
 * @name: Interface name
 * @status: status (DEVICE_UP / DEVICE_DOWN)
 *
 * This function helps in setting the network interface status to up/down.
 */
int setDeviceStatus (const char *name, int status);

/** Get Broadcast address
 * @name: Interface Name
 * @broadcastAddress: Broadcast address
 *
 * This function gets the broadcast address of network interface specified and returns null on failure.
 */
int getBroadcastAddress(const char *name, char *broadcastAddr);

/** Set Broadcast address
 * @name: interface name
 * @broadcastAddr: broadcastAddress
 *
 * This function sets the broadcast address of network interface specified.
 */
int setBroadcastAddress (const char *name, const char * broadcastAddr);

/** List interfaces
 * @iName: file descriptor of socket(PF_INET, PF_INET6)
 * @iLen: list interface size
 *
 * This function lists all the interfaces in the network which is available.
 */
int listInterfaces( nwIName **iName, int *iLen);

/** Start DHCP
 *
 * This function starts the DHCP service
 */
int enableDHCP ();

/** Stop DHCP
 *
 * This function stops the DHCP service.
 */
int disableDHCP ();

#ifdef OPENSSL
/** Create certificate
 * @configFile: Configuration file
 * @dest: Created certificate is stored in destination path
 *
 * This function creates selfsigned certificate(openssl) and will be stored in destination path specified as dest.
 */
int createCertificate(const char *configFile, const char *destCertPath, const char *destKeyPath);
#endif

/** Ftp settings
 * @data: settings information(CA / SELFSIGNED)
 *
 * This function store settings of the certificate, such as CA/SELF_SIGNED.
 */

int ftpSettings(int data);

/** Ftp set port number
 * @portNum: Port number
 *
 * This function stores the default port number of FTP.
 */
int ftpSetPortNum(int portNum);

/** Ftp get settings
 * @settings: settings information(CA / SELFSIGNED) and port number
 *
 * This function store settings of the certificate, such as CA/SELF_SIGNED.
 */
int ftpGetSettings(ftpSettinsStruct *settings);

/** Set ftp Credentials
 * @name: Name of the server
 * @hostname: Host-name of the server
 * @username: username of the server
 * @pwd:password of the user
 *
 * This function sets the hostname, user name and password.
 */
int setFtpCredentials (const char *name, const char *hostname,  const char *username, const char *pwd);

/** get ftp Credentials
 * @name: Name of the server
 * @serverInfo: the hostname, user name and password
 *
 * This function sets the hostname, user name and password.
 */
int getFtpcredentials(const char *name, ftpInfoStruct *serverInfo);

#endif /* __NW_UTILITY_SETTINGS_H__ */
