
/////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
//				Copyright (C) 2019
//				TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
/////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
//		FILE			: dcm_main.h
//		DESCRIPTION 		:
//		CREATE 	ON 		:V001.00 			Rohit Sharma 		11.11.2019
//		MODIFIED ON 		:
//
//
//
//
//
//
//
//////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef _DCM_MAIN_H
#define _DCM_MAIN_H
#endif

/************************************************************************/
/*!
                @brief		: Initialize the variable and path
                @param 		: char *configFile
                @retval 	: Returns integer status code (success or error)
                @attention	: None
*/
/************************************************************************/
int dcmInitialize(char *configFile);

/************************************************************************/
/*!
                @brief		: Run Docker Container
                @param 		: char *options, char *image, char *command
                @retval 	: Returns integer status code (success or error)
                @attention	: None
*/
/************************************************************************/
int runDocker(char *options, char *image, char *command);

/************************************************************************/
/*!
                @brief 		: Remove Docker Container
                @param 		: char *options, char *imageID
                @retval 	: Returns integer status code (success or error)
                @attention  : None
*/
/************************************************************************/
int rmDockerContainer(char *options, char *imageID);

/************************************************************************/
/*!
                @brief 		: Remove Docker Container
                @param 		: char *options, char *imageID , char *command
                @retval 	: Returns integer status code (success or error)
                @attention  : None
*/
/************************************************************************/
int rmiDockerImage(char *options, char *imageID, char *command);

/************************************************************************/
/*!
                @brief          : Gets docker container list
                @param          : char *options , char *fileList
                @retval         : Returns integer status code (success or error)
                @attention      : None
*/
/************************************************************************/
int getDockerContainerList(char *option, containerInfo ** mageList, uint32_t *imageCount);

/************************************************************************/
/*!
                @brief          : Gets docker image list
                @param          : char *dirPath, char *options, imageInfo** imageList, uint32_t *imageCount
                @retval         : Returns integer status code (success or error)
                @attention      : None
*/
/************************************************************************/
int getDockerImageList(char *dirPath, char *options, imageInfo** imageList, uint32_t *imageCount);

/************************************************************************/
/*!
                @brief          : Gets docker image list FTP
                @param          : char *dirPath, char *host, char *userName, char *password, char *option, imageInfo** imageList, uint32_t *imageCount
                @retval         : Returns integer status code (success or error)
                @attention      : None
*/
/************************************************************************/
int getDockerImageListRemote(char *dirPath, char *host, char *userName, char *password, char *option, imageInfo** imageList, uint32_t *imageCount);

/************************************************************************/
/*!
                @brief          : Gets docker image list
                @param          : char *dirPath, char *options, imageInfo** imageList, uint32_t *imageCount
                @retval         : Returns integer status code (success or error)
                @attention      : None
*/
/************************************************************************/
int getDockerFileList(char *dirPath, char *imageID, imageInfo** imageList, uint32_t *imageCount);

/************************************************************************/
/*!
                @brief          : Gets docker image list from remote
                @param          : char *dirPath, char *imageID, char *host, char *userName, char *password, imageInfo** imageList, uint32_t *imageCount
                @retval         : Returns integer status code (success or error)
                @attention      : None
*/
/************************************************************************/
int getDockerFileListRemote(char *dirPath, char *imageID, char *host, char *userName, char *password, imageInfo** imageList, uint32_t *imageCount);

/************************************************************************/
/*!
                @brief		: Free allocated memory
                @param 		: imageInfo* imageList
                @retval		: Returns integer status code (success or error)
                @attention	: None
*/
/************************************************************************/
int freeDockerImageList(imageInfo* imageList);

/************************************************************************/
/*!
                @brief		: Saves docker image
                @param 		: char *image, char *backupFileName , char *backupFilePath
                @retval		: Returns integer status code (success or error)
                @attention	: None
*/
/************************************************************************/
int saveDockerImage(char *image, char *bakupFileName, char *bakupFilePath);

/************************************************************************/
/*!
                @brief		: Saves docker image from remote
                @param 		: char *image, char *bakupFileName, char *bakupFilePath, char *host, char *userName, char *password
                @retval		: Returns integer status code (success or error)
                @attention	: None
*/
int saveDockerImageRemote(char *image, char *bakupFileName, char *bakupFilePath, char *host, char *userName, char *password);

/************************************************************************/
/*!
                @brief		: Data volume backup
                @param 		: char *volumeName, char *bakupFileName, char *backupFilePath
                @retval		: Returns integer status code (success or error)
                @attention	: None
*/
/************************************************************************/
int saveDockerVolume(char *volumeName, char *bakupFileName, char *backupFilePath);

/************************************************************************/
/*!
                @brief		: Data volume backup remote
                @param 		: char *volumeName, char *bakupFileName, char *bakupFilePath, char *host, char *userName, char *password
                @retval		: Returns integer status code (success or error)
                @attention	: None
*/
/************************************************************************/
int saveDockerVolumeRemote(char *volumeName, char *bakupFileName, char *bakupFilePath, char *host, char *userName, char *password);

/************************************************************************/
/*!
                @brief		: Load docker image
                @param 		: char *imageFilePath, char *sourceImage,char *imageID
                @retval		: Returns integer status code (success or error)
                @attention	: None
*/
/************************************************************************/
int loadDockerImage(char *imageFilePath, char *sourceImage, char *imageID);

/************************************************************************/
/*!
                @brief		: Load docker image remote
                @param 		: char *imageFileName, char *sourceImage, char *host, char *userName, char *password, char *imageFilePath, char *imageID
                @retval		: Returns integer status code (success or error)
                @attention	: None
*/
/************************************************************************/
int loadDockerImageRemote(char *imageFileName, char *sourceImage, char *host, char *userName, char *password, char *imageFilePath, char *imageID);

/************************************************************************/
/*!
                @brief		: Load the docker volume
                @param 		: char *volumeName, char *bakupFileName, char *backupFilePath
                @retval		: Returns integer status code (success or error)
                @attention	: None
*/
/************************************************************************/
int loadDockerVolume(char *volumeName, char *bakupFileName, char *backupFilePath);

/************************************************************************/
/*!
                @brief		: Load the docker volume from remote
                @param 		: char *volumeName, char *bakupFileName, char *bakupFilePath, char *host, char *userName, char *password
                @retval		: Returns integer status code (success or error)
                @attention	: None
*/
/************************************************************************/
int loadDockerVolumeRemote(char *volumeName, char *bakupFileName, char *bakupFilePath, char *host, char *userName, char *password);

/************************************************************************/
/*!
                @brief		: update docker image
                @param 		: char *image, char *dockerfilePath, char *backupDirPath
                @retval		: Returns integer status code (success or error)
                @attention	: None
*/
/************************************************************************/
int updateDockerImage(char *image, char *dockerfilePath, char *backupDirPath, char *repoTag, char *createdImageID);

/************************************************************************/
/*!
                @brief		: update docker image from remote
                @param 		: char *image, char *dockerFileName, char *dockerfilePath, char *backupDirPath, char *host, char *userName, char *password
                @retval		: Returns integer status code (success or error)
                @attention	: None
*/
/************************************************************************/
int updateDockerImageRemote(char *image, char *dockerFileName, char *dockerfilePath, char *backupDirPath, char *repoTag, char *host, char *userName, char *password, char *createdImageID);

