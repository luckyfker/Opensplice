//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		:	macros.h
//
//		DESCRIPTION :	eMMC library
//
//		CREATE ON	: 	V001.000 			Nagul.S 		11-11-2019		#0
//
//		MODIFIED ON	:
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __MACROS_H__
#define __MACROS_H__


#define 	EMMC_THRESHOLD1  					90          /*!Maximum threshold*/
#define 	EMMC_THRESHOLD2  					40          /*!Minimum threshold*/
#define 	EMMC_WARNING_MESSAGE 				1           /*!Warning message*/
#define 	EMMC_DEVICE_REPLACEMENT_MESSAGE 	2           /*!device replacement message*/
#define 	EMMC_EOL_CRITICAL    				0X03        /*!End of life Critical message*/
#define 	EMMC_EOL_WARNING 					0X02        /*!End of life Warning*/
#define 	EMMC_NORMAL 						0           /*!End of life normal*/
#define 	EMMC_ARGUMENTS_NOT_IN_RANGE 		-2          /*!Arguments not in range*/
#define 	EMMC_SUCCESS 						0           /*!Success*/
#define 	EMMC_API_CALL_FAILED 				-1		    /*!Api failure*/
#define 	EMMC_PARM1							0           /*!Parameter zero*/
#define 	EMMC_FAILURE1   					-1          /*!Failure message*/
#define 	EMMC_FAILURE2   					-2          /*!Failure message*/
#define 	EMMC_FAILURE3   					1           /*!Failure message*/
#define 	EMMC_FAILURE4   					2           /*!Failure message*/
#define 	EMMC_PARM2   						-1          /*!Parameter*/
#define 	EMMC_PARM3   						1           /*!Parameter*/
#define 	EMMC_PARM4   						20          /*!Parameter*/
#define 	EMMC_PARM5   						40          /*!Parameter*/
#define 	EMMC_PARM6   						50          /*!Parameter*/
#define 	EMMC_PARM7   						90          /*!Parameter*/
#define 	EMMC_PARM8   						101         /*!Parameter*/
#define 	EMMC_PARM9   						7500        /*!Parameter*/
#define 	EMMC_PARM10   						7.0			/*!Parameter*/	
#define		EMMC_SYS_ERROR   		256        											/*! System errors */
#define		EMMC_SYS_BLK_ERROR 		255		   											/*! System errors */

/*! This function is used to set the threshold values into the config file */

/************************************************************************************************************* */
/*!
    @brief 		: This function is used to set the threshold values into the config file
    @param      : Threshold_1 - warning message
                  Threshold_2 - Device replacement message
    @retval     : Success or Fail
    @attention  : None
*/
/************************************************************************************************************* */
int eMMC_set_thresholds(unsigned long Threshold_1, unsigned long Threshold_2);

/*! This function is used to get the threshold values from the config file */

/************************************************************************************************************* */
/*!
    @brief      : This function is used to get the threshold values from the config file
    @param      : Threshold_1 - warning message
                  Threshold_2 - Device replacement message
    @retval     : Success or Fail
    @attention  : None
*/
/************************************************************************************************************* */
int eMMC_get_thresholds(long *Threshold_1, long *Threshold_2);

/*! This function is used to get the alert status */

/************************************************************************************************************* */
/*!
    @brief      : This function is used to get the alert status
    @param      : None
    @retval     : Success or Fail
    @attention  : None
*/
/************************************************************************************************************* */
int eMMC_get_alert_status(void);

/*! This function is used to get the drive information */

/************************************************************************************************************* */
/*!
    @brief      : This function is used to get the drive information of eMMC.
    @param      : totalCapacity - total capacity of eMMC
                  freeCapacity - Free space of eMMC
    @retval     : Success or Fail
    @attention  : None
*/
/************************************************************************************************************* */
int eMMC_get_drive_Info(long int *totalCapacity,long int *freeCapacity, long int *usedSpace);

/*! This function is used to get the free space information */

/************************************************************************************************************* */
/*!
    @brief      : This function is used to get the free Space of eMMC
    @param      : freeCapacity
    @retval     : Success or Fail
    @attention  : None
*/
/************************************************************************************************************* */
int eMMC_get_free_space(long int *freeCapacity);

/*! This function is used to get the device health information */

/************************************************************************************************************* */
/*!
    @brief      : This function is used to get the health information of eMMC.
    @param      : SCL,MLC,EOL
    @retval     : Success or Fail
    @attention  : None
*/
/************************************************************************************************************* */
int eMMC_getDevice_health_info(long *SLC ,long *MLC, long *EOL);

/*! This function is used to convert the GigaByte value to MegaByte value */

/************************************************************************************************************* */
/*!
    @brief      : This function is used to covert the GB value to Mega-byte.
    @param      : x-input string
    @retval     : float value which is having Mega-bytes value
    @attention  : None
*/
/************************************************************************************************************* */
float convertToMegabyte(char *x);

#endif
