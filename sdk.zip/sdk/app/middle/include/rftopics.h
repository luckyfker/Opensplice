#if defined (__cplusplus)
extern "C" {
#endif

#include "rftopicsSacDcps.h"

#if defined (__cplusplus)
}
#endif
