//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		:	macros.h
//
//		DESCRIPTION :	bau_library
//
//		CREATE ON	: 	V001.000 			Yashas.D.G.  		11-11-2019		
//
//		MODIFIED ON	:
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __MACROS_H__
#define __MACROS_H__
#define BUF_SIZE 1024
#define config1_host "/home/tec/Documents/update/config1.ini"
#define config2_host "/home/tec/Documents/update/config2.ini"
#define config3_host "/home/tec/Documents/update/config3.ini"
#define config4_host "/home/tec/Documents/update/config4.ini"
#define config1_target "/root/ini/config1.ini"
#define config2_target "/root/ini/config2.ini"
#define config3_target "/root/ini/config3.ini"
#define config4_target "/root/ini/config4.ini"
//#define HOST
#define DEBUG printf
#define INIFILEERROR -1
#define INIOLDFILEPATH -2
#define PROGUPDATEERRORFILE -3
#define ARCHIEVEERROR -4
#define SUCCESS 0
#define COMMANDNUMBER -5
#define RECOVERY -6
#define FILEPATHERROR -7
#define COMMANDFAILURE -8
#define CONFIGINIREADFAIL -9
#define FILENOTEXIST -10
#endif
