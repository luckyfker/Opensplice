//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    Copyright (C) 2019
//      TOSHIBA TEC CORPORATION,  ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    FILE    : com_middle.h
//
//    DESCRIPTION : Implementation of library which acts as abstraction layer for OpenSplice APIs
//
//    CREATEd ON :  10-12-2019, By: mythila/bhanu/raghava/pratik Version:V0.007         #0
//
//    MODIFIED ON : 14-12-2019
//
// 	  MODIFIED ON	:V001.000	Yashas D G[TSIP]				2021.04.14(Windows Compatible) 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __COMMUNICATION_MIDDLE_H__
#define __COMMUNICATION_MIDDLE_H__

#include "dds_dcps.h"

#ifdef WIN32
#ifdef ddscomu_EXPORTS
#define COMMIDDLE_API __declspec(dllexport)
#else
#define COMMIDDLE_API __declspec(dllimport)
#endif
#else
#define COMMIDDLE_API
#endif

#ifdef WIN32
#define CMULONG unsigned long long
#define PATH_SIZE MAX_PATH
#else
#define PATH_SIZE PATH_MAX
#define CMULONG unsigned long
#endif

struct QoS_Policy;
typedef struct QoS_Policy QoS_Policy;

typedef char *LogParams;

/* Enum to select communication type */
typedef enum
{
    CM_DDS,                             /* DDS only */
    CM_SHM,                             /* Shared memory only */
    CM_DDS_SHM                          /* DDS and shared memory both */
}comType_t;

/* Enum to identify request for writer or reader */
typedef enum
{
    CM_WRITER,                          /* For writer */
    CM_READER                           /* For reader */          
}wrType_t;

/* Enum to enable/disable the clear flag in the data handler structure */
typedef enum
{
    CM_SHM_CLEAR_NOT_SET,               /* Shared memory clear is not enabled */
    CM_SHM_CLEAR_SET                    /* Shared memroy clear is enable */
}shmClr_t;

/* Structure to format the received shared memory to DDS sequence */
typedef struct
{
    DDS_unsigned_long maximum;          /* Maximum value (Padding) */
    DDS_unsigned_long length;           /* Provide the valid length of the receive data */
    char *buffer;                       /* Base address of shared memory received data */
}shmSeqDataOffset_t;
/**************************************************************************************************************/
/*!
    @brief : This function declaration is for callback function
                Defined in application and used for handling response coming from server
                Function params : void ResponseCallback(void *)
                This response will be type-casted to DDS_Topic_Name inside the function
    @param    : void * - processing demand result is acquired
    @attention  : None
*/
/**************************************************************************************************************/
typedef void (*ResponseCallback)(void *);

/**************************************************************************************************************/
/*!
    @brief : This function declaration is for callback function
                Defined in application and used for handling request coming from client
                Function params : void RequestCallback(DDS_DomainId_t, void *, void *, int *)
                This request and response will be type-casted to DDS_Topic_Name inside the function
    @param    : DDS_DomainId_t - domain id is specified
    @param    : void * - processing demand specification is carried out
    @param    : void * - processing demand result is acquired
    @param    : int * - the result code returned by Opensplice library
    @attention  : None
*/
/**************************************************************************************************************/
typedef void (*RequestCallback)(DDS_DomainId_t, void *, void *, int *);

/**************************************************************************************************************/
/*!
    @brief : This function declaration is for callback function
                Defined in application and used for Serializing Request structure into buffer
                Function params : int SerializeSample(char *, char *, DDS_Sample, char *, long *)
                This request will be type-casted to DDS_Topic_Name inside the function
    @param    : char * - topic is specified
    @param    : char * - type is specified
    @param    : DS_Sample - Request Data to be specified
    @param    : char * - Buffer where data is to be filled serially
    @param    : long * - size of the buffer
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
typedef int (*SerializeSample)(char *, char *, DDS_Sample, char *, long *);

/**************************************************************************************************************/
/*!
    @brief : This function declaration is for callback function
                Defined in application and used for Serializing Response structure into buffer
                Function params : int SerializeSample(char *, char *, DDS_Sample, char *, long *)
                This request will be type-casted to DDS_Topic_Name inside the function
    @param    : char * - topic is specified
    @param    : char * - type is specified
    @param    : DS_Sample - Response Data to be specified
    @param    : int - iteration for data is specified
    @param    : char * - Buffer where data is to be filled serially
    @param    : long * - size of the buffer
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
typedef int (*SerializeSequence)(char *, char *, DDS_Sample *, int, char *, long *);

typedef enum SysCtrlCmdtype_t
{
    GET_DEVICE_ID = 1,
    CHANGE_DOMAIN_ID,
    GET_QOS,
    SET_QOS
}SysCtrlCmdtype;

typedef enum ReliabilityQoSKind_t
{
    //INVALID_VAL=-1,
    BESTEFFORT_RELIABILITY,
    RELIABLE_RELIABILITY
} ReliabilityQoSKind;

typedef enum DurabilityQoSKind_t
{
    VOLATILE_DURABILITY,
    TRANSIENTLOCAL_DURABILITY,
    TRANSIENT_DURABILITY,
    PERSISTENT_DURABILITY
} DurabilityQoSKind;

typedef enum HistoryQoSKind_t
{
    KEEPLAST_HISTORY,
    KEEPALL_HISTORY
} HistoryQoSKind;

typedef enum SubscriberStrengthRotationType_t
{
    NONE,
    DECREMENT,
    RANDOM
} SubscriberStrengthRotationType;

typedef enum LivelinessQoSKind_t
{
    AUTOMATIC,
    MANUAL_BY_TOPIC
} LivelinessQoSKind;

typedef enum TopicKind_t
{
    NO_KEY,
    WITH_KEY
} TopicKind;

typedef enum OwnershipQoSKind_t
{
    SHARED,
    EXCLUSIVE
} OwnershipQoSKind;

typedef enum WriterDataLifecycleQosPolicy_t
{
    AUTODISPOSE_TRUE,
    AUTODISPOSE_FALSE
} WriterDataLifecycleQosPolicy;

struct ExtendedQoS_Policy
{
    CMULONG SubscriberId;
    uint8_t SubscriberStrength;
    SubscriberStrengthRotationType SubscriberRotationType;
    CMULONG TimeStamp;
};

struct QoS_Policy
{
    int use_default_QoS;
    ReliabilityQoSKind reliability_kind;
    long reliability_max_blocking_time;
    DurabilityQoSKind durability_kind;
    HistoryQoSKind history_kind;
    long history_depth;
    long history_maxsamples;
    long publisher_strength;
    long deadline_sec;
    long lifespan_sec;
    LivelinessQoSKind liveliness_kind;
    long liveliness_lease_duration;
    long liveliness_announcement_period;
    TopicKind topic_kind;
    OwnershipQoSKind ownership_kind;
    WriterDataLifecycleQosPolicy autodispose_writerdata;
    struct ExtendedQoS_Policy ex_QoS;
};

typedef enum CMStatus_t
{
    CMFail = -1,
    CMSuccess = 0,
    CMMutexInitFailed,
    CMCreateParticipantFailed,
    CMCreateDomainHandlerFailed,
    CMInvalidHandle,
    CMDDSQosProviderGetTopicFailed,
    CMDDSQosProviderGetDataReaderFailed,
    CMDDSQosProviderGetDataWriterFailed,
    CMDDSQosProviderAllocFailed,
    CMCreateTopicFailed,
    CMCreatePublisherFailed,
    CMListPushFailed,
    CMCreateDataWriterHandlerFailed,
    CMListFindFailed,
    CMCreateDataReaderHandlerFailed,
    CMCreateSubscriberFailed,
    CMSetLogFileNameFailed,
    CMSetLogRingBufferFailed,
    CMInvalidParameter,
    CMReadSubscriberDataFailed,
    CMTimeoutInWriteDDSClientReqSync,
    CMRecordNotFound,
    CMCreateServerHandlerFailed,
    CMDDSGetBuiltinSubscriberFailed,
    CMCreateClientHandlerFailed,
    CMCreateContentFilteredTopicFailed,
    CMCreateContentFilteredDataReaderFailed,
    CMTimeoutInLogsReader,
    CMDDSDataWriterQOSAllocFailed,
    CMDDSTopicQOSAllocFailed,
    CMLoadQOSFailed,
    CMDDSDataReaderQOSAllocFailed,
    CMWritePublishDataFailed,
    CMShutdownDataWriterFailed,
    CMShutdownDataReaderFailed,
    CMDDSTopicQOSInitFailed,
    CMDDSDataWriterFailed,
    CMDDSDataReaderTakeWConditionFailed,
    CMDDSDataReaderTakeFailed,
    DDSDataReaderDeleteReadConditionFailed,
    CMDeleteDataWriterFailed,
    CMDeleteTopicFailed,
    CMDeleteDataReaderFailed,
    CMDeleteContainedEntitiesFailed,
    CMDeletePublisherFailed,
    CMDeleteSubscriberFailed,
    CMDeleteParticipantFailed,
    CMDeleteContentFilteredTopicFailed,
    CMRegisterMessageTypeFailed,
    CMFindTopicFailed,
    CMGetQoSFailed,
    CMSetQoSFailed,
    CMDeviceInfoFailed,
    CMDeviceInfoAllocFailed,
    CMInvalidComType,
    CMInvalidWriterReaderType,
    CMInvalidkeyPath,
    CMInvalidTopicSize,
    CMInvalidShmSize,
    CMShmInitError,
    CMShmDeinitError,
    CMShmReadError,
    CMShmClrError,
    CMShmInvalidInfoSeq,
    CMShmDataWriterError,
    CMDDSShmDataWriterError,
    CMShmDataReaderFailed,
    CMDDSShmDataReaderFailed,
	CMSetComTypeInitError,
	CMSetSharedMemoryInitError
    
} CMStatus;

#ifndef WIN32
typedef struct{

    key_t rbKey;
    int rbID;
    unsigned long rbSize;
    unsigned int msgSize;
    char appName[NAME_MAX];
    char filePath[NAME_MAX];
    unsigned int isLogTopic;

}rb_data_t;
#endif

#ifdef __cplusplus

extern "C"
{
#endif

/**************************************************************************************************************/
/*!
    @brief : This function is use to create domain participant
    @param    : DomainID - Domain ID for which participant is created
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetParticipant(int DomainID);

/**************************************************************************************************************/
/*!
    @brief : This function is use to create domain participant
    @param    : DomainID - Domain ID for which participant is created
    @param    : pubPartition - Publisher's partition name
    @param    : subPartition - Subscriber's partition name
    @param    : userData - userdefined structure that holds custom data
    @param    : userDataSize - size of userdata structure
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetParticipantEx(int DomainID, const char* pubPartition, const char* subPartition, void *userData, int userDataSize);

/**************************************************************************************************************/
/*!
    @brief : This function is use to create the data writer
    @param    : DomainID - Domain ID for which participant is created
    @param    : topicName - Name of the topic
    @param    : QoS_Policy QoS - QoS file consists of all QoS parameters
    @param    : DataWriterID - Data writer id is passed
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDataWriter(int DomainID, const char *topicName, const char *typeName, QoS_Policy *QoS, CMULONG *DataWriterID, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is use to create the data writer
    @param    : DomainID - Domain ID for which participant is created
    @param    : topicName - Name of the topic
    @param    : QoS_Policy QoS - QoS file consists of all QoS parameters
    @param    : DataWriterID - Data writer id is passed
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDataWriterUseQoSFile(int DomainID, const char *topicName, const char *typeName, const char *QoSFileName, CMULONG *DataWriterID, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is use to create the data writer using prebuilt type dependant libraries
    @param    : DomainID - Domain ID for which participant is created
    @param    : topicName - Name of the topic
    @param    : QoS_Policy QoS - QoS file consists of all QoS parameters
    @param    : DataWriterID - Data writer id is passed
    @param    : resultCode - the result code returned by Opensplice library
    @param    : libFileName - the library filename to be used.
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDataWriterLib(int DomainID, const char *topicName, const char *typeName, const char *typeLib, QoS_Policy *QoS, CMULONG *DataWriterID, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is use to create the data writer
    @param    : DomainID - Domain ID for which participant is created
    @param    : topicName - Name of the topic
    @param    : QoS_Policy QoS - QoS file consists of all QoS parameters
    @param    : DataWriterID - Data writer id is passed
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDataWriterLibUseQoSFile(int DomainID, const char *topicName, const char *typeName, const char *typeLib, const char *QoSFileName, CMULONG *DataWriterID, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is use to create the data writer
    @param    : DomainID - Domain ID for which participant is created
    @param    : topicName - Name of the topic
    @param    : QoS_Policy QoS - QoS file consists of all QoS parameters
    @param    : DataWriterID - Data writer id is passed
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDataReader(int DomainID, const char *topicName, const char *typeName, QoS_Policy *QoS, CMULONG *DataReaderID, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is use to create the data writer
    @param    : DomainID - Domain ID for which participant is created
    @param    : topicName - Name of the topic
    @param    : QoS_Policy QoS - QoS file consists of all QoS parameters
    @param    : DataWriterID - Data writer id is passed
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDataReaderUseQoSFile(int DomainID, const char *topicName, const char *typeName, const char *QoSFileName, CMULONG *DataReaderID, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is use to create the data writer using prebuilt type dependant libraries
    @param    : DomainID - Domain ID for which participant is created
    @param    : topicName - Name of the topic
    @param    : QoS_Policy QoS - QoS file consists of all QoS parameters
    @param    : DataWriterID - Data writer id is passed
    @param    : resultCode - the result code returned by Opensplice library
    @param    : libFileName - the library filename to be used.
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDataReaderLib(int DomainID, const char *topicName, const char *typeName, const char *typeLib, QoS_Policy *QoS, CMULONG *DataReaderID, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is use to create the data writer
    @param    : DomainID - Domain ID for which participant is created
    @param    : topicName - Name of the topic
    @param    : QoS_Policy QoS - QoS file consists of all QoS parameters
    @param    : DataWriterID - Data writer id is passed
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDataReaderLibUseQoSFile(int DomainID, const char *topicName, const char *typeName, const char *typeLib, const char *QoSFileName, CMULONG *DataReaderID, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is use to publish data to specified domain
    @param    : DomainID - Domain ID for which participant is created
    @param    : datawriterId - Data writer id is provided
    @param    : publishData- Data to be published is passed here
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus WritePublishData(int DomainID, CMULONG datawriterId, void *publishData, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is use to publish data to specified domain
    @param    : DomainID - Domain ID for which participant is created
    @param    : datawriterId - Data writer id is provided
    @param    : publishData- Data to be published is passed here
    @param    : instance_handle: The handle of registered instance needs to be passed. If no instances registered, DDS_HANDLE_NIL to be passed.
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus WritePublishDataEx(int DomainID, CMULONG datawriterId, void *publishData, CMULONG instance_handle, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is use to read the data published by subscriber
    @param    : DomainID - Domain ID for which participant is created
    @param    : DataReaderID - Data reader id is provided
    @param    : SubData - the structure with received data is returned to application
    @param    : SubInfoSeq - the structure with sequence info is returned to application
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus ReadSubscriberData(int DomainID, CMULONG datareaderId, void *SubData, void *SubInfoSeq, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief    : This function is use to read the data published by publisher
    @param    : DomainID - Domain ID for which participant is created
    @param    : DataReaderID - Data reader id is provided
    @param    : SubData - data recieved is stored
    @param    : resultCode - the result code returned by Opensplice library
    @param    : SubData1 - data recieved from shared memory is stored
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus ReadSubscriberDataDDS_SM(int DomainID, CMULONG datareaderId, void *SubData, void *SubInfoSeq, char *resultCode, void *SubData1);

/**************************************************************************************************************/
/*!
    @brief : This function is use to read the data published by subscriber
    @param    : DomainID - Domain ID for which participant is created
    @param    : DataReaderID - Data reader id is provided
    @param    : SubData - the structure with received data is returned to application
    @param    : SubInfoSeq - the structure with sequence info is returned to application from DDS
    @param    : condition - the read condition is passed. If this argument is null, normal read operation takes place
    @param    : resultCode - the result code returned by Opensplice library
	@param    : SubData1 -  the structure with received data is returned to application from the shared memory
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus ReadSubscriberDataEx(int DomainID, CMULONG datareaderId, void *SubData, void *SubInfoSeq, CMULONG condition, char *resultCode, void *SubData1);

// CMStatus ReturnLoan( DDS_DataReader datareaderId, char *SubData, char *SubInfoSeq, char *resultCode)

/**************************************************************************************************************/
/*!
    @brief : This function is used to recursively delete all entities in the DomainParticipant
    @param    : DomainID - Domain ID for which participant is created
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/

COMMIDDLE_API CMStatus ShutdownContainedEntities(int DomainID, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used to delete the participant
    @param    : DomainID - Domain ID for which participant is created
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/

COMMIDDLE_API CMStatus ShutdownParticipant(int DomainID, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used to delete data writer of specified Domain Id. Internally, the publisher and topic would also be deleted
    @param    : DomainID - Domain ID for which participant is created
    @param    : datawriterId - Data writer id is provided
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/

COMMIDDLE_API CMStatus ShutdownDataWriter(int DomainID, CMULONG datawriterId, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used to delete the reader. Internally, the publisher and topic would also be deleted
    @param    : DomainID - Domain ID for which participant is created
    @param    : DataReaderID - Data reader id is provided
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : Nonev
*/
/**************************************************************************************************************/

COMMIDDLE_API CMStatus ShutdownDataReader(int DomainID, CMULONG datareaderId, char *resultCode);
COMMIDDLE_API CMStatus ShutdownSubscriber(int DomainID, CMULONG subscriberID, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used to create the log file to save all publisher data
    @param    : DomainID - Domain ID for which participant is created
    @param    : publisherID - publisher id is provided
    @param    : LogParams param - path to save file
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/

COMMIDDLE_API CMStatus SetPublisherLog(int DomainID, CMULONG datawriterId, short *FileId, const char *Filename, SerializeSample serial_callback);

/**************************************************************************************************************/
/*!
    @brief : This function is used to create the log file to save all subscriber data
    @param    : DomainID - Domain ID for which participant is created
    @param    : subscriberID - subscriber id is provided
    @param    : LogParams param - path to save file
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/

COMMIDDLE_API CMStatus SetSubscriberLog(int DomainID, CMULONG datareaderId, short *FileId, const char *Filename, SerializeSequence serial_callback);

/**************************************************************************************************************/
/*!
    @brief : This function is use to create the ring buffer to store publishers logs
    @param    : DomainID - Domain ID for which participant is created
    @param    : publisherID - publisher id is provided
    @param    : ringBufferAddr - the head address of ring buffer is specified
    @param    : ringBufferSize - hsize of ring buffer is specified
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/

COMMIDDLE_API CMStatus SetPublisherSaveRingBuffer(int DomainID, CMULONG datawriterId, short *FileId, const char *Filename, SerializeSample serial_callback, void *ringBufferAddr, long ringBufferSize);

/**************************************************************************************************************/
/*!
    @brief : This function is use to store the subscriber logs
    @param    : DomainID - Domain ID for which participant is created
    @param    : subscriberId - Subscriber id is provided
    @param    : ringBufferAddr - the head address of ring buffer is specified
    @param    : ringBufferSize - hsize of ring buffer is specified
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/

COMMIDDLE_API CMStatus SetSubscriberSaveRingBuffer(int DomainID, CMULONG datareaderId, short *FileId, const char *Filename, SerializeSequence serial_callback, void *ringBufferAddr, long ringBufferSize);

/**************************************************************************************************************/
/*!
    @brief : This function is use to create participant for system management
    @param    : void
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/

COMMIDDLE_API CMStatus SetParticipantSysCtrl();

/**************************************************************************************************************/
/*!
    @brief : This function is use to create publisher for system control
    @param    : QoSFileName - QoS file name with QoS parameters
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/

COMMIDDLE_API CMStatus SetPublisherSysCtrl(int DomainID, const char *QoSFileName, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is use to create subscriber for system control
    @param    : QoSFileName - QoS file name with QoS parameters
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetSubscriberSysCtrl(int DomainID, void *callback_fun, const char *QoSFileName, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is use to delete publisher for system control
    @param    : void
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/

COMMIDDLE_API CMStatus ShutdownPublisherSysCtrl(void);

/**************************************************************************************************************/
/*!
    @brief : This function is use to delete subscriber for system control
    @param    : void
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus ShutdownSubscriberSysCtrl(void);

/**************************************************************************************************************/
/*!
    @brief : This function is use to publish system **control data to subscriber
    @param    : void
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus WritePublishDataSysCtrl(int DomainID, void *client_callback, void *request, void *response, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is use to read the published data by **Subscriber
    @param    : void
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus ReadSubscriberDataSysCtrl(void);

/**************************************************************************************************************/
/*!
    @brief : This function is use to delete the publisher for system **control
    @param    : void
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus ShutdownSysCtrl(int DomainID, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used by subscriber for a request and for the process and demand is generated
    @param    : DomainID - Domain ID is specified
    @param    : topicName_pub - topic name is specified
    @param    : typeName_pub - Type of the Publisher topic
    @param    : Qos_pub - QoS policy of publisher is specified
    @param    : topicName_sub - topic name is specified
    @param    : typeName_sub - Type of the Subscriber topic
    @param    : Qos_sub - QoS policy of subscriber is specified
    @param    : clientId - client id is generated and returned from this function
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDdsClient(int DomainID, char *topicName_pub, const char *typeName_pub, QoS_Policy *Qos_pub, char *topicName_sub, const char *typeName_sub, QoS_Policy *Qos_sub, CMULONG *clientId, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used by subscriber for a request and for the process and demand is generated by using QoS file
    @param    : DomainID - domain id is specified
    @param    : topicName_pub - topic name is specified
    @param    : typeName_pub - Type of the Publisher topic
    @param    : QoSFileName_pub - QOS_PROFILE file is provided for publisher
    @param    : topicName_sub - topic name is specified
    @param    : typeName_sub - Type of the Subscriber topic
    @param    : QoSFileName_sub - QOS_PROFILE file is provided for subscriber
    @param    : clientId - client id is generated and returned from this function
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDdsClientUseQoSFile(int DomainID, char *topicName_pub, const char *typeName_pub, const char *QoSFileName_pub, char *topicName_sub, const char *typeName_sub, const char *QoSFileName_sub, CMULONG *clientId, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used  to process request and take back the result in sync manner
    @param    : DomainID - domain id is specified
    @param    : clientId -  client id is specified
    @param    : requestData - request data sent to server
    @param    : responseData - response data came from server
    @param    : timeout - time out is specified
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus WriteDdsClientReqSync(int DomainID, CMULONG clientId, void *requestData, void *responseData, void *responseInfoSeq, int timeout, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used  to process request and take back the result in async manner
    @param    : DomainID - domain id is specified
    @param    : clientId -  client id is specified
    @param    : client_callback - callback function
                Defined in application and used for handling response coming from server
                Function params : void client_callback(void *result)
                This result will be type-casted to DDS_sequence_Result_Mul inside the function
    @param    : request - request data sent to server
    @param    : response - response data came from server
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus WriteDdsClientReqAsync(int DomainID, CMULONG clientId, void *client_callback, void *request, void *response, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used to start a log file server.
    @param    : DomainID - domain id is specified
    @param    : topicName_pub -  topic name is specified
    @param    : Qos_pub - QoS policy is provided by the publisher
    @param    : topicName_sub - topic name is specified
    @param    : Qos_sub - QoS policy is provided by the subscriber
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDdsLogClient(int DomainID, char *topicName_pub, QoS_Policy *Qos_pub, char *topicName_sub,
	QoS_Policy *Qos_sub, CMULONG *clientId, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief 	  : This function is used to start the log client using a qos file.
    @param    : DomainID - domain id is specified
    @param    : topicName_pub -  topic name is specified
    @param    : QoSFileName_pub - QoS file name is provided by the publisher
    @param    : topicName_sub - topic name is specified
    @param    : QoSFileName_sub- QoS file name is provided by the subscriber
    @param    : clientId - After creating the log client. client id is sotored her.
	@param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDdsLogClientUseQoSFile(int DomainID, char *topicName_pub, const char *QoSFileName_pub, char *topicName_sub,	const char *QoSFileName_sub, CMULONG *clientId, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief    : This function is used to perserve the file of the received log in sync manner
    @param    : DomainID - domain id is specified
    @param    : clientId - client id is specified.
    @param    : request - request parameters that needs to be sent to server
    @param    : lpszoutputlogfileName - the place  where the **received log data to be stored is specified
    @param    : timeout- timeout time from the processing demand to a response result
	@param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus WriteDdsLogClientReqSync(int DomainID, CMULONG clientId, void *request,
                                  char *lpszoutputlogfileName, int timeout, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief    : This function is used to perserve the file of the recieved log in async manner
    @param    : DomainID - domain id is specified
    @param    : clientId - client id is specified
	@param    : request - client requesting details will be here.
    @param    : lpszoutputlogfileName -name of the file to be specified
    @param    : filetype- 0.TEXT 1.BINARY
    @param    : timeout- timeout time from the processing demand to a response result
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus WriteDdsLogClientReqAsync(int DomainID, CMULONG clientId, void *request,
                                   char *lpszoutputlogfileName, int timeout, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used to delete publisher and the processing demand
    @param    : DomainID - domain id is specified
    @param    : clientId - client id is specified
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus ShutdownDdsClient(int DomainID, int clientId, char *resultCode);

/**************************************************************************************************************/ /*!
    @brief : This function is used to set a server for respective request and response topics
    @param    : DomainID - domain id is passed
    @param    : serverId - server id is generated and returned to caller
    @param    : callback_fun - callback function pointer
    @param    : request - request data sent to client
    @param    : response - response data came from client
    @param    : topicName_pub - topic name is specified
    @param    : typeName_pub - Type of the Publisher topic
    @param    : QoS_pub - QoS_Policy structure is provided for publisher
    @param    : topicName_sub - topic name is specified
    @param    : typeName_sub - Type of the Subscriber topic
    @param    : QoS_sub - QoS_Policy structure is provided for subscriber
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDdsServer(int DomainID, void *callback_fun, void *request, void *response, char *topicName_pub, const char *typeName_pub,
                      QoS_Policy *QoS_pub, char *topicName_sub, const char *typeName_sub,
					  QoS_Policy *QoS_sub, CMULONG *serverId, char *resultCode);

/**************************************************************************************************************/ /*!
    @brief : This function is used to set a server (by using QoS file) for respective request and response topics
    @param    : DomainID - domain id is passed
    @param    : serverId - server id is generated and returned to caller
    @param    : callback_fun - callback function pointer
    @param    : request - request data sent to client
    @param    : response - response data came from client
    @param    : topicName_pub - topic name is specified
    @param    : typeName_pub - Type of the Publisher topic
    @param    : QoSFileName_pub - QOS_PROFILE file is provided for publisher
    @param    : topicName_sub - topic name is specified
    @param    : typeName_sub - Type of the Subscriber topic
    @param    : QoSFileName_sub - QOS_PROFILE file is provided for subscriber
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/

COMMIDDLE_API CMStatus SetDdsServerUseQoSFile(int DomainID, void *callback_fun, void *request, void *response, char *topicName_pub,
                                const char *typeName_pub, const char *QoSFileName_pub, char *topicName_sub, const char *typeName_sub,
								const char *QoSFileName_sub, CMULONG *serverId, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used to recieve log file from publisher.
    @param    : DomainID - domain id is specified
    @param    : topicName_pub -  topic name is specified
    @param    : QoS_pub - QoS policy is provided by the publisher
    @param    : topicName_sub - topic name is specified
    @param    : QoS_sub - QoS policy is provided by the subscriber
    @param    : logServerID - Created server id is stored in this.
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDdsLogServer(int domainId, char *topicName_pub, QoS_Policy *QoS_pub, char *topicName_sub,
	QoS_Policy *QoS_sub, CMULONG *logServerID, char *result);

/**************************************************************************************************************/
/*!
    @brief : This function is used to recieve log file from publisher using QoS file
    @param    : DomainID - domain id is specified
    @param    : topicName_pub -  topic name is specified
    @param    : QoSFileName_pub - QoS policy is provided here in qos file
    @param    : topicName_sub - topic name is specified
    @param    : QoSFileName_sub - QoS policy is provided here in qos file
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDdsLogServerUseQoSFile(int DomainID, char *topicName_pub, const char *QoSFileName_pub,
	char *topicName_sub, const char *QoSFileName_sub, CMULONG *logServerID,
                                   char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used read the request
      @param    : DomainID - domain id is specified
    @param    : serverID -  server name is specified
    @param    : ServerReq - Server request is provided here
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/

COMMIDDLE_API CMStatus ReadDdsServerReq(int DomainID, int serverID, void *ServerReq, char *resultCode);

/**************************************************************************************************************/

/*!
    @brief : This function is used to write response to client from publisher
      @param    : DomainID - domain id is specified
    @param    : serverID -  server name is specified
    @param    : ServerReq - Server request is provided here
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus WriteDdsServerRes(int DomainID, int serverID, void *ServerReq, char *resultCode);

/**************************************************************************************************************/

/*!
    @brief : This function is used to delete server
      @param    : DomainID - domain id is specified
    @param    : serverID -  server name is specified
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus ShutdownDdsServer(int DomainID, int serverId, char *resultCode);

//utility functions
#ifndef WIN32
/**************************************************************************************************************/
/*!
    @brief : This function is create the monitoring thread
    @param    : threadID - thread handler is stored here
    @param    : argv - mapfile path, given from user in command line argument
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus comMiddleInit(unsigned long int *threadID, void *mapFilePath);
#endif
/**************************************************************************************************************/
/*!
    @brief    : This function is used to create a reader for contentfiltered topic
    @param    : DomainID - the ID of the Domain to which the DDS_DomainParticipant is joined.
    @param    : topicName - contains the name of the DDS_ContentFilteredTopic.
    @param    : DataReaderIDold - a pointer to the previously-created DDS_DataReader for the old/related topic
    @param    : filter_expression - holds the SQL expression (subset of SQL), which defines the filtering.
    @param    : filter_parameters - the handle to a sequence of strings with the parameter value used in the SQL expression (i.e., the number of %n tokens in the expression)
    @param    : DataReaderIDnew - a pointer to the newly-created DDS_DataReader
    @param    : resultCode - the return code returned by Opensplice library
    @retval   : CMStatus - Success or Fail
    @attention  : Please note that the filtered expression should be passed as per the instructions provided in: http://download.prismtech.com/docs/Vortex/apis/ospl/isocpp2/html/a00051.html
    @attention  : The expression supports only few data types. Please refer to the link shared above. Please note that char arrray won't work in place of string.
**************************************************************************************************************/
COMMIDDLE_API CMStatus SetContentFilteredReader(int DomainID, const char *topicName, CMULONG DataReaderIDold, const char *filter_expression, const DDS_StringSeq *filter_parameters, CMULONG *DataReaderIDnew, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief    : This function is used to delete a reader for contentfiltered topic
    @param    : DomainID - Domain ID under which the reader needs to be deleted
    @param    : DataReaderID - a pointer to the DDS_DataReader corresponding to content filtered topic is passed
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : CMStatus - Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus ShutdownContentFilteredReader(int DomainID, CMULONG datareaderId, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief    : This function is used to create a query condition for a data reader
    @param    : datareaderId - a pointer to the DDS_DataReader for which querycondition is applied
    @param    : query_string - holds the SQL expression (subset of SQL), which defines the filtering.
    @param    : queryCondition:The handle to quercondition for this reader.
    @param    : query_parameters - the handle to a sequence of strings with the parameter value used in the SQL expression (i.e., the number of %n tokens in the expression)
    @retval   : CMStatus - Success or Fail
    @attention  : Please note that the filtered expression should be passed as per the instructions provided in: http://download.prismtech.com/docs/Vortex/apis/ospl/isocpp2/html/a00051.html
    @attention  : The expression supports only few data types. Please refer to the link shared above. Please note that char arrray won't work in place of string.
*/
/***************************************************************************************************************/
COMMIDDLE_API CMStatus setQueryCondition(CMULONG datareaderId, const char *query_string, const DDS_StringSeq *query_parameters, CMULONG *queryCondition);

/**************************************************************************************************************/
/*!
    @brief    : This function is used to delete a query condition for a reader
    @param    : datareaderId - a pointer to the DDS_DataReader
    @param    : queryCondition - a pointer to the querycondition corresponding to a reader
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : CMStatus - Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus shutdownQueryCondition(CMULONG datareaderId, CMULONG queryCondition, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used to create the data reader for the builtin-topics
    @param    : DomainID - Domain ID for which participant is created
    @param    : DataReaderID - Pointer to the datareader for builtin topics
    @param    : resultCode - the result code returned by Opensplice library
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetBuiltInTopicsReader(int DomainID, CMULONG *DataReaderID, char *resultCode);

#ifndef WIN32
enum rbEventType {
    rbEventClear = 1,
    rbEventFlush = 2,
    rbEventGetHandle = 3,
    rbEventPublishedFlag = 4
};

typedef struct rbEventInfo {
    unsigned int eventId;
    unsigned int msg_type;
    int SourceType;
    key_t key;
    char fileName[NAME_MAX];
    char AppName[NAME_MAX];
    unsigned int rb_flag;

} RBEventInfo;

int NotifyClearBuffer(RBEventInfo *eventInfo);

int NotifyFlushBuffer(RBEventInfo *eventInfo);
#endif

/**************************************************************************************************************/
/*!
    @brief : This function is used to get the topicQoS for the given topic. These qos policies are changeable in runtime
    @param    : DomainID - Domain ID for which participant is created
    @param    : topicName - The name of the topic whose QoS policy is to be fetched
    @param    : QoS - the QoS policy structure as defined in IDL file
    @param    : resultCode - The errorcode is returned
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus GetTopicQoS(int DomainID, const char *topicName, void* QoS, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used to Set the topicQoS for the given topic. These qos policies are changeable in runtime
    @param    : DomainID - Domain ID for which participant is created
    @param    : topicName - The name of the topic whose QoS policy is to be fetched
    @param    : QoS - the QoS policy structure as defined in IDL file
    @param    : resultCode - The errorcode is returned
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetTopicQoS(int DomainID, const char *topicName, void* QoS, char *resultCode);

/**************************************************************************************************************/
/*!
    @brief : This function is used to Set the Device Information of the Device. These Device info will be stored in
    @param    : ReqDeviceInfo - Device information needs to be filled by Application
    @param    : resultCode - The errorcode is returned
    @retval   : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetDeviceInfo(void *ReqDeviceInfo);

/**************************************************************************************************************/
/*!
    @brief      : This function is used to Set the Com type for the datawriter or datareader
    @param      : DomainID - Domain ID
    @param      : wrType    - Writer or Reader selection (CM_WRITER or CM_READER)
    @param      : wrID      - Writer or Reader id depending on wrType selection
    @param      : comType   - Communicatino type there are 3 modes (CM_DDS,CM_SHM, CM_DDS_SHM)
    @retval     : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetComType(int DomainID, wrType_t wrType, CMULONG wrID, comType_t comType);

/**************************************************************************************************************/
/*!
    @brief      : This function is used to Set the shared memory to start CM communiaction
                  Over shared memory.
    @param      : DomainID - Domain ID
    @param      : wrType    - Writer or Reader selection (CM_WRITER or CM_READER)
    @param      : wrID      - Writer or Reader id depending on wrType selection
    @param      : keyPath   - User requested path to where key will genenrate
    @param      : topicSize - Topic size (in Bytes)
    @param      : shmSize   - Shared memory size (in Bytes)
    @retval     : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus SetSharedMemory(int DomainID, wrType_t wrType, CMULONG wrID, const char *keyPath, CMULONG topicSize, CMULONG shmSize);

/**************************************************************************************************************/
/*!
    @brief      : This function is used to clear the shared memory
    @param      : DomainID - Domain ID
    @param      : wrType - Writer or Reader selection (CM_WRITER or CM_READER)
    @param      : wrID - Writer or Reader id depending on wrType selection
    @retval     : Success or Fail
    @attention  : None
*/
/**************************************************************************************************************/
COMMIDDLE_API CMStatus ClearSharedMemory(int DomainID, wrType_t wrType, CMULONG wrID);

#ifdef __cplusplus

}
#endif
#endif
