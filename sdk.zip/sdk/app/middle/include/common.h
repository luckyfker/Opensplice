/////////////////////////////////////////////////////////////////////////////
//
//	    Copyright (C) 2002
//				TEC CORPORATION,  ALL Rights Reserved
//				1-14-10 Uchikanda Chiyoda-ku Tokyo JAPAN
//
/////////////////////////////////////////////////////////////////////////////
//
//  MODULE NAME	:  common.h
//  (FILE NAME)
//  PARAMETERS	:  NONE
//
//  DESCRIPTION	:  libinifile.so ����������
//			/ Linux�� INI�ե����륢�������ؿ��ʥ��������ɥ饤�֥���
//
//  CREATE   NO :  V001.001		2002.07.11    ITAGAKI YU-YA [TOSHIBA TEC]
//
//  MODIFIED NO :
//
/////////////////////////////////////////////////////////////////////////////

#ifndef __COMMON_H__
#define __COMMON_H__

#define TRUE 1
#define FALSE 0
#define BOOL int

#endif // __COMMON_H__
