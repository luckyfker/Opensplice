///////////////////////////////////////////////////////////////
//
//
//	Copyright (C) 2019
//	TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
////////////////////////////////////////////////////////////////
//
//
//	FILE        : ftpClient.h
//
//	DESCRIPTION : ftpClient library
//
//	CREATE ON   : V001.000        Sachin Gowda K        2019.11.11
//
//	MODIFIED ON :
//
//
//
//
//
//
//
/////////////////////////////////////////////////////////////////

#ifndef FTP_CLIENT_H
#define FTP_CLIENT_H
#include <stdint.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <limits.h>

struct filelist
{
char token[256];
};

/*! Connect API to connect to the FTP-server */
int ftpConnect(const char *IPaddr, const uint16_t port);

/*! Login API to login to the server */
int ftpLogin(const char *user,const char *pass);

/*! Disconnect API to terminate FTP session */
void ftpDisconnect();

/*! ListDir API to list the contents present working directory in server */
int ftpListDir(char *List);

/*! ListFiles API to list the files in a directory in server */
int ftpListFiles(char *List);

/*! CreateDir API to create a directory in server */
int ftpCreateDir(const char *path);

/*! DeleteDir API to delete a directory in server */
int ftpDeleteDir(const char * path);

/*! DeleleteFile API to delete a file in server */
int ftpDeleteFile(const char *filename);

/*! ChangeDirectory API to change the present working directory in server */
int ftpChangeDirectory(const char *dest_path);

/*! RenameFile API to rename a file in server */
int ftpRenameFile(const char *oldFilename,const char* newFilename);

/*! DownloadFile API to download a file from server */
int ftpDownloadFile(const char *filename, const char *localpath,int *filesize);

/*! UploadFile API to upload a file to the server */
int ftpUploadFile(const char *filename, const char *localpath,int *filesize);

/*! DownloadFile API to download a directory from server */
int ftpDownloadDirectory(const char *dirname, const char *localpath);

/*! enabaleSSL API to enable TLS over SSL communication */
int ftpEnableSSL();

/*! getPwd API to get the present working directory of a server */
int ftpGetPwd(char *pwd);

/*! cancelTransaction API to abort active file transfer */
void ftpCancelTransaction();

#endif // FTP_CLIENT_H

