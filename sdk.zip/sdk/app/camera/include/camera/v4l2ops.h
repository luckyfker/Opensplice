/*
 * V4L2 Oparations
 *
 * Copyright (c) 2019 Regulus co.,ltd. All rights reserved.
 * This is proprietary software.
 */
#ifndef _V4L2OPS_H_
#define _V4L2OPS_H_

//#ifdef __cplusplus
//extern "C" {
//#endif /* __cplusplus */

#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>

#include <linux/videodev2.h>

#define V4L2OPS_MAX_VIDEO_BUFFER_NUM 32
#define V4L2OPS_MULTI_PLANE_NUM 1


/* ----------------------------------------------------------------------------
 * Struct
 */

enum v4l2_device_type {
	v4l2_dev_capture = 0,
	v4l2_dev_output,
};

struct v4l2_simple_format {
	uint32_t width;
	uint32_t height;
	uint32_t stride;
	uint32_t v4l2_pix_fmt;/* V4L2_PIX_FMT_* */
};

struct v4l2_video_buffer {
	int id;
	unsigned char *start;
	size_t length;
	unsigned int bytesused;
	
	/* internal */
	struct v4l2_format format;
	uint32_t dmabuf_fd;
	int queing;
	struct v4l2_buffer vbuf;
	struct v4l2_plane vplane[V4L2OPS_MULTI_PLANE_NUM];
};

struct v4l2_video_buffer_group {
	enum v4l2_memory mem_type;
	enum v4l2_buf_type buf_type;
	int qbuf_num;
	int bufs_num;
	struct v4l2_video_buffer bufs[V4L2OPS_MAX_VIDEO_BUFFER_NUM];
};

struct v4l2_device {
	char *devname;
	int fd;
};

struct v4l2_video_device {
	struct v4l2_device dev;
	
	enum v4l2_device_type dev_type;
	
	struct v4l2_format format;

	struct v4l2_video_buffer_group bufgrp;
	int extbuf_start_idx;
	
	pthread_mutex_t mutex;
};

/* ----------------------------------------------------------------------------
 * API
 */
// 
int v4l2_open(struct v4l2_video_device *vdev, char* devname, enum v4l2_device_type dev_type, enum v4l2_memory mem_type);
void v4l2_close(struct v4l2_video_device *vdev);
int v4l2_set_format(struct v4l2_video_device *vdev, struct v4l2_simple_format sfmt);
//int v4l2_create_bufs(struct v4l2_video_device *vdev, struct v4l2_simple_format sfmt, int count);
int v4l2_create_bufs(struct v4l2_video_device *vdev, struct v4l2_simple_format sfmt, int count, void* ptr);
struct v4l2_video_buffer *v4l2_get_buf_id(struct v4l2_video_device *vdev, int id);
int v4l2_destroy_bufs(struct v4l2_video_device *vdev);
int v4l2_stream_on(struct v4l2_video_device *vdev);
int v4l2_stream_off(struct v4l2_video_device *vdev);
int v4l2_qbuf_all(struct v4l2_video_device *vdev);
int v4l2_qbuf(struct v4l2_video_device *vdev, struct v4l2_video_buffer *buf);
int v4l2_qbuf_id(struct v4l2_video_device *vdev, int id);
struct v4l2_video_buffer *v4l2_dqbuf(struct v4l2_video_device *vdev);

//#ifdef __cplusplus
//}
//#endif /* __cplusplus */

#endif /* _V4L2OPS_H_ */
