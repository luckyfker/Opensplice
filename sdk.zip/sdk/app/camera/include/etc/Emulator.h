#ifndef _EMULATOR_H_
#define _EMULATOR_H_
#include <stdint.h>
#include <stddef.h>
#define _CRTDBG_MAP_ALLOC

#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#ifndef BYTE
typedef unsigned char BYTE;
#endif

#ifndef WORD
typedef unsigned short WORD;
#endif

/*#ifndef LONG
typedef int LONG;
#endif*/

#ifndef DWORD
typedef unsigned int DWORD;
#endif

#ifndef max
#define max(a,b) ((a)>(b)?(a):(b))
#endif

#ifndef min
#define min(a,b) ((a)<(b)?(a):(b))
#endif

#define RoundBYTE(a) min(max(a,0),255)

#ifndef TH_HPF_BINARIZE_A
//#define TH_HPF_BINARIZE_A	131		/* HPFの２値化閾値 for FPGA (for R-LED-44)                 */ //27
#define TH_HPF_BINARIZE_A	132		/* HPFの２値化閾値 for FPGA (for R-LED-44)                 */ //26
//#define TH_HPF_BINARIZE_A	130		/* HPFの２値化閾値 for FPGA (for R-LED-44)                 */ //27
//#define TH_HPF_BINARIZE_A	133		/* HPFの２値化閾値 for FPGA (for R-LED-44)                 */ //29
#endif

//#ifndef TH_HPF_BINARIZE_B
//#define TH_HPF_BINARIZE_B	133		/* HPFの２値化閾値 for FPGA (for else)                     */
//#endif

#ifndef SXGA_X
#define SXGA_X (0x500)	// 1280
#endif

#ifndef SXGA_Y
#define SXGA_Y (0x400)	// 1024
#endif

#define BMP_X SXGA_X
#define BMP_Y SXGA_Y

#define STRIDE (1024*8)
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;

#endif