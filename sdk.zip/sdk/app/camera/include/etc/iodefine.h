/************************************************************************
*                                                                       *
*      Copyright (C) 2012                                               *
*      TOSHIBA TEC CORPORATION All Rights Reserved                      *
*      570 Ohito, Izunokuni-shi, Shizuoka-ken, JAPAN                    *
*                                                                       *
************************************************************************/
/***********************************************************************/
/*                                                                     */
/*  FILE        :iodefine.h                                            */
/*  DATE        :Fri, Jan 13, 2012                                     */
/*  DESCRIPTION :Definition of I/O Register                            */
/*  CPU TYPE    :SH7720,SH7721                                         */
/*                                                                     */
/*  This file is downloaded by homepage of Renesas technical Update.   */
/*                                                                     */
/***********************************************************************/

#include "AbsoluteDefinition.h"


#ifdef XILINX_HEADER
#include "xparameters.h"
#include "xstatus.h"
#include "xgpiops.h"

extern XGpioPs	GpioInOut_GlbPs;				/* The driver instance for GPIOPS(�e���ݻ&����&�M��)			*/
#endif
/*******************************************************/
/***           <<<<<  FPGA BIT FIELD >>>>>           ***/
/*******************************************************/

/*******************************************************/
/***    <<<<< Register Address(PL) redefine >>>>>    ***/
/*******************************************************/
#define FPGA_VD					0x41230000		//�@VD�M��(0bit�̂�)
#define	FPGA_SPI_SET			0x43C00003		// �J�����ݒ�@SPI
#define FPGA_SPI_DATA			0x43C00002		// �J�����ݒ�@���M�f�[�^

#define FPGA_IMG_SELECT0		0x43C30000		// �摜�o�͐ݒ�(0�C1����)
#define FPGA_IMG_SELECT1		0x43C30001		// �摜�o�͐ݒ�(2�C3����)
#define FPGA_IMG_HD_THIN		0x43C20003		// HD�Ԉ���

#define FPGA_LIGHT				0x43C00000		// �Ɩ�(2byte)

#define FPGA_BLUELED_EX			0x43C50001		// �O����LED (IS-820�p IS-200�ł͓����|�[�g��ԐFLED�Ŏg�p���Ă���)

#define FPGA_ADD_LINE			0x43C20001		// ���z���C��
#define FPGA_TH_HPF				0x43C20000		// �n�C�p�X�t�B���^�[臒l

#define FPGA_GAMMA				0x43C10002		// ���␳

#define FPGA_BLUE_LED			0x43C50000		// �FLED
#define FPGA_RED_LED			0x43C50001		// �ԐFLED

#define FPGA_GREEN_LED			0x43C50002		// �ΐFLED (���i�ɂ͖�����)

/*******************************************************/
/***          <<<<< GPIO(PL) redefine >>>>>          ***/
/*******************************************************/

/***************************************/
/*** <<<<< GPIO(PL) Bit define >>>>> ***/
/***************************************/
// GPIO Input/Output Level
#define GPIO_LEVEL_LOW		(0u)		// Low level
#define GPIO_LEVEL_HIGH		(1u)		// High level

/***************************************/
/*** <<<<< GPIO(PS) Bit define >>>>> ***/
/***************************************/
#ifndef INDICATOR_LED_SWAP
#define MIO_PS_GPIO_GREENLED        10          			// 10 Bit : GPIO(O)(3.3V)        : ��LED      		: 1=ON,0=OFF
#define MIO_PS_GPIO_BLUELED        	11          			// 11 Bit : GPIO(O)(3.3V)        : ��LED      		: 1=ON,0=OFF
#else
#define MIO_PS_GPIO_GREENLED        11          			// 11 Bit : GPIO(O)(3.3V)        : ��LED      		: 1=ON,0=OFF
#define MIO_PS_GPIO_BLUELED        	10          			// 10 Bit : GPIO(O)(3.3V)        : ��LED      		: 1=ON,0=OFF
#endif

#define MIO_PS_GPIO_TESTPIN_0       24          			// 24 Bit : GPIO(O)(3.3V)        : �e�X�g�s��(�A�N�`���G�[�^�[�����p) :
#define MIO_PS_GPIO_TESTPIN_1       25          			// 25 Bit : GPIO(O)(3.3V)        : �e�X�g�s�� :

#define MIO_PS_GPIO_USBRES         	40          			// 40 Bit : GPIO(O)(3.3V)        : USB3320-RES  	: 0=ؾ��,1=ؾ�ĉ���
#define MIO_SOUND_AMP_SHUTDOWN     	41          			// 41 Bit : GPIO(O)(3.3V)        : TPA6211A1		: 0=Shudown, 1=Active

#define MIO_PS_GPIO_SW_MODE_BIT		42						// 42 Bit : GPIO(I)(3.3V)        : ���[�h �X�C�b�`	:
#define MIO_PS_GPIO_SW_MODE_ACTIVE	GPIO_LEVEL_LOW			// 								 : �A�N�e�B�u High

#define MIO_PS_GPIO_SW_VOL_BIT		43						// 43 Bit : GPIO(I)(3.3V)        : ���� �X�C�b�`	:
#define MIO_PS_GPIO_SW_VOL_ACTIVE	GPIO_LEVEL_LOW			// 								 : �A�N�e�B�u High

#define MIO_PS_GPIO_CAM_3V3CE		44						// 44 Bit : GPIO(O)(3.3V)        : �J����3.3V Enable	: H=Enable

#define MIO_PS_GPIO_SENS_M9K		45						// 45 Bit : GPIO(O)(3.3V)        : M9K�p���̌��m�o��(���g�p)	:

#define MIO_PS_GPIO_USB_VBUS_BIT	46						// 46 Bit : GPIO(I)(3.3V)        : VBUS���m�M��	:
#define MIO_PS_GPIO_USB_VBUS_ACTIVE	GPIO_LEVEL_HIGH			// 								 : �A�N�e�B�u High

#ifdef MINI_SCANNER
#define MIO_PS_GPIO_SW_LIGHT_BIT	47						// 47 Bit : GPIO(I)(3.3V)        : Saturn�p�Ɩ� �X�C�b�`	:
#define MIO_PS_GPIO_SW_LIGHT_ACTIVE	GPIO_LEVEL_LOW			// 								 : �A�N�e�B�u High
#endif


/*******************************************************/
/***           <<<<< Exception Mask >>>>>            ***/
/*******************************************************/


/*******************************************************/
/***            <<<<< Exception ID >>>>>             ***/
/*******************************************************/
#ifdef GPIO_STUB
#define isAssertedGpio(gpio)	\
	(\
		MIO_PS_GPIO_##gpio##_ACTIVE == XGpioPs_ReadPin(&GpioInOut_GlbPs, MIO_PS_GPIO_##gpio##_BIT)\
	)

#endif