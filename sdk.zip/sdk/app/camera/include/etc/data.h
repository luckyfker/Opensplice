/***************************************************************************
 *	Copyright (C) 2017
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		data.h
 *	\brief 		�f�[�^�̒�`
 *
 *	@date		2017.08.28	�V�K�쐬
 *	@author		Takuya1_Takasu@toshibatec.co.jp
****************************************************************************/

#ifndef INC_DATA_H_
#define INC_DATA_H_

#ifndef Emulator
#else	// Emulator
typedef unsigned int u32;
#endif	// Emulator
#include "AbsoluteDefinition.h"


/** �A�h���X�擾�֐� */

AddressType DecodeTextData_get_addr();
AddressType DecodeTextData2_get_addr();

AddressType SendRequestData_get_addr();
AddressType SendRequestDataBackup_get_addr();
AddressType SendRequestDataBackup2_get_addr();
AddressType SendRequestDataBackup3_get_addr();

AddressType bf_plural_barcode_get_addr();
AddressType bf_3dan_barcode_get_addr();
AddressType bf_addon_barcode_get_addr();
AddressType bf_seal_barcode_get_addr();

#ifdef USE_SEAL_RECOGNITION				// �l�����V�[��
AddressType sealrcg_in_get_addr();
AddressType sealrcg_out_get_addr();
#endif

#ifdef MINI_SCANNER
AddressType bf_apo_image_para_get_addr();
#endif


/** �ǂݎ��֐� */

#if defined(USE_OBJECT_RECOGNITION) || defined(DEBUG_SEAL_ONLY_RECOGNITION)	// �I�u�W�F�N�g�F��
int seal_format_backup_read();
#endif

AddressType processing_image_adr_read();


/** �������݊֐� */

#if defined(USE_OBJECT_RECOGNITION) || defined(DEBUG_SEAL_ONLY_RECOGNITION)	// �I�u�W�F�N�g�F��
int seal_format_backup_write(int val);
#endif

AddressType processing_image_adr_write(AddressType val);

#endif /* INC_DATA_H_ */
