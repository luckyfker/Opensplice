/*
 * Utilities
 *
 * Copyright (c) 2019 Regulus co.,ltd. All rights reserved.
 * This is proprietary software.
 */

#include "utils.h"

/* ----------------------------------------------------------------------------
 * API
 */

int streq(const char *str0,const char *str1)
{
	return (strcmp((const char *)str0, (const char *)str1) == 0);
}

int printerr(const char* format, ...)
{
	int ret;
	va_list args;
	
	va_start(args, format);
	ret = vprintf(format, args);
	va_end(args);
	
	return ret;
}
