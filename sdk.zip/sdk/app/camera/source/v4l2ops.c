/*
 * V4L2 Oparations
 *
 * Copyright (c) 2019 Regulus co.,ltd. All rights reserved.
 * This is proprietary software.
 */

#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <linux/videodev2.h>

#include "v4l2ops.h"
//#include  "apl_common.h"
//#include  "locallog.h"

extern int logFileId;

/* ---------------------------------------------------------------------------
 * Pieces
 */

static void print_fmt(struct v4l2_format format, char * prefix)
{
    printf("%s: wh %4dx%4d, bpl %4d, size 0x%0X, fmt %s, type %s \n",
            prefix, format.fmt.pix.width, format.fmt.pix.height, format.fmt.pix.bytesperline, format.fmt.pix.sizeimage,
            format.fmt.pix.pixelformat == V4L2_PIX_FMT_GREY ? "GREY": format.fmt.pix.pixelformat == V4L2_PIX_FMT_JPEG ? "JPEG": "YUYV",
            format.type == V4L2_BUF_TYPE_VIDEO_OUTPUT ? "OUT": "CAP");
}

static struct v4l2_video_buffer *seach_buf_id(int id, struct v4l2_video_buffer_group *bg)
{
    int i;
    
    for (i = 0; i < bg->bufs_num; i++) {
        if (bg->bufs[i].id == id)
            return &bg->bufs[i];
    }
    return NULL;
}

static int qbuf(struct v4l2_device *dev, struct v4l2_video_buffer *buf, enum v4l2_buf_type buf_type)
{
    int ret;
    
    if (V4L2_TYPE_IS_OUTPUT(buf_type))
        buf->vbuf.bytesused = buf->bytesused;
    
    /* _DPRINT("%s: %s: QBUF idx=%d, buse=0x%X, len=0x%X\n", __FUNCTION__, dev->devname, buf->vbuf.index, buf->vbuf.bytesused); */

    ret = ioctl(dev->fd, VIDIOC_QBUF, &buf->vbuf);
    if (ret != 0) {
        printf("%s: %s: VIDIOC_QBUF failed: vbuf %d: %s (%d)\n", __FUNCTION__, dev->devname, buf->vbuf.index, strerror(errno), errno);
        /*WriteLogEx(logFileId, 0, LOG_ERR, "%s: %s: VIDIOC_QBUF failed: vbuf %d: %s (%d)", 
                __FUNCTION__, dev->devname, buf->vbuf.index, strerror(errno), errno);
        */return 0;
    }
    
    buf->queing = 1;
    
    return 1;
}

static char *string_mem_type(enum v4l2_memory mem_type)
{
    switch (mem_type) {
        case V4L2_MEMORY_MMAP:      return "MMAP";
        case V4L2_MEMORY_USERPTR:   return "USERPTR ";
        case V4L2_MEMORY_OVERLAY:   return "OVERLAY";
        case V4L2_MEMORY_DMABUF:    return "DMABUF";
        default:                    return "unknown";
    }
    return "";
}

static char *string_buf_type(enum v4l2_buf_type buf_type)
{
    switch (buf_type) {
        case V4L2_BUF_TYPE_VIDEO_CAPTURE:           return "CAPTURE";
        case V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE:    return "CAPTURE_MPLANE";
        case V4L2_BUF_TYPE_VIDEO_OUTPUT:            return "OUTPUT";
        case V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE:     return "OUTPUT_MPLANE";
        default:                                    return "unknown";
    }
    return "";
}

static struct v4l2_format gen_v4l2_format(enum v4l2_buf_type buf_type, struct v4l2_simple_format sfmt)
{
    struct v4l2_format vfmt = {0};
    
    vfmt.type = buf_type;
    
    if (V4L2_TYPE_IS_MULTIPLANAR(buf_type)) {
        vfmt.fmt.pix_mp.pixelformat = sfmt.v4l2_pix_fmt;
        vfmt.fmt.pix_mp.field = V4L2_FIELD_NONE;
        vfmt.fmt.pix_mp.width = sfmt.width;
        vfmt.fmt.pix_mp.height = sfmt.height;
        vfmt.fmt.pix_mp.num_planes = V4L2OPS_MULTI_PLANE_NUM;
        vfmt.fmt.pix_mp.plane_fmt[0].bytesperline = sfmt.stride;
        vfmt.fmt.pix_mp.plane_fmt[0].sizeimage = vfmt.fmt.pix_mp.plane_fmt[0].bytesperline * vfmt.fmt.pix_mp.height;
    } else {
        vfmt.fmt.pix.pixelformat = sfmt.v4l2_pix_fmt;
        vfmt.fmt.pix.field = V4L2_FIELD_NONE;
        vfmt.fmt.pix.width = sfmt.width;
        vfmt.fmt.pix.height = sfmt.height;
        vfmt.fmt.pix.bytesperline =  sfmt.stride;
        vfmt.fmt.pix.sizeimage = vfmt.fmt.pix.bytesperline * vfmt.fmt.pix.height;
    }
    
    return vfmt;
}

static int diff_format(enum v4l2_buf_type buf_type, struct v4l2_simple_format sfmt, struct v4l2_format vfmt)
{
    int diff = 0;
    
    if (V4L2_TYPE_IS_MULTIPLANAR(buf_type)) {
        diff |= vfmt.fmt.pix_mp.pixelformat != sfmt.v4l2_pix_fmt;
        diff |= vfmt.fmt.pix_mp.width != sfmt.width;
        diff |= vfmt.fmt.pix_mp.height != sfmt.height;
        diff |= vfmt.fmt.pix_mp.plane_fmt[0].bytesperline != sfmt.stride;
        diff |= vfmt.fmt.pix_mp.plane_fmt[0].sizeimage != sfmt.stride * sfmt.height;
    } else {
        diff |= vfmt.fmt.pix.pixelformat != sfmt.v4l2_pix_fmt;
        diff |= vfmt.fmt.pix.width != sfmt.width;
        diff |= vfmt.fmt.pix.height != sfmt.height;
        diff |= vfmt.fmt.pix.bytesperline != sfmt.stride;
        diff |= vfmt.fmt.pix.sizeimage != sfmt.stride * sfmt.height;
    }

    return diff;
}

// add 2021.02.16 asno
static int create_buf_userptr(struct v4l2_device *dev, struct v4l2_simple_format sfmt, int count, struct v4l2_video_buffer_group *bg, void *udmabuf_ptr)
{
        struct v4l2_requestbuffers req = {0};
        req.count = count;
        req.type = bg->buf_type;
        req.memory = bg->mem_type;
        int ret = ioctl(dev->fd, VIDIOC_REQBUFS, &req);
        if(ret < 0){
            /*WriteLogEx(logFileId, 0, LOG_ERR, 
                "%s: %s: VIDIOC_REQBUFS failed: %s (%d)", __FUNCTION__, dev->devname, strerror(errno), errno ); 
            */return -1;
        }
        //WriteLogEx(logFileId, 0, LOG_DEBUG, "VIDIOC_REQBUFS OK");

        struct v4l2_create_buffers cbuf = {0};
        cbuf.count = count;
        cbuf.memory = bg->mem_type;
        cbuf.format = gen_v4l2_format(bg->buf_type, sfmt);

        for(int i = 0; i < count; ++i){
            int id = i + bg->bufs_num;
            struct v4l2_video_buffer *buf = &bg->bufs[id];
            buf->id = id;
            buf->format = cbuf.format;
            buf->vbuf.index = id;
            buf->vbuf.type = bg->buf_type;
            buf->vbuf.memory = bg->mem_type;

            if(buf->vbuf.memory = V4L2_MEMORY_USERPTR){
                if (V4L2_TYPE_IS_MULTIPLANAR(bg->buf_type)) {
                    buf->vbuf.m.planes = &buf->vplane[0];
                    buf->vbuf.length = V4L2OPS_MULTI_PLANE_NUM;
                }
                ret = ioctl(dev->fd, VIDIOC_QUERYBUF, &buf->vbuf);

                if(ret < 0){
                    /*WriteLogEx(logFileId, 0, LOG_ERR, 
                        "%s: %s: VIDIOC_QUERYBUFS failed: %s (%d)", __FUNCTION__, dev->devname, strerror(errno), errno ); 
                    */return -1;
                }
                //WriteLogEx(logFileId, 0, LOG_DEBUG, "VIDIOC_QUERYBUFS OK");
            }

            size_t length;
            off_t offset;
            if (V4L2_TYPE_IS_MULTIPLANAR(bg->buf_type)) {
                length = buf->vbuf.m.planes[0].length;
                offset = buf->vbuf.m.planes[0].m.mem_offset;
                buf->vbuf.m.planes[0].m.userptr = (unsigned long)udmabuf_ptr + offset;
            } else {
                length = buf->vbuf.length;
                offset = buf->vbuf.m.offset;
            }

            buf->start = udmabuf_ptr + offset;
            buf->length = length;
        }
    bg->bufs_num += cbuf.count;
    return cbuf.count;
}

static int create_buf(struct v4l2_device *dev, struct v4l2_simple_format sfmt, int count, struct v4l2_video_buffer_group *bg)
{
    struct v4l2_create_buffers cbuf = {0};
    struct v4l2_exportbuffer ebuf = {0};

    unsigned int i;
    int ret;

    cbuf.count = count;
    cbuf.memory = bg->mem_type;
    cbuf.format = gen_v4l2_format(bg->buf_type, sfmt);

    ret = ioctl(dev->fd, VIDIOC_CREATE_BUFS, &cbuf);
    if(ret != 0) {
        printf("%s: %s: VIDIOC_CREATE_BUFS failed: %s (%d)\n", __FUNCTION__, dev->devname, strerror(errno), errno);
        //WriteLogEx(logFileId, 0, LOG_ERR, "%s: %s: VIDIOC_CREATE_BUFS failed: %s (%d)", __FUNCTION__, dev->devname, strerror(errno), errno ); 
        return 0;
    }
    
    for (i = 0; i < cbuf.count; ++i) {
        int id = i + bg->bufs_num;
        struct v4l2_video_buffer *buf = &bg->bufs[id];
        
        buf->id = id;
        buf->format = cbuf.format;
        buf->vbuf.index = id;
        buf->vbuf.type = bg->buf_type;
        buf->vbuf.memory = bg->mem_type;
        
        if (buf->vbuf.memory == V4L2_MEMORY_MMAP) {
            /* mmap */
            if (V4L2_TYPE_IS_MULTIPLANAR(bg->buf_type)) {
                buf->vbuf.m.planes = &buf->vplane[0];
                buf->vbuf.length = V4L2OPS_MULTI_PLANE_NUM;
            }
            
            ret = ioctl(dev->fd, VIDIOC_QUERYBUF, &buf->vbuf);
            if(ret != 0) {
                printf("%s: %s: VIDIOC_QUERYBUF failed: %s (%d)\n", __FUNCTION__, dev->devname, strerror(errno), errno);
                //WriteLogEx(logFileId, 0, LOG_ERR, "%s: %s: VIDIOC_QUERYBUF failed: %s (%d)", __FUNCTION__, dev->devname, strerror(errno), errno); 
                return 0;
            }
            
            size_t length;
            off_t offset; 
            if (V4L2_TYPE_IS_MULTIPLANAR(bg->buf_type)) {
                length = buf->vbuf.m.planes[0].length;
                offset = buf->vbuf.m.planes[0].m.mem_offset;
            } else {
                length = buf->vbuf.length;
                offset = buf->vbuf.m.offset;
            }

            buf->start = mmap(NULL, length, PROT_READ | PROT_WRITE, MAP_SHARED, dev->fd, offset);
            if (buf->start == MAP_FAILED)
                printf("%s: %s: mmap() failed: %s (%d)\n", __FUNCTION__, dev->devname, strerror(errno), errno);
                //WriteLogEx(logFileId, 0, LOG_ERR, "%s: %s: mmap() failed: %s (%d)", __FUNCTION__, dev->devname, strerror(errno), errno); 

            buf->length = length;
            
            /* DMABUF fd export */
            ebuf.type = bg->buf_type;
            ebuf.plane = 0;
            ebuf.index = id;
            ret = ioctl(dev->fd, VIDIOC_EXPBUF, &ebuf);
            if (ret != 0)
                printf("%s: %s: VIDIOC_EXPBUF failed: %s (%d)\n", __FUNCTION__, dev->devname, strerror(errno), errno);
                //WriteLogEx(logFileId, 0, LOG_ERR, "%s: %s: VIDIOC_EXPBUF failed: %s (%d)", __FUNCTION__, dev->devname, strerror(errno), errno); 
            
            buf->dmabuf_fd = ebuf.fd;
            
            /* _DPRINT("%s: Buffer %d mapped at %p, len=%08X, ofs=0x%08X, dmabuf_fd %d\n", __FUNCTION__, buf->id, buf->start, buf->length, offset, buf->dmabuf_fd); */
        }
    }
    
    bg->bufs_num += cbuf.count;

    return cbuf.count;
}

/* ---------------------------------------------------------------------------
 * video capture/output device
 */

int v4l2_open(struct v4l2_video_device *vdev, char *devname, enum v4l2_device_type dev_type, enum v4l2_memory mem_type)
{
    struct v4l2_capability vcapa = {0};
    uint32_t capa;
    enum v4l2_buf_type buf_type;
    int ret;
    int fd;

    /*
     * open 
     */
    fd = open(devname, O_RDWR);
    if (fd < 0) {
        printf("%s: %s: failed to open: %s (%d)\n", __FUNCTION__, devname, strerror(errno), errno);
        //WriteLogEx(logFileId, 0, LOG_ERR, "%s: %s: failed to open: %s (%d)", __FUNCTION__, devname, strerror(errno), errno); 
        return 0;
    }
    
    /*
     * cneck device capability 
     */
    ret = ioctl(fd, VIDIOC_QUERYCAP, &vcapa);
    if(ret != 0) {
        printf("%s: %s: VIDIOC_QUERYCAP failed: %s (%d)\n", __FUNCTION__, devname, strerror(errno), errno);
        //WriteLogEx(logFileId, 0, LOG_ERR, "%s: %s: VIDIOC_QUERYCAP failed: %s (%d)", __FUNCTION__, devname, strerror(errno), errno); 
        close(fd);
        return 0;
    }
    
    if (vcapa.capabilities & V4L2_CAP_DEVICE_CAPS)
        capa = vcapa.device_caps; /* capabilities of the opened device */
    else
        capa = vcapa.capabilities; /* capabilities of the physical devic */
    
    /* find buf type */
    if (dev_type == v4l2_dev_capture) {
        if (capa & V4L2_CAP_VIDEO_CAPTURE) {
            buf_type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        } else if (capa & V4L2_CAP_VIDEO_CAPTURE_MPLANE) {
            buf_type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
        } else {
            printf("%s: %s: not support VIDEO_CAPTURE or VIDEO_CAPTURE_MPLANE\n", __FUNCTION__, devname);
            close(fd);
            return 0;
        }
    } else /*if (dev_type == v4l2_dev_outpuy)*/ {
        if (capa & V4L2_CAP_VIDEO_OUTPUT) {
            buf_type = V4L2_BUF_TYPE_VIDEO_OUTPUT;
        } else if (capa & V4L2_CAP_VIDEO_OUTPUT_MPLANE) {
            buf_type = V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE;
        } else {
            printf("%s: %s: not support V4L2_CAP_VIDEO_OUTPUT or V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE\n", __FUNCTION__, devname);
            //WriteLogEx(logFileId, 0, LOG_ERR,"%s: %s: not support V4L2_CAP_VIDEO_OUTPUT or V4L2_BUF_TYPE_VIDEO_OUTPUT_MPLANE", __FUNCTION__, devname); 
            close(fd);
            return 0;
        }
    }
    
    pthread_mutex_init(&vdev->mutex, NULL);
    
    vdev->dev.devname = devname;
    vdev->dev.fd = fd;
    vdev->dev_type = dev_type;
    vdev->bufgrp.mem_type = mem_type;
    vdev->bufgrp.buf_type = buf_type;
    vdev->extbuf_start_idx = -1;

    printf("open video device %s, fd=%d, %s, %s, info %s:%s:%s, ver 0x%08X\n", vdev->dev.devname, vdev->dev.fd, string_buf_type(buf_type), string_mem_type(mem_type), vcapa.driver, vcapa.card, vcapa.bus_info, vcapa.version);
    /*WriteLogEx(logFileId, 0, LOG_INFO, "open video device %s, fd=%d, %s, %s, info %s:%s:%s, ver 0x%08X", 
            vdev->dev.devname, vdev->dev.fd, string_buf_type(buf_type), string_mem_type(mem_type), 
            vcapa.driver, vcapa.card, vcapa.bus_info, vcapa.version);
*/
    return 1;
}

void v4l2_close(struct v4l2_video_device *vdev)
{
    close(vdev->dev.fd);
    vdev->dev.fd = -1;
    return;
}

int v4l2_set_format(struct v4l2_video_device *vdev, struct v4l2_simple_format sfmt)
{
    struct v4l2_format vfmt = gen_v4l2_format(vdev->bufgrp.buf_type, sfmt);
    int ret;
    
    ret = ioctl(vdev->dev.fd, VIDIOC_S_FMT, &vfmt);
    if(ret != 0) {
        printf("%s: %s: VIDIOC_S_FMT failed: %s (%d)\n", __FUNCTION__, vdev->dev.devname, strerror(errno), errno);
        //WriteLogEx(logFileId, 0, LOG_ERR,"%s: %s: VIDIOC_S_FMT failed: %s (%d)", __FUNCTION__, vdev->dev.devname, strerror(errno), errno);
        return 0;
    }
    
    ret = ioctl(vdev->dev.fd, VIDIOC_G_FMT, &vfmt);
    if(ret != 0) {
        printf("%s: %s: VIDIOC_G_FMT failed: %s (%d)\n", __FUNCTION__, vdev->dev.devname, strerror(errno), errno);
        //WriteLogEx(logFileId, 0, LOG_ERR, "%s: %s: VIDIOC_G_FMT failed: %s (%d)", __FUNCTION__, vdev->dev.devname, strerror(errno), errno);
        return 0;
    }
    
    if (diff_format(vdev->bufgrp.buf_type, sfmt, vfmt)) {
        printf("%s: %s: unmatch actual format\n", __FUNCTION__, vdev->dev.devname);
        //WriteLogEx(logFileId, 0, LOG_ERR, "%s: %s: unmatch actual format", __FUNCTION__, vdev->dev.devname);
    }
    
    vdev->format = vfmt;

    return 1;
}

int v4l2_create_bufs(struct v4l2_video_device *vdev, struct v4l2_simple_format sfmt, int count, void* udma_ptr)
{
    int cnt = 0;
    if(udma_ptr != NULL){
        cnt = create_buf_userptr(&vdev->dev, sfmt, count, &vdev->bufgrp, udma_ptr);
    }else{
        cnt = create_buf(&vdev->dev, sfmt, count, &vdev->bufgrp);
    }
    printf("%s: %s: %u buffers allocated (total %d buffers)\n", __FUNCTION__, vdev->dev.devname, cnt, vdev->bufgrp.bufs_num);
    /*WriteLogEx(logFileId, 0, LOG_INFO, "%s: %s: %u buffers allocated (total %d buffers)", 
            __FUNCTION__, vdev->dev.devname, cnt, vdev->bufgrp.bufs_num);
    */return (cnt == 0) ? 0: 1;
}

int v4l2_create_extbufs(struct v4l2_video_device *vdev, struct v4l2_simple_format sfmt, int count)
{
    if (vdev->bufgrp.buf_type != V4L2_MEMORY_MMAP)
        return 0;
    
    if (vdev->extbuf_start_idx == -1)
        vdev->extbuf_start_idx = vdev->bufgrp.bufs_num;
    
    int cnt = create_buf(&vdev->dev, sfmt, count, &vdev->bufgrp);
    printf("%s: %s: %u buffers allocated (total %d buffers)\n", __FUNCTION__, vdev->dev.devname, cnt, vdev->bufgrp.bufs_num);
    //WriteLogEx(logFileId, 0, LOG_INFO, "%s: %s: %u buffers allocated (total %d buffers)", __FUNCTION__, vdev->dev.devname, cnt, vdev->bufgrp.bufs_num);
    return (cnt == 0) ? 0: 1;
}

struct v4l2_video_buffer *v4l2_get_buf_id(struct v4l2_video_device *vdev, int id)
{
    return seach_buf_id(id, &vdev->bufgrp);
}

int v4l2_destroy_bufs(struct v4l2_video_device *vdev)
{
    int i;
    int ret;
    
    for (i = 0; i < vdev->bufgrp.bufs_num; ++i) {

        if (vdev->bufgrp.mem_type == V4L2_MEMORY_MMAP) {
            
            close(vdev->bufgrp.bufs[i].dmabuf_fd);
            
            ret = munmap(vdev->bufgrp.bufs[i].start, vdev->bufgrp.bufs[i].length);
            if (ret != 0)
                printf("%s: %s: munmap() failed: id=%d, %s (%d)\n", __FUNCTION__, vdev->dev.devname, i, strerror(errno), errno);
                /*WriteLogEx(logFileId, 0, LOG_INFO, "%s: %s: munmap() failed: id=%d, %s (%d)", 
                        __FUNCTION__, vdev->dev.devname, i, strerror(errno), errno);
*/
            vdev->bufgrp.bufs[i].length = 0;
        }
    }
    
    return 1;
}

int v4l2_stream_on(struct v4l2_video_device *vdev)
{
    int buf_type = vdev->bufgrp.buf_type;
    int ret;

    
    printf("%s: %s: \n", __FUNCTION__, vdev->dev.devname);
    //WriteLogEx(logFileId, 0, LOG_INFO, "%s: %s:", __FUNCTION__, vdev->dev.devname);
    
    pthread_mutex_lock(&vdev->mutex);
    ret = ioctl(vdev->dev.fd, VIDIOC_STREAMON, &buf_type);
    pthread_mutex_unlock(&vdev->mutex);
    if (ret != 0) {
        printf("%s: %s: VIDIOC_STREAMON failed: %s (%d)\n", __FUNCTION__, vdev->dev.devname, strerror(errno), errno);
        //WriteLogEx(logFileId, 0, LOG_ERR, "%s: %s: VIDIOC_STREAMON failed: %s (%d)", __FUNCTION__, vdev->dev.devname, strerror(errno), errno);
        return 0;
    }
    
    return 1;
}

int v4l2_stream_off(struct v4l2_video_device *vdev)
{
    int buf_type = vdev->bufgrp.buf_type;
    int ret;
    
    
    printf("%s: %s: \n", __FUNCTION__, vdev->dev.devname);
    //WriteLogEx(logFileId, 0, LOG_INFO, "%s: %s:", __FUNCTION__, vdev->dev.devname);

    pthread_mutex_lock(&vdev->mutex);
    ret = ioctl(vdev->dev.fd, VIDIOC_STREAMOFF, &buf_type);
    pthread_mutex_unlock(&vdev->mutex);
    if (ret != 0) {
        printf("%s: %s: VIDIOC_STREAMOFF failed: %s (%d)\n", __FUNCTION__, vdev->dev.devname, strerror(errno), errno);
        //WriteLogEx(logFileId, 0, LOG_ERR, "%s: %s: VIDIOC_STREAMOFF failed: %s (%d)", __FUNCTION__, vdev->dev.devname, strerror(errno), errno);
        return 0;
    }
    
    vdev->bufgrp.qbuf_num = 0;
    
    return 0;
}

int v4l2_qbuf_all(struct v4l2_video_device *vdev)
{
    int ret;
    int i;
    
    pthread_mutex_lock(&vdev->mutex);
    
    int max = vdev->extbuf_start_idx >= 0 ? vdev->extbuf_start_idx: vdev->bufgrp.bufs_num;
    
    for (i = 0; i < max; i++) {
        if (vdev->bufgrp.bufs[i].queing == 0) {
            ret = qbuf(&vdev->dev, &vdev->bufgrp.bufs[i], vdev->bufgrp.buf_type);
            if (ret == 0)
                break;
            vdev->bufgrp.qbuf_num++;
        }
    }
    
    pthread_mutex_unlock(&vdev->mutex);
    
    return ret;
}

int v4l2_qbuf(struct v4l2_video_device *vdev, struct v4l2_video_buffer *buf)
{
    int ret;
    
    pthread_mutex_lock(&vdev->mutex);
    
    if (vdev->bufgrp.bufs_num <= vdev->bufgrp.qbuf_num) {
        //printf("%s: %s: over que. nbufs=%d, qbuf_num=%d, id=%d, buse=0x%X,  len=0x%X \n",
        //    __FUNCTION__, vdev->dev.devname, vdev->bufgrp.bufs_num, vdev->bufgrp.qbuf_num, buf->id, buf->bytesused, buf->length);
        pthread_mutex_unlock(&vdev->mutex);
        return 0;
    }

    ret = qbuf(&vdev->dev, buf, vdev->bufgrp.buf_type);
    if (ret)
        vdev->bufgrp.qbuf_num++;

    pthread_mutex_unlock(&vdev->mutex);
    
    return ret;
}

int v4l2_qbuf_id(struct v4l2_video_device *vdev, int id)
{ 
    struct v4l2_video_buffer *buf = seach_buf_id(id, &vdev->bufgrp);
    
    if (buf != NULL)
        return v4l2_qbuf(vdev, buf);
    else
        return 0; /* not fond */
}

struct v4l2_video_buffer *v4l2_dqbuf(struct v4l2_video_device *vdev)
{
    struct v4l2_buffer vbuf = {0};
    struct v4l2_plane vpln = {0};
    vbuf.m.planes = &vpln;

    int ret;
    int i;
    
    pthread_mutex_lock(&vdev->mutex);
    
    if(vdev->bufgrp.qbuf_num == 0) {
        pthread_mutex_unlock(&vdev->mutex);
        return NULL;
    }
    
    vbuf.type = vdev->bufgrp.buf_type;
    vbuf.memory = vdev->bufgrp.mem_type;
    vbuf.length = vdev->format.fmt.pix_mp.num_planes;

    ret = ioctl(vdev->dev.fd, VIDIOC_DQBUF, &vbuf);
    if (ret != 0){
        if(errno == 11) {
            pthread_mutex_unlock(&vdev->mutex);
            return NULL;
        } else {
            printf("%s: %s: VIDIOC_DQBUF failed: vbuf %d: %s (%d)\n", __FUNCTION__, vdev->dev.devname, vbuf.index, strerror(errno), errno);
            //WriteLogEx(logFileId, 0, LOG_ERR,"%s: %s: VIDIOC_DQBUF failed: vbuf %d: %s (%d)", __FUNCTION__, vdev->dev.devname, vbuf.index, strerror(errno), errno);
        }
    }
    
    /* search from bufs[] */
    struct v4l2_video_buffer *buf = NULL;
    for (i = 0; i < vdev->bufgrp.bufs_num; i++) {
        if (vdev->bufgrp.bufs[i].vbuf.index == vbuf.index) {
            buf = &vdev->bufgrp.bufs[i];
            break;
        }
    }
    
    if (buf == NULL) {
        pthread_mutex_unlock(&vdev->mutex);
        return NULL;
    }
    
    buf->queing = 0;
    vdev->bufgrp.qbuf_num--;
    
    if (vdev->bufgrp.buf_type == V4L2_BUF_TYPE_VIDEO_CAPTURE)
        buf->bytesused = vbuf.bytesused;
    else if (vdev->bufgrp.buf_type == V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE)
        buf->bytesused = vbuf.m.planes[0].bytesused;
    
    /* _DPRINT("%s: %s: D-QBUF idx=%d, buse=0x%X\n", __FUNCTION__, vdev->dev.devname, vbuf.index, buf->bytesused); */
    
    pthread_mutex_unlock(&vdev->mutex);
    
    return buf;
}
