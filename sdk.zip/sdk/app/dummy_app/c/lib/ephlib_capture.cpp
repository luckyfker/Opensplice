#include "ephlib_job.h"

#include <chrono>
#include <exception>

// Dummy data
static const std::string deviceId = "DS010";
static const std::string cameraId = "001AX";
static const std::string requestDate = "20210827";
static const std::string priceReductionId = "001";

EPHLIB_CaptureImageJob::EPHLIB_CaptureImageJob(int domainId, const char * topicName, unsigned int intervalSec) :
    domainId(domainId), topicName(topicName),
    intervalMilis(intervalSec * 1000), seqNumber(0) {
    // Create data reader
    CMStatus status = SetDataWriterLibUseQoSFile(domainId,
        (char *)topicName, (char *)"Image_Take_Topic::Data",
        TYPELIB_PATH,
        QOS_POLICY_URI,
        &this->dataWriter,
        NULL
    );

    if (status != CMSuccess) {
        std::cerr << "Create Data Writer failed" << std::endl;
    }

    // Open camera
    camera = std::unique_ptr<cv::VideoCapture>(new cv::VideoCapture(0));
    if (!camera->isOpened()) {
        // Warning only
    }

    // Initialize for reading data
    this->lastCaptureTime = getCurrentTime();
}

EPHLIB_CaptureImageJob::~EPHLIB_CaptureImageJob() {
    // Release camera
    camera = nullptr;

    // Shutdown Data Reader, don't handle when error when shutdown
    if (!this->dataWriter) {
        ShutdownDataWriter(domainId, this->dataWriter, NULL);
        this->dataWriter = NULL;
    }

}

void EPHLIB_CaptureImageJob::run() {
    long long now = getCurrentTime();
    if (now - lastCaptureTime >= intervalMilis) {
        lastCaptureTime = now;

        // Capture image
        std::vector<uchar> buffer;
        if (captureImage(buffer)) {
            publishImage((const char*)&buffer[0], buffer.size());
        }
    }
}

bool EPHLIB_CaptureImageJob::captureImage(std::vector<uchar>& buffer) {
    // Try to open camera again
    if (!camera->isOpened() && !camera->open(0)) {
        std::cerr << "Cannot capture image." << std::endl;
        return false;
    }

    // capture the next frame from the webcam
    cv::Mat frame;
    if (!camera->grab() || !camera->retrieve(frame) || frame.empty()) {
        std::cerr << "Cannot capture image." << std::endl;
        return false;
    }

    // Successful capturing image
    return convertToJPEG(frame, buffer);
}

bool EPHLIB_CaptureImageJob::convertToJPEG(cv::Mat& frame, std::vector<uchar>& buffer) {
    std::vector<int> param(2);

    param[0] = cv::IMWRITE_JPEG_QUALITY;
    param[1] = 100; //jpeg�̕i���@�ō��F100�@�Œ�F0
    return cv::imencode(".jpg", frame, buffer, param);
}

void EPHLIB_CaptureImageJob::publishImage(const char* data, int length) {
    // Allocate memory
    Image_Take_Topic_Data* pubData = allocPublishData(length);
    if (!pubData) {
        std::cerr << "Write data failed" << std::endl;

        return;
    }
    pubData->request_SeqNo = seqNumber;
    seqNumber++;

    // Fill value
    memcpy(pubData->request_DeviceId, deviceId.c_str(), deviceId.length());
    memcpy(pubData->request_CameraId, cameraId.c_str(), cameraId.length());
    memcpy(pubData->request_Date._buffer, requestDate.c_str(), requestDate.length());
    memcpy(pubData->PricereductionCut_cutImage._buffer, data, length);
    memcpy(pubData->Pricereduction_DeviceId, priceReductionId.c_str(), priceReductionId.length());

    // Send data
    CMStatus status = WritePublishData(domainId, dataWriter, pubData, NULL);
    DDS_free(pubData);
    if (status != CMSuccess) {
        std::cerr << "Writer data failed" << std::endl;
    }
}

long long EPHLIB_CaptureImageJob::getCurrentTime() {
    auto start = std::chrono::system_clock::now();
    std::chrono::milliseconds ms = std::chrono::duration_cast<std::chrono::milliseconds>(start.time_since_epoch());
    return ms.count();
}

Image_Take_Topic_Data* EPHLIB_CaptureImageJob::allocPublishData(int length) {
    Image_Take_Topic_Data * pubData = Image_Take_Topic_Data__alloc();
    if (!pubData) {
        return pubData;
    }

    // Allocate with the dummy data
    pubData->request_DeviceId = DDS_string_alloc(deviceId.length());
    pubData->request_CameraId = DDS_string_alloc(cameraId.length());
    pubData->request_Date._buffer = DDS_sequence_char_allocbuf(requestDate.length());
    pubData->request_Date._length = requestDate.length();
    pubData->request_Date._maximum = requestDate.length();
    pubData->PricereductionCut_cutImage._buffer = DDS_sequence_char_allocbuf(length);
    pubData->PricereductionCut_cutImage._length = length;
    pubData->PricereductionCut_cutImage._maximum = length;
    pubData->Pricereduction_DeviceId = DDS_string_alloc(priceReductionId.length());

    return pubData;
}
