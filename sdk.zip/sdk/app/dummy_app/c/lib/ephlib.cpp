#include "ephlib.h"
#include "ephlib_job.h"
#include "worker_thread.h"

static int g_domainID = 0;
static std::unique_ptr<WorkerThread> workerThread;

static void startThreadIfNot() {
    if (!workerThread) {
        workerThread = std::unique_ptr<WorkerThread>(new WorkerThread());
        workerThread->start();
    }
}

// Subscribe
CMULONG SaveCapturedImage(const char* topicName, const char* folderPath) {
    if (!topicName || !folderPath || !(*topicName) || !(*folderPath)) {
        std::cerr << "Create job failed" << std::endl;

        return NULL;
    }

    startThreadIfNot();

    SetParticipant(g_domainID);
    auto job = std::make_shared<EPHLIB_SaveImageJob>(g_domainID, topicName, folderPath);
    workerThread->submitPeriodicJob(job);
    return (CMULONG)job.get();
}

CMULONG GetImageRecognizeResult(const char* requestTopicName, const char* responseTopicName, const char * filePath, RecognitionCallback callback) {
    if (!requestTopicName || !responseTopicName || !(*requestTopicName) || !(*responseTopicName) || !filePath || !(*filePath)) {
        std::cerr << "Create job failed." << std::endl;

        return NULL;
    }

    if (!callback) {
        std::cerr << "Create job failed.\n";

        return NULL;
    }

    startThreadIfNot();

    SetParticipant(g_domainID);
    auto job = std::make_shared<EPHLIB_GetImageRecognizeResultJob>(g_domainID, requestTopicName, responseTopicName, filePath, callback);
    workerThread->submitPeriodicJob(job);
    return (CMULONG)job.get();
}

CMULONG RecognizeImage(const char* requestTopic, const char* answerTopic, const ImageOption* options) {
    if (!options) {
        std::cerr <<  "Creat job failed" << std::endl;

        return NULL;
    }

    if (!requestTopic || !answerTopic || !(*requestTopic) || !(*answerTopic)) {
        std::cerr << "Create job failed" << std::endl;

        return NULL;
    }

    startThreadIfNot();

    SetParticipant(g_domainID);
    auto job = std::make_shared<EPHLIB_RecognizeImageJob>(g_domainID, requestTopic, answerTopic, options);
    workerThread->submitPeriodicJob(job);
    return (CMULONG)job.get();
}

CMULONG CaptureImage(const char * topicName) {
    if (!topicName || !(*topicName)) {
        std::cerr << "Create job failed." << std::endl;

        return NULL;
    }

    startThreadIfNot();

    SetParticipant(g_domainID);
    auto job = std::make_shared<EPHLIB_CaptureImageJob>(g_domainID, topicName, 10);
    workerThread->submitPeriodicJob(job);
    return (CMULONG)job.get();
}

void WaitAllJob() {
    if (!workerThread) {
        return;
    }

    workerThread->join();
}

void StopJob(CMULONG jobId) {
    if (!workerThread) {
        return;
    }
    workerThread->removePeriodicJob((const Job*)jobId);
}

void ShutdownAllJob() {
    if (!workerThread) {
        return;
    }
    workerThread->stopAndWait();
    // Do nothing when participant could not shutdown
    ShutdownParticipant(g_domainID, NULL);
    workerThread = nullptr;
}


