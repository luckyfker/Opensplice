#include "main.h"

int cap_img();

int camera_init();
