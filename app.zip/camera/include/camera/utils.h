/*
 * Utilities
 *
 * Copyright (c) 2019 Regulus co.,ltd. All rights reserved.
 * This is proprietary software.
 */
#ifndef _UTILS_H_
#define _UTILS_H_

#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>

/* ----------------------------------------------------------------------------
 * Define
 */
 
#define ZEROFILL(x)	memset (&(x), 0, sizeof (x))

#define ARRAY_SIZE(a)	((int)((sizeof(a) / sizeof(a[0]))))

#define STRUCT_PTR_CLEAR(sptr)			\
	do {								\
		typeof(*sptr) s_zero = {0};		\
		*sptr = s_zero;					\
	} while(0)

#define max(a, b)	(((a) > (b)) ? (a) : (b))
#define min(a, b)	(((a) < (b)) ? (a) : (b))

#define ABORT(condition, ...)											\
		do {															\
			if (condition) {											\
				int errno_save = errno;									\
				fprintf(stderr, "Abort at %s:%d: ", __FILE__, __LINE__);\
				errno = errno_save;										\
				fprintf(stderr,  __VA_ARGS__);							\
				abort();												\
			}															\
		} while(0)

#define BIT_FLAG(x)	(1<<x)

/* Debug */

#ifdef DEBUG
#define _DPRINT printf
#else
#define _DPRINT 1 ? (void) 0 : printf
#endif

/* ----------------------------------------------------------------------------
 * API
 */

int streq(const char *str0,const char *str1);

int printerr(const char* format, ...);

#endif /* _UTILS_H_ */
