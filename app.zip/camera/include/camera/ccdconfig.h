/***************************************************************************
 *	Copyright (C) 2013
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/
/************************************************************************//**
 * @file	ccdconfig.h
 * @brief	Image Sensor関連API
 * @details
 *
 *
 * @author	SSハ周ス 宮越 秀彦<<hidehiko_miyakoshi@toshibatec.co.jp>>
 *
 ****************************************************************************/
#ifndef _CcdConfig_H
#define _CcdConfig_H

#include "AbsoluteDefinition.h"


#include        <stdio.h>
#include        <stdint.h>
#include        <unistd.h>
#include        <fcntl.h>
#include        <string.h>
#include        <sys/types.h>

static inline uint32_t regs_read32(void* addr)
{
    volatile uint32_t* regs_addr = (uint32_t*)(addr);
    return *regs_addr;
}

static inline uint16_t regs_read16(void* addr)
{
    volatile uint16_t* regs_addr = (uint16_t*)(addr);
    return *regs_addr;
}

static inline uint8_t  regs_read8(void* addr)
{
    volatile uint8_t*  regs_addr = (uint8_t* )(addr);
    return *regs_addr;
}

static inline void regs_write32(void* addr, uint32_t data)
{
    volatile uint32_t* regs_addr = (uint32_t*)(addr);
    *regs_addr = data;
}

static inline void regs_write16(void* addr, uint16_t data)
{
    volatile uint16_t* regs_addr = (uint16_t*)(addr);
    *regs_addr = data;
}

static inline void regs_write8(void* addr, uint8_t data)
{
    volatile uint8_t*  regs_addr = (uint8_t* )(addr);
    *regs_addr = data;
}


/*
#define  MM2S_DMACR      (0x0000)
#define  MM2S_DMASR      (0x0004)
#define  MM2S_SA         (0x0018)
#define  MM2S_SA_MSB     (0x001c)
#define  MM2S_LENGTH     (0x0028)

static inline void dma_mm2s_reset(void* regs)
{
    regs_write32(regs + MM2S_DMACR, DMA_CR_RESET);
    while( regs_read32(regs + MM2S_DMACR) & DMA_CR_RESET );
}
*/

/* === E2V Register === */
///* 30fps
#define roi1_t_int_ll_1_30fps			0x00	//露光時間
#define roi1_t_int_ll_2_30fps			0x08	//露光時間
//*/
#ifdef ENABLE_60FPS
///* 60fps(24MHz)
#define roi1_t_int_ll_1_60fps			0x00	//露光時間
#define roi1_t_int_ll_2_60fps			0x0E	//露光時間
//*/
#endif
///* 30fps(AddOn)
#define roi1_t_int_ll_1_30fps_1			0x00	//露光時間
#define roi1_t_int_ll_2_30fps_1			0x0A	//露光時間
//*/
#ifdef ENABLE_60FPS
///* 60fps(24MHz) (AddOn)
#define roi1_t_int_ll_1_60fps_1			0x00	//露光時間
#define roi1_t_int_ll_2_60fps_1			0x0E	//露光時間
//*/
#endif
#define roi1_ana_gain					0x0		//アナログゲイン x1
// #define roi1_ana_gain				0x1		//アナログゲイン x1.5
//#define roi1_ana_gain					0x2		//アナログゲイン x2
// #define roi1_ana_gain				0x4		//アナログゲイン x4
//#define roi1_ana_gain					0x5		//アナログゲイン x6
//#define roi1_ana_gain					0x6		//アナログゲイン x8
#define roi1_ana_gain_1					0x2		//アナログゲイン x2 (AddOn)
#define roi1_dig_gain					0x00	//デジタルゲイン x1
#define roi1_dig_gain_1					0x00	//デジタルゲイン x1 (AddOn)

//携帯モード用
///* 30fps
#define roi1_t_int_ll_1_for_mobile_30fps	0x01	//露光時間(携帯モード用)
#define roi1_t_int_ll_2_for_mobile_30fps	0x00	//露光時間(携帯モード用)
//*/
#ifdef ENABLE_60FPS
///* 60fps(24MHz)
#define roi1_t_int_ll_1_for_mobile_60fps	0x01	//露光時間(携帯モード用)
#define roi1_t_int_ll_2_for_mobile_60fps	0x6E	//露光時間(携帯モード用)
//*/
#endif

#define roi1_ana_gain_for_mobile			0x05	//アナログゲイン x6
#define roi1_dig_gain_for_mobile			0x00	//デジタルゲイン x1

///* 30fps(AddOn)
#define roi1_t_int_ll_1_for_mobile_30fps_1	0x01	//露光時間(携帯モード用)
#define roi1_t_int_ll_2_for_mobile_30fps_1	0x00	//露光時間(携帯モード用)
//*/
#ifdef ENABLE_60FPS
///* 60fps(24MHz) (AddOn)
#define roi1_t_int_ll_1_for_mobile_60fps_1	0x01	//露光時間(携帯モード用)
#define roi1_t_int_ll_2_for_mobile_60fps_1	0x6E	//露光時間(携帯モード用)
//*/
#endif

#define roi1_ana_gain_for_mobile_1			0x05	//アナログゲイン x6 (AddOn)
#define roi1_dig_gain_for_mobile_1			0x00	//デジタルゲイン x1 (AddOn)

/************************************************************************//**
 * @brief Image Sensor動作モード
 * @details
 *
 ****************************************************************************/
typedef enum _CcdMode {
	CcdMode_NormalScan_33fps,		//!< 通常読み取りモード
#ifdef ENABLE_60FPS
	CcdMode_NormalScan_60fps,		//!< 通常読み取りモード
#endif
	CcdMode_MobileScan_33fps,		//!< 携帯読み取りモード
#ifdef ENABLE_60FPS
	CcdMode_MobileScan_60fps,		//!< 携帯読み取りモード
#endif

	CcdMode_ReadData,		//!< �ݒ�f�[�^�ǂݏo�� (����ݒ�)

	CcdMode_Num				//<! Image Sensor動作モード数
} CcdMode;

/*************************************************************************//**
 * @brief 現在のImage Sensor動作モードを取得する
 * @details
 *
 * @return Image Sensor動作モード
 ****************************************************************************/
CcdMode CcdConfig_getCcdMode();

/*************************************************************************//**
 * @brief Image Sensor動作モードを設定する
 * @details
 *
 * @param [in] p_Mode Image Sensor動作モード
 ****************************************************************************/
void CcdConfig_setCcdMode(CcdMode p_Mode);

/*************************************************************************//**
 * @brief Image Sensor動作モードを更新する
 * @details
 *	現在の動作モードに応じて、Image Sensor動作モードを更新する
 ****************************************************************************/
void CcdConfig_updateCcdMode();

/*************************************************************************//**
 * @brief Image Sensor動作モードを直ちに設定する
 * @details
 *
 * @param [in] p_Mode Image Sensor動作モード
 ****************************************************************************/
void CcdConfig_setCcdModeDirectly(CcdMode p_Mode);

/*************************************************************************//**
 * @brief Image Sensorの電源を投入し、動作モードを直ちに設定する
 * @details
 *
 * @param [in] p_Mode Image Sensor動作モード
 ****************************************************************************/
void CcdConfig_setCcdModeDirectlyWithPowerOn(CcdMode p_Mode);

/*************************************************************************//**
 * @brief Image Sensorの設定データを読み出す
 * @details
 *
 * @param [in] id カメラID(0:Main, 1:AddOn)
 ****************************************************************************/
void ReadCcdConfigData(int id);

/*************************************************************************//**
 * @brief Image 画像入力をベイヤーに切り換える
 * @details
 *
 ****************************************************************************/
void Set_Bayer();

/*************************************************************************//**
 * @brief Image 画像入力をモノクロに切り換える
 * @details
 *
 ****************************************************************************/
void Reset_Bayer();

/*************************************************************************//**
 * @brief 入力画像の設定
 * @details
 *
 ****************************************************************************/
int Init_ImageSelect();

/*************************************************************************//**
 * @brief 画像・カメラ設定
 * @details
 *
 ****************************************************************************/
void Init_ImageSet();

/*************************************************************************//**
 * @brief トリガーモード用のタイマー設定#include        <stdio.h>
#include        <stdint.h>
#include        <unistd.h>
#include        <fcntl.h>
#include        <string.h>
#include        <sys/types.h>

static inline uint32_t regs_read32(void* addr)
{
    volatile uint32_t* regs_addr = (uint32_t*)(addr);
    return *regs_addr;
}

static inline uint16_t regs_read16(void* addr)
{
    volatile uint16_t* regs_addr = (uint16_t*)(addr);
    return *regs_addr;
}

static inline uint8_t  regs_read8(void* addr)
{
    volatile uint8_t*  regs_addr = (uint8_t* )(addr);
    return *regs_addr;
}

static inline void regs_write32(void* addr, uint32_t data)
{
    volatile uint32_t* regs_addr = (uint32_t*)(addr);
    *regs_addr = data;
}

static inline void regs_write16(void* addr, uint16_t data)
{
    volatile uint16_t* regs_addr = (uint16_t*)(addr);
    *regs_addr = data;
}

static inline void regs_write8(void* addr, uint8_t data)
{
    volatile uint8_t*  regs_addr = (uint8_t* )(addr);
    *regs_addr = data;
}



#define  MM2S_DMACR      (0x0000)
#define  MM2S_DMASR      (0x0004)
#define  MM2S_SA         (0x0018)
#define  MM2S_SA_MSB     (0x001c)
#define  MM2S_LENGTH     (0x0028)

#define  S2MM_DMACR      (0x0030)
#define  S2MM_DMASR      (0x0034)
#define  S2MM_DA         (0x0048)
#define  S2MM_DA_MSB     (0x004c)
#define  S2MM_LENGTH     (0x0058)

#define  DMA_CR_RS     (1u<<0)
#define  DMA_CR_RESET  (1u<<2)
#define  DMA_CR_IOC_IrqEn  (1u<<12)
#define  DMA_CR_ERR_IrqEn  (1u<<14)

#define  DMA_SR_HALTED (1u<<0)
#define  DMA_SR_IDLE   (1u<<1)
#define  DMA_SR_IOC_Irq    (1u<<12)
#define  DMA_SR_ERR_Irq    (1u<<14)

#define SPEAKER_AMP_RESET_N (35)
#define MIO_EMIO_OFFSET (54)


static inline void dma_mm2s_reset(void* regs)
{
    regs_write32(regs + MM2S_DMACR, DMA_CR_RESET);
    while( regs_read32(regs + MM2S_DMACR) & DMA_CR_RESET );
}
static inline void dma_s2mm_reset(void* regs)
{
    regs_write32(regs + S2MM_DMACR, DMA_CR_RESET);
    while( regs_read32(regs + S2MM_DMACR) & DMA_CR_RESET );
}
static inline void dma_mm2s_setup(void* regs, unsigned long buf_addr)
{
    regs_write32(regs + MM2S_DMACR , DMA_CR_RS | DMA_CR_IOC_IrqEn | DMA_CR_ERR_IrqEn);
    regs_write32(regs + MM2S_DMASR , DMA_SR_IOC_Irq | DMA_SR_ERR_Irq);
    regs_write32(regs + MM2S_SA    , buf_addr);
    regs_write32(regs + MM2S_SA_MSB, buf_addr >> 32);
}

static inline void dma_s2mm_setup(void* regs, unsigned long buf_addr)
{
    regs_write32(regs + S2MM_DMACR , DMA_CR_RS | DMA_CR_IOC_IrqEn | DMA_CR_ERR_IrqEn);
    regs_write32(regs + S2MM_DMASR , DMA_SR_IOC_Irq | DMA_SR_ERR_Irq);
    regs_write32(regs + S2MM_DA    , buf_addr);
    regs_write32(regs + S2MM_DA_MSB, buf_addr >> 32);
}

static inline void dma_mm2s_start(void* regs, unsigned int xfer_size)
{
    regs_write32(regs + MM2S_LENGTH, xfer_size);
}

static inline void dma_s2mm_start(void* regs, unsigned int xfer_size)
{
    regs_write32(regs + S2MM_LENGTH, xfer_size);
}

static inline void dma_mm2s_clear_status(void* regs)
{
    regs_write32(regs + MM2S_DMASR, DMA_SR_IOC_Irq | DMA_SR_ERR_Irq);
}

static inline void dma_s2mm_clear_status(void* regs)
{
    regs_write32(regs + S2MM_DMASR, DMA_SR_IOC_Irq | DMA_SR_ERR_Irq);
}

static inline void dma_reset(void* regs)
{
    dma_mm2s_reset(regs);
    dma_s2mm_reset(regs);
}

static inline void dma_setup(void* regs, unsigned long src_addr, unsigned long dst_addr)
{
    dma_s2mm_setup(regs, dst_addr);
    dma_mm2s_setup(regs, src_addr);
}

static inline void dma_start(void* regs, unsigned int xfer_size)
{
    dma_s2mm_start(regs, xfer_size);
    dma_mm2s_start(regs, xfer_size);
}

static inline void dma_clear_status(void* regs)
{
    dma_s2mm_clear_status(regs);
    dma_mm2s_clear_status(regs);
}

struct udmabuf {
    char           name[128];
    int            file;
    unsigned char* buf;
    unsigned int   buf_size;
    unsigned long  phys_addr;
    unsigned long  debug_vma;
    unsigned long  sync_mode;
};
 * @details
 *
 ****************************************************************************/
int Init_Trigger();

int Init_LEDFlash();

/*************************************************************************//**
 * @brief Gainの設定（ホワイトバランス設定用）
 * @details
 *
 ****************************************************************************/
void spi_set_gain(int id, unsigned char red, unsigned char green, unsigned char blue);

/*************************************************************************//**
 * @brief Image Sensor ゲイン更新
 * @details
 *
 ****************************************************************************/
void Ccd_Update_Roop_Gain();

/*************************************************************************//**
 * @brief Image Sensor ゲイン更新(2度読み中)
 * @details
 *
 ****************************************************************************/
void Ccd_Update_FrameNg();

#ifdef USE_APO_BY_IMAGE

/*************************************************************************//**
 * @brief Image Sensor ゲイン更新(指定値)
 * @details
 *
 * @param [in] gain 設定するゲイン(1,2,4,8)
 ****************************************************************************/
void Ccd_Update_Gain_SetValue(int gain);

/*************************************************************************//**
 * @brief Image Sensor ゲイン設定値確認
 * @details
 *
 * @return ゲイン値
 ****************************************************************************/
u32 Ccd_Update_Gain_GetValue();

/*************************************************************************//**
 * @brief Image Sensor 露光時間更新(指定値)
 * @details
 *
 * @param [in] exp 設定する露光時間設定値(直接入力値)
 ****************************************************************************/
void Ccd_Update_Exp_SetValue(unsigned short exp);

/*************************************************************************//**
 * @brief Image Sensor カメラパラメーターリセット
 * @details
 *
 ****************************************************************************/
void Ccd_Reset();

#endif

#endif // _CcdConfig_H

