////////////////////////////////////////////////////////////////////////////
//	Copyright (C) 2020
//	TOSHIBA TEC CORPORATION All Right Reserved
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//  FILE		:	macros.h
//	DESCRIPTION	:	This file contain all macros definition
//	
//
//	CREATE ON	:	V001.000	Yashas D G[TSIP]				2020.06.18
//
//	MODIFIED ON	:	
////////////////////////////////////////////////////////////////////////////
/***************************************************************************
 *	Macro Definition
****************************************************************************/

#ifndef INCLUDE_MACROS_H_
#define INCLUDE_MACROS_H_

#define DEFAULT_MODE 0 //Default transfer Mode - Int_Mode
#define INT_MODE 1 //Interrupt mode 
#define BULK_MODE 2 //Bulk Mode

#define USB_MAX_PROC 10			//Maximum supported application

#define USB_HW_DISCONNECTED 0   // Hardware disconnected status
#define USB_HW_CONNECTED 1		// Hardware Connected status

#define DEFAULT_APL_MODE 0 //Default Application mode - OPOSCHK_APL_MODE
#define OPOSCHK_APL_MODE 1 // OPOSCHK Application mode
#define DISPLAY_APL_MODE 2 // Display Application mode
#define FW_UPDATE_APL_MODE 3 //Firmware Update Application mode

#define TX_EVENT 0 //TX Event flag
#define RX_EVENT 1 // RX Event Flag

#define MAX_INTERFACE 2  // Two Interface selection
#define INTERFACE0 0   // Interface 0 selection
#define INTERFACE1 1   // Interface 1 selection

#define USB_BUFFER_SIZE 131072 // Maximum usb buffer size
#define USB_MAX_INT_SIZE 200 //Interrupt transfer Maximum number of bytes
#define USB_MAX_BULK_SIZE 200000 //Bulk transfer Maximum number of bytes

#define GET_MAX_SIZE(var) ((var == BULK_MODE)? USB_MAX_BULK_SIZE : USB_MAX_INT_SIZE ) //Get maximum size based on the mode

#endif /* INCLUDE_MACROS_H_ */