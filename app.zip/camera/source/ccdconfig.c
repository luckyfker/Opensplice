/***************************************************************************
 *	Copyright (C) 2010
 *	TOSHIBA TEC CORPORATION All Right Reserved
 *	570 Ohito,Izunokuni-shi,Shizuoka-ken
****************************************************************************/

/***********************************************************************//**
 *  \file 		ccdconfig.c
 *	\brief 		CCD初期設定�?��?
 *
 *	@date		2010.01.20	新規作�??
 *	@author		Naitou@toshibatec.co.jp
****************************************************************************/
#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <linux/spi/spidev.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <sys/mman.h>

#include "AbsoluteDefinition.h"
#include "ccdconfig.h"
#include "LightApi.h"
#include "OperatingModeApi.h"
#include "xil_types.h"
#include "main.h"
#include "utils.h"


#define DEBUG                          /*本RDソ連絡のバグ修正201015tsuchiya*/
#define SPI_DEVICE_NAME_A "/dev/spidev2.0"
#define SPI_DEVICE_NAME_B "/dev/spidev2.0"
#define SPI_SPEED_HZ    1000000
#define SPI_DELAY_USECS 1
#define SPI_BITS        8
#define WAIT_TIME_AFTER_POWERON (100*1000)

/* === E2V Register === */
///* 30fps
#define line_length_1_30fps				0x00
#define line_length_2_30fps				0xA0
#define	clk_adc_on_ctrl_domain_30fps	0x0
#define	clk_on_adc_domain_30fps			0x3
#define	clk_on_chain_domain_30fps		0x3
#define	div_clk_ctrl_30fps				0x2
#define	div_clk_chain_30fps				0x1
#define t_flame_period_1_30fps			0x00
#define t_flame_period_2_30fps			0x00
#define t_flash_del_on_30fps			0x00	//delay_on
#define	pll_n_30fps						0x3
#define	pll_fb_30fps					0x4B   //114MHz
#define t_wait_1_30fps					0x00
#define t_wait_2_30fps					0x0B
//*/

/*
#define LINE_LENGTH_1_30FPS                    0x00
#define LINE_LENGTH_2_30FPS                    0xA0
#define CLK_ADC_ON_CTRL_DOMAIN_30FPS           0x0
#define CLK_ON_ADC_DOMAIN_30FPS                0x3
#define CLK_ON_CHAIN_DOMAIN_30FPS              0x3
#define DIV_CLK_CTRL_30FPS                     0x2
#define DIV_CLK_CHAIN_30FPS                    0x1
#define T_FRAME_PERIOD_1_30FPS                 0x00
#define T_FRAME_PERIOD_2_30FPS                 0x00
#define T_FLASH_DEL_ON_30FPS                   0x00
#define PLL_N_30FPS                            0x3
#define PLL_FB_30FPS                           0x4B            //114MHz

#define CAMERA1_EXP_0_30FPS                            0x00
#define CAMERA1_EXP_1_30FPS                            0x0B
*/

#define range_coeff			0x5A	//0x00:default  range_coeff
#define color_en			0x1		//0?��B&W  1?��Color					// 白�?/カラー�?替
#define roi_flip_v			0x1
#define roi_flip_h			0x1
//#define roi_flip_h			0x0    //左右反転tsuchiya200722
#define pattern_type		0x0		//0:RAW
#define roi_ddc_en			0x0		//Defect correction enable		0:Disable	1:Enable
#define range_en			0x0		//10bit�?8bit					0:Disable	1:Enable
#define trig_pad_sel		0x1		//トリガーモー�?
#define rsroi_flash_mode	0x1		//フラ�?シュON
#define roi_video_en		0x0		//トリガーモー�?
#define roi_overlap_en		0x0		//トリガーモー�?
#define trig_rqst			0x0		//トリガーモー�?


#define	gb_dig_gain			0x8B//0x76
#define	gr_dig_gain			0x8B//0x76
#define	bb_dig_gain			0xC8//0x7A
#define	rr_dig_gain			0x8B//0x8C

///* 30fps(AddOn)
#define line_length_1_30fps_1			0x00
#define line_length_2_30fps_1			0xA0
#define	clk_adc_on_ctrl_domain_30fps_1	0x0
#define	clk_on_adc_domain_30fps_1		0x3
#define	clk_on_chain_domain_30fps_1		0x3
#define	div_clk_ctrl_30fps_1			0x2
#define	div_clk_chain_30fps_1			0x1
#define t_flame_period_1_30fps_1		0x05
#define t_flame_period_2_30fps_1		0x45
#define t_flash_del_on_30fps_1			0x00	//delay_on
#define	pll_n_30fps_1					0x3
#define	pll_fb_30fps_1					0x4B
#define t_wait_1_30fps_1				0x00
#define t_wait_2_30fps_1				0x00
//*/


#define range_coeff_1		0x5A	//0x00:default  range_coeff
#define color_en_1			0x0		//0?��B&W  1?��Color					// 白�?/カラー�?替
#define roi_flip_v_1		0x1
#define roi_flip_h_1		0x0
#define pattern_type_1		0x0		//0:RAW
#define roi_ddc_en_1		0x0		//Defect correction enable		0:Disable	1:Enable
#define range_en_1			0x0		//10bit�?8bit					0:Disable	1:Enable
#define trig_pad_sel_1		0x1		//トリガーモー�?
#define rsroi_flash_mode_1	0x1		//フラ�?シュON
#define roi_video_en_1		0x0		//トリガーモー�?
#define roi_overlap_en_1	0x0		//トリガーモー�?
#define trig_rqst_1			0x0		//トリガーモー�?

#define	gb_dig_gain_1		0x80
#define	gr_dig_gain_1		0x80
#define	bb_dig_gain_1		0x80
#define	rr_dig_gain_1		0x80

#define	roi1_h_1_1			0x4		//画像サイズ垂直方�? SXGA 1024
#define	roi1_h_1_2			0x00	//画像サイズ垂直方�? SXGA 1024
#define	roi1_w_1_1			0x5		//画像サイズ水平方�? SXGA 1280
#define	roi1_w_1_2			0x00	//画像サイズ水平方�? SXGA 1280

static unsigned char mobile_gain[2][4] = {	//携帯モードで用�?るゲイン
		{0x0, 0x2, 0x3, 0x5},				// (x1,x2,x3,x6)
		{0x0, 0x2, 0x3, 0x5}				// (x1,x2,x3,x6) (AddOn)
};
static unsigned char m_roop_gain = 0;

//e2v[]のGainの�?ータ位置
#define offset_ana_gain		13*3+1
#define offset_rr_dig_gain	24*3+2
#define offset_gb_dig_gain	23*3+1
#define offset_gr_dig_gain	23*3+2
#define offset_bb_dig_gain	24*3+1

/* e2v CMOS SENSOR Config */
static uint8_t e2v_30fps[] =
{
		0x84,(0x80 | line_length_1_30fps),(0x00 | line_length_2_30fps),
		0x88,(0xC0 | clk_adc_on_ctrl_domain_30fps << 4 | clk_on_adc_domain_30fps << 2 | clk_on_chain_domain_30fps),
			(0x00 | div_clk_ctrl_30fps << 4 | div_clk_chain_30fps << 0),
		0x8C,(0x00 | t_flame_period_1_30fps),(0x00 | t_flame_period_2_30fps),
		0x85,0x00,(0x00 | t_flash_del_on_30fps),
		0x86,0xD0,(0x00 | range_coeff),
		0x87,(0x0A | color_en << 2),(0x01 | roi_flip_h << 7 | roi_flip_v <<6 | pattern_type << 4),
		0x89,(0x60 | pll_n_30fps),(0x00 | pll_fb_30fps),
		0x8A,0x02,(0xC0 | roi_ddc_en << 5 |range_en << 4),
		0x8B,(0x00 | trig_pad_sel),
			(0x00 | rsroi_flash_mode << 6 | roi_video_en << 3 | roi_overlap_en << 2 | trig_rqst << 1),
		0x8D,(0x00 | t_wait_1_30fps),(0x00 | t_wait_2_30fps),
		0x8E,(0x00 | roi1_t_int_ll_1_30fps << 0),(0x00	| roi1_t_int_ll_2_30fps << 0),
		0x8F,0x00,0x00,
		0x90,0x00,0x00,
		0x91,(0x00 | roi1_ana_gain),(0x00 | roi1_dig_gain),
		0x92,0x00,0x06,
		0x93,(0x00 | roi1_h_1_1),(0x00 | roi1_h_1_2),
		0x94,0x00,0x06,
		0x95,(0x00 | roi1_w_1_1),(0x00 | roi1_w_1_2),
		0x96,0x00,0x00,
		0x97,0x00,0x00,
		0x98,0x00,0x00,
		0x99,0x00,0x00,
		0x9A,0x00,0x00,
		0xB6,(0x00 | gb_dig_gain),(0x00 | gr_dig_gain),
		0xB7,(0x00 | bb_dig_gain),(0x00 | rr_dig_gain),
		0xC1,0x97,0x30,		//Temporal Row Noise Reduction
		0xC4,0x00,0x00,       //DATA_CLK always active except in STANDBY state
};

//(AddOn)
static uint8_t e2v_30fps_1[] =
{
		0x84,(0x80 | line_length_1_30fps_1),(0x00 | line_length_2_30fps_1),
		0x88,(0xC0 | clk_adc_on_ctrl_domain_30fps_1 << 4 | clk_on_adc_domain_30fps_1 << 2 | clk_on_chain_domain_30fps_1),
			(0x00 | div_clk_ctrl_30fps_1 << 4 | div_clk_chain_30fps_1 << 0),
		0x8C,(0x00 | t_flame_period_1_30fps_1),(0x00 | t_flame_period_2_30fps_1),
		0x85,0x00,(0x00 | t_flash_del_on_30fps_1),
		0x86,0xD0,(0x00 | range_coeff_1),
		0x87,(0x0A | color_en_1 << 2),(0x01 | roi_flip_h_1 << 7 | roi_flip_v_1 <<6 | pattern_type_1 << 4),
		0x89,(0x60 | pll_n_30fps_1),(0x00 | pll_fb_30fps_1),
		0x8A,0x02,(0xC0 | roi_ddc_en_1 << 5 |range_en_1 << 4),
		0x8B,(0x00 | trig_pad_sel_1),
			(0x00 | rsroi_flash_mode_1 << 6 | roi_video_en_1 << 3 | roi_overlap_en_1 << 2 | trig_rqst_1 << 1),
		0x8D,(0x00 | t_wait_1_30fps_1),(0x00 | t_wait_2_30fps_1),
		0x8E,(0x00 | roi1_t_int_ll_1_30fps_1 << 0),(0x00	| roi1_t_int_ll_2_30fps_1 << 0),
		0x8F,0x00,0x00,
		0x90,0x00,0x00,
		0x91,(0x00 | roi1_ana_gain_1),(0x00 | roi1_dig_gain_1),
		0x92,0x00,0x06,
		0x93,(0x00 | roi1_h_1_1),(0x00 | roi1_h_1_2),
		0x94,0x00,0x06,
		0x95,(0x00 | roi1_w_1_1),(0x00 | roi1_w_1_2),
		0x96,0x00,0x00,
		0x97,0x00,0x00,
		0x98,0x00,0x00,
		0x99,0x00,0x00,
		0x9A,0x00,0x00,
		0xB6,(0x00 | gb_dig_gain_1),(0x00 | gr_dig_gain_1),
		0xB7,(0x00 | bb_dig_gain_1),(0x00 | rr_dig_gain_1),
		0xC1,0x97,0x30,		//Temporal Row Noise Reduction
		0xC4,0x00,0x00,       //DATA_CLK always active except in STANDBY state
		};

/* e2v CMOS SENSOR Config (携帯モード用)*/
static uint8_t e2v_for_mobile_30fps[] =
{
		0x84,(0x80 | line_length_1_30fps),(0x00 | line_length_2_30fps),
		0x88,(0xC0 | clk_adc_on_ctrl_domain_30fps << 4 | clk_on_adc_domain_30fps << 2 | clk_on_chain_domain_30fps),
			(0x00 | div_clk_ctrl_30fps << 4 | div_clk_chain_30fps << 0),
		0x8C,(0x00 | t_flame_period_1_30fps),(0x00 | t_flame_period_2_30fps),
		0x85,0x00,(0x00 | t_flash_del_on_30fps),
		0x86,0xD0,(0x00 | range_coeff),
		0x87,(0x0A | color_en << 2),(0x01 | roi_flip_h << 7 | roi_flip_v <<6 | pattern_type << 4),
		0x89,(0x60 | pll_n_30fps),(0x00 | pll_fb_30fps),
		0x8A,0x02,(0xC0 | roi_ddc_en << 5 |range_en << 4),
		0x8B,(0x00 | trig_pad_sel),
			(0x00 | rsroi_flash_mode << 6 | roi_video_en << 3 | roi_overlap_en << 2 | trig_rqst << 1),
		0x8D,(0x00 | t_wait_1_30fps),(0x00 | t_wait_2_30fps),
		0x8E,(0x00 | roi1_t_int_ll_1_for_mobile_30fps << 0),(0x00	| roi1_t_int_ll_2_for_mobile_30fps << 0),
		0x8F,0x00,0x00,
		0x90,0x00,0x00,
		0x91,(0x00 | roi1_ana_gain_for_mobile),(0x00 | roi1_dig_gain_for_mobile),
		0x92,0x00,0x06,
		0x93,(0x00 | roi1_h_1_1),(0x00 | roi1_h_1_2),
		0x94,0x00,0x06,
		0x95,(0x00 | roi1_w_1_1),(0x00 | roi1_w_1_2),
		0x96,0x00,0x00,
		0x97,0x00,0x00,
		0x98,0x00,0x00,
		0x99,0x00,0x00,
		0x9A,0x00,0x00,
		0xB6,(0x00 | gb_dig_gain),(0x00 | gr_dig_gain),
		0xB7,(0x00 | bb_dig_gain),(0x00 | rr_dig_gain),
		0xC1,0x97,0x30,		//Temporal Row Noise Reduction
		0xC4,0x00,0x00,       //DATA_CLK always active except in STANDBY state
};

//(AddOn)
static uint8_t e2v_for_mobile_30fps_1[] =
{
		0x84,(0x80 | line_length_1_30fps_1),(0x00 | line_length_2_30fps_1),
		0x88,(0xC0 | clk_adc_on_ctrl_domain_30fps_1 << 4 | clk_on_adc_domain_30fps_1 << 2 | clk_on_chain_domain_30fps_1),
			(0x00 | div_clk_ctrl_30fps_1 << 4 | div_clk_chain_30fps_1 << 0),
		0x8C,(0x00 | t_flame_period_1_30fps_1),(0x00 | t_flame_period_2_30fps_1),
		0x85,0x00,(0x00 | t_flash_del_on_30fps_1),
		0x86,0xD0,(0x00 | range_coeff_1),
		0x87,(0x0A | color_en_1 << 2),(0x01 | roi_flip_h_1 << 7 | roi_flip_v_1 <<6 | pattern_type_1 << 4),
		0x89,(0x60 | pll_n_30fps_1),(0x00 | pll_fb_30fps_1),
		0x8A,0x02,(0xC0 | roi_ddc_en_1 << 5 |range_en_1 << 4),
		0x8B,(0x00 | trig_pad_sel_1),
			(0x00 | rsroi_flash_mode_1 << 6 | roi_video_en_1 << 3 | roi_overlap_en_1 << 2 | trig_rqst_1 << 1),
		0x8D,(0x00 | t_wait_1_30fps_1),(0x00 | t_wait_2_30fps_1),
		0x8E,(0x00 | roi1_t_int_ll_1_for_mobile_30fps_1 << 0),(0x00	| roi1_t_int_ll_2_for_mobile_30fps_1 << 0),
		0x8F,0x00,0x00,
		0x90,0x00,0x00,
		0x91,(0x00 | roi1_ana_gain_for_mobile_1),(0x00 | roi1_dig_gain_for_mobile_1),
		0x92,0x00,0x06,
		0x93,(0x00 | roi1_h_1_1),(0x00 | roi1_h_1_2),
		0x94,0x00,0x06,
		0x95,(0x00 | roi1_w_1_1),(0x00 | roi1_w_1_2),
		0x96,0x00,0x00,
		0x97,0x00,0x00,
		0x98,0x00,0x00,
		0x99,0x00,0x00,
		0x9A,0x00,0x00,
		0xB6,(0x00 | gb_dig_gain_1),(0x00 | gr_dig_gain_1),
		0xB7,(0x00 | bb_dig_gain_1),(0x00 | rr_dig_gain_1),
		0xC1,0x97,0x30,		//Temporal Row Noise Reduction
		0xC4,0x00,0x00,       //DATA_CLK always active except in STANDBY state
};

/* e2v CMOS SENSOR Config (Read) */
static uint8_t e2v_read[] =
{
		0x04,0x00,0x00,
		0x05,0x00,0x00,
		0x06,0x00,0x00,
		0x07,0x00,0x00,
		0x08,0x00,0x00,
		0x09,0x00,0x00,
		0x0A,0x00,0x00,
		0x0B,0x00,0x00,
		0x0C,0x00,0x00,
		0x0D,0x00,0x00,
		0x0E,0x00,0x00,
		0x0F,0x00,0x00,
		0x10,0x00,0x00,
		0x11,0x00,0x00,
		0x12,0x00,0x00,
		0x13,0x00,0x00,
		0x14,0x00,0x00,
		0x15,0x00,0x00,
		0x16,0x00,0x00,
		0x17,0x00,0x00,
		0x18,0x00,0x00,
		0x19,0x00,0x00,
		0x1A,0x00,0x00,
		0x1B,0x00,0x00,
		0x1C,0x00,0x00,
		0x1D,0x00,0x00,
		0x1E,0x00,0x00,
		0x1F,0x00,0x00,
		0x20,0x00,0x00,
		0x21,0x00,0x00,
		0x22,0x00,0x00,
		0x23,0x00,0x00,
		0x24,0x00,0x00,
		0x25,0x00,0x00,
		0x26,0x00,0x00,
		0x27,0x00,0x00,
		0x28,0x00,0x00,
		0x29,0x00,0x00,
		0x2A,0x00,0x00,
		0x2B,0x00,0x00,
		0x2C,0x00,0x00,
		0x2D,0x00,0x00,
		0x2E,0x00,0x00,
		0x2F,0x00,0x00,
		0x30,0x00,0x00,
		0x31,0x00,0x00,
		0x32,0x00,0x00,
		0x33,0x00,0x00,
		0x34,0x00,0x00,
		0x35,0x00,0x00,
		0x36,0x00,0x00,
		0x37,0x00,0x00,
		0x38,0x00,0x00,
		0x39,0x00,0x00,
		0x3A,0x00,0x00,
		0x3B,0x00,0x00,
		0x3C,0x00,0x00,
		0x3D,0x00,0x00,
		0x3E,0x00,0x00,
		0x3F,0x00,0x00,
		0x40,0x00,0x00,
		0x41,0x00,0x00,
		0x42,0x00,0x00,
		0x43,0x00,0x00,
		0x44,0x00,0x00,
		0x45,0x00,0x00,
		0x46,0x00,0x00,
		0x47,0x00,0x00,
		0x48,0x00,0x00,
		0x49,0x00,0x00,
		0x4A,0x00,0x00,
		0x4B,0x00,0x00,
		0x4C,0x00,0x00,
		0x4D,0x00,0x00,
		0x4E,0x00,0x00,
		0x4F,0x00,0x00,
		0x50,0x00,0x00,
		0x51,0x00,0x00,
		0x52,0x00,0x00,
		0x53,0x00,0x00,
		0x54,0x00,0x00,
		0x55,0x00,0x00,
		0x56,0x00,0x00,
		0x57,0x00,0x00,
		0x58,0x00,0x00,
		0x59,0x00,0x00,
		0x5A,0x00,0x00,
		0x5B,0x00,0x00,
		0x64,0x00,0x00,
		0x7A,0x00,0x00,
		0x7F,0x00,0x00,
};


static unsigned char e2v_gain[] = {				//ホワイトバランス調整用�?ーブル
		0xb6,0x00,0x00,
		0xb7,0x00,0x00
};

typedef struct _CcdConfigData {
	uint8_t* m_data;
	size_t m_Size;
} CcdConfigData;

static CcdConfigData m_CcdConfigData[2][CcdMode_Num] =
{
	{
			{e2v_30fps, sizeof(e2v_30fps)},
			{e2v_for_mobile_30fps, sizeof(e2v_for_mobile_30fps)},
	},
	{
			{e2v_30fps_1, sizeof(e2v_30fps_1)},
			{e2v_for_mobile_30fps_1, sizeof(e2v_for_mobile_30fps_1)},
	}
};

static CcdMode m_CurrentState_A = CcdMode_NormalScan_33fps;
static CcdMode m_NextState_A = CcdMode_NormalScan_33fps;
static CcdMode m_CurrentState_B = CcdMode_NormalScan_33fps;
static CcdMode m_NextState_B = CcdMode_NormalScan_33fps;

/*************************************************************************//**
 * @brief Image Sensorに�?ータを送信する
 * @details
 *
 * @param [in] id カメラID(0:Main, 1:AddOn)
 * @param [in] senddata 送信�?ータ格納�?�域先�?�へのポインタ
 * @param [in] totalsize 送信サイズ [Bytes]
 ****************************************************************************/
static int spicmd(int id, unsigned char* senddata, int totalsize)
{
    /* int cnt; */
    int cnt,ret;                        /*本RDソ連絡のバグ修正201015tsuchiya*/
    int fd;

    uint8_t wlen = 32; // 効果な�?
     /*goto�?を使用する場合、その前に変数の初期化が終わって�?る�?要がある　下よ�?*/

	if(0 == id){
		fd = open(SPI_DEVICE_NAME_A, O_RDWR);
	}else if (1 == id){
		fd = open(SPI_DEVICE_NAME_B, O_RDWR);
	}else{
		perror("invalid id in spicmd function\n");
		/* return */
		return -1;              /*本RDソ連絡のバグ修正201015tsuchiya*/
	}
/*
    uint8_t tx[8];
    uint8_t rx[8] = {0,};
    struct spi_ioc_transfer tr[1];

    int trsize = 3;

    tr[0].tx_buf        = (__u64)tx;
    tr[0].rx_buf        = (__u64)rx;
    tr[0].len           = trsize;
    tr[0].delay_usecs   = SPI_DELAY_USECS;
    tr[0].speed_hz      = SPI_SPEED_HZ;
    tr[0].bits_per_word = 8;
    tr[0].cs_change     = 0;
	 memset(rx,0 , trsize);
*/
    uint8_t tx[8];
    uint8_t rx[8] = {0,};
    struct spi_ioc_transfer tr[1] = {0} ;
    int trsize = 3;
    tr[0].tx_buf        = (__u64)tx;
    tr[0].rx_buf        = (__u64)rx;
    tr[0].len           = trsize;
    tr[0].delay_usecs   = SPI_DELAY_USECS;
    tr[0].speed_hz      = SPI_SPEED_HZ;
    tr[0].bits_per_word = 8;
    tr[0].cs_change     = 0;
    tr[0].tx_nbits 		= 0;
    tr[0].rx_nbits 		= 0;
    memset(rx,0 , trsize);



    uint8_t mode = SPI_MODE_0; // 効果あ�?
/*    ioctl(fd, SPI_IOC_WR_MODE, &mode); */
    /*本RDソ連絡のバグ修正201015tsuchiya*/
    ret = ioctl(fd, SPI_IOC_WR_MODE, &mode);
    if(ret<0){
        perror("SPI_IOC_WR_MODE");
        goto end;
    }


/*    uint8_t wlen = 32; */ /* goto�?を使用する場合、その前に変数の初期化が終わって�?る�?要がある 上記に移�?*/ // 効果な�?
    ioctl(fd, SPI_IOC_WR_BITS_PER_WORD, &wlen);

    for(cnt=0;cnt <(totalsize/3);cnt++){
    	memset(rx,0 , trsize);

        tx[0] = senddata[cnt*3];
    	tx[1] = senddata[cnt*3+1];
    	tx[2] = senddata[cnt*3+2];

/*  	ioctl(fd, SPI_IOC_MESSAGE(1), tr); */     /*本RDソ連絡のバグ修正201015tsuchiya*/
        _DPRINT("set spi len=%d %dHz %dus bpw=%d cs_c=%d tx_nb=%d rx_nb=%d tx@%llx rx@%llx"
        ,tr[0].len,tr[0].speed_hz,tr[0].delay_usecs
        ,tr[0].bits_per_word,tr[0].cs_change
        ,tr[0].tx_nbits,tr[0].rx_nbits
        ,tr[0].tx_buf,tr[0].rx_buf);

    	_DPRINT("tx_data: %x %x %x",tx[0],tx[1],tx[2]);

    	ret = ioctl(fd, SPI_IOC_MESSAGE(1), tr);

    	if(ret<0){
            perror("SPI_IOC_MESSAGE");
            goto end;
    	}

    }
    /* close(fd); */    /*本RDソ連絡のバグ修正201015tsuchiya*/
    /* return 0; */    /*本RDソ連絡のバグ修正201015tsuchiya*/
end:
    if(fd>0)
    	close(fd);

    return ret;
}


/*************************************************************************//**
 * @brief �?定された動作モード用の設定データをImage Sensorに送信する
 * @details
 *
 * @param [in] p_Mode Image Sensor動作モー�?
 ****************************************************************************/
static void sendConfigData(int id, CcdMode p_Mode)
{
	CcdConfigData* l_configData;

	if(CcdMode_Num <= p_Mode){
		return;
	}
	l_configData = &m_CcdConfigData[id][p_Mode];

         /*本RDソ連絡のバグ修正201015tsuchiya*/
	_DPRINT("Write to SPIDEV with size of %d",l_configData->m_Size); 

	spicmd(id, l_configData->m_data, l_configData->m_Size);
}

/*************************************************************************//**
 * @brief 現在のImage Sensor動作モードを取得す�?
 * @details
 *
 * @return Image Sensor動作モー�?
 ****************************************************************************/
CcdMode CcdConfig_getCcdMode()
{
	return m_CurrentState_A;  //dummy
}


/*************************************************************************//**
 * @brief Image Sensor動作モードを設定す�?
 * @details
 *
 * @param [in] p_Mode Image Sensor動作モー�?
 ****************************************************************************/
void CcdConfig_setCcdMode(CcdMode p_Mode)
{
}

/*************************************************************************//**
 * @brief Image Sensor動作モードを更新する
 * @details
 *	現在の動作モードに応じて、Image Sensor動作モードを更新する
 ****************************************************************************/
void CcdConfig_updateCcdMode()
{

}

/*************************************************************************//**
 * @brief Image Sensor動作モードを直ちに設定す�?
 * @details
 *
 * @param [in] p_Mode Image Sensor動作モー�?
 ****************************************************************************/
void CcdConfig_setCcdModeDirectly(CcdMode p_Mode)
{
#ifndef CAMERA_STUB
	// do nothing
#else
	m_CurrentState = m_NextState = p_Mode;
	sendConfigData(p_Mode);
#endif
}

/* ---------------------------------------------------------------------------
 * GPIO driver
------------------------------------------------------------------------------ */
/* ---------------------------------------------------------------------------
 * GPIO driver
 */

static int gpio_export(int gpio)
{
	int fd;
	int len;
	int ret;
	char str[128];
	char dir[] = "out";

	/* export */
	snprintf(str, sizeof(str), "/sys/class/gpio/gpio%d", gpio);
	fd = open("/sys/class/gpio/export", O_WRONLY);
	if (fd < 0) {
		perror("gpio export open failed");
		return 0;
	}

	len = snprintf(str, sizeof(str), "%d", gpio);
	ret = write(fd, str, len);
	close(fd);
	if (ret != len) {
		perror("write to export failed");
		return 0;
	}

	/* set dir */
	len = snprintf(str, sizeof(str), "/sys/class/gpio/gpio%d/direction", gpio);
	fd = open(str, O_WRONLY);
	if (fd < 0) {
		perror("gpio dir open failed");
		return 0;
	}

	len = strlen(dir);
	ret = write(fd, dir, len);
	close(fd);
	if (ret != len) {
		printerr("write to direction failed\n");
		return 0;
	}

	return 1;
}

//static int gpio_unexport(int gpio)  //tsuchiya191222 test
static int gpio_unexport(int gpio)
{
	int fd;
	int len;
	int ret;
	char str[128];

	/* unexport */
	fd = open("/sys/class/gpio/unexport", O_WRONLY);
	if (fd < 0) {
		perror("gpio unexport open failed");
		return 0;
	}

	len = snprintf(str, sizeof(str), "%d", gpio);
	ret = write(fd, str, len);
	close(fd);
	if (ret != len) {
		printerr("write to unexport failed\n");
		return 0;
	}

	return 1;
}

static int gpio_set_value(int gpio, int value)
{
	int fd;
	int len;
	int ret;
	char str[128];

	/* value */
	len = snprintf(str, sizeof(str), "/sys/class/gpio/gpio%d/value", gpio);
	fd = open(str, O_WRONLY);
	if (fd < 0) {
		perror("gpio value open failed");
		printerr("%s %s\n", __FUNCTION__, str);
		return 0;
	}

	len = snprintf(str, sizeof(str), "%d", value);
	ret = write(fd, str, len);
	close(fd);
	if (ret != len) {
		printerr("write to value failed\n");
		return 0;
	}

	return 1;
}


/*************************************************************************//**
 * @brief Image Sensorの電源を投�?�する (PS側)
 * @details
 *
 ****************************************************************************/
static void turnOnPower()
{

}


/*************************************************************************//**
 * @brief Image Sensorの電源を投�?�し、動作モードを直ちに設定す�?
 * @details
 *
 * @param [in] p_Mode Image Sensor動作モー�?
 ****************************************************************************/
void CcdConfig_setCcdModeDirectlyWithPowerOn(CcdMode p_Mode)
{
	//カメラ電源�?�投�?�
        /*本RDソ連絡のバグ修正201015tsuchiya*/
    //    int sleep_t=1 ;
	//_DPRINT("power up sensor via GPIO");
	//turnOnPower();
	//usleep(WAIT_TIME_AFTER_POWERON);
	//_DPRINT("wait for sensor stabilize: %d second",sleep_t);
	//sleep(sleep_t);

	//CAMERAAのカメラを設定する�?
	//現在動作モードを更新する
	//_DPRINT("Launch SPI A configure");
	sendConfigData(0,p_Mode);
	//printf("sendConfigData(0,p_Mode) = %d\n",p_Mode);
	m_CurrentState_A = m_NextState_A = p_Mode;

	//CAMERABのカメラを設定する�?
	//現在動作モードを更新する
	//_DPRINT("Launch SPI B configure");
	//sendConfigData(1,p_Mode);
	//m_CurrentState_B = m_NextState_B = p_Mode;

}

/*************************************************************************//**
 * @brief Image Sensorの設定データを読み出�?
 * @details
 *
 * @param [in] id カメラID(0:Main, 1:AddOn)
 ****************************************************************************/
void ReadCcdConfigData(int id)
{
	CcdConfigData* l_configData = 0;
	l_configData->m_data = e2v_read;
	l_configData->m_Size = sizeof(e2v_read);

	spicmd(id, l_configData->m_data, l_configData->m_Size);
}

/*************************************************************************//**
 * @brief Image 画像�?�力をベイヤーに�?り換える
 * @details
 *
 ****************************************************************************/
void Set_Bayer()
{
/*
	IMG_SELECT0	= 0x20;							//メイン基板の入力画像�?�設�?(ベイヤー)
*/
}

/*************************************************************************//**
 * @brief Image 画像�?�力をモノクロに�?り換える
 * @details
 *
 ****************************************************************************/
void Reset_Bayer()
{
/*
	IMG_SELECT0	= 0x21;							//メイン基板の入力画像�?�設�?(モノクロ)
*/
}

/*************************************************************************//**
 * @brief Image 入力画像�?�設�?
 * @details
 *
 ****************************************************************************/
int Init_ImageSelect()
{
    printf("\nimageselect_init_start\n");
	int 			uio_fd;
	void*          regs;
	if ((uio_fd = open("/dev/uio3", O_RDWR)) == -1) {
		printf("Can not open /dev/uio3\n");
		return -1;
	}
	regs = mmap(NULL, 0x1000, PROT_READ|PROT_WRITE, MAP_SHARED, uio_fd, 0);

	//regs_write8(regs+0x0,0x0);    //reserved
	//regs_write8(regs+0x1,0x0);    //reserved
	//regs_write8(regs+0x2,0x0);    //reserved
	regs_write8(regs+0x3,0x0);    //video interface controller mode[3:0] and ImageProcessingColor mode[3:0]
	//regs_write8(regs+0x4,0x10);    //reserved(speaker amp volume)
	regs_write8(regs+0x5,0x0);    //CamInputColor Reg8
	regs_write8(regs+0x6,0x0);    //VideoInterfaceController VICREG[7:0]
	regs_write8(regs+0x7,0x0);    //caminputcolor reg8
	regs_write8(regs+0x8,0x84);    //invbina reg8
	regs_write8(regs+0x9,0x1);    //unshrmasfcolor reg8 addline reg8
	//regs_write8(regs+0xa,0x0);    //reserved
	regs_write8(regs+0xb,0x2);    //convtimopti reg8
	regs_write8(regs+0xc,0x21);    //mixing data reg0
	regs_write8(regs+0xd,0x43);    //mixing data reg1
	//regs_write8(regs+0xe,0x0);    //reserved
	// regs_write8(regs+0xf,0x0);    //reserved

	close(uio_fd);

	return 1;
}

/*************************************************************************//**
 * @brief 画像�?�カメラ設�?
 * @details
 *
 ****************************************************************************/
void Init_ImageSet()
{
/*
	Fpga_Gamma gamma_res;
	Fpga_Spi spi_res;

	gamma_res.WORD = 0;
	gamma_res.BIT.Sensor = 0;		// E2V
	gamma_res.BIT.Gamma = 0;		// IS-910の補正値
	gamma_res.BIT.Color = 0;		// GBスター�?
	gamma_res.BIT.CamLed = 0;		// Mainカメラ照明ON
	gamma_res.BIT.CamLed_1 = 0;		// AddOnカメラ照明ON
	GAMMA_SET = gamma_res.WORD;

	spi_res.WORD = FPGA_REGISTOR_0;
	spi_res.BIT.EmbData = 1;		// 画像埋め込み?��有
	spi_res.BIT.CamCtrl = 0;		// カメラコントローラーの出力：有
	FPGA_REGISTOR_0 = spi_res.WORD;
*/




}

/*************************************************************************//**
 * @brief LED照明設�?
 * @details
 *
 ****************************************************************************/
int Init_LEDFlash()
{
    printf("\nLED_init_start\n");
	int 			uio_fd;
	void*          regs;

	if ((uio_fd = open( "/dev/uio3" , O_RDWR)) == -1) {
        printf("Can not open /dev/uio3 \n");
        return -1;
    }
    regs = mmap(NULL, 0x1000, PROT_READ|PROT_WRITE, MAP_SHARED, uio_fd, 0);

    regs_write8(regs+4*4+0x0,0x02);    //reg8a
    //regs_write8(regs+4*4+0x1,0x10);    //reg8b
    regs_write8(regs+4*4+0x2,0x20);    //reg8c

    close(uio_fd);

	return 1;
}

/*************************************************************************//**
 * @brief トリガーモード用のタイマ�?�設�?
 * @details
 *
 ****************************************************************************/
int Init_Trigger()
{
    printf("\ntriger_init_start\n");
	//	volatile u32 *AxiTimer_TCSR0, *AxiTimer_TLR0;
	//	AxiTimer_TCSR0 = (u32 *)0x42800000;
	//	AxiTimer_TLR0 = (u32 *)0x42800004;

	// Axi_Timer設�?(トリガーモード用)
	//	*AxiTimer_TCSR0 = 0x00000496;
	//	*AxiTimer_TLR0 = 0x0012E1FA;

	int 			uio_fd;
	void*          regs;
	int 			uio_fd2;
	void*          regs2;
	unsigned char temp;

	if ((uio_fd = open( "/dev/uio0" , O_RDWR)) == -1) {
        printf("Can not open /dev/uio0 \n");
        return -1;
    }
    regs = mmap(NULL, 0x1000, PROT_READ|PROT_WRITE, MAP_SHARED, uio_fd, 0);

    regs_write32(regs+0x0,0x00000496);    ////	AxiTimer_TCSR0 = (u32 *)0x42800000;  	*AxiTimer_TCSR0 = 0x00000496;
    regs_write32(regs+0x4,0x0044aa1e);    ////	AxiTimer_TLR0 = (u32 *)0x42800004;  	*AxiTimer_TLR0 = 0x0044aa1e;

    close(uio_fd);

    if ((uio_fd2 = open("/dev/uio3", O_RDWR)) == -1) {
        printf("Can not open /dev/uio3\n");
        return -1;
    }
    regs2 = mmap(NULL, 0x1000, PROT_READ|PROT_WRITE, MAP_SHARED, uio_fd2, 0);

    temp = regs_read8(regs2+0x0) | (1 << 5);
    regs_write8(regs2+0x0, temp );    //Triggermode

    close(uio_fd2);

	return 1;

}

/*************************************************************************//**
 * @brief Image Gainの設定（�?�ワイトバランス設定用?�?
 * @details
 *
 ****************************************************************************/
void spi_set_gain(
		int id,
		unsigned char red,
		unsigned char green,
		unsigned char blue
)
{
	e2v_gain[1] = green;
	e2v_gain[2] = green;
	e2v_gain[4] = blue;
	e2v_gain[5] = red;

	spicmd(id, e2v_gain, sizeof(e2v_gain));
}

/*************************************************************************//**
 * @brief Image Sensor ゲイン更新
 * @details
 *
 ****************************************************************************/
void Ccd_Update_Roop_Gain()
{
	unsigned char data[3];

	m_roop_gain++;
	m_roop_gain %= 4;

	data[0] = 0x91;				// roi1_ana_gain
	data[1] = mobile_gain[0][m_roop_gain];
	data[2] = 0x00;
	spicmd(0, data, 3);

	data[0] = 0x91;				// roi1_ana_gain
	data[1] = mobile_gain[1][m_roop_gain];
	data[2] = 0x00;
	spicmd(1, data, 3);
}

/*************************************************************************//**
 * @brief Image Sensor ゲイン更新(2度読み中)
 * @details
 *
 ****************************************************************************/
void Ccd_Update_FrameNg()
{
}


