#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <poll.h>
#include <sys/mman.h>
#include "v4l2ops.h"
#include "Emulator.h"
#include "FPGA.h"
#include "ccdconfig.h"

#define  IMG_WIDTH    1280*4
#define  IMG_HEIGHT   1024
#define  UDMA_BUF_SZ  4*4*1280*1024
#define CAM_IMAGE_SIZE      1280*1024
//#define DEBUG//！！！！！！！！！！！！！！！！！！！！！！！！！！評価時はコメントアウト！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
//#define DEBUG2
#define DEBUG3//評価時コメントアウトを外す

//DDS用変数
#define CSV_PATH "IMAGE_SEND"
#define DATA_SIZE 1024*1280
#define FILE_PATH_BUFF 256
#define BILLION 1000000000LL
extern char* g_result;
char g_deviceId[10];
extern FILE *g_fp1,*g_fp2;

static unsigned long long current_timestamp(void);
unsigned long long g_time_stamp1,g_time_stamp2,g_time_stamp3,g_time_stamp4,g_time_stamp5;//タイムスタンプ保存用変数
extern	int fcnt_total;
extern unsigned char newframe;
extern int g_domainID;
extern char g_resize_width[10];
extern char g_resize_height[10];
extern char g_quality[10];
extern char g_background[10];
extern char g_sticker_size[10];
extern bool g_timeOutStatus;

int                     ufd;
void*                   udma_ptr;

struct v4l2_video_device vdev_cap = {0};
struct v4l2_simple_format sfmt = {0};

/***********************************************************************/
/**
 * @fn static int initV4L2(void)
 * @brief initialize application
 * @return int
/***********************************************************************/
static int initV4L2(char* devname_vcap, char* udma_dev)
{
    int ret = 0;

    if(udma_dev != NULL){
        ufd = open(udma_dev, O_RDWR, 0);
        if(ufd < 0){
            printf("UDMA Device Open failure !!!!!!!!!!! \n");
            return (EXIT_FAILURE);
        }

        udma_ptr = mmap(NULL, UDMA_BUF_SZ, PROT_READ|PROT_WRITE, MAP_SHARED, ufd, 0);
        if(udma_ptr == MAP_FAILED){
            printf("UDMA Memory Map failure !!!!!!!!!!! \n");
            close(ufd);
            return (EXIT_FAILURE);
        }
        uint64_t* word_ptr = (uint64_t*)(udma_ptr);
        size_t words = UDMA_BUF_SZ/sizeof(uint64_t);
        for(int i=0; i<words; i++){
            word_ptr[i] = 0;
        }
    }

    /* video device */
    sfmt.v4l2_pix_fmt = V4L2_PIX_FMT_GREY;
    //g_sfmt.width  = IMG_WIDTH;
    sfmt.width  = IMG_WIDTH; //FPGA_WIDTH;
    sfmt.height = IMG_HEIGHT;
    //g_sfmt.stride = IMG_WIDTH;
    sfmt.stride = IMG_WIDTH; //FPGA_WIDTH;

    if(udma_dev != NULL){
        ret = v4l2_open(&vdev_cap, devname_vcap, v4l2_dev_capture, V4L2_MEMORY_USERPTR);
    }else{
        ret = v4l2_open(&vdev_cap, devname_vcap, v4l2_dev_capture, V4L2_MEMORY_MMAP);
    }

    if(ret == 0)
    {
        printf("Camera Open Failure !!!!!!!!!!! \n");
        return (EXIT_FAILURE);
    }

    ret = v4l2_set_format(&vdev_cap, sfmt);
    if(ret == 0)
    {
        printf("Camera Format Settings Failure !!!!!!!!!!! \n");
        return (EXIT_FAILURE);
    }

    //ret = v4l2_create_bufs(&g_vdev_cap, g_sfmt, 4);
    ret = v4l2_create_bufs(&vdev_cap, sfmt, 4, udma_ptr);
    if(ret == 0)
    {
        printf("Buffer Creation Failure !!!!!!!!!!! \n");
        return (EXIT_FAILURE);
    }

    v4l2_qbuf_all(&vdev_cap);

    ret = v4l2_stream_on(&vdev_cap);
    if(ret == 0)
    {
        printf("Camera Stream On Failure !!!!!!!!!!! \n");
        return (EXIT_FAILURE);
    }

    printf("Camera Init Successful !!!!!!!!!!! \n");
    //memset(g_bufferCap, 0, sizeof(g_bufferCap));

    return(EXIT_SUCCESS);
}

int camera_init() {
    printf("\ncamera_init_start\n");
    int ret;
    //?????????????????
    //CcdMode p_Mode = CcdMode_NormalScan_33fps;		//!< ??????????
    //CcdConfig_setCcdModeDirectlyWithPowerOn(p_Mode);
    //return 0;
    /** ????? */
    //Light_initialLightingMode();		// (fps???????)

    ret = Init_LEDFlash();						//lowend????210303
    if(ret != true)
    {
        printf("\nLED_ERROR\n");
        return -1;
    }
    //printf("Init_LEDFlash() completed\n");

    /** ?????? */
    ret = Init_ImageSelect();					// ???????
    if(ret != true)
    {
        printf("\nImageSelect_ERROR\n");
        return -1;
    }
    //printf("Init_ImageSelect() completed\n");
    //Init_ImageSet();					    // ???????????
    ret = Init_Trigger();						// ??????????
    if(ret != true)
    {
        printf("\nTrigger_ERROR\n");
        return -1;
    }
    //printf("Init_Trigger() completed\n");

    return 1;
}

#if 0
int cap_img()
{
    FILE * fs;
    FILE *fp_jpeg,*fp_raw;
    int width = BMP_X*4; //5120
    int height = BMP_Y; //1024
    int iterationCount = 0;
    int ret;
    DDS_unsigned_long seqNo = 0;
    char filePath[FILE_PATH_BUFF];
    int i=0;
    bool a;

    unsigned char      raw_imageData[CAM_IMAGE_SIZE];

    //カメラキャプチャの初期設定ーーーーーーーーーーーーーーーーーーーーーーーーーーーー
    /* Command line option */
    char *devname_vcap = "/dev/video0";
    if(initV4L2(devname_vcap, NULL) ==  EXIT_FAILURE){ goto done; }

    /* capture */
    if(vdev_cap.dev.fd != NULL)
        printf("vdev_cap.dev.fd: %x\n", vdev_cap.dev.fd);
    else
        printf("File descriptor NULL\n");

    struct pollfd pfd = {.fd = vdev_cap.dev.fd, .events = POLLIN, .revents = 0};

    printf("start capture\n");
    fflush(stdout);
    //ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー


#ifdef DEBUG
    printf("Inside the thread before camera while loop\n");
#endif


    //DDSトピック初期化　１回だけセットーーーーーーーーーーーーーーーー
    g_pub_message_Sample.PricereductionCut_cutImage._buffer = DDS_sequence_char_allocbuf(DATA_SIZE);//ddsのメモリ確保
    g_pub_message_Sample.PricereductionCut_cutImage._maximum = DATA_SIZE;
    g_pub_message_Sample.PricereductionCut_cutImage._release = true;
    g_pub_message_Sample.request_DeviceId = g_deviceId;  // deviceId
    //ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー

    //ログ出力準備ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー
//    sprintf(filePath,"%s_%s_%s_%s_%s.csv",CSV_PATH,g_deviceId,g_quality,g_resize_width,g_resize_height);
    sprintf(filePath,"%s_%s_%s_%s_%s_%s.csv",CSV_PATH,g_deviceId,g_resize_width,g_background,g_sticker_size,g_quality);
    g_fp1 = fopen(filePath,"w+");
    fprintf(g_fp1,"Device Id, Seq No,Image Size, ImageCap Start, Trim Start, Resize Start, ImageConvert Start, ImageSend Start, End   \n");
    //fputc("Device Id",g_fp1);
    unsigned long long time_stamp_cap_start;
    //ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー

    if(strcmp(g_resize_width,"1280")==0){
        a=1;
    }
    else
    {
     a=0;
    }


    while (1) {//while loop start



        //データがあるか定期的にチェック
        if ((ret = poll(&pfd, 1, 1000)) <= 0)	{
            if(ret == 0)  continue;
            if(errno==4)  continue;
            printf("polling failed %s(%d)\n", strerror(errno), errno);
            break;
        }
        //データがあるときの処理
        if (pfd.revents & POLLIN) {
#ifdef DEBUG
            printf("Buffer present\n");
#endif//DEBUG

            time_stamp_cap_start= current_timestamp();//カメラ画像取得開始

            struct v4l2_video_buffer *b = v4l2_dqbuf(&vdev_cap);//ポインタb　に画像データを渡す。b->startに画像の先頭ポインタが保存されている


            if (b != NULL) {
#ifdef DEBUG2
    printf("1 \n");
#endif

                //測定時にはif(0)にすること<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                if(0){
                    //printf("check_point6\n");
                    char dst[12] = "dump";
                    char str[4];
                    sprintf(str, "%d", fcnt_total);
                    strcat(dst, str);
                    strcat(dst, ".raw");
                    printf("Filename: %s\n",dst);
                    fs = fopen(dst, "wb+");
                    fwrite(b->start, 1, b->bytesused, fs);
                    fclose(fs);
                }
#ifdef DEBUG2
    printf("2 \n");
#endif

                //bitmapをそのまま送信する場合の処理（切り出し）ーーーーーーーーーーーーーーーーーーーーーー
                if(a){
#ifdef DEBUG2
    printf("2.2 \n");
#endif
                    g_time_stamp1= current_timestamp();//切り出しスタートのタイムスタンプ
                    for (int y = 0; y < BMP_Y; y++)
                    {
                        //printf("画像の分割:%d\n",y);
                        unsigned char *src_ptr = b->start + y*width;//コピー元
                        unsigned char *dst_ptr = &raw_imageData;
#ifdef DEBUG3
                        dst_ptr += y*1280;//コピー先
#endif
                        memcpy(dst_ptr, src_ptr, BMP_X);//BMP_X=1280
                    }
                    g_time_stamp2= current_timestamp();//切り出し終了のタイムスタンプ
#ifdef DEBUG3
                    //+++++変換後の画像サイズセットと型変換++++++++++++++++++++++++++++++++++++++++++++++++
                    g_pub_message_Sample.PricereductionCut_cutImage._length= CAM_IMAGE_SIZE;//変換後の画像データサイズ
                    memcpy(g_pub_message_Sample.PricereductionCut_cutImage._buffer,&raw_imageData,CAM_IMAGE_SIZE);//変換後の画像コピー
                    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#endif
                }
                else {
                    //画像切り出しとjpeg変換
#ifdef DEBUG3
                    ImageFlipResizeJpeg(b->start,atoi(g_resize_width),atoi(g_resize_height));//入力画像の先頭ポインタ、リサイズ幅、リサイズ高さ
#endif
                }
                //ーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーーー

#ifdef DEBUG2
    printf("3 \n");
#endif
                //DDSで配信するデータの更新
                //画像のデータサイズのセットは「Image_convert」で実行
                g_pub_message_Sample.request_SeqNo = ++seqNo;

#ifdef DEBUG2
    printf("4 \n");
#endif

                // DDS publish Date　データ配信
#ifdef DEBUG3
                WritePublishData(g_domainID, g_message_DataWriter, &g_pub_message_Sample, g_result);
#endif

#ifdef DEBUG2
    printf("5 \n");
#endif



                g_time_stamp5= current_timestamp();
#ifdef DEBUG3
                //DDS配信データのログ書き出し
                fprintf(g_fp1,"%s ,%ld ,%ld ,%lld ,%lld ,%lld ,%lld ,%lld ,%lld \n",
                        g_pub_message_Sample.request_DeviceId,
                        g_pub_message_Sample.request_SeqNo,
                        g_pub_message_Sample.PricereductionCut_cutImage._length,
                        time_stamp_cap_start,g_time_stamp1,g_time_stamp2,g_time_stamp3,g_time_stamp4,g_time_stamp5);
#endif

#ifdef DEBUG2
    printf("6 \n");
#endif
                //キャプチャの解放
                v4l2_qbuf(&vdev_cap, b);

#ifdef DEBUG
                printf("Frame %d for processing !!!!!! \n",fcnt_total);
#endif//DEBUG

            }//bにデータがあるときの処理＿END
        }//データがあるときの処理＿END

        fcnt_total++;
        //指定時間経過したらスレッドを終了するーーーーーーー
        if(g_timeOutStatus == true)
        {
            pthread_exit(NULL);
        }
        //ーーーーーーーーーーーーーーーーーーーーーーーーーーー
    } //while loop 先頭にもどる

done:

#ifdef CAMERA_MODE
    /* finalize */
    v4l2_stream_off(&vdev_cap);
    v4l2_destroy_bufs(&vdev_cap);
    v4l2_close(&vdev_cap);
#endif

    return 0;
}
#endif


/***************************************************************************/
/*!
  @brief		:	This function is used to get the current time in nanoseconds.
  @param		:	none
  @retval		:	nanoseconds
  @attention	:	none
  */
/***************************************************************************/
static unsigned long long current_timestamp(void)
{
    struct timespec te;
    clock_gettime( CLOCK_REALTIME, &te);
    unsigned long long nanoseconds = (te.tv_sec * BILLION + te.tv_nsec );
    return nanoseconds;
}



