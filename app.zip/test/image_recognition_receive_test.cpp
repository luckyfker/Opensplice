#include <gtest/gtest.h>
#include "ephlib_job.h"
#include <gmock/gmock.h>
#include "com_middle_mock.h"


/*************** readImage() ***************/
TEST(GetRecognizeResultTest, TC11001) {
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* folderPath = "./";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_CaptureImageJob getRecognizeResultJobObj(domainId, requestTopic, responseTopic, folderPath, NULL);

    //mock
    //CREATE_COM_MOCK_OBJ(comMockObj);
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    bool retVal = getRecognizeResultJobObj.readImage(buffer);


    // Expect captureImage() return true
    EXPECT_EQ(true, retVal);
}

/*************** receiveResult() ***************/
TEST(GetRecognizeResultTest, TC12001) {
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* folderPath = "./";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_CaptureImageJob getRecognizeResultJobObj(domainId, requestTopic, responseTopic, folderPath, NULL);

    //mock
    //CREATE_COM_MOCK_OBJ(comMockObj);
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    DDS_SampleInfoSeq sequenceInfo;
    sequenceInfo._buffer[0].valid_data = true;
    
    DDS_sequence_Result_Send_Topic_Data sequenceData;
    sequenceData.length = 1;
    sequenceData._buffer[0].Pricereduction_srtRecognition = "Test";
    
    
    getRecognizeResultJobObj.sequenceResultData = &sequenceData;
    getRecognizeResultJobObj.resultDataSequenceInfo = &sequenceInfo;
    
    bool retVal = getRecognizeResultJobObj.receiveResult();


    // Expect captureImage() return true
    EXPECT_STREQ("Test", retVal);
}

/*************** publishRecognizeImage() ***************/
TEST(GetRecognizeResultTest, TC13001) {
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* folderPath = "./";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_CaptureImageJob getRecognizeResultJobObj(domainId, requestTopic, responseTopic, folderPath, NULL);

    //mock
    CREATE_COM_MOCK_OBJ(comMockObj);
    EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 1;
    bool retVal = getRecognizeResultJobObj.publishRecognizeImage((const char*)&buffer[0], length);
    
    
    getRecognizeResultJobObj.sequenceResultData = &sequenceData;
    getRecognizeResultJobObj.resultDataSequenceInfo = &sequenceInfo;
    
    getRecognizeResultJobObj.publishRecognizeImage((const char*)&buffer[0], length);
    //No display error message
}

TEST(GetRecognizeResultTest, TC13002) {
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* folderPath = "./";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_CaptureImageJob getRecognizeResultJobObj(domainId, requestTopic, responseTopic, folderPath, NULL);

    //mock
    CREATE_COM_MOCK_OBJ(comMockObj);
    EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 0xFFFFFFFF;
    bool retVal = getRecognizeResultJobObj.publishRecognizeImage((const char*)&buffer[0], length);
    
    
    captureImageJobObj.sequenceResultData = &sequenceData;
    captureImageJobObj.resultDataSequenceInfo = &sequenceInfo;
    
    captureImageJobObj.publishRecognizeImage((const char*)&buffer[0], length);
    //No display error message
}

/*************** allocPublishData() ***************/
TEST(GetRecognizeResultTest, TC14001) {
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* folderPath = "./";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_CaptureImageJob getRecognizeResultJobObj(domainId, requestTopic, responseTopic, folderPath, NULL);

    //mock
    //CREATE_COM_MOCK_OBJ(comMockObj);
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 1;
    Image_Send_Topic_Data* pubData = getRecognizeResultJobObj.allocPublishData(length);


    // Expect captureImage() return true
    EXPECT_NE(NULL, pubData);
}

TEST(GetRecognizeResultTest, TC14002) {
    int domainId = 1;
    const char* requestTopic = "Image_Send_Topic::Data";
    const char* folderPath = "./";
    const char* responseTopic = "Result_Send_Topic::Data";
    EPHLIB_CaptureImageJob getRecognizeResultJobObj(domainId, requestTopic, responseTopic, folderPath, NULL);

    //mock
    //CREATE_COM_MOCK_OBJ(comMockObj);
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 0xFFFFFFFF;
    Image_Send_Topic_Data* pubData = getRecognizeResultJobObj.allocPublishData(length);


    // Expect captureImage() return true
    EXPECT_NE(NULL, pubData);
}