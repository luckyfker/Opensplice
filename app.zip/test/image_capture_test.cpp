#include <gtest/gtest.h>
#include "ephlib_job.h"
#include <gmock/gmock.h>
#include "com_middle_mock.h"

/*************** captureImage() ***************/
TEST(ImageCaptureTest, TC03001) {
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_CaptureImageJob captureImageJobObj(domainId, topicName, intervalSec);
    
    std::vector<uchar> buffer;
    
    bool retVal = captureImageJobObj.captureImage(buffer);


    // Expect captureImage() return true
    EXPECT_EQ(true, retVal);
}

/*************** convertToJPEG() ***************/
TEST(ImageCaptureTest, TC04001) {
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_CaptureImageJob captureImageJobObj(domainId, topicName, intervalSec);

    std::vector<uchar> buffer;
    cv::Mat frame = cv::Mat::zeros(100,100,CV_8UC1);
    
    bool retVal = captureImageJobObj.convertToJPEG(frame, buffer);


    // Expect captureImage() return true
    EXPECT_EQ(true, retVal);
}

/*************** publishImage() ***************/
TEST(ImageCaptureTest, TC05001) {
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_CaptureImageJob captureImageJobObj(domainId, topicName, intervalSec);

    //mock
    CREATE_COM_MOCK_OBJ(comMockObj);
    EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 1;
    captureImageJobObj.publishImage((const char*)&buffer[0], length);
    //No display error message
}

TEST(ImageCaptureTest, TC05002) {
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_CaptureImageJob captureImageJobObj(domainId, topicName, intervalSec);

    //mock
    CREATE_COM_MOCK_OBJ(comMockObj);
    EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 0xFFFFFFFF;
    captureImageJobObj.publishImage((const char*)&buffer[0], length);
    //No display error message
}

/*************** allocPublishData() ***************/
TEST(ImageCaptureTest, TC06001) {
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_CaptureImageJob captureImageJobObj(domainId, topicName, intervalSec);

    //mock
    //CREATE_COM_MOCK_OBJ(comMockObj);
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 1;
    Image_Take_Topic_Data* pubData = captureImageJobObj.allocPublishData(length);


    // Expect captureImage() return true
    EXPECT_NE(NULL, pubData);
}

TEST(ImageCaptureTest, TC06002) {
    int domainId = 1;
    const char* topicName = "Image_Take_Topic::Data";
    unsigned int intervalSec = 10;
    EPHLIB_CaptureImageJob captureImageJobObj(domainId, topicName, intervalSec);

    //mock
    //CREATE_COM_MOCK_OBJ(comMockObj);
    //EXPECT_CALL(comMockObj, WritePublishData(1, 1, NULL, NULL)).Times(1).WillOnce(Return(CMSuccess));
    
    //Call function
    std::vector<uchar> buffer;
    int length = 0xFFFFFFFF;
    Image_Take_Topic_Data* pubData = captureImageJobObj.allocPublishData(length);


    // Expect captureImage() return true
    EXPECT_NE(NULL, pubData);
}
