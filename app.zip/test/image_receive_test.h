#ifndef IMAGE_RECEIVE_TEST_H
#define IMAGE_RECEIVE_TEST_H

// List all test suite here
#define SaveImageJob_Tests() \
    EPHLIB_FRIEND_TEST_SUITE(saveImageTest, TC01001); \
    EPHLIB_FRIEND_TEST_SUITE(saveImageTest, TC01002); \
    EPHLIB_FRIEND_TEST_SUITE(saveImageTest, TC02001); \

#endif
