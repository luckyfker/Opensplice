#ifndef COM_MIDDLE_MOCK_H
#define COM_MIDDLE_MOCK_H

#include <gmock/gmock.h>
#include "com_middle.h"

#define CREATE_COM_MOCK_OBJ(x) ::testing::NiceMock<ComMiddleMock> x; setupComMiddleMock(&(x));

class ComMiddleMock {
    public:
        ComMiddleMock();
        ~ComMiddleMock() {}

        // mock methods
        MOCK_METHOD(CMStatus, SetParticipant,
                        (int DomainID)
                );

        MOCK_METHOD(CMStatus, WritePublishData,
                        (int DomainID, CMULONG datawriterId,
                         void *publishData, char *resultCode)
                );

        MOCK_METHOD(CMStatus, ReadSubscriberData,
                        (int DomainID, CMULONG datareaderId,
                         void *SubData, void *SubInfoSeq, char *resultCode)
                );

        MOCK_METHOD(CMStatus, SetDataWriterLibUseQoSFile,
                        (int DomainID, const char *topicName,
                         const char *typeName, const char *typeLib,
                         const char *QoSFileName, CMULONG *DataWriterID,
                         char *resultCode)
                );

        MOCK_METHOD(CMStatus, SetDataReaderLibUseQoSFile,
                        (int DomainID, const char *topicName,
                         const char *typeName, const char *typeLib,
                         const char *QoSFileName, CMULONG *DataReaderID,
                         char *resultCode)
                );

        MOCK_METHOD(CMStatus, ShutdownDataWriter,
                        (int DomainID, CMULONG datawriterId, char *resultCode)
                );

        MOCK_METHOD(CMStatus, ShutdownDataReader,
                        (int DomainID, CMULONG datareaderId, char *resultCode)
                );

};

extern "C" void setupComMiddleMock(ComMiddleMock* mockObj);

#endif
