// MOCK functions for com_middle.h
#include <gmock/gmock.h>
#include "com_middle_mock.h"
#include "com_middle.h"

#ifdef NDEBUG
#undef NDEBUG
#endif

// uncomment to disable assert()
// #define NDEBUG
#include <cassert>

#define comMockObj      (*comMockObjPtr)
#define MOCK_OBJ_ASSERT()       assert(comMockObjPtr != NULL)

static ComMiddleMock* comMockObjPtr = NULL;

ComMiddleMock::ComMiddleMock(void) {
    ON_CALL(*this, SetParticipant).WillByDefault([this](int DomainID) {
          return CMSuccess;
        });

    ON_CALL(*this, WritePublishData).WillByDefault([this](int DomainID, CMULONG datawriterId,
                                                          void *publishData, char *resultCode) {
          return CMSuccess;
        });

    ON_CALL(*this, ReadSubscriberData).WillByDefault([this](int DomainID, CMULONG datareaderId,
                                                            void *SubData, void *SubInfoSeq, char *resultCode) {
          return CMSuccess;
        });

    ON_CALL(*this, SetDataWriterLibUseQoSFile).WillByDefault([this](int DomainID, const char *topicName,
                                                                    const char *typeName, const char *typeLib,
                                                                    const char *QoSFileName, CMULONG *DataWriterID,
                                                                    char *resultCode) {
          return CMSuccess;
        });

    ON_CALL(*this, SetDataReaderLibUseQoSFile).WillByDefault([this](int DomainID, const char *topicName,
                                                                    const char *typeName, const char *typeLib,
                                                                    const char *QoSFileName, CMULONG *DataReaderID,
                                                                    char *resultCode) {
          return CMSuccess;
        });

    ON_CALL(*this, ShutdownDataWriter).WillByDefault([this](int DomainID, CMULONG datawriterId, char *resultCode) {
          return CMSuccess;
        });

    ON_CALL(*this, ShutdownDataReader).WillByDefault([this](int DomainID, CMULONG datareaderId, char *resultCode) {
          return CMSuccess;
        });
}

extern "C" void setupComMiddleMock(ComMiddleMock* mockObj) {
    comMockObjPtr = mockObj;
}

// com_middle Interface implementation
extern "C" CMStatus SetParticipant(int DomainID) {
    MOCK_OBJ_ASSERT();
    return comMockObj.SetParticipant(DomainID);

}

extern "C" CMStatus WritePublishData(int DomainID,
                                     CMULONG datawriterId,
                                     void *publishData,
                                     char *resultCode) {
    MOCK_OBJ_ASSERT();
    return comMockObj.WritePublishData(DomainID, datawriterId, publishData, resultCode);
}

extern "C" CMStatus ReadSubscriberData(int DomainID,
                                       CMULONG datareaderId,
                                       void *SubData,
                                       void *SubInfoSeq,
                                       char *resultCode) {
    return comMockObj.ReadSubscriberData(DomainID, datareaderId, SubData, SubInfoSeq, resultCode);
}

extern "C" CMStatus SetDataWriterLibUseQoSFile(int DomainID,
                                               const char *topicName,
                                               const char *typeName,
                                               const char *typeLib,
                                               const char *QoSFileName,
                                               CMULONG *DataWriterID,
                                               char *resultCode) {
    MOCK_OBJ_ASSERT();
    return comMockObj.SetDataWriterLibUseQoSFile(DomainID, topicName, typeName, typeLib,
                                                 QoSFileName, DataWriterID, resultCode);
}

extern "C" CMStatus SetDataReaderLibUseQoSFile(int DomainID,
                                               const char *topicName,
                                               const char *typeName,
                                               const char *typeLib,
                                               const char *QoSFileName,
                                               CMULONG *DataReaderID,
                                               char *resultCode) {
    MOCK_OBJ_ASSERT();
    return comMockObj.SetDataReaderLibUseQoSFile(DomainID, topicName, typeName, typeLib,
                                                 QoSFileName, DataReaderID, resultCode);
}

extern "C" CMStatus ShutdownDataWriter(int DomainID, CMULONG datawriterId, char *resultCode) {
    MOCK_OBJ_ASSERT();
    return comMockObj.ShutdownDataWriter(DomainID, datawriterId, resultCode);
}

extern "C" CMStatus ShutdownDataReader(int DomainID, CMULONG datareaderId, char *resultCode) {
    MOCK_OBJ_ASSERT();
    return comMockObj.ShutdownDataReader(DomainID, datareaderId, resultCode);
}