/* @file */
/*****************************************************************************
**
**		Copyright (C) 2019
**				TOSHIBA TEC CORPORATION,  ALL Rights Reserved
**				1-14-10 Uchikanda Chiyoda-ku Tokyo JAPAN
**
**----------------------------------------------------------------------------
**
**	MODULE NAME	:	TypeUtils.c
**	(FILE NAME)
**	PARAMETERS	:	NONE
**
**	DESCRIPTION	:	
**
**	CREATE ON	:	V001.000
**
**	MODIFIED ON :
**
*****************************************************************************/

/*****************************************************************************
**	HEADER FILES
*****************************************************************************/
#include "dds_dcps.h"
#include "typeutils.h"
#include "evaluation_topic.h"

/*****************************************************************************
**	MACROS
*****************************************************************************/
#define TOTAL_TYPES 2		/* type count */

#define TU_SUCCESS 0
#define TU_FAIL -1

/*****************************************************************************
**	STRUCTURES
*****************************************************************************/
struct TypeSupportTable
{
	DDS_TypeSupport messageTypeSupport;
	char* messageTypeName;
};

/*****************************************************************************
**	STATIC VARIABLES
*****************************************************************************/
static struct TypeSupportTable TypeTable[TOTAL_TYPES];

/**************************************************************************************************************/
/*!
	@brief : This function compares the typename and fetches respective typesupport
	@param    : TypeName for respective topic
	@retval   : TypeSupport for respective topic
	@attention  : None
*/
/**************************************************************************************************************/
int	get_type_support(char* messageTypeName, DDS_TypeSupport *messageTypeSupport)
{
    int retval = TU_FAIL;
    unsigned int i = 0;

	if (TypeTable[0].messageTypeSupport == NULL)
	{
		TypeTable[0].messageTypeSupport = Image_Send_Topic_DataTypeSupport__alloc();
		TypeTable[0].messageTypeName = Image_Send_Topic_DataTypeSupport_get_type_name(TypeTable[0].messageTypeSupport);
	}

	if (TypeTable[1].messageTypeSupport == NULL)
	{
		TypeTable[1].messageTypeSupport = Result_Send_Topic_DataTypeSupport__alloc();
		TypeTable[1].messageTypeName = Result_Send_Topic_DataTypeSupport_get_type_name(TypeTable[1].messageTypeSupport);
	}


    for (i = 0; i < TOTAL_TYPES; i++)
	{
		if (strcmp(messageTypeName, TypeTable[i].messageTypeName) == 0)
		{
			*messageTypeSupport = TypeTable[i].messageTypeSupport;
			retval = TU_SUCCESS;
			break;
		}
    }
    	
    return retval;
}

/**************************************************************************************************************/
/*!
	@brief : This function frees the memory allocated for typesupport
	@retval   : success only
	@attention  : None
*/
/**************************************************************************************************************/
int finalTypeUtils(void)
{
   unsigned int i = 0;

   for (i = 0; i < TOTAL_TYPES; i++)
   {
	   if (TypeTable[i].messageTypeSupport != NULL)
	   {
		   DDS_free(TypeTable[i].messageTypeSupport);
	   }
   }

   return TU_SUCCESS;
}
