/* @file */
/*****************************************************************************
**
**		Copyright (C) 2006
**				TOSHIBA TEC CORPORATION,  ALL Rights Reserved
**				1-14-10 Uchikanda Chiyoda-ku Tokyo JAPAN
**
**----------------------------------------------------------------------------
**
**	MODULE NAME	:	sensorapi.h
**	(FILE NAME)
**	PARAMETERS	:	NONE
**
**	DESCRIPTION	:	���󥵡��������API���󶡤��롣
**
**	CREATE ON	:	V001.000				2006.02.28		K.Takahara[SG]
**
**	MODIFIED ON :
**
*****************************************************************************/
#ifndef ___SENSORAPI_H___
#define ___SENSORAPI_H___

/*****************************************************************************
**	MACROS
*****************************************************************************/
#define SENSOR_OK						0					/* ����								*/
#define SENSOR_PARAM_ERR				(-1)				/* �ѥ�᡼�����顼					*/
#define SENSOR_DATAGET_ERR				(-2)				/* ���󥵡��ǡ����������顼			*/

/*****************************************************************************
**	EXTERN FUNCTIONS
*****************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif

/* ���󥵡��ǥХ��������	*/

/**************************************************************************************************************/

/*!
        @brief 		: This function initializes the selected sensor
        @param		: device - To select either the PS or PL block
        @param		: fileName - Filename for DDS
        @retval		: Success - returns 0 in case of success,
                      Failure - returns -1 in case of failure.
        @attention	:  None
*/

/**************************************************************************************************************/
int		sensorDevInit();
/* ���󥵡��ǥХ�����λ		*/

/**************************************************************************************************************/

/*!
        @brief 		: This function terminates or closes the selected sensor which was opened earlier
        @param		: device - To terminate either the PS or PL block
        @retval		: Success - returns 0 in case of success,
                      Failure - returns -1 in case of failure.
        @attention	:  None
*/

/**************************************************************************************************************/
int		sensorDevTerm(int devId);
/* ���󥵡��ǥХ����������	*/

/**************************************************************************************************************/

/*!
        @brief 		: This function Reads the SYSMON registers
        @param		: register - Register address for the particular voltage/ temperature in PS and Pl block
        @param		: readstruct - Returns value and status either reached threshold
        @retval		: Success - returns 0 in case of success,
                      Failure - returns -1 in case of failure.
        @attention	:  None
*/

/**************************************************************************************************************/
int		sensorDevGetData(int devId, long *localTemp, long *remoteTemp);


#ifdef __cplusplus
}
#endif

#endif	/* ___SENSORAPI_H___ */
