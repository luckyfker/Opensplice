//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		:	macros.h
//
//		DESCRIPTION :	eMMC library
//
//		CREATE ON	: 	V001.000 			Nagul.S 		11-11-2019		#0
//
//		MODIFIED ON	:
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __MACROS_H__
#define __MACROS_H__


#define 		EEP_API_CALL_FAILED 			-1					/*! EEPROM call fail error */
#define 		EEP_SUCCESS 					0					/*! EEPROM success */
#define 		EEPROM_FAILURE 					-1					/*! EEPROM API call fail error */
#define 		EEPROM_SUCCESS 					0					/*! EEPROM success */
#define 		EEP_CRITICAL 					-2 					/*! Device replacement message*/
#define 		EEP_WARNING 					-3					/*! Warning message */
#define 		EEP_NORMAL 						-22					/*! EEPROM Noramal messgae */
#define 		EEP_WRITE_TO_DEV_FAIL 			-10					/*! EEPROM Writing to device failure */
#define 		EEP_PAGESIZE_ERROR 				-9					/*! EEPROM Page size error */
#define 		EEP_ARGUMENTS_NOT_IN_RANGE 		-12					/*! EEPROM Arguments error */

#define 		EEP_DEVICE_OPEN_FAIL 			-4					/*! Device opening failure*/
#define 		EEP_NO_DEVICE 					-5					/*! No device error*/
#define 		EEP_SEND_READ_FAILURE 			-6					/*! Send read error*/
#define 		EEP_FILEREAD_FAIL 				-7					/*! File read error*/
#define 		EEP_ADDR_WRITE_FAIL 			-8					/*! ADDRESS write error*/			
#define 		EEP_PAGESIZE_ERROR 				-9					/*! Page size error*/
#define 		EEP_WRITE_TO_DEV_FAIL 			-10					/*! Writing to device error*/
#define 		EEP_WRITE_TO_FILE_FAIL 			-11					/*! Writing to file error*/
#define 		EEP_READ_ERROR 					-13					/*! EEPROM read error*/
#define 		EEP_CRITICAL 					-2  				/*! Device replacement message*/
#define 		EEP_WARNING 					-3					/*! Warning message*/
#define 		EEP_NORMAL 						-22					/*! Normal message*/
#define 		EEP_API_CALL_FAILED 			-1					/*! API call failed*/
#define 		EEP_ARGUMENTS_NOT_IN_RANGE 		-12					/*! Arguments are not in range*/
#define 		EEP_SUCCESS 					0					/*! SUCCESS*/
#define 		EEPROM_API_FAILURE 				-1
#define 		EEPROM_API_SUCCESS				0


/*!This function is used to read the data from the EEPROM*/

/**************************************************************************************************************/

/*!
        @brief      : This function is used to read eeprom data
        @param      : item_number : item number to read
        @param      : dst_addr    : destination address
        @param      : size        : size to read
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
 */

/**************************************************************************************************************/
int read_eeprom(long, unsigned char *, unsigned int);

/*!This function is used to Write the data to the EEPROM*/

/************************************************************************************************************* */

/*!
        @brief      : This function is used to write in to the eeprom in the given item range.It will check for the low write count and write in to that location
        @param      : start     : starting-item number
        @param      : end       : ending item number
        @param      : src_addr  : source address
        @param      : size      : size to write
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/************************************************************************************************************* */
int write_eeprom2(long, long, unsigned char*,unsigned int);

/*!This function is used to read the data from the EEPROM from the last write location*/

/************************************************************************************************************* */

/*!
        @brief      : This function is used to read the eeprom data from the last written location
        @param      : start     : starting-item number
        @param      : end       : ending item number
        @param      : dst_addr  : destination address
        @param      : size      : size to write
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None			
  */

/************************************************************************************************************* */
int read_eeprom2(unsigned char *, unsigned int);

/*!This function is used to set the thresholds in config file*/

/************************************************************************************************************* */

/*!
        @brief      : This function is used to set the thresholds in config file
        @param      : maxThreshold : threshold to give device replacement message
        @param      : minThreshold : threshold to give warning message
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/************************************************************************************************************* */
int set_write_operations_limit(long, long);

/*!This function is used to get the thresholds from the config file*/

/************************************************************************************************************* */

/*!
        @brief      : This function is used to get the thresholds from the config file
        @param      : maxThreshold : threshold to give device replacement message
        @param      : minThreshold : threshold to give warning message
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/************************************************************************************************************* */
int get_write_operations_limit(long *, long *);

/*!This function is used to get the write count using the item number*/

/************************************************************************************************************* */

/*!
        @brief      : This function is used to get the write count from the config file
        @param      : item_number : item-number to get the count
        @param      : write_count : write count of item number
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/************************************************************************************************************* */
int get_write_count(long, long *);

/*!This function is used to read the alert status using the item number*/

/************************************************************************************************************* */

/*!
        @brief      : This function is used to read the alert status
        @param      : item_number : item-number to check the alert status
        @param      : status : status of the device
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/************************************************************************************************************* */
int read_alert_status(int, int *);

/*!This function is used to get the device information*/

/************************************************************************************************************* */

/*!
        @brief      : This function is used to get the device information
        @param      : size : size of the EEPROM in bytes
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/**************************************************************************************************************/
int get_device_info(int *);

/*!This function is used to enable the logs*/

/************************************************************************************************************* */

/*!
        @brief      : This function is used to enable the logs
        @param      : N/A
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/************************************************************************************************************* */
int enable_logs(void);

/*!This function is used to disable the logs*/

/************************************************************************************************************* */

/*!
        @brief      : This function is used to disable the logs publishing
        @param      : N/A
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/************************************************************************************************************* */
int disable_logs(void);

/*!This function is used to write into the eeprom*/

/************************************************************************************************************* */

/*!
        @brief      : This is an internal function used by Write_eeprom and used to write into eeprom.
        @param      : addr_hi   :   High address byte
        @param      : addr_lo   :   Low address byte
        @param      : buf       :   source address
        @param      : len       :   size to write
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/************************************************************************************************************* */
int write_to_device(uint8_t, uint8_t, unsigned char *, int);

/*!This function is used to write into the eeprom*/

/************************************************************************************************************* */

/*!
        @brief      : This function is used to write into eeprom
        @param      : src_addr  : source address
        @param      : item      : item number to write
        @param      : size      : size to write
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/************************************************************************************************************* */
int write_eeprom(unsigned char*, long, unsigned int);

/*!This function is used to write into the file*/

/************************************************************************************************************* */

/*!
        @brief      : This function is used to write into eeprom
        @param      : write_count  : write count to write
        @param      : item      : item number to write
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/************************************************************************************************************* */
int writeTofile(long, long );

/*!This function is used to write address into the file*/

/************************************************************************************************************* */

/*!
        @brief      : This function is used to write into eeprom
        @param      : address  : address to store
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/************************************************************************************************************* */
int writeAddressToFile(uint16_t );

#endif
