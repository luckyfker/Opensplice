//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    Copyright (C) 2019
//    TOSHIBA TEC CORPORATION,  ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    FILE    : autopublish_utilities.h
//
//    DESCRIPTION : Implementation of library which supports create/write/delete of ring buffer, files required for
//					autopublish functionality					 
//
//    CREATEd ON :  7-2-2020, By: bhanu	Version:V0.001         #0
//
//    MODIFIED ON : 7-2-2020
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __AUTOPUBLISH_UTILITIES_H__
#define __AUTOPUBLISH_UTILITIES_H__

#include <stdio.h>
#include <stdint.h>
#include <limits.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include "linux/limits.h"


typedef struct rbHeader{
    uint32_t msgSize;
    uint32_t seqNum;
}RingBuffHeader;

typedef struct rbHandle{

    key_t rbKey;
    int rbId;
    void *rbAddress;
    unsigned long rbSize;
    unsigned int rbRecordSize;
    unsigned int rbHeaderSize;
    FILE *rbFile;
    char fileName[NAME_MAX];
    char filePath[NAME_MAX];
    char sourceSection[30];

    long offset;
    RingBuffHeader recHeader;
    unsigned int topic_type; // 1 indicates log topic type, 0 indicates other topic type
	unsigned long rbLineNo;

}RingBuffHandle;


/**************************************************************************************************************/
/*!
    @brief : This function creates a ring buffer on shared memeory using IPC shared memory concept
    		The function returns the address. It has to be assigned to a char type array.
    		Ex: char *arr = CreateRingbuffer(pass arguments here);
    @param    : size - This argumennt defines the size of ring buffer that needs to be created in shared mem		
    @param    : DomainID - Domain ID on which DDS communication happens //assign 0 for logging
    @param    : topicName - name of the topic to which data should be published over DDS //assign null for logging
    @param    : typeName - name of the type used for data, that's published over DDS //assign null for logging
    @param    : typeLib - path to dynnamically load type library //assign null for logging
    @param    : QoSFileName - path to qos file that shall be used for DDS communication //assign null for logging
    @param    : handle - This is an OUTPUT argument. This needs to be used by the user to write data.
    			This handle shall be passed as an argument for WriteLog() and WriteMsg() functions
    @retval   : returns 0 if successful or -1 if failed
    @attention  : None
*/
/**************************************************************************************************************/
int SetAutoPublishBuffer(unsigned int bufferSize, unsigned int msgSize, int domainID,
                         const char *topicName, const char *typeName, const char *typeLib,
                         const char *QoSFileName, unsigned long *rbHandle);

/**************************************************************************************************************/
/*!
    @brief : This function creates a file that will be used for autopublishing of data using com middle
    @param    : FileName - filename of the file that needs to be created (with path)
    @param    : size - This argumennt defines the size of file that needs to be created		
    @param    : DomainID - Domain ID on which DDS communication happens //assign 0 for logging
    @param    : topicName - name of the topic to which data should be published over DDS //assign null for logging
    @param    : typeName - name of the type used for data, that's published over DDS //assign null for logging
    @param    : typeLib - path to dynnamically load type library //assign null for logging
    @param    : QoSFileName - path to qos file that shall be used for DDS communication //assign null for logging
    @param    : handle - This is an OUTPUT argument. This needs to be used by the user to write data.
    			This handle shall be passed as an argument for WriteLog() and WriteMsg() functions
    @retval   : returns 0 if successful or -1 if failed
    @attention  : None
*/
/**************************************************************************************************************/
int SetAutoPublishFile(const char *fileName, unsigned long fileSize, unsigned int msgSize,
                       int domainID, const char *topicName, const char *typeName, const char *typeLib,
                       const char *QoSFileName, unsigned long *rbHandle);

/**************************************************************************************************************/
/*!
    @brief : This function writes data into the ringbuffer or file in the log format as defined in log topic
    		 This function internally appends line number, date and time
    @param    : handle - The handle for the file/ringbuffer. This would be returned from CreateRingbuffer/Createfile
    @param    : loglevel - The loglevel of the data being written. Ex: 0 or 1 based on criticality of log 
    @param    : logcode - The logcode of the data being written. Use if applicable - TBD
    @param    : message -pointer to character array containing the log
    @retval   : returns 0 if successful or -1 if failed
    @attention  : message shoudl be the pointer to character array, not exceeding 256 bytes 
    				i.e. arr[255] is the max allowed
*/
/**************************************************************************************************************/
int rbWriteLog(unsigned long handle, unsigned int loglevel, long logcode, char* message);

/**************************************************************************************************************/
/*!
    @brief : This function writes data into the ringbuffer or file as per the application specific type

    @param    : handle - The handle for the file/ringbuffer. This was returned from CreateRingbuffer/Createfile
    @param    : size - The size of the data being written.
    @param    : message - pointer to the structure filled with data that needs to be published
    @retval   : returns 0 if successful or -1 if failed
    @attention  : none
*/
/**************************************************************************************************************/
int rbWriteMsg(unsigned long handle, void* message);

int ClearBuffer(unsigned long handle);

int FlushBuffer(unsigned long handle);

/**************************************************************************************************************/
/*!
    @brief : This function deletes the ringbuffer from the shared memory / closes the auto publish file
    @param    : handle - The handle for the file/ringbuffer. This was returned from CreateRingbuffer/Createfile
    @retval   : returns 0 if successful or -1 if failed
    @attention  : none
*/
/**************************************************************************************************************/
int DeleteAutoPublishSource(unsigned long handle);

int rbWriteCommonLog(unsigned int loglevel, long logcode, char* message);

/**************************************************************************************************************/
/*!
    @brief    : This function is used for clearing the Common log file used by libraries.
    @param    : None
    @retval   : returns 0 if successful or -1 if failed
    @attention  : This function internally uses the ClearBuffer(). The handle used would be the rbCommongLogHandle
*/
/**************************************************************************************************************/
int rbClearCommonLog(void);


/**************************************************************************************************************/
/*!
    @brief : This function takes the ring buffer related data and returns the ringfrom the shared memory / closes the auto publish file
    @param    : rbData- The ring buffer related data collected from boot-up application - for the file/ringbuffer.
    @param    : rbhandle - The handle for the file/ringbuffer.
    @retval   : returns 0 if successful or -1 if failed
    @attention  : none
*/
/**************************************************************************************************************/
int getRbHandle(void* rbData, unsigned long* rbHandle);


#endif
