//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		: WDT_local.h
//
//		DESCRIPTION     : WDT library
//
//		CREATE ON	: V001.000 			Suresh B 		23-01-2020		#0
//
//		MODIFIED ON	: 18-02-2020
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __WDT_LOCAL_H__
#define __WDT_LOCAL_H__

////////////////////////////////////////////////////////////////////////////////
//	Definition
////////////////////////////////////////////////////////////////////////////////

//#define RUN_ON_HOST
#define INFO
#define DEBUG
#define PERROR

#define SIGETX 46

#define WDT "/dev/watchdog"
#define WDT0 "/dev/watchdog0"
#define WDT1 "/dev/watchdog1"

#define WDT_APP_ID      2

#define WDT_HANDLER_ENABLE 	0x01
#define WDT_HANDLER_DISABLE 	0x02

#define WDT_RESET_SIGNAL 	0x01
#define WDT_IRQ_SIGNAL		0x02

#define WDT_DEFAULT_TIMEOUT 1000


#define SIG SIGRTMIN
#define CLOCKID CLOCK_REALTIME

#ifdef  DEBUG 
#define DEBUG_PRINT    printf
#else
#define DEBUG_PRINT(x,...)  ((void)0)
#endif



#ifdef  INFO
#define INFO_PRINT    printf
#else
#define INFO_PRINT(x,...)  ((void)0)
#endif

#ifdef  PERROR
#define PERROR_PRINT    perror
#else
#define PERROR_PRINT(x,...)  ((void)0)
#endif

#endif /* __WDT_LOCAL_H__ */

