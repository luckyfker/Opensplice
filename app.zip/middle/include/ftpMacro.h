///////////////////////////////////////////////////////////////
//
//
//	Copyright (C) 2019
//	TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
////////////////////////////////////////////////////////////////
//
//
//	FILE        : ftpMacro.h
//
//	DESCRIPTION : Header file which consists of declaration of
//                all the macros
//
//	CREATE ON   : V001.000        Sachin Gowda K        2019.11.11
//
//	MODIFIED ON :
//
//
//
//
//
//
//
/////////////////////////////////////////////////////////////////
#ifndef MACRO_H
#define MACRO_H

#define FTP_CONNECTION_ESTABLISHED								0
#define FTP_CONNECTION_FAILED									-100
#define FTP_LOGIN_SUCCESS 										0
#define FTP_LOGIN_FAILED 										-200
#define	FTP_LIST_SUCCESS 										0
#define	FTP_LIST_FAILED 										-300
#define FTP_CREATE_DIRECTORY_SUCCESS 							0
#define FTP_CREATE_DIRECTORY_FAILED 							-400
#define FTP_DELETE_DIRECTORY_SUCCESS 							0
#define FTP_DELETE_DIRECTORY_FAILED 							-500
#define FTP_DELETE_FILE_SUCCESS 								0
#define FTP_DELETE_FILE_FAILED					 				-600
#define FTP_CHANGE_DIRECTORY_SUCCESS 							0
#define FTP_CHANGE_DIRECTORY_FAILED 							-700
#define FTP_RENAME_FILE_SUCCESS 								0
#define FTP_RENMAE_FILE_FAILED 									-800
#define FTP_DOWNLOAD_FILE_SUCCESS 								0
#define FTP_DOWNLOAD_FILE_FAILED 								-900
#define FTP_DOWNLOAD_DIRECTORY_SUCCESS 							0
#define FTP_DOWNLOAD_DIRECTORY_FAILED							-1000
#define FTP_UPLOAD_FILE_SUCCESS 								0
#define FTP_UPLOAD_FILE_FAILED									-1100
#define FTP_GET_PWD_SUCCESS 									0
#define FTP_GET_PWD_FAILURE										-1200
#define PATH 100
#define CAFILE "/home/utthuna/Documents/FTPS/Source/lib/ftp_client/prog/source/rootcert.pem"
#define CERTFILE "/home/utthuna/Documents/FTPS/Source/lib/ftp_client/prog/source/client.pem"
#endif
