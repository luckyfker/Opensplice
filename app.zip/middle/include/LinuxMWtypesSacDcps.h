#ifndef LinuxMWtypesSACDCPS_H
#define LinuxMWtypesSACDCPS_H

#include "dds_dcps.h"
#include "LinuxMWtypesDcps.h"

#ifndef DDS_API
#define DDS_API
#endif


#define HelloWorldData_MsgTypeSupport DDS_TypeSupport

DDSCOMU_API HelloWorldData_MsgTypeSupport
HelloWorldData_MsgTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgTypeSupport_register_type (
    HelloWorldData_MsgTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
HelloWorldData_MsgTypeSupport_get_type_name (
    HelloWorldData_MsgTypeSupport _this
    );

#ifndef _DDS_sequence_HelloWorldData_Msg_defined
#define _DDS_sequence_HelloWorldData_Msg_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    HelloWorldData_Msg *_buffer;
    DDS_boolean _release;
} DDS_sequence_HelloWorldData_Msg;

DDSCOMU_API DDS_sequence_HelloWorldData_Msg *DDS_sequence_HelloWorldData_Msg__alloc (void);
DDSCOMU_API HelloWorldData_Msg *DDS_sequence_HelloWorldData_Msg_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_HelloWorldData_Msg_defined */

#define HelloWorldData_MsgDataWriter DDS_DataWriter

#define HelloWorldData_MsgDataWriter_enable DDS_Entity_enable

#define HelloWorldData_MsgDataWriter_get_status_changes DDS_Entity_get_status_changes

#define HelloWorldData_MsgDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define HelloWorldData_MsgDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define HelloWorldData_MsgDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define HelloWorldData_MsgDataWriter_get_listener DDS_DataWriter_get_listener

#define HelloWorldData_MsgDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define HelloWorldData_MsgDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define HelloWorldData_MsgDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define HelloWorldData_MsgDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define HelloWorldData_MsgDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define HelloWorldData_MsgDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define HelloWorldData_MsgDataWriter_get_publisher DDS_DataWriter_get_publisher

#define HelloWorldData_MsgDataWriter_get_qos DDS_DataWriter_get_qos

#define HelloWorldData_MsgDataWriter_get_topic DDS_DataWriter_get_topic

#define HelloWorldData_MsgDataWriter_set_listener DDS_DataWriter_set_listener

#define HelloWorldData_MsgDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
HelloWorldData_MsgDataWriter_register_instance (
    HelloWorldData_MsgDataWriter _this,
    const HelloWorldData_Msg *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
HelloWorldData_MsgDataWriter_register_instance_w_timestamp (
    HelloWorldData_MsgDataWriter _this,
    const HelloWorldData_Msg *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataWriter_unregister_instance (
    HelloWorldData_MsgDataWriter _this,
    const HelloWorldData_Msg *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataWriter_unregister_instance_w_timestamp (
    HelloWorldData_MsgDataWriter _this,
    const HelloWorldData_Msg *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataWriter_write (
    HelloWorldData_MsgDataWriter _this,
    const HelloWorldData_Msg *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataWriter_write_w_timestamp (
    HelloWorldData_MsgDataWriter _this,
    const HelloWorldData_Msg *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataWriter_dispose (
    HelloWorldData_MsgDataWriter _this,
    const HelloWorldData_Msg *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataWriter_dispose_w_timestamp (
    HelloWorldData_MsgDataWriter _this,
    const HelloWorldData_Msg *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataWriter_writedispose (
    HelloWorldData_MsgDataWriter _this,
    const HelloWorldData_Msg *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataWriter_writedispose_w_timestamp (
    HelloWorldData_MsgDataWriter _this,
    const HelloWorldData_Msg *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataWriter_get_key_value (
    HelloWorldData_MsgDataWriter _this,
    HelloWorldData_Msg *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
HelloWorldData_MsgDataWriter_lookup_instance (
    HelloWorldData_MsgDataWriter _this,
    const HelloWorldData_Msg *key_holder
    );

#define HelloWorldData_MsgDataReader DDS_DataReader

#define HelloWorldData_MsgDataReader_enable DDS_Entity_enable

#define HelloWorldData_MsgDataReader_get_status_changes DDS_Entity_get_status_changes

#define HelloWorldData_MsgDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define HelloWorldData_MsgDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define HelloWorldData_MsgDataReader_create_querycondition DDS_DataReader_create_querycondition

#define HelloWorldData_MsgDataReader_create_readcondition DDS_DataReader_create_readcondition

#define HelloWorldData_MsgDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define HelloWorldData_MsgDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define HelloWorldData_MsgDataReader_get_listener DDS_DataReader_get_listener

#define HelloWorldData_MsgDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define HelloWorldData_MsgDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define HelloWorldData_MsgDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define HelloWorldData_MsgDataReader_get_qos DDS_DataReader_get_qos

#define HelloWorldData_MsgDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define HelloWorldData_MsgDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define HelloWorldData_MsgDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define HelloWorldData_MsgDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define HelloWorldData_MsgDataReader_get_subscriber DDS_DataReader_get_subscriber

#define HelloWorldData_MsgDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define HelloWorldData_MsgDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define HelloWorldData_MsgDataReader_set_listener DDS_DataReader_set_listener

#define HelloWorldData_MsgDataReader_set_qos DDS_DataReader_set_qos

#define HelloWorldData_MsgDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_read (
    HelloWorldData_MsgDataReader _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_take (
    HelloWorldData_MsgDataReader _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_read_w_condition (
    HelloWorldData_MsgDataReader _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_take_w_condition (
    HelloWorldData_MsgDataReader _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_read_next_sample (
    HelloWorldData_MsgDataReader _this,
    HelloWorldData_Msg *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_take_next_sample (
    HelloWorldData_MsgDataReader _this,
    HelloWorldData_Msg *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_read_instance (
    HelloWorldData_MsgDataReader _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_take_instance (
    HelloWorldData_MsgDataReader _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_read_next_instance (
    HelloWorldData_MsgDataReader _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_take_next_instance (
    HelloWorldData_MsgDataReader _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_read_next_instance_w_condition (
    HelloWorldData_MsgDataReader _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_take_next_instance_w_condition (
    HelloWorldData_MsgDataReader _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_return_loan (
    HelloWorldData_MsgDataReader _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReader_get_key_value (
    HelloWorldData_MsgDataReader _this,
    HelloWorldData_Msg *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
HelloWorldData_MsgDataReader_lookup_instance (
    HelloWorldData_MsgDataReader _this,
    const HelloWorldData_Msg *key_holder
    );

#define HelloWorldData_MsgDataReaderView DDS_DataReaderView

#define HelloWorldData_MsgDataReaderView_enable DDS_Entity_enable

#define HelloWorldData_MsgDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define HelloWorldData_MsgDataReaderView_get_qos DDS_DataReaderView_get_qos

#define HelloWorldData_MsgDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define HelloWorldData_MsgDataReaderView_set_qos DDS_DataReaderView_set_qos

#define HelloWorldData_MsgDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define HelloWorldData_MsgDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define HelloWorldData_MsgDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define HelloWorldData_MsgDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_read (
    HelloWorldData_MsgDataReaderView _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_take (
    HelloWorldData_MsgDataReaderView _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_read_next_sample (
    HelloWorldData_MsgDataReaderView _this,
    HelloWorldData_Msg *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_take_next_sample (
    HelloWorldData_MsgDataReaderView _this,
    HelloWorldData_Msg *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_read_instance (
    HelloWorldData_MsgDataReaderView _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_take_instance (
    HelloWorldData_MsgDataReaderView _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_read_next_instance (
    HelloWorldData_MsgDataReaderView _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_take_next_instance (
    HelloWorldData_MsgDataReaderView _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_return_loan (
    HelloWorldData_MsgDataReaderView _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_read_w_condition (
    HelloWorldData_MsgDataReaderView _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_take_w_condition (
    HelloWorldData_MsgDataReaderView _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_read_next_instance_w_condition (
    HelloWorldData_MsgDataReaderView _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_take_next_instance_w_condition (
    HelloWorldData_MsgDataReaderView _this,
    DDS_sequence_HelloWorldData_Msg *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
HelloWorldData_MsgDataReaderView_get_key_value (
    HelloWorldData_MsgDataReaderView _this,
    HelloWorldData_Msg *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
HelloWorldData_MsgDataReaderView_lookup_instance (
    HelloWorldData_MsgDataReaderView _this,
    HelloWorldData_Msg *key_holder
    );


#define Input_DataTypeSupport DDS_TypeSupport

DDSCOMU_API Input_DataTypeSupport
Input_DataTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataTypeSupport_register_type (
    Input_DataTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
Input_DataTypeSupport_get_type_name (
    Input_DataTypeSupport _this
    );

#ifndef _DDS_sequence_Input_Data_defined
#define _DDS_sequence_Input_Data_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    Input_Data *_buffer;
    DDS_boolean _release;
} DDS_sequence_Input_Data;

DDSCOMU_API DDS_sequence_Input_Data *DDS_sequence_Input_Data__alloc (void);
DDSCOMU_API Input_Data *DDS_sequence_Input_Data_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_Input_Data_defined */

#define Input_DataDataWriter DDS_DataWriter

#define Input_DataDataWriter_enable DDS_Entity_enable

#define Input_DataDataWriter_get_status_changes DDS_Entity_get_status_changes

#define Input_DataDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define Input_DataDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define Input_DataDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define Input_DataDataWriter_get_listener DDS_DataWriter_get_listener

#define Input_DataDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define Input_DataDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define Input_DataDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define Input_DataDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define Input_DataDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define Input_DataDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define Input_DataDataWriter_get_publisher DDS_DataWriter_get_publisher

#define Input_DataDataWriter_get_qos DDS_DataWriter_get_qos

#define Input_DataDataWriter_get_topic DDS_DataWriter_get_topic

#define Input_DataDataWriter_set_listener DDS_DataWriter_set_listener

#define Input_DataDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
Input_DataDataWriter_register_instance (
    Input_DataDataWriter _this,
    const Input_Data *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
Input_DataDataWriter_register_instance_w_timestamp (
    Input_DataDataWriter _this,
    const Input_Data *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataWriter_unregister_instance (
    Input_DataDataWriter _this,
    const Input_Data *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataWriter_unregister_instance_w_timestamp (
    Input_DataDataWriter _this,
    const Input_Data *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataWriter_write (
    Input_DataDataWriter _this,
    const Input_Data *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataWriter_write_w_timestamp (
    Input_DataDataWriter _this,
    const Input_Data *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataWriter_dispose (
    Input_DataDataWriter _this,
    const Input_Data *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataWriter_dispose_w_timestamp (
    Input_DataDataWriter _this,
    const Input_Data *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataWriter_writedispose (
    Input_DataDataWriter _this,
    const Input_Data *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataWriter_writedispose_w_timestamp (
    Input_DataDataWriter _this,
    const Input_Data *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataWriter_get_key_value (
    Input_DataDataWriter _this,
    Input_Data *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
Input_DataDataWriter_lookup_instance (
    Input_DataDataWriter _this,
    const Input_Data *key_holder
    );

#define Input_DataDataReader DDS_DataReader

#define Input_DataDataReader_enable DDS_Entity_enable

#define Input_DataDataReader_get_status_changes DDS_Entity_get_status_changes

#define Input_DataDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define Input_DataDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define Input_DataDataReader_create_querycondition DDS_DataReader_create_querycondition

#define Input_DataDataReader_create_readcondition DDS_DataReader_create_readcondition

#define Input_DataDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define Input_DataDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define Input_DataDataReader_get_listener DDS_DataReader_get_listener

#define Input_DataDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define Input_DataDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define Input_DataDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define Input_DataDataReader_get_qos DDS_DataReader_get_qos

#define Input_DataDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define Input_DataDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define Input_DataDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define Input_DataDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define Input_DataDataReader_get_subscriber DDS_DataReader_get_subscriber

#define Input_DataDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define Input_DataDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define Input_DataDataReader_set_listener DDS_DataReader_set_listener

#define Input_DataDataReader_set_qos DDS_DataReader_set_qos

#define Input_DataDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_read (
    Input_DataDataReader _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_take (
    Input_DataDataReader _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_read_w_condition (
    Input_DataDataReader _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_take_w_condition (
    Input_DataDataReader _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_read_next_sample (
    Input_DataDataReader _this,
    Input_Data *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_take_next_sample (
    Input_DataDataReader _this,
    Input_Data *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_read_instance (
    Input_DataDataReader _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_take_instance (
    Input_DataDataReader _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_read_next_instance (
    Input_DataDataReader _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_take_next_instance (
    Input_DataDataReader _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_read_next_instance_w_condition (
    Input_DataDataReader _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_take_next_instance_w_condition (
    Input_DataDataReader _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_return_loan (
    Input_DataDataReader _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReader_get_key_value (
    Input_DataDataReader _this,
    Input_Data *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
Input_DataDataReader_lookup_instance (
    Input_DataDataReader _this,
    const Input_Data *key_holder
    );

#define Input_DataDataReaderView DDS_DataReaderView

#define Input_DataDataReaderView_enable DDS_Entity_enable

#define Input_DataDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define Input_DataDataReaderView_get_qos DDS_DataReaderView_get_qos

#define Input_DataDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define Input_DataDataReaderView_set_qos DDS_DataReaderView_set_qos

#define Input_DataDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define Input_DataDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define Input_DataDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define Input_DataDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_read (
    Input_DataDataReaderView _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_take (
    Input_DataDataReaderView _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_read_next_sample (
    Input_DataDataReaderView _this,
    Input_Data *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_take_next_sample (
    Input_DataDataReaderView _this,
    Input_Data *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_read_instance (
    Input_DataDataReaderView _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_take_instance (
    Input_DataDataReaderView _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_read_next_instance (
    Input_DataDataReaderView _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_take_next_instance (
    Input_DataDataReaderView _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_return_loan (
    Input_DataDataReaderView _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_read_w_condition (
    Input_DataDataReaderView _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_take_w_condition (
    Input_DataDataReaderView _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_read_next_instance_w_condition (
    Input_DataDataReaderView _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_take_next_instance_w_condition (
    Input_DataDataReaderView _this,
    DDS_sequence_Input_Data *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Input_DataDataReaderView_get_key_value (
    Input_DataDataReaderView _this,
    Input_Data *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
Input_DataDataReaderView_lookup_instance (
    Input_DataDataReaderView _this,
    Input_Data *key_holder
    );


#define Result_MulTypeSupport DDS_TypeSupport

DDSCOMU_API Result_MulTypeSupport
Result_MulTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulTypeSupport_register_type (
    Result_MulTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
Result_MulTypeSupport_get_type_name (
    Result_MulTypeSupport _this
    );

#ifndef _DDS_sequence_Result_Mul_defined
#define _DDS_sequence_Result_Mul_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    Result_Mul *_buffer;
    DDS_boolean _release;
} DDS_sequence_Result_Mul;

DDSCOMU_API DDS_sequence_Result_Mul *DDS_sequence_Result_Mul__alloc (void);
DDSCOMU_API Result_Mul *DDS_sequence_Result_Mul_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_Result_Mul_defined */

#define Result_MulDataWriter DDS_DataWriter

#define Result_MulDataWriter_enable DDS_Entity_enable

#define Result_MulDataWriter_get_status_changes DDS_Entity_get_status_changes

#define Result_MulDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define Result_MulDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define Result_MulDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define Result_MulDataWriter_get_listener DDS_DataWriter_get_listener

#define Result_MulDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define Result_MulDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define Result_MulDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define Result_MulDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define Result_MulDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define Result_MulDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define Result_MulDataWriter_get_publisher DDS_DataWriter_get_publisher

#define Result_MulDataWriter_get_qos DDS_DataWriter_get_qos

#define Result_MulDataWriter_get_topic DDS_DataWriter_get_topic

#define Result_MulDataWriter_set_listener DDS_DataWriter_set_listener

#define Result_MulDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
Result_MulDataWriter_register_instance (
    Result_MulDataWriter _this,
    const Result_Mul *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
Result_MulDataWriter_register_instance_w_timestamp (
    Result_MulDataWriter _this,
    const Result_Mul *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataWriter_unregister_instance (
    Result_MulDataWriter _this,
    const Result_Mul *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataWriter_unregister_instance_w_timestamp (
    Result_MulDataWriter _this,
    const Result_Mul *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataWriter_write (
    Result_MulDataWriter _this,
    const Result_Mul *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataWriter_write_w_timestamp (
    Result_MulDataWriter _this,
    const Result_Mul *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataWriter_dispose (
    Result_MulDataWriter _this,
    const Result_Mul *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataWriter_dispose_w_timestamp (
    Result_MulDataWriter _this,
    const Result_Mul *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataWriter_writedispose (
    Result_MulDataWriter _this,
    const Result_Mul *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataWriter_writedispose_w_timestamp (
    Result_MulDataWriter _this,
    const Result_Mul *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataWriter_get_key_value (
    Result_MulDataWriter _this,
    Result_Mul *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
Result_MulDataWriter_lookup_instance (
    Result_MulDataWriter _this,
    const Result_Mul *key_holder
    );

#define Result_MulDataReader DDS_DataReader

#define Result_MulDataReader_enable DDS_Entity_enable

#define Result_MulDataReader_get_status_changes DDS_Entity_get_status_changes

#define Result_MulDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define Result_MulDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define Result_MulDataReader_create_querycondition DDS_DataReader_create_querycondition

#define Result_MulDataReader_create_readcondition DDS_DataReader_create_readcondition

#define Result_MulDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define Result_MulDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define Result_MulDataReader_get_listener DDS_DataReader_get_listener

#define Result_MulDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define Result_MulDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define Result_MulDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define Result_MulDataReader_get_qos DDS_DataReader_get_qos

#define Result_MulDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define Result_MulDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define Result_MulDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define Result_MulDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define Result_MulDataReader_get_subscriber DDS_DataReader_get_subscriber

#define Result_MulDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define Result_MulDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define Result_MulDataReader_set_listener DDS_DataReader_set_listener

#define Result_MulDataReader_set_qos DDS_DataReader_set_qos

#define Result_MulDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_read (
    Result_MulDataReader _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_take (
    Result_MulDataReader _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_read_w_condition (
    Result_MulDataReader _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_take_w_condition (
    Result_MulDataReader _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_read_next_sample (
    Result_MulDataReader _this,
    Result_Mul *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_take_next_sample (
    Result_MulDataReader _this,
    Result_Mul *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_read_instance (
    Result_MulDataReader _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_take_instance (
    Result_MulDataReader _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_read_next_instance (
    Result_MulDataReader _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_take_next_instance (
    Result_MulDataReader _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_read_next_instance_w_condition (
    Result_MulDataReader _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_take_next_instance_w_condition (
    Result_MulDataReader _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_return_loan (
    Result_MulDataReader _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReader_get_key_value (
    Result_MulDataReader _this,
    Result_Mul *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
Result_MulDataReader_lookup_instance (
    Result_MulDataReader _this,
    const Result_Mul *key_holder
    );

#define Result_MulDataReaderView DDS_DataReaderView

#define Result_MulDataReaderView_enable DDS_Entity_enable

#define Result_MulDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define Result_MulDataReaderView_get_qos DDS_DataReaderView_get_qos

#define Result_MulDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define Result_MulDataReaderView_set_qos DDS_DataReaderView_set_qos

#define Result_MulDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define Result_MulDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define Result_MulDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define Result_MulDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_read (
    Result_MulDataReaderView _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_take (
    Result_MulDataReaderView _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_read_next_sample (
    Result_MulDataReaderView _this,
    Result_Mul *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_take_next_sample (
    Result_MulDataReaderView _this,
    Result_Mul *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_read_instance (
    Result_MulDataReaderView _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_take_instance (
    Result_MulDataReaderView _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_read_next_instance (
    Result_MulDataReaderView _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_take_next_instance (
    Result_MulDataReaderView _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_return_loan (
    Result_MulDataReaderView _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_read_w_condition (
    Result_MulDataReaderView _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_take_w_condition (
    Result_MulDataReaderView _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_read_next_instance_w_condition (
    Result_MulDataReaderView _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_take_next_instance_w_condition (
    Result_MulDataReaderView _this,
    DDS_sequence_Result_Mul *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
Result_MulDataReaderView_get_key_value (
    Result_MulDataReaderView _this,
    Result_Mul *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
Result_MulDataReaderView_lookup_instance (
    Result_MulDataReaderView _this,
    Result_Mul *key_holder
    );


#define ThroughputModule_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule_DataTypeTypeSupport
ThroughputModule_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeTypeSupport_register_type (
    ThroughputModule_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule_DataTypeTypeSupport_get_type_name (
    ThroughputModule_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule_DataType_defined
#define _DDS_sequence_ThroughputModule_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule_DataType *DDS_sequence_ThroughputModule_DataType__alloc (void);
DDSCOMU_API ThroughputModule_DataType *DDS_sequence_ThroughputModule_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule_DataType_defined */

#define ThroughputModule_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule_DataTypeDataWriter_register_instance (
    ThroughputModule_DataTypeDataWriter _this,
    const ThroughputModule_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule_DataTypeDataWriter _this,
    const ThroughputModule_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataWriter_unregister_instance (
    ThroughputModule_DataTypeDataWriter _this,
    const ThroughputModule_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule_DataTypeDataWriter _this,
    const ThroughputModule_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataWriter_write (
    ThroughputModule_DataTypeDataWriter _this,
    const ThroughputModule_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule_DataTypeDataWriter _this,
    const ThroughputModule_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataWriter_dispose (
    ThroughputModule_DataTypeDataWriter _this,
    const ThroughputModule_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule_DataTypeDataWriter _this,
    const ThroughputModule_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataWriter_writedispose (
    ThroughputModule_DataTypeDataWriter _this,
    const ThroughputModule_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule_DataTypeDataWriter _this,
    const ThroughputModule_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataWriter_get_key_value (
    ThroughputModule_DataTypeDataWriter _this,
    ThroughputModule_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule_DataTypeDataWriter_lookup_instance (
    ThroughputModule_DataTypeDataWriter _this,
    const ThroughputModule_DataType *key_holder
    );

#define ThroughputModule_DataTypeDataReader DDS_DataReader

#define ThroughputModule_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_read (
    ThroughputModule_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_take (
    ThroughputModule_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_read_w_condition (
    ThroughputModule_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_take_w_condition (
    ThroughputModule_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_read_next_sample (
    ThroughputModule_DataTypeDataReader _this,
    ThroughputModule_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_take_next_sample (
    ThroughputModule_DataTypeDataReader _this,
    ThroughputModule_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_read_instance (
    ThroughputModule_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_take_instance (
    ThroughputModule_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_read_next_instance (
    ThroughputModule_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_take_next_instance (
    ThroughputModule_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_return_loan (
    ThroughputModule_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReader_get_key_value (
    ThroughputModule_DataTypeDataReader _this,
    ThroughputModule_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule_DataTypeDataReader_lookup_instance (
    ThroughputModule_DataTypeDataReader _this,
    const ThroughputModule_DataType *key_holder
    );

#define ThroughputModule_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_read (
    ThroughputModule_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_take (
    ThroughputModule_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_read_next_sample (
    ThroughputModule_DataTypeDataReaderView _this,
    ThroughputModule_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_take_next_sample (
    ThroughputModule_DataTypeDataReaderView _this,
    ThroughputModule_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_read_instance (
    ThroughputModule_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_take_instance (
    ThroughputModule_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_read_next_instance (
    ThroughputModule_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_take_next_instance (
    ThroughputModule_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_return_loan (
    ThroughputModule_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_read_w_condition (
    ThroughputModule_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_take_w_condition (
    ThroughputModule_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule_DataTypeDataReaderView_get_key_value (
    ThroughputModule_DataTypeDataReaderView _this,
    ThroughputModule_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule_DataTypeDataReaderView_lookup_instance (
    ThroughputModule_DataTypeDataReaderView _this,
    ThroughputModule_DataType *key_holder
    );


#define ThroughputModule128_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule128_DataTypeTypeSupport
ThroughputModule128_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeTypeSupport_register_type (
    ThroughputModule128_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule128_DataTypeTypeSupport_get_type_name (
    ThroughputModule128_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule128_DataType_defined
#define _DDS_sequence_ThroughputModule128_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule128_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule128_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule128_DataType *DDS_sequence_ThroughputModule128_DataType__alloc (void);
DDSCOMU_API ThroughputModule128_DataType *DDS_sequence_ThroughputModule128_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule128_DataType_defined */

#define ThroughputModule128_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule128_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule128_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule128_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule128_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule128_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule128_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule128_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule128_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule128_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule128_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule128_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule128_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule128_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule128_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule128_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule128_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule128_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule128_DataTypeDataWriter_register_instance (
    ThroughputModule128_DataTypeDataWriter _this,
    const ThroughputModule128_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule128_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule128_DataTypeDataWriter _this,
    const ThroughputModule128_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataWriter_unregister_instance (
    ThroughputModule128_DataTypeDataWriter _this,
    const ThroughputModule128_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule128_DataTypeDataWriter _this,
    const ThroughputModule128_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataWriter_write (
    ThroughputModule128_DataTypeDataWriter _this,
    const ThroughputModule128_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule128_DataTypeDataWriter _this,
    const ThroughputModule128_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataWriter_dispose (
    ThroughputModule128_DataTypeDataWriter _this,
    const ThroughputModule128_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule128_DataTypeDataWriter _this,
    const ThroughputModule128_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataWriter_writedispose (
    ThroughputModule128_DataTypeDataWriter _this,
    const ThroughputModule128_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule128_DataTypeDataWriter _this,
    const ThroughputModule128_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataWriter_get_key_value (
    ThroughputModule128_DataTypeDataWriter _this,
    ThroughputModule128_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule128_DataTypeDataWriter_lookup_instance (
    ThroughputModule128_DataTypeDataWriter _this,
    const ThroughputModule128_DataType *key_holder
    );

#define ThroughputModule128_DataTypeDataReader DDS_DataReader

#define ThroughputModule128_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule128_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule128_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule128_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule128_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule128_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule128_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule128_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule128_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule128_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule128_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule128_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule128_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule128_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule128_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule128_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule128_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule128_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule128_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule128_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule128_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule128_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule128_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_read (
    ThroughputModule128_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_take (
    ThroughputModule128_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_read_w_condition (
    ThroughputModule128_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_take_w_condition (
    ThroughputModule128_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_read_next_sample (
    ThroughputModule128_DataTypeDataReader _this,
    ThroughputModule128_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_take_next_sample (
    ThroughputModule128_DataTypeDataReader _this,
    ThroughputModule128_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_read_instance (
    ThroughputModule128_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_take_instance (
    ThroughputModule128_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_read_next_instance (
    ThroughputModule128_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_take_next_instance (
    ThroughputModule128_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule128_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule128_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_return_loan (
    ThroughputModule128_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReader_get_key_value (
    ThroughputModule128_DataTypeDataReader _this,
    ThroughputModule128_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule128_DataTypeDataReader_lookup_instance (
    ThroughputModule128_DataTypeDataReader _this,
    const ThroughputModule128_DataType *key_holder
    );

#define ThroughputModule128_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule128_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule128_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule128_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule128_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule128_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule128_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule128_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule128_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule128_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_read (
    ThroughputModule128_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_take (
    ThroughputModule128_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_read_next_sample (
    ThroughputModule128_DataTypeDataReaderView _this,
    ThroughputModule128_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_take_next_sample (
    ThroughputModule128_DataTypeDataReaderView _this,
    ThroughputModule128_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_read_instance (
    ThroughputModule128_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_take_instance (
    ThroughputModule128_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_read_next_instance (
    ThroughputModule128_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_take_next_instance (
    ThroughputModule128_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_return_loan (
    ThroughputModule128_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_read_w_condition (
    ThroughputModule128_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_take_w_condition (
    ThroughputModule128_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule128_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule128_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128_DataTypeDataReaderView_get_key_value (
    ThroughputModule128_DataTypeDataReaderView _this,
    ThroughputModule128_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule128_DataTypeDataReaderView_lookup_instance (
    ThroughputModule128_DataTypeDataReaderView _this,
    ThroughputModule128_DataType *key_holder
    );


#define ThroughputModule256_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule256_DataTypeTypeSupport
ThroughputModule256_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeTypeSupport_register_type (
    ThroughputModule256_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule256_DataTypeTypeSupport_get_type_name (
    ThroughputModule256_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule256_DataType_defined
#define _DDS_sequence_ThroughputModule256_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule256_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule256_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule256_DataType *DDS_sequence_ThroughputModule256_DataType__alloc (void);
DDSCOMU_API ThroughputModule256_DataType *DDS_sequence_ThroughputModule256_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule256_DataType_defined */

#define ThroughputModule256_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule256_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule256_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule256_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule256_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule256_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule256_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule256_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule256_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule256_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule256_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule256_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule256_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule256_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule256_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule256_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule256_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule256_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule256_DataTypeDataWriter_register_instance (
    ThroughputModule256_DataTypeDataWriter _this,
    const ThroughputModule256_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule256_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule256_DataTypeDataWriter _this,
    const ThroughputModule256_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataWriter_unregister_instance (
    ThroughputModule256_DataTypeDataWriter _this,
    const ThroughputModule256_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule256_DataTypeDataWriter _this,
    const ThroughputModule256_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataWriter_write (
    ThroughputModule256_DataTypeDataWriter _this,
    const ThroughputModule256_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule256_DataTypeDataWriter _this,
    const ThroughputModule256_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataWriter_dispose (
    ThroughputModule256_DataTypeDataWriter _this,
    const ThroughputModule256_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule256_DataTypeDataWriter _this,
    const ThroughputModule256_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataWriter_writedispose (
    ThroughputModule256_DataTypeDataWriter _this,
    const ThroughputModule256_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule256_DataTypeDataWriter _this,
    const ThroughputModule256_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataWriter_get_key_value (
    ThroughputModule256_DataTypeDataWriter _this,
    ThroughputModule256_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule256_DataTypeDataWriter_lookup_instance (
    ThroughputModule256_DataTypeDataWriter _this,
    const ThroughputModule256_DataType *key_holder
    );

#define ThroughputModule256_DataTypeDataReader DDS_DataReader

#define ThroughputModule256_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule256_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule256_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule256_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule256_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule256_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule256_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule256_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule256_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule256_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule256_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule256_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule256_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule256_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule256_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule256_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule256_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule256_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule256_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule256_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule256_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule256_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule256_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_read (
    ThroughputModule256_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_take (
    ThroughputModule256_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_read_w_condition (
    ThroughputModule256_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_take_w_condition (
    ThroughputModule256_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_read_next_sample (
    ThroughputModule256_DataTypeDataReader _this,
    ThroughputModule256_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_take_next_sample (
    ThroughputModule256_DataTypeDataReader _this,
    ThroughputModule256_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_read_instance (
    ThroughputModule256_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_take_instance (
    ThroughputModule256_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_read_next_instance (
    ThroughputModule256_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_take_next_instance (
    ThroughputModule256_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule256_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule256_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_return_loan (
    ThroughputModule256_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReader_get_key_value (
    ThroughputModule256_DataTypeDataReader _this,
    ThroughputModule256_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule256_DataTypeDataReader_lookup_instance (
    ThroughputModule256_DataTypeDataReader _this,
    const ThroughputModule256_DataType *key_holder
    );

#define ThroughputModule256_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule256_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule256_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule256_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule256_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule256_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule256_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule256_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule256_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule256_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_read (
    ThroughputModule256_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_take (
    ThroughputModule256_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_read_next_sample (
    ThroughputModule256_DataTypeDataReaderView _this,
    ThroughputModule256_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_take_next_sample (
    ThroughputModule256_DataTypeDataReaderView _this,
    ThroughputModule256_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_read_instance (
    ThroughputModule256_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_take_instance (
    ThroughputModule256_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_read_next_instance (
    ThroughputModule256_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_take_next_instance (
    ThroughputModule256_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_return_loan (
    ThroughputModule256_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_read_w_condition (
    ThroughputModule256_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_take_w_condition (
    ThroughputModule256_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule256_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule256_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256_DataTypeDataReaderView_get_key_value (
    ThroughputModule256_DataTypeDataReaderView _this,
    ThroughputModule256_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule256_DataTypeDataReaderView_lookup_instance (
    ThroughputModule256_DataTypeDataReaderView _this,
    ThroughputModule256_DataType *key_holder
    );


#define ThroughputModule512_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule512_DataTypeTypeSupport
ThroughputModule512_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeTypeSupport_register_type (
    ThroughputModule512_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule512_DataTypeTypeSupport_get_type_name (
    ThroughputModule512_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule512_DataType_defined
#define _DDS_sequence_ThroughputModule512_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule512_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule512_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule512_DataType *DDS_sequence_ThroughputModule512_DataType__alloc (void);
DDSCOMU_API ThroughputModule512_DataType *DDS_sequence_ThroughputModule512_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule512_DataType_defined */

#define ThroughputModule512_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule512_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule512_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule512_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule512_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule512_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule512_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule512_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule512_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule512_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule512_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule512_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule512_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule512_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule512_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule512_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule512_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule512_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule512_DataTypeDataWriter_register_instance (
    ThroughputModule512_DataTypeDataWriter _this,
    const ThroughputModule512_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule512_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule512_DataTypeDataWriter _this,
    const ThroughputModule512_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataWriter_unregister_instance (
    ThroughputModule512_DataTypeDataWriter _this,
    const ThroughputModule512_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule512_DataTypeDataWriter _this,
    const ThroughputModule512_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataWriter_write (
    ThroughputModule512_DataTypeDataWriter _this,
    const ThroughputModule512_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule512_DataTypeDataWriter _this,
    const ThroughputModule512_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataWriter_dispose (
    ThroughputModule512_DataTypeDataWriter _this,
    const ThroughputModule512_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule512_DataTypeDataWriter _this,
    const ThroughputModule512_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataWriter_writedispose (
    ThroughputModule512_DataTypeDataWriter _this,
    const ThroughputModule512_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule512_DataTypeDataWriter _this,
    const ThroughputModule512_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataWriter_get_key_value (
    ThroughputModule512_DataTypeDataWriter _this,
    ThroughputModule512_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule512_DataTypeDataWriter_lookup_instance (
    ThroughputModule512_DataTypeDataWriter _this,
    const ThroughputModule512_DataType *key_holder
    );

#define ThroughputModule512_DataTypeDataReader DDS_DataReader

#define ThroughputModule512_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule512_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule512_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule512_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule512_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule512_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule512_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule512_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule512_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule512_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule512_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule512_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule512_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule512_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule512_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule512_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule512_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule512_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule512_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule512_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule512_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule512_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule512_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_read (
    ThroughputModule512_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_take (
    ThroughputModule512_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_read_w_condition (
    ThroughputModule512_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_take_w_condition (
    ThroughputModule512_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_read_next_sample (
    ThroughputModule512_DataTypeDataReader _this,
    ThroughputModule512_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_take_next_sample (
    ThroughputModule512_DataTypeDataReader _this,
    ThroughputModule512_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_read_instance (
    ThroughputModule512_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_take_instance (
    ThroughputModule512_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_read_next_instance (
    ThroughputModule512_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_take_next_instance (
    ThroughputModule512_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule512_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule512_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_return_loan (
    ThroughputModule512_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReader_get_key_value (
    ThroughputModule512_DataTypeDataReader _this,
    ThroughputModule512_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule512_DataTypeDataReader_lookup_instance (
    ThroughputModule512_DataTypeDataReader _this,
    const ThroughputModule512_DataType *key_holder
    );

#define ThroughputModule512_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule512_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule512_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule512_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule512_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule512_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule512_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule512_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule512_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule512_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_read (
    ThroughputModule512_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_take (
    ThroughputModule512_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_read_next_sample (
    ThroughputModule512_DataTypeDataReaderView _this,
    ThroughputModule512_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_take_next_sample (
    ThroughputModule512_DataTypeDataReaderView _this,
    ThroughputModule512_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_read_instance (
    ThroughputModule512_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_take_instance (
    ThroughputModule512_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_read_next_instance (
    ThroughputModule512_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_take_next_instance (
    ThroughputModule512_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_return_loan (
    ThroughputModule512_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_read_w_condition (
    ThroughputModule512_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_take_w_condition (
    ThroughputModule512_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule512_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule512_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512_DataTypeDataReaderView_get_key_value (
    ThroughputModule512_DataTypeDataReaderView _this,
    ThroughputModule512_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule512_DataTypeDataReaderView_lookup_instance (
    ThroughputModule512_DataTypeDataReaderView _this,
    ThroughputModule512_DataType *key_holder
    );


#define ThroughputModule1024_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule1024_DataTypeTypeSupport
ThroughputModule1024_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeTypeSupport_register_type (
    ThroughputModule1024_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule1024_DataTypeTypeSupport_get_type_name (
    ThroughputModule1024_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule1024_DataType_defined
#define _DDS_sequence_ThroughputModule1024_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule1024_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule1024_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule1024_DataType *DDS_sequence_ThroughputModule1024_DataType__alloc (void);
DDSCOMU_API ThroughputModule1024_DataType *DDS_sequence_ThroughputModule1024_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule1024_DataType_defined */

#define ThroughputModule1024_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule1024_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule1024_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule1024_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule1024_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule1024_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule1024_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule1024_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule1024_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule1024_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule1024_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule1024_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule1024_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule1024_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule1024_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule1024_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule1024_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule1024_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule1024_DataTypeDataWriter_register_instance (
    ThroughputModule1024_DataTypeDataWriter _this,
    const ThroughputModule1024_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule1024_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule1024_DataTypeDataWriter _this,
    const ThroughputModule1024_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataWriter_unregister_instance (
    ThroughputModule1024_DataTypeDataWriter _this,
    const ThroughputModule1024_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule1024_DataTypeDataWriter _this,
    const ThroughputModule1024_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataWriter_write (
    ThroughputModule1024_DataTypeDataWriter _this,
    const ThroughputModule1024_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule1024_DataTypeDataWriter _this,
    const ThroughputModule1024_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataWriter_dispose (
    ThroughputModule1024_DataTypeDataWriter _this,
    const ThroughputModule1024_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule1024_DataTypeDataWriter _this,
    const ThroughputModule1024_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataWriter_writedispose (
    ThroughputModule1024_DataTypeDataWriter _this,
    const ThroughputModule1024_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule1024_DataTypeDataWriter _this,
    const ThroughputModule1024_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataWriter_get_key_value (
    ThroughputModule1024_DataTypeDataWriter _this,
    ThroughputModule1024_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule1024_DataTypeDataWriter_lookup_instance (
    ThroughputModule1024_DataTypeDataWriter _this,
    const ThroughputModule1024_DataType *key_holder
    );

#define ThroughputModule1024_DataTypeDataReader DDS_DataReader

#define ThroughputModule1024_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule1024_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule1024_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule1024_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule1024_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule1024_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule1024_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule1024_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule1024_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule1024_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule1024_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule1024_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule1024_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule1024_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule1024_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule1024_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule1024_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule1024_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule1024_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule1024_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule1024_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule1024_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule1024_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_read (
    ThroughputModule1024_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_take (
    ThroughputModule1024_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_read_w_condition (
    ThroughputModule1024_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_take_w_condition (
    ThroughputModule1024_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_read_next_sample (
    ThroughputModule1024_DataTypeDataReader _this,
    ThroughputModule1024_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_take_next_sample (
    ThroughputModule1024_DataTypeDataReader _this,
    ThroughputModule1024_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_read_instance (
    ThroughputModule1024_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_take_instance (
    ThroughputModule1024_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_read_next_instance (
    ThroughputModule1024_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_take_next_instance (
    ThroughputModule1024_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule1024_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule1024_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_return_loan (
    ThroughputModule1024_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReader_get_key_value (
    ThroughputModule1024_DataTypeDataReader _this,
    ThroughputModule1024_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule1024_DataTypeDataReader_lookup_instance (
    ThroughputModule1024_DataTypeDataReader _this,
    const ThroughputModule1024_DataType *key_holder
    );

#define ThroughputModule1024_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule1024_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule1024_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule1024_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule1024_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule1024_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule1024_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule1024_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule1024_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule1024_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_read (
    ThroughputModule1024_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_take (
    ThroughputModule1024_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_read_next_sample (
    ThroughputModule1024_DataTypeDataReaderView _this,
    ThroughputModule1024_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_take_next_sample (
    ThroughputModule1024_DataTypeDataReaderView _this,
    ThroughputModule1024_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_read_instance (
    ThroughputModule1024_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_take_instance (
    ThroughputModule1024_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_read_next_instance (
    ThroughputModule1024_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_take_next_instance (
    ThroughputModule1024_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_return_loan (
    ThroughputModule1024_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_read_w_condition (
    ThroughputModule1024_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_take_w_condition (
    ThroughputModule1024_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule1024_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule1024_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1024_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1024_DataTypeDataReaderView_get_key_value (
    ThroughputModule1024_DataTypeDataReaderView _this,
    ThroughputModule1024_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule1024_DataTypeDataReaderView_lookup_instance (
    ThroughputModule1024_DataTypeDataReaderView _this,
    ThroughputModule1024_DataType *key_holder
    );


#define ThroughputModule2048_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule2048_DataTypeTypeSupport
ThroughputModule2048_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeTypeSupport_register_type (
    ThroughputModule2048_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule2048_DataTypeTypeSupport_get_type_name (
    ThroughputModule2048_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule2048_DataType_defined
#define _DDS_sequence_ThroughputModule2048_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule2048_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule2048_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule2048_DataType *DDS_sequence_ThroughputModule2048_DataType__alloc (void);
DDSCOMU_API ThroughputModule2048_DataType *DDS_sequence_ThroughputModule2048_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule2048_DataType_defined */

#define ThroughputModule2048_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule2048_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule2048_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule2048_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule2048_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule2048_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule2048_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule2048_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule2048_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule2048_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule2048_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule2048_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule2048_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule2048_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule2048_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule2048_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule2048_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule2048_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule2048_DataTypeDataWriter_register_instance (
    ThroughputModule2048_DataTypeDataWriter _this,
    const ThroughputModule2048_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule2048_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule2048_DataTypeDataWriter _this,
    const ThroughputModule2048_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataWriter_unregister_instance (
    ThroughputModule2048_DataTypeDataWriter _this,
    const ThroughputModule2048_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule2048_DataTypeDataWriter _this,
    const ThroughputModule2048_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataWriter_write (
    ThroughputModule2048_DataTypeDataWriter _this,
    const ThroughputModule2048_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule2048_DataTypeDataWriter _this,
    const ThroughputModule2048_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataWriter_dispose (
    ThroughputModule2048_DataTypeDataWriter _this,
    const ThroughputModule2048_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule2048_DataTypeDataWriter _this,
    const ThroughputModule2048_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataWriter_writedispose (
    ThroughputModule2048_DataTypeDataWriter _this,
    const ThroughputModule2048_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule2048_DataTypeDataWriter _this,
    const ThroughputModule2048_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataWriter_get_key_value (
    ThroughputModule2048_DataTypeDataWriter _this,
    ThroughputModule2048_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule2048_DataTypeDataWriter_lookup_instance (
    ThroughputModule2048_DataTypeDataWriter _this,
    const ThroughputModule2048_DataType *key_holder
    );

#define ThroughputModule2048_DataTypeDataReader DDS_DataReader

#define ThroughputModule2048_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule2048_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule2048_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule2048_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule2048_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule2048_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule2048_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule2048_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule2048_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule2048_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule2048_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule2048_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule2048_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule2048_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule2048_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule2048_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule2048_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule2048_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule2048_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule2048_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule2048_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule2048_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule2048_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_read (
    ThroughputModule2048_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_take (
    ThroughputModule2048_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_read_w_condition (
    ThroughputModule2048_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_take_w_condition (
    ThroughputModule2048_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_read_next_sample (
    ThroughputModule2048_DataTypeDataReader _this,
    ThroughputModule2048_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_take_next_sample (
    ThroughputModule2048_DataTypeDataReader _this,
    ThroughputModule2048_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_read_instance (
    ThroughputModule2048_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_take_instance (
    ThroughputModule2048_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_read_next_instance (
    ThroughputModule2048_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_take_next_instance (
    ThroughputModule2048_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule2048_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule2048_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_return_loan (
    ThroughputModule2048_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReader_get_key_value (
    ThroughputModule2048_DataTypeDataReader _this,
    ThroughputModule2048_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule2048_DataTypeDataReader_lookup_instance (
    ThroughputModule2048_DataTypeDataReader _this,
    const ThroughputModule2048_DataType *key_holder
    );

#define ThroughputModule2048_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule2048_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule2048_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule2048_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule2048_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule2048_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule2048_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule2048_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule2048_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule2048_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_read (
    ThroughputModule2048_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_take (
    ThroughputModule2048_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_read_next_sample (
    ThroughputModule2048_DataTypeDataReaderView _this,
    ThroughputModule2048_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_take_next_sample (
    ThroughputModule2048_DataTypeDataReaderView _this,
    ThroughputModule2048_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_read_instance (
    ThroughputModule2048_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_take_instance (
    ThroughputModule2048_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_read_next_instance (
    ThroughputModule2048_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_take_next_instance (
    ThroughputModule2048_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_return_loan (
    ThroughputModule2048_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_read_w_condition (
    ThroughputModule2048_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_take_w_condition (
    ThroughputModule2048_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule2048_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule2048_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule2048_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule2048_DataTypeDataReaderView_get_key_value (
    ThroughputModule2048_DataTypeDataReaderView _this,
    ThroughputModule2048_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule2048_DataTypeDataReaderView_lookup_instance (
    ThroughputModule2048_DataTypeDataReaderView _this,
    ThroughputModule2048_DataType *key_holder
    );


#define ThroughputModule4096_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule4096_DataTypeTypeSupport
ThroughputModule4096_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeTypeSupport_register_type (
    ThroughputModule4096_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule4096_DataTypeTypeSupport_get_type_name (
    ThroughputModule4096_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule4096_DataType_defined
#define _DDS_sequence_ThroughputModule4096_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule4096_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule4096_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule4096_DataType *DDS_sequence_ThroughputModule4096_DataType__alloc (void);
DDSCOMU_API ThroughputModule4096_DataType *DDS_sequence_ThroughputModule4096_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule4096_DataType_defined */

#define ThroughputModule4096_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule4096_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule4096_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule4096_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule4096_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule4096_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule4096_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule4096_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule4096_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule4096_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule4096_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule4096_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule4096_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule4096_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule4096_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule4096_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule4096_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule4096_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule4096_DataTypeDataWriter_register_instance (
    ThroughputModule4096_DataTypeDataWriter _this,
    const ThroughputModule4096_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule4096_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule4096_DataTypeDataWriter _this,
    const ThroughputModule4096_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataWriter_unregister_instance (
    ThroughputModule4096_DataTypeDataWriter _this,
    const ThroughputModule4096_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule4096_DataTypeDataWriter _this,
    const ThroughputModule4096_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataWriter_write (
    ThroughputModule4096_DataTypeDataWriter _this,
    const ThroughputModule4096_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule4096_DataTypeDataWriter _this,
    const ThroughputModule4096_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataWriter_dispose (
    ThroughputModule4096_DataTypeDataWriter _this,
    const ThroughputModule4096_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule4096_DataTypeDataWriter _this,
    const ThroughputModule4096_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataWriter_writedispose (
    ThroughputModule4096_DataTypeDataWriter _this,
    const ThroughputModule4096_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule4096_DataTypeDataWriter _this,
    const ThroughputModule4096_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataWriter_get_key_value (
    ThroughputModule4096_DataTypeDataWriter _this,
    ThroughputModule4096_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule4096_DataTypeDataWriter_lookup_instance (
    ThroughputModule4096_DataTypeDataWriter _this,
    const ThroughputModule4096_DataType *key_holder
    );

#define ThroughputModule4096_DataTypeDataReader DDS_DataReader

#define ThroughputModule4096_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule4096_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule4096_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule4096_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule4096_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule4096_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule4096_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule4096_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule4096_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule4096_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule4096_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule4096_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule4096_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule4096_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule4096_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule4096_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule4096_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule4096_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule4096_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule4096_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule4096_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule4096_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule4096_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_read (
    ThroughputModule4096_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_take (
    ThroughputModule4096_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_read_w_condition (
    ThroughputModule4096_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_take_w_condition (
    ThroughputModule4096_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_read_next_sample (
    ThroughputModule4096_DataTypeDataReader _this,
    ThroughputModule4096_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_take_next_sample (
    ThroughputModule4096_DataTypeDataReader _this,
    ThroughputModule4096_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_read_instance (
    ThroughputModule4096_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_take_instance (
    ThroughputModule4096_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_read_next_instance (
    ThroughputModule4096_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_take_next_instance (
    ThroughputModule4096_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule4096_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule4096_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_return_loan (
    ThroughputModule4096_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReader_get_key_value (
    ThroughputModule4096_DataTypeDataReader _this,
    ThroughputModule4096_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule4096_DataTypeDataReader_lookup_instance (
    ThroughputModule4096_DataTypeDataReader _this,
    const ThroughputModule4096_DataType *key_holder
    );

#define ThroughputModule4096_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule4096_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule4096_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule4096_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule4096_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule4096_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule4096_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule4096_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule4096_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule4096_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_read (
    ThroughputModule4096_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_take (
    ThroughputModule4096_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_read_next_sample (
    ThroughputModule4096_DataTypeDataReaderView _this,
    ThroughputModule4096_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_take_next_sample (
    ThroughputModule4096_DataTypeDataReaderView _this,
    ThroughputModule4096_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_read_instance (
    ThroughputModule4096_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_take_instance (
    ThroughputModule4096_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_read_next_instance (
    ThroughputModule4096_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_take_next_instance (
    ThroughputModule4096_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_return_loan (
    ThroughputModule4096_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_read_w_condition (
    ThroughputModule4096_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_take_w_condition (
    ThroughputModule4096_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule4096_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule4096_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule4096_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule4096_DataTypeDataReaderView_get_key_value (
    ThroughputModule4096_DataTypeDataReaderView _this,
    ThroughputModule4096_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule4096_DataTypeDataReaderView_lookup_instance (
    ThroughputModule4096_DataTypeDataReaderView _this,
    ThroughputModule4096_DataType *key_holder
    );


#define ThroughputModule8192_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule8192_DataTypeTypeSupport
ThroughputModule8192_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeTypeSupport_register_type (
    ThroughputModule8192_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule8192_DataTypeTypeSupport_get_type_name (
    ThroughputModule8192_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule8192_DataType_defined
#define _DDS_sequence_ThroughputModule8192_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule8192_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule8192_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule8192_DataType *DDS_sequence_ThroughputModule8192_DataType__alloc (void);
DDSCOMU_API ThroughputModule8192_DataType *DDS_sequence_ThroughputModule8192_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule8192_DataType_defined */

#define ThroughputModule8192_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule8192_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule8192_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule8192_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule8192_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule8192_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule8192_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule8192_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule8192_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule8192_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule8192_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule8192_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule8192_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule8192_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule8192_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule8192_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule8192_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule8192_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule8192_DataTypeDataWriter_register_instance (
    ThroughputModule8192_DataTypeDataWriter _this,
    const ThroughputModule8192_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule8192_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule8192_DataTypeDataWriter _this,
    const ThroughputModule8192_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataWriter_unregister_instance (
    ThroughputModule8192_DataTypeDataWriter _this,
    const ThroughputModule8192_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule8192_DataTypeDataWriter _this,
    const ThroughputModule8192_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataWriter_write (
    ThroughputModule8192_DataTypeDataWriter _this,
    const ThroughputModule8192_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule8192_DataTypeDataWriter _this,
    const ThroughputModule8192_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataWriter_dispose (
    ThroughputModule8192_DataTypeDataWriter _this,
    const ThroughputModule8192_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule8192_DataTypeDataWriter _this,
    const ThroughputModule8192_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataWriter_writedispose (
    ThroughputModule8192_DataTypeDataWriter _this,
    const ThroughputModule8192_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule8192_DataTypeDataWriter _this,
    const ThroughputModule8192_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataWriter_get_key_value (
    ThroughputModule8192_DataTypeDataWriter _this,
    ThroughputModule8192_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule8192_DataTypeDataWriter_lookup_instance (
    ThroughputModule8192_DataTypeDataWriter _this,
    const ThroughputModule8192_DataType *key_holder
    );

#define ThroughputModule8192_DataTypeDataReader DDS_DataReader

#define ThroughputModule8192_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule8192_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule8192_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule8192_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule8192_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule8192_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule8192_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule8192_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule8192_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule8192_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule8192_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule8192_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule8192_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule8192_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule8192_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule8192_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule8192_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule8192_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule8192_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule8192_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule8192_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule8192_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule8192_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_read (
    ThroughputModule8192_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_take (
    ThroughputModule8192_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_read_w_condition (
    ThroughputModule8192_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_take_w_condition (
    ThroughputModule8192_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_read_next_sample (
    ThroughputModule8192_DataTypeDataReader _this,
    ThroughputModule8192_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_take_next_sample (
    ThroughputModule8192_DataTypeDataReader _this,
    ThroughputModule8192_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_read_instance (
    ThroughputModule8192_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_take_instance (
    ThroughputModule8192_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_read_next_instance (
    ThroughputModule8192_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_take_next_instance (
    ThroughputModule8192_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule8192_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule8192_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_return_loan (
    ThroughputModule8192_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReader_get_key_value (
    ThroughputModule8192_DataTypeDataReader _this,
    ThroughputModule8192_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule8192_DataTypeDataReader_lookup_instance (
    ThroughputModule8192_DataTypeDataReader _this,
    const ThroughputModule8192_DataType *key_holder
    );

#define ThroughputModule8192_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule8192_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule8192_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule8192_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule8192_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule8192_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule8192_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule8192_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule8192_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule8192_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_read (
    ThroughputModule8192_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_take (
    ThroughputModule8192_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_read_next_sample (
    ThroughputModule8192_DataTypeDataReaderView _this,
    ThroughputModule8192_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_take_next_sample (
    ThroughputModule8192_DataTypeDataReaderView _this,
    ThroughputModule8192_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_read_instance (
    ThroughputModule8192_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_take_instance (
    ThroughputModule8192_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_read_next_instance (
    ThroughputModule8192_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_take_next_instance (
    ThroughputModule8192_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_return_loan (
    ThroughputModule8192_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_read_w_condition (
    ThroughputModule8192_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_take_w_condition (
    ThroughputModule8192_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule8192_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule8192_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule8192_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule8192_DataTypeDataReaderView_get_key_value (
    ThroughputModule8192_DataTypeDataReaderView _this,
    ThroughputModule8192_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule8192_DataTypeDataReaderView_lookup_instance (
    ThroughputModule8192_DataTypeDataReaderView _this,
    ThroughputModule8192_DataType *key_holder
    );


#define ThroughputModule16384_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule16384_DataTypeTypeSupport
ThroughputModule16384_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeTypeSupport_register_type (
    ThroughputModule16384_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule16384_DataTypeTypeSupport_get_type_name (
    ThroughputModule16384_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule16384_DataType_defined
#define _DDS_sequence_ThroughputModule16384_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule16384_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule16384_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule16384_DataType *DDS_sequence_ThroughputModule16384_DataType__alloc (void);
DDSCOMU_API ThroughputModule16384_DataType *DDS_sequence_ThroughputModule16384_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule16384_DataType_defined */

#define ThroughputModule16384_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule16384_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule16384_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule16384_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule16384_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule16384_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule16384_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule16384_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule16384_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule16384_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule16384_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule16384_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule16384_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule16384_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule16384_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule16384_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule16384_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule16384_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule16384_DataTypeDataWriter_register_instance (
    ThroughputModule16384_DataTypeDataWriter _this,
    const ThroughputModule16384_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule16384_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule16384_DataTypeDataWriter _this,
    const ThroughputModule16384_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataWriter_unregister_instance (
    ThroughputModule16384_DataTypeDataWriter _this,
    const ThroughputModule16384_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule16384_DataTypeDataWriter _this,
    const ThroughputModule16384_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataWriter_write (
    ThroughputModule16384_DataTypeDataWriter _this,
    const ThroughputModule16384_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule16384_DataTypeDataWriter _this,
    const ThroughputModule16384_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataWriter_dispose (
    ThroughputModule16384_DataTypeDataWriter _this,
    const ThroughputModule16384_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule16384_DataTypeDataWriter _this,
    const ThroughputModule16384_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataWriter_writedispose (
    ThroughputModule16384_DataTypeDataWriter _this,
    const ThroughputModule16384_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule16384_DataTypeDataWriter _this,
    const ThroughputModule16384_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataWriter_get_key_value (
    ThroughputModule16384_DataTypeDataWriter _this,
    ThroughputModule16384_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule16384_DataTypeDataWriter_lookup_instance (
    ThroughputModule16384_DataTypeDataWriter _this,
    const ThroughputModule16384_DataType *key_holder
    );

#define ThroughputModule16384_DataTypeDataReader DDS_DataReader

#define ThroughputModule16384_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule16384_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule16384_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule16384_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule16384_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule16384_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule16384_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule16384_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule16384_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule16384_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule16384_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule16384_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule16384_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule16384_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule16384_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule16384_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule16384_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule16384_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule16384_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule16384_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule16384_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule16384_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule16384_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_read (
    ThroughputModule16384_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_take (
    ThroughputModule16384_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_read_w_condition (
    ThroughputModule16384_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_take_w_condition (
    ThroughputModule16384_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_read_next_sample (
    ThroughputModule16384_DataTypeDataReader _this,
    ThroughputModule16384_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_take_next_sample (
    ThroughputModule16384_DataTypeDataReader _this,
    ThroughputModule16384_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_read_instance (
    ThroughputModule16384_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_take_instance (
    ThroughputModule16384_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_read_next_instance (
    ThroughputModule16384_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_take_next_instance (
    ThroughputModule16384_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule16384_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule16384_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_return_loan (
    ThroughputModule16384_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReader_get_key_value (
    ThroughputModule16384_DataTypeDataReader _this,
    ThroughputModule16384_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule16384_DataTypeDataReader_lookup_instance (
    ThroughputModule16384_DataTypeDataReader _this,
    const ThroughputModule16384_DataType *key_holder
    );

#define ThroughputModule16384_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule16384_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule16384_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule16384_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule16384_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule16384_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule16384_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule16384_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule16384_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule16384_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_read (
    ThroughputModule16384_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_take (
    ThroughputModule16384_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_read_next_sample (
    ThroughputModule16384_DataTypeDataReaderView _this,
    ThroughputModule16384_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_take_next_sample (
    ThroughputModule16384_DataTypeDataReaderView _this,
    ThroughputModule16384_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_read_instance (
    ThroughputModule16384_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_take_instance (
    ThroughputModule16384_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_read_next_instance (
    ThroughputModule16384_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_take_next_instance (
    ThroughputModule16384_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_return_loan (
    ThroughputModule16384_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_read_w_condition (
    ThroughputModule16384_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_take_w_condition (
    ThroughputModule16384_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule16384_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule16384_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule16384_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule16384_DataTypeDataReaderView_get_key_value (
    ThroughputModule16384_DataTypeDataReaderView _this,
    ThroughputModule16384_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule16384_DataTypeDataReaderView_lookup_instance (
    ThroughputModule16384_DataTypeDataReaderView _this,
    ThroughputModule16384_DataType *key_holder
    );


#define ThroughputModule32768_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule32768_DataTypeTypeSupport
ThroughputModule32768_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeTypeSupport_register_type (
    ThroughputModule32768_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule32768_DataTypeTypeSupport_get_type_name (
    ThroughputModule32768_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule32768_DataType_defined
#define _DDS_sequence_ThroughputModule32768_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule32768_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule32768_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule32768_DataType *DDS_sequence_ThroughputModule32768_DataType__alloc (void);
DDSCOMU_API ThroughputModule32768_DataType *DDS_sequence_ThroughputModule32768_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule32768_DataType_defined */

#define ThroughputModule32768_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule32768_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule32768_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule32768_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule32768_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule32768_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule32768_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule32768_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule32768_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule32768_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule32768_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule32768_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule32768_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule32768_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule32768_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule32768_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule32768_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule32768_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule32768_DataTypeDataWriter_register_instance (
    ThroughputModule32768_DataTypeDataWriter _this,
    const ThroughputModule32768_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule32768_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule32768_DataTypeDataWriter _this,
    const ThroughputModule32768_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataWriter_unregister_instance (
    ThroughputModule32768_DataTypeDataWriter _this,
    const ThroughputModule32768_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule32768_DataTypeDataWriter _this,
    const ThroughputModule32768_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataWriter_write (
    ThroughputModule32768_DataTypeDataWriter _this,
    const ThroughputModule32768_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule32768_DataTypeDataWriter _this,
    const ThroughputModule32768_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataWriter_dispose (
    ThroughputModule32768_DataTypeDataWriter _this,
    const ThroughputModule32768_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule32768_DataTypeDataWriter _this,
    const ThroughputModule32768_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataWriter_writedispose (
    ThroughputModule32768_DataTypeDataWriter _this,
    const ThroughputModule32768_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule32768_DataTypeDataWriter _this,
    const ThroughputModule32768_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataWriter_get_key_value (
    ThroughputModule32768_DataTypeDataWriter _this,
    ThroughputModule32768_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule32768_DataTypeDataWriter_lookup_instance (
    ThroughputModule32768_DataTypeDataWriter _this,
    const ThroughputModule32768_DataType *key_holder
    );

#define ThroughputModule32768_DataTypeDataReader DDS_DataReader

#define ThroughputModule32768_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule32768_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule32768_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule32768_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule32768_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule32768_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule32768_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule32768_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule32768_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule32768_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule32768_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule32768_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule32768_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule32768_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule32768_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule32768_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule32768_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule32768_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule32768_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule32768_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule32768_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule32768_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule32768_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_read (
    ThroughputModule32768_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_take (
    ThroughputModule32768_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_read_w_condition (
    ThroughputModule32768_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_take_w_condition (
    ThroughputModule32768_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_read_next_sample (
    ThroughputModule32768_DataTypeDataReader _this,
    ThroughputModule32768_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_take_next_sample (
    ThroughputModule32768_DataTypeDataReader _this,
    ThroughputModule32768_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_read_instance (
    ThroughputModule32768_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_take_instance (
    ThroughputModule32768_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_read_next_instance (
    ThroughputModule32768_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_take_next_instance (
    ThroughputModule32768_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule32768_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule32768_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_return_loan (
    ThroughputModule32768_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReader_get_key_value (
    ThroughputModule32768_DataTypeDataReader _this,
    ThroughputModule32768_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule32768_DataTypeDataReader_lookup_instance (
    ThroughputModule32768_DataTypeDataReader _this,
    const ThroughputModule32768_DataType *key_holder
    );

#define ThroughputModule32768_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule32768_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule32768_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule32768_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule32768_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule32768_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule32768_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule32768_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule32768_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule32768_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_read (
    ThroughputModule32768_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_take (
    ThroughputModule32768_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_read_next_sample (
    ThroughputModule32768_DataTypeDataReaderView _this,
    ThroughputModule32768_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_take_next_sample (
    ThroughputModule32768_DataTypeDataReaderView _this,
    ThroughputModule32768_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_read_instance (
    ThroughputModule32768_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_take_instance (
    ThroughputModule32768_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_read_next_instance (
    ThroughputModule32768_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_take_next_instance (
    ThroughputModule32768_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_return_loan (
    ThroughputModule32768_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_read_w_condition (
    ThroughputModule32768_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_take_w_condition (
    ThroughputModule32768_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule32768_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule32768_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule32768_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule32768_DataTypeDataReaderView_get_key_value (
    ThroughputModule32768_DataTypeDataReaderView _this,
    ThroughputModule32768_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule32768_DataTypeDataReaderView_lookup_instance (
    ThroughputModule32768_DataTypeDataReaderView _this,
    ThroughputModule32768_DataType *key_holder
    );


#define ThroughputModule65536_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule65536_DataTypeTypeSupport
ThroughputModule65536_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeTypeSupport_register_type (
    ThroughputModule65536_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule65536_DataTypeTypeSupport_get_type_name (
    ThroughputModule65536_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule65536_DataType_defined
#define _DDS_sequence_ThroughputModule65536_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule65536_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule65536_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule65536_DataType *DDS_sequence_ThroughputModule65536_DataType__alloc (void);
DDSCOMU_API ThroughputModule65536_DataType *DDS_sequence_ThroughputModule65536_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule65536_DataType_defined */

#define ThroughputModule65536_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule65536_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule65536_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule65536_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule65536_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule65536_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule65536_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule65536_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule65536_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule65536_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule65536_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule65536_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule65536_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule65536_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule65536_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule65536_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule65536_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule65536_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule65536_DataTypeDataWriter_register_instance (
    ThroughputModule65536_DataTypeDataWriter _this,
    const ThroughputModule65536_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule65536_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule65536_DataTypeDataWriter _this,
    const ThroughputModule65536_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataWriter_unregister_instance (
    ThroughputModule65536_DataTypeDataWriter _this,
    const ThroughputModule65536_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule65536_DataTypeDataWriter _this,
    const ThroughputModule65536_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataWriter_write (
    ThroughputModule65536_DataTypeDataWriter _this,
    const ThroughputModule65536_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule65536_DataTypeDataWriter _this,
    const ThroughputModule65536_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataWriter_dispose (
    ThroughputModule65536_DataTypeDataWriter _this,
    const ThroughputModule65536_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule65536_DataTypeDataWriter _this,
    const ThroughputModule65536_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataWriter_writedispose (
    ThroughputModule65536_DataTypeDataWriter _this,
    const ThroughputModule65536_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule65536_DataTypeDataWriter _this,
    const ThroughputModule65536_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataWriter_get_key_value (
    ThroughputModule65536_DataTypeDataWriter _this,
    ThroughputModule65536_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule65536_DataTypeDataWriter_lookup_instance (
    ThroughputModule65536_DataTypeDataWriter _this,
    const ThroughputModule65536_DataType *key_holder
    );

#define ThroughputModule65536_DataTypeDataReader DDS_DataReader

#define ThroughputModule65536_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule65536_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule65536_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule65536_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule65536_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule65536_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule65536_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule65536_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule65536_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule65536_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule65536_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule65536_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule65536_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule65536_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule65536_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule65536_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule65536_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule65536_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule65536_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule65536_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule65536_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule65536_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule65536_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_read (
    ThroughputModule65536_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_take (
    ThroughputModule65536_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_read_w_condition (
    ThroughputModule65536_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_take_w_condition (
    ThroughputModule65536_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_read_next_sample (
    ThroughputModule65536_DataTypeDataReader _this,
    ThroughputModule65536_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_take_next_sample (
    ThroughputModule65536_DataTypeDataReader _this,
    ThroughputModule65536_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_read_instance (
    ThroughputModule65536_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_take_instance (
    ThroughputModule65536_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_read_next_instance (
    ThroughputModule65536_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_take_next_instance (
    ThroughputModule65536_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule65536_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule65536_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_return_loan (
    ThroughputModule65536_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReader_get_key_value (
    ThroughputModule65536_DataTypeDataReader _this,
    ThroughputModule65536_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule65536_DataTypeDataReader_lookup_instance (
    ThroughputModule65536_DataTypeDataReader _this,
    const ThroughputModule65536_DataType *key_holder
    );

#define ThroughputModule65536_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule65536_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule65536_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule65536_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule65536_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule65536_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule65536_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule65536_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule65536_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule65536_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_read (
    ThroughputModule65536_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_take (
    ThroughputModule65536_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_read_next_sample (
    ThroughputModule65536_DataTypeDataReaderView _this,
    ThroughputModule65536_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_take_next_sample (
    ThroughputModule65536_DataTypeDataReaderView _this,
    ThroughputModule65536_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_read_instance (
    ThroughputModule65536_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_take_instance (
    ThroughputModule65536_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_read_next_instance (
    ThroughputModule65536_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_take_next_instance (
    ThroughputModule65536_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_return_loan (
    ThroughputModule65536_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_read_w_condition (
    ThroughputModule65536_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_take_w_condition (
    ThroughputModule65536_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule65536_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule65536_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule65536_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule65536_DataTypeDataReaderView_get_key_value (
    ThroughputModule65536_DataTypeDataReaderView _this,
    ThroughputModule65536_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule65536_DataTypeDataReaderView_lookup_instance (
    ThroughputModule65536_DataTypeDataReaderView _this,
    ThroughputModule65536_DataType *key_holder
    );


#define ThroughputModule128K_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule128K_DataTypeTypeSupport
ThroughputModule128K_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeTypeSupport_register_type (
    ThroughputModule128K_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule128K_DataTypeTypeSupport_get_type_name (
    ThroughputModule128K_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule128K_DataType_defined
#define _DDS_sequence_ThroughputModule128K_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule128K_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule128K_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule128K_DataType *DDS_sequence_ThroughputModule128K_DataType__alloc (void);
DDSCOMU_API ThroughputModule128K_DataType *DDS_sequence_ThroughputModule128K_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule128K_DataType_defined */

#define ThroughputModule128K_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule128K_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule128K_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule128K_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule128K_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule128K_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule128K_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule128K_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule128K_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule128K_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule128K_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule128K_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule128K_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule128K_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule128K_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule128K_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule128K_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule128K_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule128K_DataTypeDataWriter_register_instance (
    ThroughputModule128K_DataTypeDataWriter _this,
    const ThroughputModule128K_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule128K_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule128K_DataTypeDataWriter _this,
    const ThroughputModule128K_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataWriter_unregister_instance (
    ThroughputModule128K_DataTypeDataWriter _this,
    const ThroughputModule128K_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule128K_DataTypeDataWriter _this,
    const ThroughputModule128K_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataWriter_write (
    ThroughputModule128K_DataTypeDataWriter _this,
    const ThroughputModule128K_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule128K_DataTypeDataWriter _this,
    const ThroughputModule128K_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataWriter_dispose (
    ThroughputModule128K_DataTypeDataWriter _this,
    const ThroughputModule128K_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule128K_DataTypeDataWriter _this,
    const ThroughputModule128K_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataWriter_writedispose (
    ThroughputModule128K_DataTypeDataWriter _this,
    const ThroughputModule128K_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule128K_DataTypeDataWriter _this,
    const ThroughputModule128K_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataWriter_get_key_value (
    ThroughputModule128K_DataTypeDataWriter _this,
    ThroughputModule128K_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule128K_DataTypeDataWriter_lookup_instance (
    ThroughputModule128K_DataTypeDataWriter _this,
    const ThroughputModule128K_DataType *key_holder
    );

#define ThroughputModule128K_DataTypeDataReader DDS_DataReader

#define ThroughputModule128K_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule128K_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule128K_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule128K_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule128K_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule128K_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule128K_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule128K_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule128K_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule128K_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule128K_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule128K_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule128K_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule128K_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule128K_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule128K_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule128K_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule128K_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule128K_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule128K_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule128K_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule128K_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule128K_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_read (
    ThroughputModule128K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_take (
    ThroughputModule128K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_read_w_condition (
    ThroughputModule128K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_take_w_condition (
    ThroughputModule128K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_read_next_sample (
    ThroughputModule128K_DataTypeDataReader _this,
    ThroughputModule128K_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_take_next_sample (
    ThroughputModule128K_DataTypeDataReader _this,
    ThroughputModule128K_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_read_instance (
    ThroughputModule128K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_take_instance (
    ThroughputModule128K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_read_next_instance (
    ThroughputModule128K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_take_next_instance (
    ThroughputModule128K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule128K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule128K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_return_loan (
    ThroughputModule128K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReader_get_key_value (
    ThroughputModule128K_DataTypeDataReader _this,
    ThroughputModule128K_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule128K_DataTypeDataReader_lookup_instance (
    ThroughputModule128K_DataTypeDataReader _this,
    const ThroughputModule128K_DataType *key_holder
    );

#define ThroughputModule128K_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule128K_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule128K_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule128K_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule128K_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule128K_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule128K_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule128K_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule128K_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule128K_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_read (
    ThroughputModule128K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_take (
    ThroughputModule128K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_read_next_sample (
    ThroughputModule128K_DataTypeDataReaderView _this,
    ThroughputModule128K_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_take_next_sample (
    ThroughputModule128K_DataTypeDataReaderView _this,
    ThroughputModule128K_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_read_instance (
    ThroughputModule128K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_take_instance (
    ThroughputModule128K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_read_next_instance (
    ThroughputModule128K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_take_next_instance (
    ThroughputModule128K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_return_loan (
    ThroughputModule128K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_read_w_condition (
    ThroughputModule128K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_take_w_condition (
    ThroughputModule128K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule128K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule128K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule128K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule128K_DataTypeDataReaderView_get_key_value (
    ThroughputModule128K_DataTypeDataReaderView _this,
    ThroughputModule128K_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule128K_DataTypeDataReaderView_lookup_instance (
    ThroughputModule128K_DataTypeDataReaderView _this,
    ThroughputModule128K_DataType *key_holder
    );


#define ThroughputModule256K_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule256K_DataTypeTypeSupport
ThroughputModule256K_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeTypeSupport_register_type (
    ThroughputModule256K_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule256K_DataTypeTypeSupport_get_type_name (
    ThroughputModule256K_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule256K_DataType_defined
#define _DDS_sequence_ThroughputModule256K_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule256K_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule256K_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule256K_DataType *DDS_sequence_ThroughputModule256K_DataType__alloc (void);
DDSCOMU_API ThroughputModule256K_DataType *DDS_sequence_ThroughputModule256K_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule256K_DataType_defined */

#define ThroughputModule256K_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule256K_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule256K_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule256K_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule256K_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule256K_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule256K_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule256K_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule256K_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule256K_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule256K_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule256K_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule256K_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule256K_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule256K_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule256K_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule256K_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule256K_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule256K_DataTypeDataWriter_register_instance (
    ThroughputModule256K_DataTypeDataWriter _this,
    const ThroughputModule256K_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule256K_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule256K_DataTypeDataWriter _this,
    const ThroughputModule256K_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataWriter_unregister_instance (
    ThroughputModule256K_DataTypeDataWriter _this,
    const ThroughputModule256K_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule256K_DataTypeDataWriter _this,
    const ThroughputModule256K_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataWriter_write (
    ThroughputModule256K_DataTypeDataWriter _this,
    const ThroughputModule256K_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule256K_DataTypeDataWriter _this,
    const ThroughputModule256K_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataWriter_dispose (
    ThroughputModule256K_DataTypeDataWriter _this,
    const ThroughputModule256K_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule256K_DataTypeDataWriter _this,
    const ThroughputModule256K_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataWriter_writedispose (
    ThroughputModule256K_DataTypeDataWriter _this,
    const ThroughputModule256K_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule256K_DataTypeDataWriter _this,
    const ThroughputModule256K_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataWriter_get_key_value (
    ThroughputModule256K_DataTypeDataWriter _this,
    ThroughputModule256K_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule256K_DataTypeDataWriter_lookup_instance (
    ThroughputModule256K_DataTypeDataWriter _this,
    const ThroughputModule256K_DataType *key_holder
    );

#define ThroughputModule256K_DataTypeDataReader DDS_DataReader

#define ThroughputModule256K_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule256K_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule256K_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule256K_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule256K_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule256K_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule256K_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule256K_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule256K_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule256K_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule256K_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule256K_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule256K_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule256K_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule256K_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule256K_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule256K_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule256K_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule256K_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule256K_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule256K_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule256K_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule256K_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_read (
    ThroughputModule256K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_take (
    ThroughputModule256K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_read_w_condition (
    ThroughputModule256K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_take_w_condition (
    ThroughputModule256K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_read_next_sample (
    ThroughputModule256K_DataTypeDataReader _this,
    ThroughputModule256K_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_take_next_sample (
    ThroughputModule256K_DataTypeDataReader _this,
    ThroughputModule256K_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_read_instance (
    ThroughputModule256K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_take_instance (
    ThroughputModule256K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_read_next_instance (
    ThroughputModule256K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_take_next_instance (
    ThroughputModule256K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule256K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule256K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_return_loan (
    ThroughputModule256K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReader_get_key_value (
    ThroughputModule256K_DataTypeDataReader _this,
    ThroughputModule256K_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule256K_DataTypeDataReader_lookup_instance (
    ThroughputModule256K_DataTypeDataReader _this,
    const ThroughputModule256K_DataType *key_holder
    );

#define ThroughputModule256K_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule256K_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule256K_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule256K_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule256K_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule256K_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule256K_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule256K_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule256K_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule256K_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_read (
    ThroughputModule256K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_take (
    ThroughputModule256K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_read_next_sample (
    ThroughputModule256K_DataTypeDataReaderView _this,
    ThroughputModule256K_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_take_next_sample (
    ThroughputModule256K_DataTypeDataReaderView _this,
    ThroughputModule256K_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_read_instance (
    ThroughputModule256K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_take_instance (
    ThroughputModule256K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_read_next_instance (
    ThroughputModule256K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_take_next_instance (
    ThroughputModule256K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_return_loan (
    ThroughputModule256K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_read_w_condition (
    ThroughputModule256K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_take_w_condition (
    ThroughputModule256K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule256K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule256K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule256K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule256K_DataTypeDataReaderView_get_key_value (
    ThroughputModule256K_DataTypeDataReaderView _this,
    ThroughputModule256K_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule256K_DataTypeDataReaderView_lookup_instance (
    ThroughputModule256K_DataTypeDataReaderView _this,
    ThroughputModule256K_DataType *key_holder
    );


#define ThroughputModule512K_DataTypeTypeSupport DDS_TypeSupport

DDSCOMU_API ThroughputModule512K_DataTypeTypeSupport
ThroughputModule512K_DataTypeTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeTypeSupport_register_type (
    ThroughputModule512K_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
ThroughputModule512K_DataTypeTypeSupport_get_type_name (
    ThroughputModule512K_DataTypeTypeSupport _this
    );

#ifndef _DDS_sequence_ThroughputModule512K_DataType_defined
#define _DDS_sequence_ThroughputModule512K_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule512K_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule512K_DataType;

DDSCOMU_API DDS_sequence_ThroughputModule512K_DataType *DDS_sequence_ThroughputModule512K_DataType__alloc (void);
DDSCOMU_API ThroughputModule512K_DataType *DDS_sequence_ThroughputModule512K_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule512K_DataType_defined */

#define ThroughputModule512K_DataTypeDataWriter DDS_DataWriter

#define ThroughputModule512K_DataTypeDataWriter_enable DDS_Entity_enable

#define ThroughputModule512K_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule512K_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule512K_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule512K_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define ThroughputModule512K_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener

#define ThroughputModule512K_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define ThroughputModule512K_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define ThroughputModule512K_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define ThroughputModule512K_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define ThroughputModule512K_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define ThroughputModule512K_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define ThroughputModule512K_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher

#define ThroughputModule512K_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos

#define ThroughputModule512K_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic

#define ThroughputModule512K_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener

#define ThroughputModule512K_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule512K_DataTypeDataWriter_register_instance (
    ThroughputModule512K_DataTypeDataWriter _this,
    const ThroughputModule512K_DataType *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule512K_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule512K_DataTypeDataWriter _this,
    const ThroughputModule512K_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataWriter_unregister_instance (
    ThroughputModule512K_DataTypeDataWriter _this,
    const ThroughputModule512K_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule512K_DataTypeDataWriter _this,
    const ThroughputModule512K_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataWriter_write (
    ThroughputModule512K_DataTypeDataWriter _this,
    const ThroughputModule512K_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule512K_DataTypeDataWriter _this,
    const ThroughputModule512K_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataWriter_dispose (
    ThroughputModule512K_DataTypeDataWriter _this,
    const ThroughputModule512K_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule512K_DataTypeDataWriter _this,
    const ThroughputModule512K_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataWriter_writedispose (
    ThroughputModule512K_DataTypeDataWriter _this,
    const ThroughputModule512K_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule512K_DataTypeDataWriter _this,
    const ThroughputModule512K_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataWriter_get_key_value (
    ThroughputModule512K_DataTypeDataWriter _this,
    ThroughputModule512K_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule512K_DataTypeDataWriter_lookup_instance (
    ThroughputModule512K_DataTypeDataWriter _this,
    const ThroughputModule512K_DataType *key_holder
    );

#define ThroughputModule512K_DataTypeDataReader DDS_DataReader

#define ThroughputModule512K_DataTypeDataReader_enable DDS_Entity_enable

#define ThroughputModule512K_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes

#define ThroughputModule512K_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define ThroughputModule512K_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule512K_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition

#define ThroughputModule512K_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition

#define ThroughputModule512K_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define ThroughputModule512K_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define ThroughputModule512K_DataTypeDataReader_get_listener DDS_DataReader_get_listener

#define ThroughputModule512K_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define ThroughputModule512K_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define ThroughputModule512K_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define ThroughputModule512K_DataTypeDataReader_get_qos DDS_DataReader_get_qos

#define ThroughputModule512K_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule512K_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule512K_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule512K_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule512K_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule512K_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule512K_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule512K_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule512K_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule512K_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_read (
    ThroughputModule512K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_take (
    ThroughputModule512K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_read_w_condition (
    ThroughputModule512K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_take_w_condition (
    ThroughputModule512K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_read_next_sample (
    ThroughputModule512K_DataTypeDataReader _this,
    ThroughputModule512K_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_take_next_sample (
    ThroughputModule512K_DataTypeDataReader _this,
    ThroughputModule512K_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_read_instance (
    ThroughputModule512K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_take_instance (
    ThroughputModule512K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_read_next_instance (
    ThroughputModule512K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_take_next_instance (
    ThroughputModule512K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule512K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule512K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_return_loan (
    ThroughputModule512K_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReader_get_key_value (
    ThroughputModule512K_DataTypeDataReader _this,
    ThroughputModule512K_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule512K_DataTypeDataReader_lookup_instance (
    ThroughputModule512K_DataTypeDataReader _this,
    const ThroughputModule512K_DataType *key_holder
    );

#define ThroughputModule512K_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule512K_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule512K_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule512K_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule512K_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule512K_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule512K_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule512K_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule512K_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule512K_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_read (
    ThroughputModule512K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_take (
    ThroughputModule512K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_read_next_sample (
    ThroughputModule512K_DataTypeDataReaderView _this,
    ThroughputModule512K_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_take_next_sample (
    ThroughputModule512K_DataTypeDataReaderView _this,
    ThroughputModule512K_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_read_instance (
    ThroughputModule512K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_take_instance (
    ThroughputModule512K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_read_next_instance (
    ThroughputModule512K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_take_next_instance (
    ThroughputModule512K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_return_loan (
    ThroughputModule512K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_read_w_condition (
    ThroughputModule512K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_take_w_condition (
    ThroughputModule512K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule512K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule512K_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule512K_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule512K_DataTypeDataReaderView_get_key_value (
    ThroughputModule512K_DataTypeDataReaderView _this,
    ThroughputModule512K_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule512K_DataTypeDataReaderView_lookup_instance (
    ThroughputModule512K_DataTypeDataReaderView _this,
    ThroughputModule512K_DataType *key_holder
    );


#define ThroughputModule1M_DataTypeTypeSupport DDS_TypeSupport
DDSCOMU_API ThroughputModule1M_DataTypeTypeSupport
ThroughputModule1M_DataTypeTypeSupport__alloc (
    void
    );
DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeTypeSupport_register_type (
    ThroughputModule1M_DataTypeTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );
DDSCOMU_API DDS_string
ThroughputModule1M_DataTypeTypeSupport_get_type_name (
    ThroughputModule1M_DataTypeTypeSupport _this
    );
#ifndef _DDS_sequence_ThroughputModule1M_DataType_defined
#define _DDS_sequence_ThroughputModule1M_DataType_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    ThroughputModule1M_DataType *_buffer;
    DDS_boolean _release;
} DDS_sequence_ThroughputModule1M_DataType;
DDSCOMU_API DDS_sequence_ThroughputModule1M_DataType *DDS_sequence_ThroughputModule1M_DataType__alloc (void);
DDSCOMU_API ThroughputModule1M_DataType *DDS_sequence_ThroughputModule1M_DataType_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_ThroughputModule1M_DataType_defined */
#define ThroughputModule1M_DataTypeDataWriter DDS_DataWriter
#define ThroughputModule1M_DataTypeDataWriter_enable DDS_Entity_enable
#define ThroughputModule1M_DataTypeDataWriter_get_status_changes DDS_Entity_get_status_changes
#define ThroughputModule1M_DataTypeDataWriter_get_statuscondition DDS_Entity_get_statuscondition
#define ThroughputModule1M_DataTypeDataWriter_get_instance_handle DDS_Entity_get_instance_handle
#define ThroughputModule1M_DataTypeDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness
#define ThroughputModule1M_DataTypeDataWriter_get_listener DDS_DataWriter_get_listener
#define ThroughputModule1M_DataTypeDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status
#define ThroughputModule1M_DataTypeDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data
#define ThroughputModule1M_DataTypeDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions
#define ThroughputModule1M_DataTypeDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status
#define ThroughputModule1M_DataTypeDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status
#define ThroughputModule1M_DataTypeDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status
#define ThroughputModule1M_DataTypeDataWriter_get_publisher DDS_DataWriter_get_publisher
#define ThroughputModule1M_DataTypeDataWriter_get_qos DDS_DataWriter_get_qos
#define ThroughputModule1M_DataTypeDataWriter_get_topic DDS_DataWriter_get_topic
#define ThroughputModule1M_DataTypeDataWriter_set_listener DDS_DataWriter_set_listener
#define ThroughputModule1M_DataTypeDataWriter_set_qos DDS_DataWriter_set_qos
DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule1M_DataTypeDataWriter_register_instance (
    ThroughputModule1M_DataTypeDataWriter _this,
    const ThroughputModule1M_DataType *instance_data
    );
DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule1M_DataTypeDataWriter_register_instance_w_timestamp (
    ThroughputModule1M_DataTypeDataWriter _this,
    const ThroughputModule1M_DataType *instance_data,
    const DDS_Time_t *source_timestamp
    );
DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataWriter_unregister_instance (
    ThroughputModule1M_DataTypeDataWriter _this,
    const ThroughputModule1M_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );
DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataWriter_unregister_instance_w_timestamp (
    ThroughputModule1M_DataTypeDataWriter _this,
    const ThroughputModule1M_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );
DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataWriter_write (
    ThroughputModule1M_DataTypeDataWriter _this,
    const ThroughputModule1M_DataType *instance_data,
    const DDS_InstanceHandle_t handle
    );
DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataWriter_write_w_timestamp (
    ThroughputModule1M_DataTypeDataWriter _this,
    const ThroughputModule1M_DataType *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );
DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataWriter_dispose (
    ThroughputModule1M_DataTypeDataWriter _this,
    const ThroughputModule1M_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );
DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataWriter_dispose_w_timestamp (
    ThroughputModule1M_DataTypeDataWriter _this,
    const ThroughputModule1M_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );
DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataWriter_writedispose (
    ThroughputModule1M_DataTypeDataWriter _this,
    const ThroughputModule1M_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );
DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataWriter_writedispose_w_timestamp (
    ThroughputModule1M_DataTypeDataWriter _this,
    const ThroughputModule1M_DataType *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );
DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataWriter_get_key_value (
    ThroughputModule1M_DataTypeDataWriter _this,
    ThroughputModule1M_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );
DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule1M_DataTypeDataWriter_lookup_instance (
    ThroughputModule1M_DataTypeDataWriter _this,
    const ThroughputModule1M_DataType *key_holder
    );
#define ThroughputModule1M_DataTypeDataReader DDS_DataReader
#define ThroughputModule1M_DataTypeDataReader_enable DDS_Entity_enable
#define ThroughputModule1M_DataTypeDataReader_get_status_changes DDS_Entity_get_status_changes
#define ThroughputModule1M_DataTypeDataReader_get_statuscondition DDS_Entity_get_statuscondition
#define ThroughputModule1M_DataTypeDataReader_get_instance_handle DDS_Entity_get_instance_handle
#define ThroughputModule1M_DataTypeDataReader_create_querycondition DDS_DataReader_create_querycondition
#define ThroughputModule1M_DataTypeDataReader_create_readcondition DDS_DataReader_create_readcondition
#define ThroughputModule1M_DataTypeDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities
#define ThroughputModule1M_DataTypeDataReader_delete_readcondition DDS_DataReader_delete_readcondition
#define ThroughputModule1M_DataTypeDataReader_get_listener DDS_DataReader_get_listener
#define ThroughputModule1M_DataTypeDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status
#define ThroughputModule1M_DataTypeDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data
#define ThroughputModule1M_DataTypeDataReader_get_matched_publications DDS_DataReader_get_matched_publications
#define ThroughputModule1M_DataTypeDataReader_get_qos DDS_DataReader_get_qos
#define ThroughputModule1M_DataTypeDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define ThroughputModule1M_DataTypeDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define ThroughputModule1M_DataTypeDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define ThroughputModule1M_DataTypeDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define ThroughputModule1M_DataTypeDataReader_get_subscriber DDS_DataReader_get_subscriber

#define ThroughputModule1M_DataTypeDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define ThroughputModule1M_DataTypeDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define ThroughputModule1M_DataTypeDataReader_set_listener DDS_DataReader_set_listener

#define ThroughputModule1M_DataTypeDataReader_set_qos DDS_DataReader_set_qos

#define ThroughputModule1M_DataTypeDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_read (
    ThroughputModule1M_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_take (
    ThroughputModule1M_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_read_w_condition (
    ThroughputModule1M_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_take_w_condition (
    ThroughputModule1M_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_read_next_sample (
    ThroughputModule1M_DataTypeDataReader _this,
    ThroughputModule1M_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_take_next_sample (
    ThroughputModule1M_DataTypeDataReader _this,
    ThroughputModule1M_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_read_instance (
    ThroughputModule1M_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_take_instance (
    ThroughputModule1M_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_read_next_instance (
    ThroughputModule1M_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_take_next_instance (
    ThroughputModule1M_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_read_next_instance_w_condition (
    ThroughputModule1M_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_take_next_instance_w_condition (
    ThroughputModule1M_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_return_loan (
    ThroughputModule1M_DataTypeDataReader _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReader_get_key_value (
    ThroughputModule1M_DataTypeDataReader _this,
    ThroughputModule1M_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule1M_DataTypeDataReader_lookup_instance (
    ThroughputModule1M_DataTypeDataReader _this,
    const ThroughputModule1M_DataType *key_holder
    );

#define ThroughputModule1M_DataTypeDataReaderView DDS_DataReaderView

#define ThroughputModule1M_DataTypeDataReaderView_enable DDS_Entity_enable

#define ThroughputModule1M_DataTypeDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define ThroughputModule1M_DataTypeDataReaderView_get_qos DDS_DataReaderView_get_qos

#define ThroughputModule1M_DataTypeDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define ThroughputModule1M_DataTypeDataReaderView_set_qos DDS_DataReaderView_set_qos

#define ThroughputModule1M_DataTypeDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define ThroughputModule1M_DataTypeDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define ThroughputModule1M_DataTypeDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define ThroughputModule1M_DataTypeDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_read (
    ThroughputModule1M_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_take (
    ThroughputModule1M_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_read_next_sample (
    ThroughputModule1M_DataTypeDataReaderView _this,
    ThroughputModule1M_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_take_next_sample (
    ThroughputModule1M_DataTypeDataReaderView _this,
    ThroughputModule1M_DataType *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_read_instance (
    ThroughputModule1M_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_take_instance (
    ThroughputModule1M_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_read_next_instance (
    ThroughputModule1M_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_take_next_instance (
    ThroughputModule1M_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_return_loan (
    ThroughputModule1M_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_read_w_condition (
    ThroughputModule1M_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_take_w_condition (
    ThroughputModule1M_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_read_next_instance_w_condition (
    ThroughputModule1M_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_take_next_instance_w_condition (
    ThroughputModule1M_DataTypeDataReaderView _this,
    DDS_sequence_ThroughputModule1M_DataType *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
ThroughputModule1M_DataTypeDataReaderView_get_key_value (
    ThroughputModule1M_DataTypeDataReaderView _this,
    ThroughputModule1M_DataType *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
ThroughputModule1M_DataTypeDataReaderView_lookup_instance (
    ThroughputModule1M_DataTypeDataReaderView _this,
    ThroughputModule1M_DataType *key_holder
    );
#define LMWtopics_Req_PublishLogTypeSupport DDS_TypeSupport

DDSCOMU_API LMWtopics_Req_PublishLogTypeSupport
LMWtopics_Req_PublishLogTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogTypeSupport_register_type (
    LMWtopics_Req_PublishLogTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
LMWtopics_Req_PublishLogTypeSupport_get_type_name (
    LMWtopics_Req_PublishLogTypeSupport _this
    );

#ifndef _DDS_sequence_LMWtopics_Req_PublishLog_defined
#define _DDS_sequence_LMWtopics_Req_PublishLog_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    LMWtopics_Req_PublishLog *_buffer;
    DDS_boolean _release;
} DDS_sequence_LMWtopics_Req_PublishLog;

DDSCOMU_API DDS_sequence_LMWtopics_Req_PublishLog *DDS_sequence_LMWtopics_Req_PublishLog__alloc (void);
DDSCOMU_API LMWtopics_Req_PublishLog *DDS_sequence_LMWtopics_Req_PublishLog_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_LMWtopics_Req_PublishLog_defined */

#define LMWtopics_Req_PublishLogDataWriter DDS_DataWriter

#define LMWtopics_Req_PublishLogDataWriter_enable DDS_Entity_enable

#define LMWtopics_Req_PublishLogDataWriter_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_Req_PublishLogDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_Req_PublishLogDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_Req_PublishLogDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define LMWtopics_Req_PublishLogDataWriter_get_listener DDS_DataWriter_get_listener

#define LMWtopics_Req_PublishLogDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define LMWtopics_Req_PublishLogDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define LMWtopics_Req_PublishLogDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define LMWtopics_Req_PublishLogDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define LMWtopics_Req_PublishLogDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define LMWtopics_Req_PublishLogDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define LMWtopics_Req_PublishLogDataWriter_get_publisher DDS_DataWriter_get_publisher

#define LMWtopics_Req_PublishLogDataWriter_get_qos DDS_DataWriter_get_qos

#define LMWtopics_Req_PublishLogDataWriter_get_topic DDS_DataWriter_get_topic

#define LMWtopics_Req_PublishLogDataWriter_set_listener DDS_DataWriter_set_listener

#define LMWtopics_Req_PublishLogDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_Req_PublishLogDataWriter_register_instance (
    LMWtopics_Req_PublishLogDataWriter _this,
    const LMWtopics_Req_PublishLog *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_Req_PublishLogDataWriter_register_instance_w_timestamp (
    LMWtopics_Req_PublishLogDataWriter _this,
    const LMWtopics_Req_PublishLog *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataWriter_unregister_instance (
    LMWtopics_Req_PublishLogDataWriter _this,
    const LMWtopics_Req_PublishLog *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataWriter_unregister_instance_w_timestamp (
    LMWtopics_Req_PublishLogDataWriter _this,
    const LMWtopics_Req_PublishLog *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataWriter_write (
    LMWtopics_Req_PublishLogDataWriter _this,
    const LMWtopics_Req_PublishLog *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataWriter_write_w_timestamp (
    LMWtopics_Req_PublishLogDataWriter _this,
    const LMWtopics_Req_PublishLog *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataWriter_dispose (
    LMWtopics_Req_PublishLogDataWriter _this,
    const LMWtopics_Req_PublishLog *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataWriter_dispose_w_timestamp (
    LMWtopics_Req_PublishLogDataWriter _this,
    const LMWtopics_Req_PublishLog *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataWriter_writedispose (
    LMWtopics_Req_PublishLogDataWriter _this,
    const LMWtopics_Req_PublishLog *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataWriter_writedispose_w_timestamp (
    LMWtopics_Req_PublishLogDataWriter _this,
    const LMWtopics_Req_PublishLog *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataWriter_get_key_value (
    LMWtopics_Req_PublishLogDataWriter _this,
    LMWtopics_Req_PublishLog *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_Req_PublishLogDataWriter_lookup_instance (
    LMWtopics_Req_PublishLogDataWriter _this,
    const LMWtopics_Req_PublishLog *key_holder
    );

#define LMWtopics_Req_PublishLogDataReader DDS_DataReader

#define LMWtopics_Req_PublishLogDataReader_enable DDS_Entity_enable

#define LMWtopics_Req_PublishLogDataReader_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_Req_PublishLogDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_Req_PublishLogDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_Req_PublishLogDataReader_create_querycondition DDS_DataReader_create_querycondition

#define LMWtopics_Req_PublishLogDataReader_create_readcondition DDS_DataReader_create_readcondition

#define LMWtopics_Req_PublishLogDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define LMWtopics_Req_PublishLogDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define LMWtopics_Req_PublishLogDataReader_get_listener DDS_DataReader_get_listener

#define LMWtopics_Req_PublishLogDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define LMWtopics_Req_PublishLogDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define LMWtopics_Req_PublishLogDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define LMWtopics_Req_PublishLogDataReader_get_qos DDS_DataReader_get_qos

#define LMWtopics_Req_PublishLogDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define LMWtopics_Req_PublishLogDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define LMWtopics_Req_PublishLogDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define LMWtopics_Req_PublishLogDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define LMWtopics_Req_PublishLogDataReader_get_subscriber DDS_DataReader_get_subscriber

#define LMWtopics_Req_PublishLogDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define LMWtopics_Req_PublishLogDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define LMWtopics_Req_PublishLogDataReader_set_listener DDS_DataReader_set_listener

#define LMWtopics_Req_PublishLogDataReader_set_qos DDS_DataReader_set_qos

#define LMWtopics_Req_PublishLogDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_read (
    LMWtopics_Req_PublishLogDataReader _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_take (
    LMWtopics_Req_PublishLogDataReader _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_read_w_condition (
    LMWtopics_Req_PublishLogDataReader _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_take_w_condition (
    LMWtopics_Req_PublishLogDataReader _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_read_next_sample (
    LMWtopics_Req_PublishLogDataReader _this,
    LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_take_next_sample (
    LMWtopics_Req_PublishLogDataReader _this,
    LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_read_instance (
    LMWtopics_Req_PublishLogDataReader _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_take_instance (
    LMWtopics_Req_PublishLogDataReader _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_read_next_instance (
    LMWtopics_Req_PublishLogDataReader _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_take_next_instance (
    LMWtopics_Req_PublishLogDataReader _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_read_next_instance_w_condition (
    LMWtopics_Req_PublishLogDataReader _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_take_next_instance_w_condition (
    LMWtopics_Req_PublishLogDataReader _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_return_loan (
    LMWtopics_Req_PublishLogDataReader _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReader_get_key_value (
    LMWtopics_Req_PublishLogDataReader _this,
    LMWtopics_Req_PublishLog *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_Req_PublishLogDataReader_lookup_instance (
    LMWtopics_Req_PublishLogDataReader _this,
    const LMWtopics_Req_PublishLog *key_holder
    );

#define LMWtopics_Req_PublishLogDataReaderView DDS_DataReaderView

#define LMWtopics_Req_PublishLogDataReaderView_enable DDS_Entity_enable

#define LMWtopics_Req_PublishLogDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_Req_PublishLogDataReaderView_get_qos DDS_DataReaderView_get_qos

#define LMWtopics_Req_PublishLogDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define LMWtopics_Req_PublishLogDataReaderView_set_qos DDS_DataReaderView_set_qos

#define LMWtopics_Req_PublishLogDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define LMWtopics_Req_PublishLogDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define LMWtopics_Req_PublishLogDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define LMWtopics_Req_PublishLogDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_read (
    LMWtopics_Req_PublishLogDataReaderView _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_take (
    LMWtopics_Req_PublishLogDataReaderView _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_read_next_sample (
    LMWtopics_Req_PublishLogDataReaderView _this,
    LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_take_next_sample (
    LMWtopics_Req_PublishLogDataReaderView _this,
    LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_read_instance (
    LMWtopics_Req_PublishLogDataReaderView _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_take_instance (
    LMWtopics_Req_PublishLogDataReaderView _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_read_next_instance (
    LMWtopics_Req_PublishLogDataReaderView _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_take_next_instance (
    LMWtopics_Req_PublishLogDataReaderView _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_return_loan (
    LMWtopics_Req_PublishLogDataReaderView _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_read_w_condition (
    LMWtopics_Req_PublishLogDataReaderView _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_take_w_condition (
    LMWtopics_Req_PublishLogDataReaderView _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_read_next_instance_w_condition (
    LMWtopics_Req_PublishLogDataReaderView _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_take_next_instance_w_condition (
    LMWtopics_Req_PublishLogDataReaderView _this,
    DDS_sequence_LMWtopics_Req_PublishLog *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_Req_PublishLogDataReaderView_get_key_value (
    LMWtopics_Req_PublishLogDataReaderView _this,
    LMWtopics_Req_PublishLog *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_Req_PublishLogDataReaderView_lookup_instance (
    LMWtopics_Req_PublishLogDataReaderView _this,
    LMWtopics_Req_PublishLog *key_holder
    );


#define LMWtopics_LogTypeSupport DDS_TypeSupport

DDSCOMU_API LMWtopics_LogTypeSupport
LMWtopics_LogTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogTypeSupport_register_type (
    LMWtopics_LogTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
LMWtopics_LogTypeSupport_get_type_name (
    LMWtopics_LogTypeSupport _this
    );

#ifndef _DDS_sequence_LMWtopics_Log_defined
#define _DDS_sequence_LMWtopics_Log_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    LMWtopics_Log *_buffer;
    DDS_boolean _release;
} DDS_sequence_LMWtopics_Log;

DDSCOMU_API DDS_sequence_LMWtopics_Log *DDS_sequence_LMWtopics_Log__alloc (void);
DDSCOMU_API LMWtopics_Log *DDS_sequence_LMWtopics_Log_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_LMWtopics_Log_defined */

#define LMWtopics_LogDataWriter DDS_DataWriter

#define LMWtopics_LogDataWriter_enable DDS_Entity_enable

#define LMWtopics_LogDataWriter_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_LogDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_LogDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_LogDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define LMWtopics_LogDataWriter_get_listener DDS_DataWriter_get_listener

#define LMWtopics_LogDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define LMWtopics_LogDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define LMWtopics_LogDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define LMWtopics_LogDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define LMWtopics_LogDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define LMWtopics_LogDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define LMWtopics_LogDataWriter_get_publisher DDS_DataWriter_get_publisher

#define LMWtopics_LogDataWriter_get_qos DDS_DataWriter_get_qos

#define LMWtopics_LogDataWriter_get_topic DDS_DataWriter_get_topic

#define LMWtopics_LogDataWriter_set_listener DDS_DataWriter_set_listener

#define LMWtopics_LogDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_LogDataWriter_register_instance (
    LMWtopics_LogDataWriter _this,
    const LMWtopics_Log *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_LogDataWriter_register_instance_w_timestamp (
    LMWtopics_LogDataWriter _this,
    const LMWtopics_Log *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataWriter_unregister_instance (
    LMWtopics_LogDataWriter _this,
    const LMWtopics_Log *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataWriter_unregister_instance_w_timestamp (
    LMWtopics_LogDataWriter _this,
    const LMWtopics_Log *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataWriter_write (
    LMWtopics_LogDataWriter _this,
    const LMWtopics_Log *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataWriter_write_w_timestamp (
    LMWtopics_LogDataWriter _this,
    const LMWtopics_Log *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataWriter_dispose (
    LMWtopics_LogDataWriter _this,
    const LMWtopics_Log *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataWriter_dispose_w_timestamp (
    LMWtopics_LogDataWriter _this,
    const LMWtopics_Log *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataWriter_writedispose (
    LMWtopics_LogDataWriter _this,
    const LMWtopics_Log *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataWriter_writedispose_w_timestamp (
    LMWtopics_LogDataWriter _this,
    const LMWtopics_Log *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataWriter_get_key_value (
    LMWtopics_LogDataWriter _this,
    LMWtopics_Log *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_LogDataWriter_lookup_instance (
    LMWtopics_LogDataWriter _this,
    const LMWtopics_Log *key_holder
    );

#define LMWtopics_LogDataReader DDS_DataReader

#define LMWtopics_LogDataReader_enable DDS_Entity_enable

#define LMWtopics_LogDataReader_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_LogDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_LogDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_LogDataReader_create_querycondition DDS_DataReader_create_querycondition

#define LMWtopics_LogDataReader_create_readcondition DDS_DataReader_create_readcondition

#define LMWtopics_LogDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define LMWtopics_LogDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define LMWtopics_LogDataReader_get_listener DDS_DataReader_get_listener

#define LMWtopics_LogDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define LMWtopics_LogDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define LMWtopics_LogDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define LMWtopics_LogDataReader_get_qos DDS_DataReader_get_qos

#define LMWtopics_LogDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define LMWtopics_LogDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define LMWtopics_LogDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define LMWtopics_LogDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define LMWtopics_LogDataReader_get_subscriber DDS_DataReader_get_subscriber

#define LMWtopics_LogDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define LMWtopics_LogDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define LMWtopics_LogDataReader_set_listener DDS_DataReader_set_listener

#define LMWtopics_LogDataReader_set_qos DDS_DataReader_set_qos

#define LMWtopics_LogDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_read (
    LMWtopics_LogDataReader _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_take (
    LMWtopics_LogDataReader _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_read_w_condition (
    LMWtopics_LogDataReader _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_take_w_condition (
    LMWtopics_LogDataReader _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_read_next_sample (
    LMWtopics_LogDataReader _this,
    LMWtopics_Log *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_take_next_sample (
    LMWtopics_LogDataReader _this,
    LMWtopics_Log *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_read_instance (
    LMWtopics_LogDataReader _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_take_instance (
    LMWtopics_LogDataReader _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_read_next_instance (
    LMWtopics_LogDataReader _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_take_next_instance (
    LMWtopics_LogDataReader _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_read_next_instance_w_condition (
    LMWtopics_LogDataReader _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_take_next_instance_w_condition (
    LMWtopics_LogDataReader _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_return_loan (
    LMWtopics_LogDataReader _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReader_get_key_value (
    LMWtopics_LogDataReader _this,
    LMWtopics_Log *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_LogDataReader_lookup_instance (
    LMWtopics_LogDataReader _this,
    const LMWtopics_Log *key_holder
    );

#define LMWtopics_LogDataReaderView DDS_DataReaderView

#define LMWtopics_LogDataReaderView_enable DDS_Entity_enable

#define LMWtopics_LogDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_LogDataReaderView_get_qos DDS_DataReaderView_get_qos

#define LMWtopics_LogDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define LMWtopics_LogDataReaderView_set_qos DDS_DataReaderView_set_qos

#define LMWtopics_LogDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define LMWtopics_LogDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define LMWtopics_LogDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define LMWtopics_LogDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_read (
    LMWtopics_LogDataReaderView _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_take (
    LMWtopics_LogDataReaderView _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_read_next_sample (
    LMWtopics_LogDataReaderView _this,
    LMWtopics_Log *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_take_next_sample (
    LMWtopics_LogDataReaderView _this,
    LMWtopics_Log *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_read_instance (
    LMWtopics_LogDataReaderView _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_take_instance (
    LMWtopics_LogDataReaderView _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_read_next_instance (
    LMWtopics_LogDataReaderView _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_take_next_instance (
    LMWtopics_LogDataReaderView _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_return_loan (
    LMWtopics_LogDataReaderView _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_read_w_condition (
    LMWtopics_LogDataReaderView _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_take_w_condition (
    LMWtopics_LogDataReaderView _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_read_next_instance_w_condition (
    LMWtopics_LogDataReaderView _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_take_next_instance_w_condition (
    LMWtopics_LogDataReaderView _this,
    DDS_sequence_LMWtopics_Log *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_LogDataReaderView_get_key_value (
    LMWtopics_LogDataReaderView _this,
    LMWtopics_Log *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_LogDataReaderView_lookup_instance (
    LMWtopics_LogDataReaderView _this,
    LMWtopics_Log *key_holder
    );


#define LMWtopics_DeviceInfoTypeSupport DDS_TypeSupport

DDSCOMU_API LMWtopics_DeviceInfoTypeSupport
LMWtopics_DeviceInfoTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoTypeSupport_register_type (
    LMWtopics_DeviceInfoTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
LMWtopics_DeviceInfoTypeSupport_get_type_name (
    LMWtopics_DeviceInfoTypeSupport _this
    );

#ifndef _DDS_sequence_LMWtopics_DeviceInfo_defined
#define _DDS_sequence_LMWtopics_DeviceInfo_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    LMWtopics_DeviceInfo *_buffer;
    DDS_boolean _release;
} DDS_sequence_LMWtopics_DeviceInfo;

DDSCOMU_API DDS_sequence_LMWtopics_DeviceInfo *DDS_sequence_LMWtopics_DeviceInfo__alloc (void);
DDSCOMU_API LMWtopics_DeviceInfo *DDS_sequence_LMWtopics_DeviceInfo_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_LMWtopics_DeviceInfo_defined */

#define LMWtopics_DeviceInfoDataWriter DDS_DataWriter

#define LMWtopics_DeviceInfoDataWriter_enable DDS_Entity_enable

#define LMWtopics_DeviceInfoDataWriter_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_DeviceInfoDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_DeviceInfoDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_DeviceInfoDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define LMWtopics_DeviceInfoDataWriter_get_listener DDS_DataWriter_get_listener

#define LMWtopics_DeviceInfoDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define LMWtopics_DeviceInfoDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define LMWtopics_DeviceInfoDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define LMWtopics_DeviceInfoDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define LMWtopics_DeviceInfoDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define LMWtopics_DeviceInfoDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define LMWtopics_DeviceInfoDataWriter_get_publisher DDS_DataWriter_get_publisher

#define LMWtopics_DeviceInfoDataWriter_get_qos DDS_DataWriter_get_qos

#define LMWtopics_DeviceInfoDataWriter_get_topic DDS_DataWriter_get_topic

#define LMWtopics_DeviceInfoDataWriter_set_listener DDS_DataWriter_set_listener

#define LMWtopics_DeviceInfoDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_DeviceInfoDataWriter_register_instance (
    LMWtopics_DeviceInfoDataWriter _this,
    const LMWtopics_DeviceInfo *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_DeviceInfoDataWriter_register_instance_w_timestamp (
    LMWtopics_DeviceInfoDataWriter _this,
    const LMWtopics_DeviceInfo *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataWriter_unregister_instance (
    LMWtopics_DeviceInfoDataWriter _this,
    const LMWtopics_DeviceInfo *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataWriter_unregister_instance_w_timestamp (
    LMWtopics_DeviceInfoDataWriter _this,
    const LMWtopics_DeviceInfo *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataWriter_write (
    LMWtopics_DeviceInfoDataWriter _this,
    const LMWtopics_DeviceInfo *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataWriter_write_w_timestamp (
    LMWtopics_DeviceInfoDataWriter _this,
    const LMWtopics_DeviceInfo *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataWriter_dispose (
    LMWtopics_DeviceInfoDataWriter _this,
    const LMWtopics_DeviceInfo *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataWriter_dispose_w_timestamp (
    LMWtopics_DeviceInfoDataWriter _this,
    const LMWtopics_DeviceInfo *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataWriter_writedispose (
    LMWtopics_DeviceInfoDataWriter _this,
    const LMWtopics_DeviceInfo *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataWriter_writedispose_w_timestamp (
    LMWtopics_DeviceInfoDataWriter _this,
    const LMWtopics_DeviceInfo *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataWriter_get_key_value (
    LMWtopics_DeviceInfoDataWriter _this,
    LMWtopics_DeviceInfo *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_DeviceInfoDataWriter_lookup_instance (
    LMWtopics_DeviceInfoDataWriter _this,
    const LMWtopics_DeviceInfo *key_holder
    );

#define LMWtopics_DeviceInfoDataReader DDS_DataReader

#define LMWtopics_DeviceInfoDataReader_enable DDS_Entity_enable

#define LMWtopics_DeviceInfoDataReader_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_DeviceInfoDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_DeviceInfoDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_DeviceInfoDataReader_create_querycondition DDS_DataReader_create_querycondition

#define LMWtopics_DeviceInfoDataReader_create_readcondition DDS_DataReader_create_readcondition

#define LMWtopics_DeviceInfoDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define LMWtopics_DeviceInfoDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define LMWtopics_DeviceInfoDataReader_get_listener DDS_DataReader_get_listener

#define LMWtopics_DeviceInfoDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define LMWtopics_DeviceInfoDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define LMWtopics_DeviceInfoDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define LMWtopics_DeviceInfoDataReader_get_qos DDS_DataReader_get_qos

#define LMWtopics_DeviceInfoDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define LMWtopics_DeviceInfoDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define LMWtopics_DeviceInfoDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define LMWtopics_DeviceInfoDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define LMWtopics_DeviceInfoDataReader_get_subscriber DDS_DataReader_get_subscriber

#define LMWtopics_DeviceInfoDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define LMWtopics_DeviceInfoDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define LMWtopics_DeviceInfoDataReader_set_listener DDS_DataReader_set_listener

#define LMWtopics_DeviceInfoDataReader_set_qos DDS_DataReader_set_qos

#define LMWtopics_DeviceInfoDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_read (
    LMWtopics_DeviceInfoDataReader _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_take (
    LMWtopics_DeviceInfoDataReader _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_read_w_condition (
    LMWtopics_DeviceInfoDataReader _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_take_w_condition (
    LMWtopics_DeviceInfoDataReader _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_read_next_sample (
    LMWtopics_DeviceInfoDataReader _this,
    LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_take_next_sample (
    LMWtopics_DeviceInfoDataReader _this,
    LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_read_instance (
    LMWtopics_DeviceInfoDataReader _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_take_instance (
    LMWtopics_DeviceInfoDataReader _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_read_next_instance (
    LMWtopics_DeviceInfoDataReader _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_take_next_instance (
    LMWtopics_DeviceInfoDataReader _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_read_next_instance_w_condition (
    LMWtopics_DeviceInfoDataReader _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_take_next_instance_w_condition (
    LMWtopics_DeviceInfoDataReader _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_return_loan (
    LMWtopics_DeviceInfoDataReader _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReader_get_key_value (
    LMWtopics_DeviceInfoDataReader _this,
    LMWtopics_DeviceInfo *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_DeviceInfoDataReader_lookup_instance (
    LMWtopics_DeviceInfoDataReader _this,
    const LMWtopics_DeviceInfo *key_holder
    );

#define LMWtopics_DeviceInfoDataReaderView DDS_DataReaderView

#define LMWtopics_DeviceInfoDataReaderView_enable DDS_Entity_enable

#define LMWtopics_DeviceInfoDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_DeviceInfoDataReaderView_get_qos DDS_DataReaderView_get_qos

#define LMWtopics_DeviceInfoDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define LMWtopics_DeviceInfoDataReaderView_set_qos DDS_DataReaderView_set_qos

#define LMWtopics_DeviceInfoDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define LMWtopics_DeviceInfoDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define LMWtopics_DeviceInfoDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define LMWtopics_DeviceInfoDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_read (
    LMWtopics_DeviceInfoDataReaderView _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_take (
    LMWtopics_DeviceInfoDataReaderView _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_read_next_sample (
    LMWtopics_DeviceInfoDataReaderView _this,
    LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_take_next_sample (
    LMWtopics_DeviceInfoDataReaderView _this,
    LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_read_instance (
    LMWtopics_DeviceInfoDataReaderView _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_take_instance (
    LMWtopics_DeviceInfoDataReaderView _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_read_next_instance (
    LMWtopics_DeviceInfoDataReaderView _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_take_next_instance (
    LMWtopics_DeviceInfoDataReaderView _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_return_loan (
    LMWtopics_DeviceInfoDataReaderView _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_read_w_condition (
    LMWtopics_DeviceInfoDataReaderView _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_take_w_condition (
    LMWtopics_DeviceInfoDataReaderView _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_read_next_instance_w_condition (
    LMWtopics_DeviceInfoDataReaderView _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_take_next_instance_w_condition (
    LMWtopics_DeviceInfoDataReaderView _this,
    DDS_sequence_LMWtopics_DeviceInfo *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_DeviceInfoDataReaderView_get_key_value (
    LMWtopics_DeviceInfoDataReaderView _this,
    LMWtopics_DeviceInfo *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_DeviceInfoDataReaderView_lookup_instance (
    LMWtopics_DeviceInfoDataReaderView _this,
    LMWtopics_DeviceInfo *key_holder
    );


#define LMWtopics_QoSPolicyTypeSupport DDS_TypeSupport

DDSCOMU_API LMWtopics_QoSPolicyTypeSupport
LMWtopics_QoSPolicyTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyTypeSupport_register_type (
    LMWtopics_QoSPolicyTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
LMWtopics_QoSPolicyTypeSupport_get_type_name (
    LMWtopics_QoSPolicyTypeSupport _this
    );

#ifndef _DDS_sequence_LMWtopics_QoSPolicy_defined
#define _DDS_sequence_LMWtopics_QoSPolicy_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    LMWtopics_QoSPolicy *_buffer;
    DDS_boolean _release;
} DDS_sequence_LMWtopics_QoSPolicy;

DDSCOMU_API DDS_sequence_LMWtopics_QoSPolicy *DDS_sequence_LMWtopics_QoSPolicy__alloc (void);
DDSCOMU_API LMWtopics_QoSPolicy *DDS_sequence_LMWtopics_QoSPolicy_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_LMWtopics_QoSPolicy_defined */

#define LMWtopics_QoSPolicyDataWriter DDS_DataWriter

#define LMWtopics_QoSPolicyDataWriter_enable DDS_Entity_enable

#define LMWtopics_QoSPolicyDataWriter_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_QoSPolicyDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_QoSPolicyDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_QoSPolicyDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define LMWtopics_QoSPolicyDataWriter_get_listener DDS_DataWriter_get_listener

#define LMWtopics_QoSPolicyDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define LMWtopics_QoSPolicyDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define LMWtopics_QoSPolicyDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define LMWtopics_QoSPolicyDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define LMWtopics_QoSPolicyDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define LMWtopics_QoSPolicyDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define LMWtopics_QoSPolicyDataWriter_get_publisher DDS_DataWriter_get_publisher

#define LMWtopics_QoSPolicyDataWriter_get_qos DDS_DataWriter_get_qos

#define LMWtopics_QoSPolicyDataWriter_get_topic DDS_DataWriter_get_topic

#define LMWtopics_QoSPolicyDataWriter_set_listener DDS_DataWriter_set_listener

#define LMWtopics_QoSPolicyDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_QoSPolicyDataWriter_register_instance (
    LMWtopics_QoSPolicyDataWriter _this,
    const LMWtopics_QoSPolicy *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_QoSPolicyDataWriter_register_instance_w_timestamp (
    LMWtopics_QoSPolicyDataWriter _this,
    const LMWtopics_QoSPolicy *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataWriter_unregister_instance (
    LMWtopics_QoSPolicyDataWriter _this,
    const LMWtopics_QoSPolicy *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataWriter_unregister_instance_w_timestamp (
    LMWtopics_QoSPolicyDataWriter _this,
    const LMWtopics_QoSPolicy *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataWriter_write (
    LMWtopics_QoSPolicyDataWriter _this,
    const LMWtopics_QoSPolicy *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataWriter_write_w_timestamp (
    LMWtopics_QoSPolicyDataWriter _this,
    const LMWtopics_QoSPolicy *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataWriter_dispose (
    LMWtopics_QoSPolicyDataWriter _this,
    const LMWtopics_QoSPolicy *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataWriter_dispose_w_timestamp (
    LMWtopics_QoSPolicyDataWriter _this,
    const LMWtopics_QoSPolicy *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataWriter_writedispose (
    LMWtopics_QoSPolicyDataWriter _this,
    const LMWtopics_QoSPolicy *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataWriter_writedispose_w_timestamp (
    LMWtopics_QoSPolicyDataWriter _this,
    const LMWtopics_QoSPolicy *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataWriter_get_key_value (
    LMWtopics_QoSPolicyDataWriter _this,
    LMWtopics_QoSPolicy *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_QoSPolicyDataWriter_lookup_instance (
    LMWtopics_QoSPolicyDataWriter _this,
    const LMWtopics_QoSPolicy *key_holder
    );

#define LMWtopics_QoSPolicyDataReader DDS_DataReader

#define LMWtopics_QoSPolicyDataReader_enable DDS_Entity_enable

#define LMWtopics_QoSPolicyDataReader_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_QoSPolicyDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_QoSPolicyDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_QoSPolicyDataReader_create_querycondition DDS_DataReader_create_querycondition

#define LMWtopics_QoSPolicyDataReader_create_readcondition DDS_DataReader_create_readcondition

#define LMWtopics_QoSPolicyDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define LMWtopics_QoSPolicyDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define LMWtopics_QoSPolicyDataReader_get_listener DDS_DataReader_get_listener

#define LMWtopics_QoSPolicyDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define LMWtopics_QoSPolicyDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define LMWtopics_QoSPolicyDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define LMWtopics_QoSPolicyDataReader_get_qos DDS_DataReader_get_qos

#define LMWtopics_QoSPolicyDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define LMWtopics_QoSPolicyDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define LMWtopics_QoSPolicyDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define LMWtopics_QoSPolicyDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define LMWtopics_QoSPolicyDataReader_get_subscriber DDS_DataReader_get_subscriber

#define LMWtopics_QoSPolicyDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define LMWtopics_QoSPolicyDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define LMWtopics_QoSPolicyDataReader_set_listener DDS_DataReader_set_listener

#define LMWtopics_QoSPolicyDataReader_set_qos DDS_DataReader_set_qos

#define LMWtopics_QoSPolicyDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_read (
    LMWtopics_QoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_take (
    LMWtopics_QoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_read_w_condition (
    LMWtopics_QoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_take_w_condition (
    LMWtopics_QoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_read_next_sample (
    LMWtopics_QoSPolicyDataReader _this,
    LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_take_next_sample (
    LMWtopics_QoSPolicyDataReader _this,
    LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_read_instance (
    LMWtopics_QoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_take_instance (
    LMWtopics_QoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_read_next_instance (
    LMWtopics_QoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_take_next_instance (
    LMWtopics_QoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_read_next_instance_w_condition (
    LMWtopics_QoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_take_next_instance_w_condition (
    LMWtopics_QoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_return_loan (
    LMWtopics_QoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReader_get_key_value (
    LMWtopics_QoSPolicyDataReader _this,
    LMWtopics_QoSPolicy *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_QoSPolicyDataReader_lookup_instance (
    LMWtopics_QoSPolicyDataReader _this,
    const LMWtopics_QoSPolicy *key_holder
    );

#define LMWtopics_QoSPolicyDataReaderView DDS_DataReaderView

#define LMWtopics_QoSPolicyDataReaderView_enable DDS_Entity_enable

#define LMWtopics_QoSPolicyDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_QoSPolicyDataReaderView_get_qos DDS_DataReaderView_get_qos

#define LMWtopics_QoSPolicyDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define LMWtopics_QoSPolicyDataReaderView_set_qos DDS_DataReaderView_set_qos

#define LMWtopics_QoSPolicyDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define LMWtopics_QoSPolicyDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define LMWtopics_QoSPolicyDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define LMWtopics_QoSPolicyDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_read (
    LMWtopics_QoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_take (
    LMWtopics_QoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_read_next_sample (
    LMWtopics_QoSPolicyDataReaderView _this,
    LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_take_next_sample (
    LMWtopics_QoSPolicyDataReaderView _this,
    LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_read_instance (
    LMWtopics_QoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_take_instance (
    LMWtopics_QoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_read_next_instance (
    LMWtopics_QoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_take_next_instance (
    LMWtopics_QoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_return_loan (
    LMWtopics_QoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_read_w_condition (
    LMWtopics_QoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_take_w_condition (
    LMWtopics_QoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_read_next_instance_w_condition (
    LMWtopics_QoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_take_next_instance_w_condition (
    LMWtopics_QoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_QoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_QoSPolicyDataReaderView_get_key_value (
    LMWtopics_QoSPolicyDataReaderView _this,
    LMWtopics_QoSPolicy *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_QoSPolicyDataReaderView_lookup_instance (
    LMWtopics_QoSPolicyDataReaderView _this,
    LMWtopics_QoSPolicy *key_holder
    );


#define LMWtopics_RequestSysCtrlTypeSupport DDS_TypeSupport

DDSCOMU_API LMWtopics_RequestSysCtrlTypeSupport
LMWtopics_RequestSysCtrlTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlTypeSupport_register_type (
    LMWtopics_RequestSysCtrlTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
LMWtopics_RequestSysCtrlTypeSupport_get_type_name (
    LMWtopics_RequestSysCtrlTypeSupport _this
    );

#ifndef _DDS_sequence_LMWtopics_RequestSysCtrl_defined
#define _DDS_sequence_LMWtopics_RequestSysCtrl_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    LMWtopics_RequestSysCtrl *_buffer;
    DDS_boolean _release;
} DDS_sequence_LMWtopics_RequestSysCtrl;

DDSCOMU_API DDS_sequence_LMWtopics_RequestSysCtrl *DDS_sequence_LMWtopics_RequestSysCtrl__alloc (void);
DDSCOMU_API LMWtopics_RequestSysCtrl *DDS_sequence_LMWtopics_RequestSysCtrl_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_LMWtopics_RequestSysCtrl_defined */

#define LMWtopics_RequestSysCtrlDataWriter DDS_DataWriter

#define LMWtopics_RequestSysCtrlDataWriter_enable DDS_Entity_enable

#define LMWtopics_RequestSysCtrlDataWriter_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_RequestSysCtrlDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_RequestSysCtrlDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_RequestSysCtrlDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define LMWtopics_RequestSysCtrlDataWriter_get_listener DDS_DataWriter_get_listener

#define LMWtopics_RequestSysCtrlDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define LMWtopics_RequestSysCtrlDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define LMWtopics_RequestSysCtrlDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define LMWtopics_RequestSysCtrlDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define LMWtopics_RequestSysCtrlDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define LMWtopics_RequestSysCtrlDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define LMWtopics_RequestSysCtrlDataWriter_get_publisher DDS_DataWriter_get_publisher

#define LMWtopics_RequestSysCtrlDataWriter_get_qos DDS_DataWriter_get_qos

#define LMWtopics_RequestSysCtrlDataWriter_get_topic DDS_DataWriter_get_topic

#define LMWtopics_RequestSysCtrlDataWriter_set_listener DDS_DataWriter_set_listener

#define LMWtopics_RequestSysCtrlDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_RequestSysCtrlDataWriter_register_instance (
    LMWtopics_RequestSysCtrlDataWriter _this,
    const LMWtopics_RequestSysCtrl *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_RequestSysCtrlDataWriter_register_instance_w_timestamp (
    LMWtopics_RequestSysCtrlDataWriter _this,
    const LMWtopics_RequestSysCtrl *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataWriter_unregister_instance (
    LMWtopics_RequestSysCtrlDataWriter _this,
    const LMWtopics_RequestSysCtrl *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataWriter_unregister_instance_w_timestamp (
    LMWtopics_RequestSysCtrlDataWriter _this,
    const LMWtopics_RequestSysCtrl *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataWriter_write (
    LMWtopics_RequestSysCtrlDataWriter _this,
    const LMWtopics_RequestSysCtrl *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataWriter_write_w_timestamp (
    LMWtopics_RequestSysCtrlDataWriter _this,
    const LMWtopics_RequestSysCtrl *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataWriter_dispose (
    LMWtopics_RequestSysCtrlDataWriter _this,
    const LMWtopics_RequestSysCtrl *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataWriter_dispose_w_timestamp (
    LMWtopics_RequestSysCtrlDataWriter _this,
    const LMWtopics_RequestSysCtrl *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataWriter_writedispose (
    LMWtopics_RequestSysCtrlDataWriter _this,
    const LMWtopics_RequestSysCtrl *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataWriter_writedispose_w_timestamp (
    LMWtopics_RequestSysCtrlDataWriter _this,
    const LMWtopics_RequestSysCtrl *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataWriter_get_key_value (
    LMWtopics_RequestSysCtrlDataWriter _this,
    LMWtopics_RequestSysCtrl *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_RequestSysCtrlDataWriter_lookup_instance (
    LMWtopics_RequestSysCtrlDataWriter _this,
    const LMWtopics_RequestSysCtrl *key_holder
    );

#define LMWtopics_RequestSysCtrlDataReader DDS_DataReader

#define LMWtopics_RequestSysCtrlDataReader_enable DDS_Entity_enable

#define LMWtopics_RequestSysCtrlDataReader_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_RequestSysCtrlDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_RequestSysCtrlDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_RequestSysCtrlDataReader_create_querycondition DDS_DataReader_create_querycondition

#define LMWtopics_RequestSysCtrlDataReader_create_readcondition DDS_DataReader_create_readcondition

#define LMWtopics_RequestSysCtrlDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define LMWtopics_RequestSysCtrlDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define LMWtopics_RequestSysCtrlDataReader_get_listener DDS_DataReader_get_listener

#define LMWtopics_RequestSysCtrlDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define LMWtopics_RequestSysCtrlDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define LMWtopics_RequestSysCtrlDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define LMWtopics_RequestSysCtrlDataReader_get_qos DDS_DataReader_get_qos

#define LMWtopics_RequestSysCtrlDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define LMWtopics_RequestSysCtrlDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define LMWtopics_RequestSysCtrlDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define LMWtopics_RequestSysCtrlDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define LMWtopics_RequestSysCtrlDataReader_get_subscriber DDS_DataReader_get_subscriber

#define LMWtopics_RequestSysCtrlDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define LMWtopics_RequestSysCtrlDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define LMWtopics_RequestSysCtrlDataReader_set_listener DDS_DataReader_set_listener

#define LMWtopics_RequestSysCtrlDataReader_set_qos DDS_DataReader_set_qos

#define LMWtopics_RequestSysCtrlDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_read (
    LMWtopics_RequestSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_take (
    LMWtopics_RequestSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_read_w_condition (
    LMWtopics_RequestSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_take_w_condition (
    LMWtopics_RequestSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_read_next_sample (
    LMWtopics_RequestSysCtrlDataReader _this,
    LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_take_next_sample (
    LMWtopics_RequestSysCtrlDataReader _this,
    LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_read_instance (
    LMWtopics_RequestSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_take_instance (
    LMWtopics_RequestSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_read_next_instance (
    LMWtopics_RequestSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_take_next_instance (
    LMWtopics_RequestSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_read_next_instance_w_condition (
    LMWtopics_RequestSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_take_next_instance_w_condition (
    LMWtopics_RequestSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_return_loan (
    LMWtopics_RequestSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReader_get_key_value (
    LMWtopics_RequestSysCtrlDataReader _this,
    LMWtopics_RequestSysCtrl *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_RequestSysCtrlDataReader_lookup_instance (
    LMWtopics_RequestSysCtrlDataReader _this,
    const LMWtopics_RequestSysCtrl *key_holder
    );

#define LMWtopics_RequestSysCtrlDataReaderView DDS_DataReaderView

#define LMWtopics_RequestSysCtrlDataReaderView_enable DDS_Entity_enable

#define LMWtopics_RequestSysCtrlDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_RequestSysCtrlDataReaderView_get_qos DDS_DataReaderView_get_qos

#define LMWtopics_RequestSysCtrlDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define LMWtopics_RequestSysCtrlDataReaderView_set_qos DDS_DataReaderView_set_qos

#define LMWtopics_RequestSysCtrlDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define LMWtopics_RequestSysCtrlDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define LMWtopics_RequestSysCtrlDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define LMWtopics_RequestSysCtrlDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_read (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_take (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_read_next_sample (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_take_next_sample (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_read_instance (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_take_instance (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_read_next_instance (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_take_next_instance (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_return_loan (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_read_w_condition (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_take_w_condition (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_read_next_instance_w_condition (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_take_next_instance_w_condition (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_RequestSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_RequestSysCtrlDataReaderView_get_key_value (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    LMWtopics_RequestSysCtrl *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_RequestSysCtrlDataReaderView_lookup_instance (
    LMWtopics_RequestSysCtrlDataReaderView _this,
    LMWtopics_RequestSysCtrl *key_holder
    );


#define LMWtopics_ResponseSysCtrlTypeSupport DDS_TypeSupport

DDSCOMU_API LMWtopics_ResponseSysCtrlTypeSupport
LMWtopics_ResponseSysCtrlTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlTypeSupport_register_type (
    LMWtopics_ResponseSysCtrlTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
LMWtopics_ResponseSysCtrlTypeSupport_get_type_name (
    LMWtopics_ResponseSysCtrlTypeSupport _this
    );

#ifndef _DDS_sequence_LMWtopics_ResponseSysCtrl_defined
#define _DDS_sequence_LMWtopics_ResponseSysCtrl_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    LMWtopics_ResponseSysCtrl *_buffer;
    DDS_boolean _release;
} DDS_sequence_LMWtopics_ResponseSysCtrl;

DDSCOMU_API DDS_sequence_LMWtopics_ResponseSysCtrl *DDS_sequence_LMWtopics_ResponseSysCtrl__alloc (void);
DDSCOMU_API LMWtopics_ResponseSysCtrl *DDS_sequence_LMWtopics_ResponseSysCtrl_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_LMWtopics_ResponseSysCtrl_defined */

#define LMWtopics_ResponseSysCtrlDataWriter DDS_DataWriter

#define LMWtopics_ResponseSysCtrlDataWriter_enable DDS_Entity_enable

#define LMWtopics_ResponseSysCtrlDataWriter_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_ResponseSysCtrlDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_ResponseSysCtrlDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_ResponseSysCtrlDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define LMWtopics_ResponseSysCtrlDataWriter_get_listener DDS_DataWriter_get_listener

#define LMWtopics_ResponseSysCtrlDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define LMWtopics_ResponseSysCtrlDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define LMWtopics_ResponseSysCtrlDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define LMWtopics_ResponseSysCtrlDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define LMWtopics_ResponseSysCtrlDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define LMWtopics_ResponseSysCtrlDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define LMWtopics_ResponseSysCtrlDataWriter_get_publisher DDS_DataWriter_get_publisher

#define LMWtopics_ResponseSysCtrlDataWriter_get_qos DDS_DataWriter_get_qos

#define LMWtopics_ResponseSysCtrlDataWriter_get_topic DDS_DataWriter_get_topic

#define LMWtopics_ResponseSysCtrlDataWriter_set_listener DDS_DataWriter_set_listener

#define LMWtopics_ResponseSysCtrlDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_ResponseSysCtrlDataWriter_register_instance (
    LMWtopics_ResponseSysCtrlDataWriter _this,
    const LMWtopics_ResponseSysCtrl *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_ResponseSysCtrlDataWriter_register_instance_w_timestamp (
    LMWtopics_ResponseSysCtrlDataWriter _this,
    const LMWtopics_ResponseSysCtrl *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataWriter_unregister_instance (
    LMWtopics_ResponseSysCtrlDataWriter _this,
    const LMWtopics_ResponseSysCtrl *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataWriter_unregister_instance_w_timestamp (
    LMWtopics_ResponseSysCtrlDataWriter _this,
    const LMWtopics_ResponseSysCtrl *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataWriter_write (
    LMWtopics_ResponseSysCtrlDataWriter _this,
    const LMWtopics_ResponseSysCtrl *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataWriter_write_w_timestamp (
    LMWtopics_ResponseSysCtrlDataWriter _this,
    const LMWtopics_ResponseSysCtrl *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataWriter_dispose (
    LMWtopics_ResponseSysCtrlDataWriter _this,
    const LMWtopics_ResponseSysCtrl *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataWriter_dispose_w_timestamp (
    LMWtopics_ResponseSysCtrlDataWriter _this,
    const LMWtopics_ResponseSysCtrl *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataWriter_writedispose (
    LMWtopics_ResponseSysCtrlDataWriter _this,
    const LMWtopics_ResponseSysCtrl *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataWriter_writedispose_w_timestamp (
    LMWtopics_ResponseSysCtrlDataWriter _this,
    const LMWtopics_ResponseSysCtrl *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataWriter_get_key_value (
    LMWtopics_ResponseSysCtrlDataWriter _this,
    LMWtopics_ResponseSysCtrl *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_ResponseSysCtrlDataWriter_lookup_instance (
    LMWtopics_ResponseSysCtrlDataWriter _this,
    const LMWtopics_ResponseSysCtrl *key_holder
    );

#define LMWtopics_ResponseSysCtrlDataReader DDS_DataReader

#define LMWtopics_ResponseSysCtrlDataReader_enable DDS_Entity_enable

#define LMWtopics_ResponseSysCtrlDataReader_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_ResponseSysCtrlDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_ResponseSysCtrlDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_ResponseSysCtrlDataReader_create_querycondition DDS_DataReader_create_querycondition

#define LMWtopics_ResponseSysCtrlDataReader_create_readcondition DDS_DataReader_create_readcondition

#define LMWtopics_ResponseSysCtrlDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define LMWtopics_ResponseSysCtrlDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define LMWtopics_ResponseSysCtrlDataReader_get_listener DDS_DataReader_get_listener

#define LMWtopics_ResponseSysCtrlDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define LMWtopics_ResponseSysCtrlDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define LMWtopics_ResponseSysCtrlDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define LMWtopics_ResponseSysCtrlDataReader_get_qos DDS_DataReader_get_qos

#define LMWtopics_ResponseSysCtrlDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define LMWtopics_ResponseSysCtrlDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define LMWtopics_ResponseSysCtrlDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define LMWtopics_ResponseSysCtrlDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define LMWtopics_ResponseSysCtrlDataReader_get_subscriber DDS_DataReader_get_subscriber

#define LMWtopics_ResponseSysCtrlDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define LMWtopics_ResponseSysCtrlDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define LMWtopics_ResponseSysCtrlDataReader_set_listener DDS_DataReader_set_listener

#define LMWtopics_ResponseSysCtrlDataReader_set_qos DDS_DataReader_set_qos

#define LMWtopics_ResponseSysCtrlDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_read (
    LMWtopics_ResponseSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_take (
    LMWtopics_ResponseSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_read_w_condition (
    LMWtopics_ResponseSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_take_w_condition (
    LMWtopics_ResponseSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_read_next_sample (
    LMWtopics_ResponseSysCtrlDataReader _this,
    LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_take_next_sample (
    LMWtopics_ResponseSysCtrlDataReader _this,
    LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_read_instance (
    LMWtopics_ResponseSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_take_instance (
    LMWtopics_ResponseSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_read_next_instance (
    LMWtopics_ResponseSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_take_next_instance (
    LMWtopics_ResponseSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_read_next_instance_w_condition (
    LMWtopics_ResponseSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_take_next_instance_w_condition (
    LMWtopics_ResponseSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_return_loan (
    LMWtopics_ResponseSysCtrlDataReader _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReader_get_key_value (
    LMWtopics_ResponseSysCtrlDataReader _this,
    LMWtopics_ResponseSysCtrl *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_ResponseSysCtrlDataReader_lookup_instance (
    LMWtopics_ResponseSysCtrlDataReader _this,
    const LMWtopics_ResponseSysCtrl *key_holder
    );

#define LMWtopics_ResponseSysCtrlDataReaderView DDS_DataReaderView

#define LMWtopics_ResponseSysCtrlDataReaderView_enable DDS_Entity_enable

#define LMWtopics_ResponseSysCtrlDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_ResponseSysCtrlDataReaderView_get_qos DDS_DataReaderView_get_qos

#define LMWtopics_ResponseSysCtrlDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define LMWtopics_ResponseSysCtrlDataReaderView_set_qos DDS_DataReaderView_set_qos

#define LMWtopics_ResponseSysCtrlDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define LMWtopics_ResponseSysCtrlDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define LMWtopics_ResponseSysCtrlDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define LMWtopics_ResponseSysCtrlDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_read (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_take (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_read_next_sample (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_take_next_sample (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_read_instance (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_take_instance (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_read_next_instance (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_take_next_instance (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_return_loan (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_read_w_condition (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_take_w_condition (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_read_next_instance_w_condition (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_take_next_instance_w_condition (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    DDS_sequence_LMWtopics_ResponseSysCtrl *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ResponseSysCtrlDataReaderView_get_key_value (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    LMWtopics_ResponseSysCtrl *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_ResponseSysCtrlDataReaderView_lookup_instance (
    LMWtopics_ResponseSysCtrlDataReaderView _this,
    LMWtopics_ResponseSysCtrl *key_holder
    );


#define LMWtopics_ExtendQoSPolicyTypeSupport DDS_TypeSupport

DDSCOMU_API LMWtopics_ExtendQoSPolicyTypeSupport
LMWtopics_ExtendQoSPolicyTypeSupport__alloc (
    void
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyTypeSupport_register_type (
    LMWtopics_ExtendQoSPolicyTypeSupport _this,
    const DDS_DomainParticipant domain,
    const DDS_string name
    );

DDSCOMU_API DDS_string
LMWtopics_ExtendQoSPolicyTypeSupport_get_type_name (
    LMWtopics_ExtendQoSPolicyTypeSupport _this
    );

#ifndef _DDS_sequence_LMWtopics_ExtendQoSPolicy_defined
#define _DDS_sequence_LMWtopics_ExtendQoSPolicy_defined
typedef struct {
    DDS_unsigned_long _maximum;
    DDS_unsigned_long _length;
    LMWtopics_ExtendQoSPolicy *_buffer;
    DDS_boolean _release;
} DDS_sequence_LMWtopics_ExtendQoSPolicy;

DDSCOMU_API DDS_sequence_LMWtopics_ExtendQoSPolicy *DDS_sequence_LMWtopics_ExtendQoSPolicy__alloc (void);
DDSCOMU_API LMWtopics_ExtendQoSPolicy *DDS_sequence_LMWtopics_ExtendQoSPolicy_allocbuf (DDS_unsigned_long len);
#endif /* _DDS_sequence_LMWtopics_ExtendQoSPolicy_defined */

#define LMWtopics_ExtendQoSPolicyDataWriter DDS_DataWriter

#define LMWtopics_ExtendQoSPolicyDataWriter_enable DDS_Entity_enable

#define LMWtopics_ExtendQoSPolicyDataWriter_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_ExtendQoSPolicyDataWriter_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_ExtendQoSPolicyDataWriter_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_ExtendQoSPolicyDataWriter_assert_liveliness DDS_DataWriter_assert_liveliness

#define LMWtopics_ExtendQoSPolicyDataWriter_get_listener DDS_DataWriter_get_listener

#define LMWtopics_ExtendQoSPolicyDataWriter_get_liveliness_lost_status DDS_DataWriter_get_liveliness_lost_status

#define LMWtopics_ExtendQoSPolicyDataWriter_get_matched_subscription_data DDS_DataWriter_get_matched_subscription_data

#define LMWtopics_ExtendQoSPolicyDataWriter_get_matched_subscriptions DDS_DataWriter_get_matched_subscriptions

#define LMWtopics_ExtendQoSPolicyDataWriter_get_offered_deadline_missed_status DDS_DataWriter_get_offered_deadline_missed_status

#define LMWtopics_ExtendQoSPolicyDataWriter_get_offered_incompatible_qos_status DDS_DataWriter_get_offered_incompatible_qos_status

#define LMWtopics_ExtendQoSPolicyDataWriter_get_publication_matched_status DDS_DataWriter_get_publication_matched_status

#define LMWtopics_ExtendQoSPolicyDataWriter_get_publisher DDS_DataWriter_get_publisher

#define LMWtopics_ExtendQoSPolicyDataWriter_get_qos DDS_DataWriter_get_qos

#define LMWtopics_ExtendQoSPolicyDataWriter_get_topic DDS_DataWriter_get_topic

#define LMWtopics_ExtendQoSPolicyDataWriter_set_listener DDS_DataWriter_set_listener

#define LMWtopics_ExtendQoSPolicyDataWriter_set_qos DDS_DataWriter_set_qos

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_ExtendQoSPolicyDataWriter_register_instance (
    LMWtopics_ExtendQoSPolicyDataWriter _this,
    const LMWtopics_ExtendQoSPolicy *instance_data
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_ExtendQoSPolicyDataWriter_register_instance_w_timestamp (
    LMWtopics_ExtendQoSPolicyDataWriter _this,
    const LMWtopics_ExtendQoSPolicy *instance_data,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataWriter_unregister_instance (
    LMWtopics_ExtendQoSPolicyDataWriter _this,
    const LMWtopics_ExtendQoSPolicy *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataWriter_unregister_instance_w_timestamp (
    LMWtopics_ExtendQoSPolicyDataWriter _this,
    const LMWtopics_ExtendQoSPolicy *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataWriter_write (
    LMWtopics_ExtendQoSPolicyDataWriter _this,
    const LMWtopics_ExtendQoSPolicy *instance_data,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataWriter_write_w_timestamp (
    LMWtopics_ExtendQoSPolicyDataWriter _this,
    const LMWtopics_ExtendQoSPolicy *instance_data,
    const DDS_InstanceHandle_t handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataWriter_dispose (
    LMWtopics_ExtendQoSPolicyDataWriter _this,
    const LMWtopics_ExtendQoSPolicy *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataWriter_dispose_w_timestamp (
    LMWtopics_ExtendQoSPolicyDataWriter _this,
    const LMWtopics_ExtendQoSPolicy *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataWriter_writedispose (
    LMWtopics_ExtendQoSPolicyDataWriter _this,
    const LMWtopics_ExtendQoSPolicy *instance_data,
    const DDS_InstanceHandle_t instance_handle
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataWriter_writedispose_w_timestamp (
    LMWtopics_ExtendQoSPolicyDataWriter _this,
    const LMWtopics_ExtendQoSPolicy *instance_data,
    const DDS_InstanceHandle_t instance_handle,
    const DDS_Time_t *source_timestamp
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataWriter_get_key_value (
    LMWtopics_ExtendQoSPolicyDataWriter _this,
    LMWtopics_ExtendQoSPolicy *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_ExtendQoSPolicyDataWriter_lookup_instance (
    LMWtopics_ExtendQoSPolicyDataWriter _this,
    const LMWtopics_ExtendQoSPolicy *key_holder
    );

#define LMWtopics_ExtendQoSPolicyDataReader DDS_DataReader

#define LMWtopics_ExtendQoSPolicyDataReader_enable DDS_Entity_enable

#define LMWtopics_ExtendQoSPolicyDataReader_get_status_changes DDS_Entity_get_status_changes

#define LMWtopics_ExtendQoSPolicyDataReader_get_statuscondition DDS_Entity_get_statuscondition

#define LMWtopics_ExtendQoSPolicyDataReader_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_ExtendQoSPolicyDataReader_create_querycondition DDS_DataReader_create_querycondition

#define LMWtopics_ExtendQoSPolicyDataReader_create_readcondition DDS_DataReader_create_readcondition

#define LMWtopics_ExtendQoSPolicyDataReader_delete_contained_entities DDS_DataReader_delete_contained_entities

#define LMWtopics_ExtendQoSPolicyDataReader_delete_readcondition DDS_DataReader_delete_readcondition

#define LMWtopics_ExtendQoSPolicyDataReader_get_listener DDS_DataReader_get_listener

#define LMWtopics_ExtendQoSPolicyDataReader_get_liveliness_changed_status DDS_DataReader_get_liveliness_changed_status

#define LMWtopics_ExtendQoSPolicyDataReader_get_matched_publication_data DDS_DataReader_get_matched_publication_data

#define LMWtopics_ExtendQoSPolicyDataReader_get_matched_publications DDS_DataReader_get_matched_publications

#define LMWtopics_ExtendQoSPolicyDataReader_get_qos DDS_DataReader_get_qos

#define LMWtopics_ExtendQoSPolicyDataReader_get_requested_deadline_missed_status DDS_DataReader_get_requested_deadline_missed_status

#define LMWtopics_ExtendQoSPolicyDataReader_get_requested_incompatible_qos_status DDS_DataReader_get_requested_incompatible_qos_status

#define LMWtopics_ExtendQoSPolicyDataReader_get_sample_lost_status DDS_DataReader_get_sample_lost_status

#define LMWtopics_ExtendQoSPolicyDataReader_get_sample_rejected_status DDS_DataReader_get_sample_rejected_status

#define LMWtopics_ExtendQoSPolicyDataReader_get_subscriber DDS_DataReader_get_subscriber

#define LMWtopics_ExtendQoSPolicyDataReader_get_subscription_matched_status DDS_DataReader_get_subscription_matched_status

#define LMWtopics_ExtendQoSPolicyDataReader_get_topicdescription DDS_DataReader_get_topicdescription

#define LMWtopics_ExtendQoSPolicyDataReader_set_listener DDS_DataReader_set_listener

#define LMWtopics_ExtendQoSPolicyDataReader_set_qos DDS_DataReader_set_qos

#define LMWtopics_ExtendQoSPolicyDataReader_wait_for_historical_data DDS_DataReader_wait_for_historical_data

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_read (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_take (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_read_w_condition (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_take_w_condition (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_read_next_sample (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_take_next_sample (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_read_instance (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_take_instance (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_read_next_instance (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_take_next_instance (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_read_next_instance_w_condition (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_take_next_instance_w_condition (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_return_loan (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReader_get_key_value (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    LMWtopics_ExtendQoSPolicy *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_ExtendQoSPolicyDataReader_lookup_instance (
    LMWtopics_ExtendQoSPolicyDataReader _this,
    const LMWtopics_ExtendQoSPolicy *key_holder
    );

#define LMWtopics_ExtendQoSPolicyDataReaderView DDS_DataReaderView

#define LMWtopics_ExtendQoSPolicyDataReaderView_enable DDS_Entity_enable

#define LMWtopics_ExtendQoSPolicyDataReaderView_get_instance_handle DDS_Entity_get_instance_handle

#define LMWtopics_ExtendQoSPolicyDataReaderView_get_qos DDS_DataReaderView_get_qos

#define LMWtopics_ExtendQoSPolicyDataReaderView_get_datareader DDS_DataReaderView_get_datareader

#define LMWtopics_ExtendQoSPolicyDataReaderView_set_qos DDS_DataReaderView_set_qos

#define LMWtopics_ExtendQoSPolicyDataReaderView_create_readcondition DDS_DataReaderView_create_readcondition

#define LMWtopics_ExtendQoSPolicyDataReaderView_create_querycondition DDS_DataReaderView_create_querycondition

#define LMWtopics_ExtendQoSPolicyDataReaderView_delete_readcondition DDS_DataReaderView_delete_readcondition

#define LMWtopics_ExtendQoSPolicyDataReaderView_delete_contained_entities DDS_DataReaderView_delete_contained_entities

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_read (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_take (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_read_next_sample (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_take_next_sample (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfo *sample_info
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_read_instance (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_take_instance (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_read_next_instance (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_take_next_instance (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_SampleStateMask sample_states,
    const DDS_ViewStateMask view_states,
    const DDS_InstanceStateMask instance_states
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_return_loan (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_read_w_condition (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_take_w_condition (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_read_next_instance_w_condition (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_take_next_instance_w_condition (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    DDS_sequence_LMWtopics_ExtendQoSPolicy *received_data,
    DDS_SampleInfoSeq *info_seq,
    const DDS_long max_samples,
    const DDS_InstanceHandle_t a_handle,
    const DDS_ReadCondition a_condition
    );

DDSCOMU_API DDS_ReturnCode_t
LMWtopics_ExtendQoSPolicyDataReaderView_get_key_value (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    LMWtopics_ExtendQoSPolicy *key_holder,
    const DDS_InstanceHandle_t handle
    );

DDSCOMU_API DDS_InstanceHandle_t
LMWtopics_ExtendQoSPolicyDataReaderView_lookup_instance (
    LMWtopics_ExtendQoSPolicyDataReaderView _this,
    LMWtopics_ExtendQoSPolicy *key_holder
    );

#endif
