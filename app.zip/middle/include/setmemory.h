/////////////////////////////////////////////////////////////////////////////
//
//	    Copyright (C) 2002
//				TEC CORPORATION,  ALL Rights Reserved
//				1-14-10 Uchikanda Chiyoda-ku Tokyo JAPAN
//
/////////////////////////////////////////////////////////////////////////////
//
//  MODULE NAME	:  setmemory.h
//  (FILE NAME)
//  PARAMETERS	:  NONE
//
//  DESCRIPTION	:  SetMemory���饹���󥿡��ե�����
//			/ Linux�� INI�ե����륢�������ؿ��ʥ��������ɥ饤�֥���
//
//  CREATE   ON :  V001.001				2002.06.27
//		   ITAGAKI YU-YA [TOSHIBA TEC]
//
//  MODIFIED ON :
//
/////////////////////////////////////////////////////////////////////////////

#ifndef __SETMEMORY_H__
#define __SETMEMORY_H__

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef BOOL
#define BOOL int
#endif

class SetMemory
{
public:
	SetMemory();
	SetMemory(short nDataType);
	~SetMemory();

	void Initialize();
	void *setmemorymalloc(long nMemSize);
	long setmemorymemcpy(const void *pSrc, long nCont);
	BOOL CopyObject(SetMemory &Obj);

	char *m_aMemData;
	short m_nDataType;
	long m_nMemSize;
};

#endif // __SETMEMORY_H__
