//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//      FILE            :   common_sem.h
//
//      DESCRIPTION     :   Header File for semaphore API declaration.
//
//		CREATE ON		: 	V001.000	Subham Das[TSIP]				2021.03.16
//
//		MODIFIED ON		:   V002.000	Yashas D G[TSIP]				2021.03.25(Windows Compatible)
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef _INCLUDE_COMMON_SEM_H_
#define _INCLUDE_COMMON_SEM_H_

#include <stdint.h>

#define PERM 0777

#ifdef _WIN32
#include "pch.h"
#include <handleapi.h>
#define MAX_PATH_BUFFER_SIZE   260
#define BUFFER_SIZE_1K		  1024	// For 1K buffers.
#endif

union semun{
	int val;
	struct semid_ds *buf;
	unsigned short *array;
	struct seminfo *_buf;
} arg;

/* Semaphore return status */
typedef enum
{
	FAILURE = -1,
	SEM_SUCCESS = 0, 				//Semaphore success
	SEM_NOT_SUCCESS, 				//Semaphore not success
	SEM_FTOK_ERROR, 				//Semaphore key generation error
	SEM_GET_ERROR, 					//semaphore get error
	SEM_CTL_ERROR, 					//semaphore ctl error
	SEM_LOCK_ERROR, 				//semaphore lock error
	SEM_UNLOCK_ERROR, 				//semaphore unlock error
}semSts_t;

#define SEM_LOCK 0
#define SEM_UNLOCK 1

#ifdef _WIN32
// Function to initialize the semaphore.
semSts_t semInit(const char* keyFilePath, HANDLE* semId);

// Function to lock the semaphore.
semSts_t semLock(HANDLE semId);

// Function to unlock the semaphore.
semSts_t semUnlock(HANDLE semId);

// Function to clear/remove the semaphore.
semSts_t semClear(HANDLE semId);

#else
/*!This function is used to Initialise the semaphore*/
semSts_t semInit(const char *keyFilePath, int *semId);

/*!This function is used to lock the semaphore*/
semSts_t semLock(int semId);

/*!This function is used to unlock the semaphore*/
semSts_t semUnlock(int semId);

/*!This function is used to remove the semaphore*/
semSts_t semClear(int semId);
#endif // _WIN32

#endif /* _INCLUDE_COMMON_SEM_H_ */
