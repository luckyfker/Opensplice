//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		:	LocalLogEx2.cpp
//
//		DESCRIPTION :	Local log out library
//
//		CREATE ON	: 	V001.000 			Surendra.s 		11-27-2019		#0
//
//		MODIFIED ON	:   02-29-2020
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef VNCLOGGING
#define VNCLOGGING

/*#define	__DEBUGPRINT__*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#ifndef WIN32
#include <unistd.h>
#include "SV_SEM.h"
#endif

#define		REC_SIZE		(1024)
#define		MAX_REC_SIZE	(1024)
#define		FIRST_REC_SIZE	(20)
#define     REC_POS          (9)
#define		LOCAL_LOG_WAIT_MUTEX	2*1000\

/*data type define*/
#define	LPSTR	char*
#define LPCTSTR	char*
#define	HANDLE	void*
#define TCHAR   char
#define DWORD   unsigned long
#define ULONG   unsigned long
#define UINT    unsigned int

#define	LOGMUTEX_MODE_FLOCK		        (0)
#define	LOGMUTEX_MODE_SEMA		        (1)

#define DEFAULT_LOGLEVEL                (2)
#define MAX_LOGLEVEL                    (6)
#define MIN_LOGLEVEL                    (1)
#define DEFAULT_MAXFILESIZE             (2097152)//=(1024*1024*2) (2 MB)
#define DEFAULT_MAXRECORDCOUNT          (10000)
#define DEFAULT_OUTPUTMODE              (0)     /*CYCLIC*/
#define DEFAULT_RINGBUFOUTPUTINTERVAL   (5)
#define DEFAULT_SET_MAXFILESIZE         (10485760)//=(1024*1024*10) (10 MB)

#ifndef WIN32
#define LOGROTATECONF_FILENAME "/etc/logrotate.d/LocalLogOut"
#endif

typedef void      *DDS_Sample;
typedef int (*SerializeSample)(char *, char *, DDS_Sample, char *, long *);
typedef int (*SerializeSequence)(char *, char *, DDS_Sample *, int, char *, long *);

struct ringBufferSettings_t
{
    char *RingBuffer;
    short OutputInterval;
    short IntervalCounter;
    long TotalSize;
    long UsedSize;
    int recCount;
};

#ifndef WIN32
struct logRotateSettings_t
{
    short logrotate_interval;
    short logrotate_count;
    short logrotate_size;
    bool logrotate_missingok;
    bool logrotate_create;
    bool logrotate_nocompress;
    const char* logrotate_postRotateScript;
};
#endif

class LogEx2
{
public:
    /*Logging mode flags:*/
    static const int ToDebug;
    static const int ToFile;
    static const int ToConsole;

     /*Create a new log object.
     Parameters as follows:
        mode     - specifies where output should go, using combination
                   of flags above.
        level    - the default level
        filename - if flag Log::ToFile is specified in the type,
                   a filename must be specified here.
        append   - if logging to a file, whether or not to append to any
                   existing log.
        LogEx(int mode = ToDebug, int level = 1, LPSTR filename = NULL);*/
	LogEx2(int, int, LPSTR);

    inline void Print(int level, LPSTR format, ...)
    {
        if (level > m_level)
        {
            return;
        }
        va_list ap;
        va_start(ap, format);
        va_end(ap);
    }
    
    /*Change the log level*/
    void SetLevel(int level);
    void SetLogMaxRecCount(long lCnt);


    /*Change or set the logging filename.  This enables ToFile mode if not already enabled.*/
    void SetFile(LPSTR filename);

    void InitialLogSync(void);
    void ReleaseLogSync(void);
    void WRITELOGex(bool bLineNo,short Level,LPCTSTR szBuffer);
    void WRITELOG(LPCTSTR szBuffer);
    void cyclicRotationOfLog(char *szRecord, FILE *fp, int CurrentRecordSize, long filePositionToWrite);
    char* GetFileName(void);
    void SetLogFileMaxSize(long lSize);
    
#ifndef WIN32
	/*Change the logging mode*/
	void SetMode(int mode);
	void SetLogOutputMode(short Mode);
	void SetLogRotateSettings(short interval, short rotate_count, bool missingok, bool create, bool nocompress, char *postrotate, long size);
#endif
    void SetLogRingBuffer(const char *lpszFileName, char *RingbuffAddr, long size);
    void SetLogRingBufferInterval(short interval);
    void OutputLogRingBuff();
    void PeroidicOutRingbufferData();
	virtual ~LogEx2();

    void findOldRecordAndDelete(FILE* fp, int CurrentRecordSize, char *TempRecordToBeDeleted, int *RecordLenToBeDeleted);
    void writeLogIntoRingBuffer(char *szRecord, int CurrentRecordSize);
    void writelogIntoFileOrRingBuffer(char *szRecord, FILE* fp, long CurrentFileSize, int CurrentRecordSize, long filePositionToWrite);
    void openFile(FILE** fp);
    void addMessageToLogFormat(bool bLineNo, char *timestamp, char *debuginfo, char *szRecord, long *CurrentRecordSize);
    void WriteDDSPubLog(char *topicName, char *typeName, SerializeSample serializer, DDS_Sample *sample);
    void WriteDDSSubLog(char *topicName, char *typeName, SerializeSequence serializer, DDS_Sample *sample, int index);

protected:
#ifndef WIN32
	SysVSemaphore* m_cMtx;
#else
	HANDLE m_cMtx;
#endif


private:
    void	WriteLog(bool bLineNo,char* szMemo);
	short	SetLogFileName(LPCTSTR lpszFileName);

	bool m_tofile, m_todebug, m_toconsole;
	int m_level;
	LPSTR m_filename;
	bool m_append;    

	long m_lMaxRecCnt;
    long m_lMaxFileSize;    /*Max size of file*/
#ifndef WIN32
    short m_LogOutputMode;  /*Log output mode 0-Cyclic, 1-Rotation*/
#endif
    long m_SeekCyclicPosition;	/*File Position*/
    struct ringBufferSettings_t m_ringBufSettings; /*Ring buffer settings*/
    
#ifndef WIN32
	struct logRotateSettings_t m_logrotateSettings;	/*Rotation settings*/
#endif

	short	m_Init_Flg;
	char	m_logfilepath[MAX_PATH+1];
	long	m_lrcnt;

};

#endif // VNCLOGGING

