//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		:	local_log_out_with_dds.h
//
//		DESCRIPTION :	local log out with DDS library 
//
//		CREATE ON	: 	V001.000 			Surendra 		27-11-2019		#0
//
//		MODIFIED ON	:
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __LOCAL_LOG_OUT_WITH_DDS_H__
#define __LOCAL_LOG_OUT_WITH_DDS_H__

#include <stdio.h>
#include <limits.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <stdbool.h>
#include <sys/types.h>
#include <time.h>

#include "macros.h"

//#pragma pack(1)

#define MAX_LINENUMBER      8
#define MAX_DATE            10
#define MAX_TIME            12
#define MAX_LOGLEVEL_LEN    2
#define MAX_LOGCODE         8
#define MAX_MESSAGE         256
#define MAX_RECSIZE        256
typedef struct logData
{
    int seqNumber;
    char lineNumber[MAX_LINENUMBER];
    char date[MAX_DATE];
    char time[MAX_TIME];
    char logLevel[MAX_LOGLEVEL_LEN];
    char logCode[MAX_LOGCODE];
    char message[MAX_MESSAGE];
}logData_t;

typedef struct parsedLogData
{
    int seqNumber;
    char *lineNumber;
    int   lenLineNum;
    char *date;
    int   lenDate;
    char *time;
    int   lenTime;
    char *logLevel;
    int   lenLogLevel;
    char *logCode;
    int   lenLogCode;
    char *message;
    int   lenMessage;
} parsedLogData_t;

typedef struct logFileHandler
{
    FILE *fp;
    int offsetLen;
    int isMatched;
    int debounceMatch;
    parsedLogData_t parsedLogObject;
}logFileHandler_t;


typedef enum LWDStatus
{
    LWDSuccess = 0,
    LWDInvalidParameter,
    LWDSetLogFileNameFailed,
    LWDSetParticipantFailed
}LWDStatus;

typedef struct logSettingsLWD {
    char  fileName[NAME_MAX];
    short fileID;
    short domainID;
    char  QoSFileName[NAME_MAX];
    unsigned long  writerID;
    char *ringBuffer;
    long ringBufferTotalSize;
}logSettingsLWD_t;
	
	
void free_localLogWithDDS();

/**************************************************************************************************************/
/*!
    @brief : This function is use to create a file for logging the data
	@param		: domainID - Domain ID for which this Log should be published in
	@param		: lpszFileName - File name appended with path of the file
	@param		: qosFileName - File which consists of the QoS parameters
	@param		: FileID - File ID should be stored into this variable
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus SetLogFileNameWithDDS( int domainID, const char *lpszFileName, const char *qosFileName, short *FileID);

/**************************************************************************************************************/
/*!
    @brief : The maximum file size of a log file is set up
	@param		: FileID - File ID to identify the file
	@param		: FileSize - This variable indicates the Max size of the file
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus SetLogMaxFileSizeWithDDS (short FileID , long FileSize );

/**************************************************************************************************************/
/*!
    @brief : The number of the maximum records of a log file is set up
	@param		: FileID - File ID to identify the file
	@param		: MaxFileRcCount - This variable will decide the max records count to be allowed for the file
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus SetLogMaxRecCountWithDDS (short FileID, long MaxFileRcCount);

/**************************************************************************************************************/
/*!
    @brief : A multithread exclusion function is initialized
	@param		: FileID - File ID to identify the file
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus InitialLogSyncWithDDS( short FileID );

/**************************************************************************************************************/
/*!
    @brief : A multithread exclusion function is ended
	@param		: FileID - File ID to identify the file
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus ReleaseLogSyncWithDDS( short FileID );

/**************************************************************************************************************/
/*!
    @brief : A log is written into a log file. The files are identified by FileID
	@param		: FileID - File ID to identify the file
	@param		: LogLevel - Log level
	@param		: lpszFormat - String buffer to handle the log strings
	@param		: ... - variable arguments		
	@retval		: Success or Fail	
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus WriteLogWithDDS( short FileID, short LogLevel, const char *lpszFormat, ...);

/**************************************************************************************************************/
/*!
    @brief : A log is written into a log file. The files is identified by FileID
	@param		: FileID - File ID to identify the file
	@param		: lineNum - This parameter indicates to the library to include a line number at the beginning of the log record
	@param		: LogLevel - Log level
	@param		: lpszFormat - String buffer to handle the log strings
	@param		: ... - variable arguments	
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus WriteLogExWtihDDS( short FileID, bool lineNum, short LogLevel, const char *lpszFormat, ...);

/**************************************************************************************************************/
/*!
    @brief : The log level allowed for a file is set using this function
	@param		: FileID - File ID to identify the file
	@param		: LogLevel - Log Level
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus SetLogLevelWithDDS ( short FileID, short LogLevel);

/**************************************************************************************************************/
/*!
    @brief : This function is used to set the Log file’s output mode to "Cyclic" or "rotation" 
	@param		: FileID - File ID to identify the file
	@param		: Mode - 0 - Cyclic, 1- Rotation
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus SetLogOutputModeWithDDS (short FileID, short Mode);

/**************************************************************************************************************/
/*!
    @brief : This function sets the Rotation setting parameters for a log file. 
	         It is applicable only if the Log file is enabled with Rotation mode
    @param		: FileID - File ID to identify the file
	@param		: interval - A log rotation interval is specified.
                             0 :daily
                             1 :Weekly
                             2 :Month
                             3 :Hourly
	@param		: rotate_count - Log rotation count (ex: 5. i.e. retains up to 5 compressed logs)
	@param		: missingok - Condition: If true, missing a log file is acceptable. If false, error will be thrown when a log file is missing
	@param		: create - Condition: After performing log rotation, a new log file is created, if this parameter is true
	@param		: nocompress - Condition which says if compression for this file is required or not
	@param		: postrotate - The path to script which should be executed after rotation
	@param		: size - Size if exceeded, rotation should be performed. Parameter is in KB (ex: 100 means 100KB)
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus SetLogRotateSettingWithDDS (short FileID, short interval, short rotate_count, short missingok, short create, short nocompress, char *postrotate, short size);

/**************************************************************************************************************/
/*!
    @brief : A Ring buffer is created and a corresponding ID is generated
	@param		: lpszFileName - A ring buffer’s corresponding log file
	@param		: lpszRingBuff - Address of the ring buffer
	@param		: size - Size of the ring buffer is passed by caller
	@param		: domainID - Domain ID for which this Log should be published in
	@param		: qosFileName - File which consists of the QoS parameters
	@param		: FileID - File ID to be returned through this variable
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus SetLogRingBufferWithDDS(const char *lpszFileName, char *lpszRingBuff, long size, short domainID, char *qosFileName, short *FileID);

/**************************************************************************************************************/
/*!
    @brief : This function sets the interval at which the content of a Ring buffer is outputted to its corresponding log file
	@param		: FileID - File ID to identify the file
	@param		: interval - Time interval to be followed to write it to the file periodically. In seconds
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus SetLogRingBufferIntervalWithDDS (short FileID, unsigned short interval );

/**************************************************************************************************************/
/*!
    @brief : The data stored in the ring buffer is outputted to its corresponding log file
	@param		: FileID - File ID to identify the file
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus OutputLogRingBufferWithDDS (short FileID);

/**************************************************************************************************************/
/*!
    @brief : This function is used to publish the logs based on the range of dates (given as input)
    @param		: FileID - File ID to identify the file
	@param		: startDt - Starting date
	@param		: endDt - End date	
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus PublishLogFileDate(short FileID,char *startDate, char *endDate, logFileHandler_t *logFileHandler, logData_t *dataTakeAway);

/**************************************************************************************************************/
/*!
    @brief : This function is used to publish the logs based on the range of lines given as input
	@param		: FileID - File ID to identify the file
	@param		: Startlinno - Starting line number
	@param		: Endlinno - End line number
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus PublishLogFileLine(short FileID, char *startLine, char *endLine, logFileHandler_t *logFileHandler, logData_t *dataTakeAway);

/**************************************************************************************************************/
/*!
    @brief : This function is used to publish the logs of a ring buffer based on the range of dates given as input
	@param		: FileID - File ID to identify the file
	@param		: startDt - Starting date
	@param		: endDt - End date
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus PublishLogRingBufferDate (short FileID, char *startDate, char *endDate, logFileHandler_t *logFileHandler, logData_t *dataTakeAway);

/**************************************************************************************************************/
/*!
    @brief : This function is used to publish the logs based on the range of lines given as input
	@param		: FileID - File ID to identify the file
	@param		: Startlinno - Starting line number
	@param		: Endlinno - Last line number
	@retval		: Success or Fail
    @attention	: None
*/
/**************************************************************************************************************/
LWDStatus PublishLogRingBufferLine (short FileID, char *startLine, char *endLine, logFileHandler_t *logFileHandler, logData_t *dataTakeAway);

#endif
