//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		: Sf_Types.h
//
//		DESCRIPTION 	: Serial Flash library
//
//		CREATE ON	: V001.000 			Suresh B 		11-11-2019		#0
//
//		MODIFIED ON	: 21-11-2019
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __SFTYPES_H__
#define __SFTYPES_H__

typedef struct mtdInfoStruct {
	uint8_t type;		/* Type of Flash (MTD_ABSENT (0), MTD_RAM(1), MTD_ROM (2), MTD_NORFLASH(3), MTD_NANDFLASH(4),
				 * MTD_DATAFLASH(6), MTD_UBIVOLUME(7), MTD_MLCNANDFLASH(8) )
				 */
	uint32_t flags;         /* Some common devices / combinations of capabilities (MTD_CAP_ROM, MTD_CAP_RAM,
				 * MTD_CAP_NORFLASH, MTD_CAP_NANDFLASH, MTD_CAP_NVRAM) */
	uint32_t size;		/* Total size of the this memory*/
	uint32_t eraseSize;	/* Size in bytes of the "erase block" of this memory device - the smallest area which can be
				 * erased in a single erase command. */
	uint32_t writeSize;     /* The smallest area which can be write. */
}mtdInfo;

typedef enum {
	OPT_INFO,
	OPT_READ,
	OPT_WRITE,
	OPT_ERASE
} option;

typedef struct mtd_info_user sfMtdInfo;
typedef struct erase_info_user sfMtdEraseInfo;
#endif /* __SFTYPES_H__ */
