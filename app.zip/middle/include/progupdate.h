//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		:	progupdate.h
//
//		DESCRIPTION :	bau_library
//
//		CREATE ON	: 	V001.000 			Yashas DG 		11-11-2019		#0
//
//		MODIFIED ON	:
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//

#ifndef __LINUX_TECPROGUPDATE
#define __LINUX_TECPROGUPDATE

//Error No
#define		PROCUPDATE_ERROR_SUCCESS				(0)			//mn20031017-1	add
#define		PROCUPDATE_ERROR_PROGINF_NOTFOUND		(1000)
#define		PROCUPDATE_ERROR_PROGINF_NOTREAD		(1001)
#define		PROCUPDATE_ERROR_PROGINF_ILL			(1002)
#define		PROCUPDATE_ERROR_PROGTMP_NOTFOUND		(1003)
#define		PROCUPDATE_ERROR_PRECMD_ERR				(1004)
#define		PROCUPDATE_ERROR_POSTCMD_ERR			(1005)
#define		PROCUPDATE_ERROR_NEWFILE_UNZIP			(1006)
#define		PROCUPDATE_ERROR_OLDFILE_BACKUP			(1007)
#define		PROCUPDATE_ERROR_NEWFILE_RENAME			(1008)
#define		PROCUPDATE_ERROR_OLDTMPFILE_DELETEERR	(1009)
#define		PROCUPDATE_ERROR_NEWTMPFILE_DELETEERR	(1010)
#define		PROCUPDATE_ERROR_CONFFILE_RENAME		(1011)
#define		PROCUPDATE_ERROR_REBOOT					(1012)
#define		PROCUPDATE_ERROR_NOTUPDATEVERSION		(1013)
#define		PROCUPDATE_ERROR_ERRORCMD_ERR			(1014)
#define		PROCUPDATE_ERROR_INFPROC_SELECTERR		(1015)	// #2 Add
#define   PROCUPDATE_ERROR_PKGTYPE_GETERR         (1016)
#define   PROCUPDATE_ERROR_MACHINETYPEPATH_GETERR     (1017)
#define   PROCUPDATE_ERROR_MACHINETYPE_GETERR         (1018)
#define		PROCUPDATE_ERROR_MACHINETYPE_UNMATCH		(1019)
#define		PROCUPDATE_ERROR_FAIL					(9999)

//
#define		TEC_PROGUPDATE_RTRYMAX					(3)

#define		TECUPDATEPROC_LOGNAME		"updtproc.log"
#define		TECUPDATEPROC_INI			"proginf.ini"

#define		TECUPDATEPROCLOG_LINE		(1)		//�����Υ饤��ɽ����̵ͭ

#define		TECUPDATEPROCLOG_BASE		(1)		//������٥�	���ܾ���		//#101101-1	add
#define		TECUPDATEPROCLOG_ERROR		(2)		//������٥�	���顼��
#define		TECUPDATEPROCLOG_NORMAL		(4)		//������٥�	�Ρ��ޥ���

#define		TECUPDATEPROCLOG_STOPFILE	"/home/tec/Documents/update/progupdate.stop"

#define		PROGRESSBAR_VAL_START			(0)
#define		PROGRESSBAR_VAL_READINI			(10)
#define		PROGRESSBAR_VAL_CHECKEND		(20)
#define		PROGRESSBAR_VAL_ENDPRECOM		(40)
#define		PROGRESSBAR_VAL_ENDUPDATEFILE	(60)
#define		PROGRESSBAR_VAL_ENDPOSTCOM		(80)
#define		PROGRESSBAR_VAL_ENDRENAME		(90)
#define		PROGRESSBAR_VAL_ENDDELETE		(95)
#define		PROGRESSBAR_VAL_ENDALL			(100)

#define		TEC_PROGUPDATE_MSGCODE_NORMAL	(0)		//������
#define		TEC_PROGUPDATE_MSGCODE_ERREND	(1)		//��������

//mn20031017-1	add	start
//Err Level
#define		PUPDATE_ERRLVL_SUCCESS			(0)
#define		PUPDATE_ERRLVL_NOTTRGT			(1)
#define		PUPDATE_ERRLVL_RTRYSCCS			(2)
#define		PUPDATE_ERRLVL_ERRSCCS			(3)
#define		PUPDATE_ERRLVL_OLDVER			(4)
#define		PUPDATE_ERRLVL_FATALERR			(5)
//mn20031017-1	add	end

//#1 - add start
#define		PROGUPDATE_RC_FILE		//"/root/base/image/progupdate.rc"
//#1 - add end

#endif	//__LINUX_TECPROGUPDATE
