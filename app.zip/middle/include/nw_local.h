//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		: nw_local.h
//
//		DESCRIPTION     : nw utility settings library
//
//		CREATE ON	: V001.000 			Suresh B 		04-12-2019		#0
//
//		MODIFIED ON	: 04-12-2019
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __NW_LOCAL_H__
#define __NW_LOCAL_H__

//#include <sys/socket.h>

////////////////////////////////////////////////////////////////////////////////
//	Definition
////////////////////////////////////////////////////////////////////////////////

#define RUN_ON_TARGET
#define OPENSSL

#define NW_STATIC_ADDRESS       "10.113.131.100/24"
#define NW_STATIC_PLAIN_ADD		"10.113.131.100"
#define NW_STATIC_GATEWAY       "10.113.131.1"
#define NW_STATIC_NETMASK 		"255.255.255.0"

#define MAX_HOST_NAmE_LEN    		255          // Host names are limted to 255 bytes.
#define NW_BUFFSIZE_5120      		5120
#define NW_BUFFSIZE_1024     		1024
#define NW_BUFFSIZE_512      		512
#define NW_BUFFSIZE_256      		256
#define NW_BUFFSIZE_100      		100

#define NW_ETH0     			"eth0"
#define NW_ENS33    			"ens33"
#define NW_LO       			"lo"

#define NW_IPV4        			AF_INET
#define NW_IPV6        			AF_INET6

#define NW_DEVICE_UP   			0
#define NW_DEVICE_DOWN 			1

#define NW_CA           		1
#define NW_SELF_SIGNED  		2
#define NW_FTP_PORT_NUMBER 		21
#define NW_FTPS_PORT_NUMBER 		22

#define NW_INI_DEFAULT_INT          	999
#define NW_INI_DEFAULT_STRING       	"default_string"
#define NW_INI_FTP_CONFIG_FILENAME  	"ftp_config.ini"
#define NW_INI_HOST_NAME            	"HOST_NAME"
#define NW_INT_USER_NAME            	"USER_NAME"
#define NW_INI_PASSWORD             	"PASSWORD"
#define NW_INI_FTP_SETTINGS         	"ftpSettings"
#define NW_INI_FTP_CA_SELFSIGNED    	"CA_SELFSIGNED"
#define NW_INI_FTP_PORTNUMBER       	"PORT_NUMBER"

#define NW_CERT_FILE_NAME           	"cert.der"
#define NW_KEY_FILE_NAME            	"key.der"
#define NW_default_COUNTRY_NAME     	"IN"
#define NW_default_ORG_NAME         	"TSIP"
#define NW_DEFAULT_COMMON_NAME      	"LinuxMiddleware"

//#define DEBUG

#ifdef  DEBUG
#define DEBUG_PRINT    printf
#else
#define DEBUG_PRINT(x,...) ((void)0)
#endif

#endif /* __NW_UTILITY_SETTINGS_H__ */

