//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		: wdt.h
//
//		DESCRIPTION     : wdt library
//
//		CREATE ON	: V001.000 			Suresh B 		10-01-2020		#0
//
//		MODIFIED ON	: 28-01-2020
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __WDT_H__
#define __WDT_H__

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include "wdt_local.h"

#include <linux/limits.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#ifndef RUN_ON_HOST
#include <sys/ioctl.h>
#include <linux/types.h>
#include <linux/watchdog.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#else
//#include <unistd.h>
#include "../../prog_host/include/wdt_stub.h"
#endif

#include <signal.h>
#include "wdt_error.h"
#include "wdt_types.h"


/** wdtInit
 * @wdtPath: watchdog path (/dev/watchdog0)
 * @Wdt: WDT strcuture
 *
 * This function initialize the watchdog timer based on device id and its result will be stored at watchdog structure.
 */
int wdtInit (char *wdtPath, wdt *watchdog);

/** wdtSetTimeout
 * @Wdt: WDT strcuture
 * @timeout: Timeout value to WDT register (in secs).
 *
 * The function sets timeout to Respective WDT timer register.
 */
int wdtSetTimeout (wdt *watchdog, uint32_t timeout);

/** wdtGetTimeout
 * @Wdt: WDT strcuture
 * @timeout: Timeout value.
 *
 * Gets the timeout value configured for the WDT.
 */
int wdtGetTimeout (wdt *watchdog, uint32_t *timeout);

/** wdtStart
 * @Wdt: WDT strcuture
 *
 * The chosen WDT is started using exist configuration such as timeout, action. Hence, you will 
 * need to feed/kick (keep alive/ping) it all  the time or it will reset the system.
 */
int wdtStart (wdt *watchdog);

/** wdtStop
 * @Wdt: WDT strcuture
 *
 * The chosen WDT is stopped using this function.
 */
int wdtStop (wdt *watchdog);

/** wdtReload
 * @Wdt: WDT strcuture
 *
 * This is the routine that sends a keep alive ping to the watchdog timer hardware. This function 
 * simply reloads the WDT register, which in ticks the system watchdog timer to reset to internal
 * timer so it doesn’t trigger system reboot/interrupt.
 */
int wdtReload (wdt *watchdog);

/** wdtSetupHandler
 * @handler: Handler function
 *
 * This function sets up the interrupt system such that interrupts can occur for the device.
 */
int wdtSetupHandler (wdt *watchdog, void(*handler) ());

/** wdtEnableOutput
 * @Wdt: WDT strcuture
 *
 * This function enables the indicated signal. Valid signal is Reset and Interrupt. Only one of them can be specified at a time.
 */
int wdtEnableOutput (wdt *watchdog, int signal);

/** wdtDisableOutput
 * @Wdt: WDT strcuture
 *
 * This function disables the indicated signal If specified/availed before. Valid signal is Reset and Interrupt. Only one of them can be specified at a time.
 */
int wdtDisableOutput (wdt *watchdog);

/** wdtExit
 * @Wdt: WDT strcuture
 *
 * This function close watchdog.
 */
int wdtExit (wdt *watchdog);

/** sigEventHandler
 * @sig: The number of the signal that caused invocation of the handler.
 * @info: A pointer to a siginfo_t, which is a structure containing
 *        further information about the signal, as described below.
 * @unused: The structure pointed to by this field contains signal context
 *          information that was saved on the user-space stack by the kernel
 *
 * Library handler.
 */
void sigEventHandler(int sig, siginfo_t *info, void *unused);

/** startAppTimer
 * @pid: Application pid.
 * @timeout: Timeout value to timer (in secs).
 * @command: Application command for restart application.
 * @timerId: Timer ID.
 *
 * Starts a timer with the passed time. When timeout occurs, the parent process will be killed.
 */
int startAppTimer (pid_t  pid, uint32_t timeout, const char *command, timer_t  *timerId);

/** stopAppTimer
 * @timerId: Timer ID.
 *
 * Stops the respective timer.
 */
int stopAppTimer (timer_t timerId);

/** reloadAppTimer
 * @timerId: Timer ID.
 *
 * Reload the respective timer.
 */
int reloadAppTimer (timer_t timerId, uint32_t timeout);
#endif
