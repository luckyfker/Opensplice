//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		:	macros.h
//
//		DESCRIPTION :	sensor_management library
//
//		CREATE ON	: 	V001.000 			Nagul.S 		16-12-2019		#0
//
//		MODIFIED ON	:
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifndef __MACROS_H__
#define __MACROS_H__

#define SENSOR_API_FAILURE -1
#define SENSOR_API_SUCCESS 0
#define PS_INIT 1
#define PL_INIT 2

#define SENSOR_PL_INIT_ERROR 1003
#define SENSOR_PS_INIT_ERROR 1004
#define SENSOR_ARGUMENTS_NOT_IN_RANGE 1005
#define SENSOR_UPPER_LIMIT_CROSS 1001
#define SENSOR_LOWER_LIMIT_CROSS 1002
#define SENSOR_LIMIT_NORMAL 1000



typedef enum{
    PL_TEMP1 = 1,
    PL_TEMP2,
    PL_VCCINT,
    PL_VCCAUX,
    PL_VCCBRAM,
    PL_VCC_PSINTLP,
    PL_VCC_PSINTFP,
    PL_VCC_PSAUX,
    PS_TEMP,
    PS_VCCINT,
    PS_VCCAUX,
    PS_VCCBRAM,
    PS_VCC_PSINTLP,
    PS_VCC_PSINTFP,
    PS_VCC_PSAUX
}parms;

typedef struct readstruct
{
	uint32_t value;
	uint32_t status;
}readStruct;

typedef struct readVol
{
        float value;
        uint32_t status;
}voltage;

typedef struct writestruct
{
    uint32_t upper_range;
    uint32_t lower_range;
}writeStruct;

typedef struct thresholdStruct
{
	uint32_t value;
}Threshold;

typedef struct setthreshold
{
	uint32_t upper_range;
	uint32_t lower_range;
}setThreshold;

typedef struct statusStruct
{
        uint16_t PL_STATUS_value;
        uint16_t PS_STATUS_value;

}status;

uint8_t PS_INIT_FLAG,PL_INIT_FLAG;
uint16_t PS_STATUS_REG,PL_STATUS_REG;

/**************************************************************************************************************/

/*!
        @brief 		: This function initializes the selected sensor
        @param		: device - To select either the PS or PL block
        @param		: fileName - Filename for DDS
        @retval		: Success - returns 0 in case of success,
                      Failure - returns -1 in case of failure.
        @attention	:  None
*/

/**************************************************************************************************************/
int sensorInit(uint32_t device);

/**************************************************************************************************************/

/*!
        @brief 		: This function terminates or closes the selected sensor which was opened earlier
        @param		: device - To terminate either the PS or PL block
        @retval		: Success - returns 0 in case of success,
                      Failure - returns -1 in case of failure.
        @attention	:  None
*/

/**************************************************************************************************************/
int sensorTerminate(uint32_t device);

/**************************************************************************************************************/

/*!
        @brief 		: This function Reads the SYSMON registers
        @param		: register - Register address for the particular voltage/ temperature in PS and Pl block
        @param		: readstruct - Returns value and status either reached threshold
        @retval		: Success - returns 0 in case of success,
                      Failure - returns -1 in case of failure.
        @attention	:  None
*/

/**************************************************************************************************************/
int readRegister(uint32_t sysRegister, readStruct *);

/**************************************************************************************************************/

/*!
        @brief 		: Writes threshold data to any register of the SYSMON
        @param		: register - Register address for the particular voltage/ temperature in PS and Pl block
        @param		: writeStruct - Threshold value to be set
        @retval		: Success - returns 0 in case of success,
                      Failure - returns -1 in case of failure.
        @attention	:  None
*/

/**************************************************************************************************************/
int writeRegister(uint32_t sysRegister, writeStruct);

/**************************************************************************************************************/

/*!
        @brief 		: This function gets all the threshold values configured for the sensors
        @param		: register - Register address for the particular voltage/ temperature in PS and Pl block
        @param		: thresholdStruct - Threshold value which is set by the user
        @retval		: Success - returns 0 in case of success,
                      Failure - returns -1 in case of failure.
        @attention	:  None
*/

/**************************************************************************************************************/
int getThreshold(uint32_t sysRegister,setThreshold *);

/**************************************************************************************************************/

/*!
        @brief 		: This Function sets the upper and lower range of particular register block.
        @param		: register - Register address for the particular voltage/ temperature in PS and Pl block
        @param		: setThreshold - Upper and Lower range values to be configured
        @retval		: Success - returns 0 in case of success,
                      Failure - returns -1 in case of failure.
        @attention	:  None
*/

/**************************************************************************************************************/
int set_threshold(uint32_t sysRegister,setThreshold);

/**************************************************************************************************************/

/*!
        @brief 		: This function reads the status of the sensors.
        @param		: statusStruct - Gets the status of each block whether reached high or low.
        @retval		: Success - returns 0 in case of success,
                      Failure - returns -1 in case of failure.
        @attention	:  None
*/

/**************************************************************************************************************/
int getStatus(status *);

/**************************************************************************************************************/

/*!
        @brief 		: This function reads the particular voltage in PS and PL block.
        @param		: enum - To read each block voltage or temperature
        @param		: readstruct - Returns the value with the status reached high or low
        @retval		: Success - returns 0 in case of success,
                      Failure - returns -1 in case of failure.
        @attention	:  None
*/

/**************************************************************************************************************/
int read_voltage(parms , voltage *);

/**************************************************************************************************************/

/*!
        @brief 		: This function reads the particular temperature in PS and PL block.
        @param		: enum - To read each block voltage or temperature
        @param		: readstruct - Returns the value with the status reached high or low
        @retval		: Success - returns 0 in case of success,
                      Failure - returns -1 in case of failure.
        @attention	: None
*/

/**************************************************************************************************************/
int read_temperature(parms, voltage *);

char *convertToString(char *buf);

/************************************************************************************************************* */

/*!
        @brief      : This function is used to write into eeprom
        @param      : data      : data to write
        @param      : item      : item number to write
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/************************************************************************************************************* */
int writeTofile(long data,long item);

/************************************************************************************************************* */

/*!
        @brief      : This function is used to get the write count from the config file
        @param      : item_number : item-number to get the count
        @param      : write_count : write count of item number
        @retval     : EEPROM_API_SUCCESS - on success it will return 0
                      EEPROM_API_FAILURE - on failure it will return -1
        @attention  : None
  */

/************************************************************************************************************* */
int get_count(long item_number, long *write_count);

#endif
