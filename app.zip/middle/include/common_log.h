//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//      Copyright (C) 2019
//      TOSHIBA TEC CORPORATION, ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//      FILE            :   common_log.h
//
//      DESCRIPTION     :   This is use to print the log in the terminal.
//
//      CREATE ON       :  	V001.000	Subham Das[TSIP]				2021.03.16
//
//	    MODIFIED ON		:	V002.000	Yashas D G[TSIP]				2021.03.25(Windows Compatible)
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef COMMON_LOG_H 
#define COMMON_LOG_H

/// Application header files.
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>
#include <stddef.h>

#define LOG_FILE "sharedMemory.log"
#define LOG_ENABLE "sharedMemLogEnable.txt"
#ifndef _WIN32
void LOG_ERROR(const char* message, ...); 
void LOG_INFO(const char* message, ...);
void LOG_WARNING(const char* message, ...);
#else
// Max size for the log line.
#define MAX_LINE 1024
#define LOGGER_DEMARKER  "======================================================"

int DebugLog (const char *format, ...);
#endif

#endif //COMMON_LOG_H
