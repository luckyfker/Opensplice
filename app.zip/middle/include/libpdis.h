/*
* Date: 2003.06.19
* libpdis.h
* Purpose:	function prototype for libpdis.so

* Update :2005/12/26 mn20051226-1
		  NAGASAWA.M [CIERO]
		  USB�ǥХ����б�

*/

#ifndef _LIBPDIS_INCLUDE_
#define _LIBPDIS_INCLUDE_

// device ID (major and minor key value)
#define DEV_ID_PRINTER		0x0101
#define DEV_ID_PRINTER_USB	0x010E		//mn20051226-1	add
#define DEV_ID_SCANNER_HS 	0x0201
#define DEV_ID_SCANNER_LS 	0x0281
#define DEV_ID_DRAWER 		0x0401
#define DEV_ID_KB 			0x0501
#define DEV_ID_KB_USB		0x0502		//mn20051226-1	add
#define DEV_ID_KB_EXT 		0x0581
#define DEV_ID_KB_EXT_USB	0x0582		//mn20051226-1	add
#define DEV_ID_UPS 		0x0601
#define DEV_ID_LIU 		0x0701
#define DEV_ID_LIU_EXT 		0x0781
#define DEV_ID_CHANGED_TRAY_1	0x0801
#define DEV_ID_CHANGED_TRAY_2	0x0802
#define DEV_ID_TOUCH_P		0x0A01
#define DEV_ID_TOUCH_P_FJT	0x0A03		//mn20051226-1	add
#define DEV_ID_BACK_LIGHT 	0x0B01
#define DEV_ID_PINPAD 		0x0E01
#define DEV_ID_SCALE 		0x0F01

// num of fields for set and get
#define FIELD_NUM_SCANNER 		13
#define FIELD_NUM_UPS 		11
#define FIELD_NUM_DRAWER 		9
#define FIELD_NUM_KB 		10
#define FIELD_NUM_KB_EXT 		13
#define FIELD_NUM_BACK_LIGHT 	9
#define FIELD_NUM_PRINTER 		24
#define FIELD_NUM_LIU 		9
#define FIELD_NUM_CHANGED_TRAY 	14
#define FIELD_NUM_PINPAD 		10
#define FIELD_NUM_SCALE 		12
#define FIELD_NUM_TOUCH_P 		11
//mn20051226-1	add	start
#define FIELD_NUM_PRINTER_USB 	24
#define FIELD_NUM_KB_USB 		10
#define FIELD_NUM_KB_EXT_USB	13
#define FIELD_NUM_TOUCH_P_FJT	11
//mn20051226-1	add	end


// error code
#define ERROR_INIT		-10001
#define ERROR_FINAL		-10002
#define ERROR_PARA		-10000
#define ERROR_DEV_ACCESS	-10003

int initDeviceInfo();
int finalDeviceInfo();
int getDeviceInfo(int devid, int *num, unsigned int *info);
int setDeviceInfo(int devid, int num, unsigned int *info);

#endif
