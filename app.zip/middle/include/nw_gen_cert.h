//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		Copyright (C) 2019
//			TOSHIBA TEC CORPORATION,	ALL Rights Reserved
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//		FILE 		: nw_gen_cert.h
//
//		DESCRIPTION     : nw utility settings library
//
//		CREATE ON	: V001.000 			Suresh B 		04-12-2019		#0
//
//		MODIFIED ON	: 04-12-2019
//
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __NW_GEN_CERT_H__
#define __NW_GEN_CERT_H__

#include "nw_utility_settings.h"

#ifdef OPENSSL
#include <string.h>
#include <sys/unistd.h>

#include <openssl/pem.h>
#include <openssl/conf.h>
#include <openssl/x509v3.h>
#include <openssl/x509.h>
#include <openssl/rsa.h>
#include <openssl/err.h>

#ifndef OPENSSL_NO_ENGINE
#include <openssl/engine.h>
#endif

//#include "nw_utility_settings.h"

EVP_PKEY * generate_key();
int mkcert(X509 **x509p, EVP_PKEY **pkeyp, certConfig *config);
X509 * generate_x509(EVP_PKEY * pkey, certConfig *config);
int GetCerts(certConfig *config, const char *destCertPath, const char *destKeyPath);
#endif

#endif
