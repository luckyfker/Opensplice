#ifndef _WORKER_THREAD_H_
#define _WORKER_THREAD_H_

#include <mutex>
#include <thread>
#include <condition_variable>
#include <queue>
#include <atomic>
#include <memory>
#include <list>

class Job {
protected:
    virtual void run() {}

    friend class WorkerThread;
};

struct ThreadMsg;
class WorkerThread {
public:
    WorkerThread();

    void start();
    void join();
    void stop();
    void stopAndWait();

    // Submit one time job
    void submitJob(std::shared_ptr<Job> job);
    // Submit periodically job
    void submitPeriodicJob(std::shared_ptr<Job> job);
    // Un-submit a job
    void removePeriodicJob(std::shared_ptr<Job> job);
    void removePeriodicJob(const Job* job);

    bool isBusy();
    long long getLastProcessingTime();

private:
    std::unique_ptr<std::thread> m_thread;
    std::queue<std::shared_ptr<ThreadMsg>> m_queue;
    std::list<std::shared_ptr<Job>> m_jobList;
    std::shared_ptr<ThreadMsg> getMessage();

    std::mutex m_mutex;
    std::condition_variable m_cv;
    std::atomic<bool> m_timerExit;
    std::atomic<bool> m_busy;
    std::atomic<long long> m_lastProcessingTime; // microsecond

    void process();
    void timerThreadProc();
    void runJob(std::shared_ptr<Job> job);
};

#endif
