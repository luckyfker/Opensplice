#include "ephlib.h"

#ifdef WIN32
#include <Windows.h>
#endif

#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#ifndef WIN32
#include <unistd.h>
#endif

#ifdef WIN32
BOOL WINAPI consoleHandler(DWORD signal) {
  if (signal == CTRL_C_EVENT) {
    printf("Ctrl-C handled\n"); // do cleanup
    ShutdownAllJob();
  }

  return TRUE;
}
#else
void consoleHandler(int s) {
  printf("Ctrl-C handled\n", s);
  ShutdownAllJob();
  exit(1);
}
#endif

int main(int argc, char* argv[]) {
#ifdef WIN32
  if (!SetConsoleCtrlHandler(consoleHandler, TRUE)) {
    printf("\nERROR: Could not set control handler");
    return 1;
  }
#else
  struct sigaction sigIntHandler;

  sigIntHandler.sa_handler = consoleHandler;
  sigemptyset(&sigIntHandler.sa_mask);
  sigIntHandler.sa_flags = 0;

  sigaction(SIGINT, &sigIntHandler, NULL);
#endif

  // Start job
  CaptureImage("Test");
  // Sleep for Ctrl+C or thread exit
  WaitAllJob();
  ShutdownAllJob();
  return 0;
}
